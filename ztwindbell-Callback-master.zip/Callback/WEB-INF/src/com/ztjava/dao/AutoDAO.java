package com.ztjava.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.avaya.sce.runtimecommon.ITraceInfo;
import com.avaya.sce.runtimecommon.LoggerUtil;
import com.avaya.sce.runtimecommon.SCESession;
import com.ztjava.model.AutoResult;
import com.ztjava.model.CbData;
import com.ztjava.model.FixBill;
import com.ztjava.util.DbUtil;

public class AutoDAO {
	//新建回访记录
	public void insertResult(SCESession mySession,AutoResult autoResult){
		PreparedStatement ps=null;
		Connection con=null;
		try {
			con = DbUtil.getConnection();
			String sql = "insert into OPENEAP.CB_AUTO_RESULT (EDUID,VDN,PHONE,BILL_TYPE,BILL_ID,SERVICE_LOOKUP_CODE,START_TIME,DATA_ID) " +
					"values (?,?,?,?,?,?,?,?)";
			ps = con.prepareStatement(sql);	
			ps.setString(1,autoResult.getEduid());
			ps.setString(2,autoResult.getVdn());
			ps.setString(3,autoResult.getPhone());
			ps.setString(4,autoResult.getBill_type());
			ps.setInt(5,autoResult.getBill_id());
			ps.setString(6,autoResult.getService_lookup_code());
			ps.setString(7,autoResult.getStart_time());
			ps.setInt(8,autoResult.getData_id());
			ps.execute();
		    con.commit();
		}catch (Exception e) {
			LoggerUtil.writeTrace(mySession, ITraceInfo.TRACE_LEVEL_WARN,"insertResult error:"+e.getMessage());
			e.printStackTrace();
		}finally {
			try {
				if (ps != null){
					ps.close();
				}
				if(con!=null){
					con.close();
				}
			} catch (SQLException e) {
				LoggerUtil.writeTrace(mySession, ITraceInfo.TRACE_LEVEL_WARN,"PreparedStatement close error:"+e.getMessage());
				e.printStackTrace();
			}
		}
	}
	//结束回访
	public void overResult(SCESession mySession,AutoResult autoResult){
		PreparedStatement ps = null;
		Connection con = null;
		try {
			con = DbUtil.getConnection();
			String sql = "update OPENEAP.CB_AUTO_RESULT set END_TIME = ?,ANSWER=?,RESULT=?,MESSAGE=? where EDUID=?";
			ps = con.prepareStatement(sql);	
			ps.setString(1,autoResult.getEnd_time());
			ps.setString(2, autoResult.getAnswer());
			ps.setString(3, autoResult.getResult());
			ps.setString(4, autoResult.getMessage());
			ps.setString(5, autoResult.getEduid());
			ps.executeUpdate();
			con.commit();
			LoggerUtil.writeTrace(mySession, ITraceInfo.TRACE_LEVEL_INFO,"update OPENEAP.CB_AUTO_RESULT");
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (ps != null){		
					ps.close();
				}
				if(con!=null){
					con.close();
				}
			} catch (SQLException e) {
				LoggerUtil.writeTrace(mySession, ITraceInfo.TRACE_LEVEL_INFO,"PreparedStatement close error:"+e.getMessage());
				e.printStackTrace();
			}
		}
	}
	//获取工单导入记录
	public CbData getCbData(SCESession mySession,String phone,Integer project_id){
		PreparedStatement ps = null;
		Connection con = null;
	 	CbData cbData = new CbData();
		try {
			con = DbUtil.getConnection();
			String sql = "select addressline1,usercontactid,id from OPENEAP.CB_DATA where project_id=? and is_import='T' and PHONENUMBER1 like '%"+phone+"' order by ID desc fetch first 1 row only";
			ps = con.prepareStatement(sql);	
			ps.setInt(1,project_id);
		 	ResultSet rs = ps.executeQuery();
		 	while (rs.next()) {
		 		cbData.setAddressline1(rs.getString(1));
		 		cbData.setUsercontactId(rs.getInt(2));
		 		cbData.setId(rs.getInt(3));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (ps != null){		
					ps.close();
				}
				if(con!=null){
					con.close();
				}
			} catch (SQLException e) {
				LoggerUtil.writeTrace(mySession, ITraceInfo.TRACE_LEVEL_INFO,"PreparedStatement close error:"+e.getMessage());
				e.printStackTrace();
			}
		}	
		return cbData;
	}
	public FixBill getFixBill(SCESession mySession,Integer fix_id){
		PreparedStatement ps = null;
		Connection con = null;
		FixBill fixBill = new FixBill();
		try {
			con = DbUtil.getConnection();
			String sql = "select fix_id,service_lookup_code from ECC_SFM.FIX_AUTO_DOCUMENT_FLOWAXIS where FIX_ID=?";
			ps = con.prepareStatement(sql);	
			ps.setInt(1,fix_id);
		 	ResultSet rs = ps.executeQuery();
		 	while (rs.next()) {
		 		fixBill.setService_lookup_code(rs.getString(2));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (ps != null){		
					ps.close();
				}
				if(con!=null){
					con.close();
				}
			} catch (SQLException e) {
				LoggerUtil.writeTrace(mySession, ITraceInfo.TRACE_LEVEL_INFO,"PreparedStatement close error:"+e.getMessage());
				e.printStackTrace();
			}
		}	
		return fixBill;
	}
}
