package com.ztjava.model;

public class FixBill {
	public String getService_lookup_code() {
		return service_lookup_code;
	}
	public void setService_lookup_code(String service_lookup_code) {
		this.service_lookup_code = service_lookup_code;
	}
	public String service_lookup_code;
}
