package com.ztjava.model;

public class CbData {
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer id;
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddressline1() {
		return addressline1;
	}
	public void setAddressline1(String addressline1) {
		this.addressline1 = addressline1;
	}
	public Integer getUsercontactId() {
		return usercontactId;
	}
	public void setUsercontactId(Integer usercontactId) {
		this.usercontactId = usercontactId;
	}
	public String getIs_import() {
		return is_import;
	}
	public void setIs_import(String is_import) {
		this.is_import = is_import;
	}
	private Integer project_id;
	private String phone;
	private String addressline1;
	private Integer usercontactId;
	private String is_import;
}
