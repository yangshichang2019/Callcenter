package com.ztjava.util;

import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DbUtil {
	public static Connection getConnection() throws Exception{
		System.out.println("@@@source");
		Context initContext = new InitialContext();    
		  DataSource ds = (DataSource)initContext.lookup("java:comp/env/jdbc/pub");
		  Connection conn = ds.getConnection();   
		  System.out.println("@@@datasource");
		return conn;
	}
}
