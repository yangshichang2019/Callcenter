package com.konka.common.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.system.model.Remind;

public class BaseDAOImp implements BaseDAO {
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	private String mapper;
	//�����¼�¼
	public int insert(Object object) throws Exception {
		return this.getSqlSessionTemplate().insert(this.getMapper() + ".insert", object);
	}
	//���������¼
	public void insertBatch(List list) throws Exception{
		if(list.size()>300) {
			List tempList = new ArrayList();
			for(int i=0;i<list.size();i++) {
				tempList.add(list.get(i));
				Integer j = (i+1)%300;
				if(j==0) {
					insertBatch(tempList);
					tempList = new ArrayList();
				}
			}
			if(tempList.size()>0) {
				insertBatch(tempList);
			}
		} else {
			this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatch", list);
		}
	}
	//��������
	public void updateBatch(Object object) throws Exception {
		this.getSqlSessionTemplate().update(this.getMapper() + ".updateBatch", object);
	}
	//��ȡ��¼ͨ��ID
	public Object getById(Integer id) throws Exception {
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getById", id);
	}
	public Object getByObject(Object object) throws Exception{
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getByObject", object);
	}
	//���¼�¼
	public void update(Object object) throws Exception {
		this.getSqlSessionTemplate().update(this.getMapper() + ".update", object);
	}
	//ɾ����¼ͨ��ID
	public void delete(Integer id) throws Exception {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".delete", id);
	}
	public void deleteByObject(Object object) throws Exception{
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteByObject", object);
	}
	//��ȡȫ����¼
	public List getAllList(Object object) throws Exception {
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getAllList", object);
	}
	//��ȡ��ҳ��¼
	public List getObjectList(BaseVO baseVO,Page page) throws Exception {
		Util.setPageNum(baseVO, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList", baseVO);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
	//�ж��Ƿ����
	public boolean isExist(Object object) throws Exception {
		Object o = this.getSqlSessionTemplate().selectOne(this.getMapper()+".isExist", object);
		if(o!=null) {
			return true;
		}else {
			return false;
		}
	}
	//����ɾ��
	public void deleteBatch(BaseVO baseVO) throws Exception {
		this.getSqlSessionTemplate().delete(this.getMapper()+".deleteBatch", baseVO);
	}
	//��ȡ����
	public BaseVO getNewObject(BaseVO baseVO) throws Exception{
		return (BaseVO)this.getSqlSessionTemplate().selectOne(this.getMapper()+".getNewObject", baseVO);
	}
	public String getMapper() {
		return mapper;
	}
	public void setMapper(String mapper) {
		this.mapper = mapper;
	}
	public SqlSessionTemplate getSqlSessionTemplate() {
		return sqlSessionTemplate;
	}
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}
}
