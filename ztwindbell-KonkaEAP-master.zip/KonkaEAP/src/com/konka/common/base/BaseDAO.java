package com.konka.common.base;

import java.util.List;

import com.konka.common.tool.Page;

public interface BaseDAO {
	public int insert(Object object) throws Exception;
	public void insertBatch(List list) throws Exception;
	public Object getById(Integer id) throws Exception;
	public Object getByObject(Object object) throws Exception;
	public void update(Object object) throws Exception;
	public void delete(Integer id) throws Exception;
	public void deleteByObject(Object object) throws Exception;
	public List getAllList(Object object) throws Exception;
	public List getObjectList(BaseVO baseVO,Page page) throws Exception;
	public boolean isExist(Object object) throws Exception;
	public void deleteBatch(BaseVO baseVO) throws Exception;
	public BaseVO getNewObject(BaseVO baseVO) throws Exception;
	public void updateBatch(Object object) throws Exception;
}
