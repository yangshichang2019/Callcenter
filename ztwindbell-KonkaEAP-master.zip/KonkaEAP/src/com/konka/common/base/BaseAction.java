package com.konka.common.base;

import java.io.File;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.konka.common.tool.Page;
import com.opensymphony.xwork2.ActionContext;

import freemarker.template.Configuration;
import freemarker.template.Template;

public class BaseAction {
	ActionContext context = ActionContext.getContext();  
	HttpServletRequest request = (HttpServletRequest) context.get(ServletActionContext.HTTP_REQUEST);  
	HttpServletResponse response = (HttpServletResponse) context.get(ServletActionContext.HTTP_RESPONSE);  
	Map session = context.getSession();
	public List dataList = new ArrayList();
	public String error = "";
	public String menuNum = "";
	//ajax提交结果
	public String statusCode = "200";
	public String message = "操作成功";
	public String navTabId = "";
	public String rel = "";
	public String callbackType = "closeCurrent";
	public String forwardUrl = "";
	//分页用
	public Page page = new Page();
	//是否首次打开
	public String first;
	//id字符串
	public String groupName = "";
	public String user_single = "";
	public String user_type = "";
	public String ids = "";
	//url
	public String requestUrl = getRequestURL(request);
	
	public String callbackFun = "";
	public String getRequestURL(HttpServletRequest request) { 
		String url = request.getRequestURI(); 
		if (!"".equals(request.getQueryString()) || request.getQueryString() != null) { 
			url = url + "?" + request.getQueryString(); 
		} 
		int i = url.indexOf("&_=");
		if(i>0) {
			url = url.substring(0, i);
		}
		return url; 
	}  
	//出错
	public void toError(String msg) {
		this.statusCode = "300";
		this.message = msg;
		this.callbackType="";
	}
	/**
	 * 利用摸板倒出Excel
	 */
	protected boolean processTemplate(String templatePath, String encoding,	Map templateData, Writer out) {
		try 
		{
			//freemarker 定义 Configuration 
	        Configuration freemarker_cfg = null;
	        freemarker_cfg = new Configuration();
	        //定义freemarker模板目录
	        freemarker_cfg.setDirectoryForTemplateLoading(new File(ServletActionContext.getServletContext().getRealPath("/")));
	        //获取模板
	        Template template = freemarker_cfg.getTemplate(templatePath,encoding); 
			//模板导出
			template.process(templateData, out);
			return true;
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return false;
	}
	//获取临时文件
	protected File getTempFile(String str) throws Exception {
		String fileName = new String(str.getBytes("GB2312"), "iso8859-1");
		Properties p = System.getProperties();
		String tempPath = p.getProperty("java.io.tmpdir");
		String separator = p.getProperty("file.separator");
		File afile = new File(tempPath + separator + fileName);
		return afile;

	}
	public ActionContext getContext() {
		return context;
	}
	public void setContext(ActionContext context) {
		this.context = context;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	public HttpServletResponse getResponse() {
		return response;
	}
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	public Map getSession() {
		return session;
	}
	public void setSession(Map session) {
		this.session = session;
	}
	public List getDataList() {
		return dataList;
	}
	public void setDataList(List dataList) {
		this.dataList = dataList;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getNavTabId() {
		return navTabId;
	}
	public void setNavTabId(String navTabId) {
		this.navTabId = navTabId;
	}
	public String getRel() {
		return rel;
	}
	public void setRel(String rel) {
		this.rel = rel;
	}
	public String getCallbackType() {
		return callbackType;
	}
	public void setCallbackType(String callbackType) {
		this.callbackType = callbackType;
	}
	public String getForwardUrl() {
		return forwardUrl;
	}
	public void setForwardUrl(String forwardUrl) {
		this.forwardUrl = forwardUrl;
	}
	public Page getPage() {
		return page;
	}
	public void setPage(Page page) {
		this.page = page;
	}
	public String getIds() {
		return ids;
	}
	public void setIds(String ids) {
		this.ids = ids;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getMenuNum() {
		return menuNum;
	}
	public void setMenuNum(String menuNum) {
		this.menuNum = menuNum;
	}
	public String getCallbackFun() {
		return callbackFun;
	}
	public void setCallbackFun(String callbackFun) {
		this.callbackFun = callbackFun;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getUser_single() {
		return user_single;
	}
	public void setUser_single(String user_single) {
		this.user_single = user_single;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public String getFirst() {
		return first;
	}
	public void setFirst(String first) {
		this.first = first;
	}
}
