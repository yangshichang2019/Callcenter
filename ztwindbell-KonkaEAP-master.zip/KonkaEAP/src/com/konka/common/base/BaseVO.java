package com.konka.common.base;

import java.sql.Timestamp;

public class BaseVO {	
	//基本数据
	private Timestamp create_time;
	private String create_employee;
	private Integer create_dept;
	private Timestamp update_time;
	private String update_employee;
	private Integer update_dept;
	//备用状态
	private String enable_flag;
	private String delete_flag;
	//id字符串
	private String values;
	private String values2;
	//分页用
	private Integer start = 0;
	private Integer end = 20;
	private Integer result_count = 0;
	//排序
	private String orderField = "id";
	private String orderDirection = "desc";
	//是否选中
	private String isCheck = "";
	//时间间隔
	private String start_time;
	private String end_time;
	//查询数据数量
	private Integer fetch_count = 20;
	public String getEnable_flag() {
		return enable_flag;
	}
	public void setEnable_flag(String enable_flag) {
		this.enable_flag = enable_flag;
	}
	public String getDelete_flag() {
		return delete_flag;
	}
	public void setDelete_flag(String delete_flag) {
		this.delete_flag = delete_flag;
	}
	public Timestamp getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}
	public String getCreate_employee() {
		return create_employee;
	}
	public void setCreate_employee(String create_employee) {
		this.create_employee = create_employee;
	}
	public Integer getCreate_dept() {
		return create_dept;
	}
	public void setCreate_dept(Integer create_dept) {
		this.create_dept = create_dept;
	}
	public Timestamp getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Timestamp update_time) {
		this.update_time = update_time;
	}
	public String getUpdate_employee() {
		return update_employee;
	}
	public void setUpdate_employee(String update_employee) {
		this.update_employee = update_employee;
	}
	public Integer getUpdate_dept() {
		return update_dept;
	}
	public void setUpdate_dept(Integer update_dept) {
		this.update_dept = update_dept;
	}
	public Integer getStart() {
		return start;
	}
	public void setStart(Integer start) {
		this.start = start;
	}
	public Integer getEnd() {
		return end;
	}
	public void setEnd(Integer end) {
		this.end = end;
	}
	public Integer getResult_count() {
		return result_count;
	}
	public void setResult_count(Integer result_count) {
		this.result_count = result_count;
	}
	public String getOrderField() {
		return orderField;
	}
	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}
	public String getOrderDirection() {
		return orderDirection;
	}
	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}
	public String getValues() {
		return values;
	}
	public void setValues(String values) {
		this.values = values;
	}
	public String getIsCheck() {
		return isCheck;
	}
	public void setIsCheck(String isCheck) {
		this.isCheck = isCheck;
	}
	public String getStart_time() {
		return start_time;
	}
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	public String getEnd_time() {
		return end_time;
	}
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	public String getValues2() {
		return values2;
	}
	public void setValues2(String values2) {
		this.values2 = values2;
	}
	public Integer getFetch_count() {
		return fetch_count;
	}
	public void setFetch_count(Integer fetch_count) {
		this.fetch_count = fetch_count;
	}
}
