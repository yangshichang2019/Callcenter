package com.konka.common.template;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.database.model.LookupCode;
import com.konka.database.model.LookupItem;
import com.konka.useradmin.model.Right;
import com.konka.useradmin.model.User;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toCode")
public class ToCode implements TemplateDirectiveModel {
	@Autowired
	private HttpServletRequest request;
	private String lookupCode;
	private String value;
	private String type;
	private String name;
	private String id;
	private String className;
	private String onClick;
	private String num;//权限代码
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
			lookupCode = "";
			value = "";
			type = "";
			name = "";
			id = "";
			className = "";
			onClick = "";
			num = "";//权限代码
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("lookupCode".equals(paramName)) {
	            	lookupCode = paramValue.toString().trim();
	            }else if("value".equals(paramName)) {
	            	value = paramValue.toString().trim();
	            }else if("type".equals(paramName)) {
	            	type = paramValue.toString().trim();
	            }else if("name".equals(paramName)) {
	            	name = paramValue.toString().trim();
	            }else if("id".equals(paramName)) {
	            	id = paramValue.toString().trim();
	            }else if("className".equals(paramName)) {
	            	className = paramValue.toString().trim();
	            }else if("onClick".equals(paramName)) {
	            	onClick = paramValue.toString().trim();
	            }else if("num".equals(paramName)) {
	            	num = paramValue.toString().trim();
	            }
	        }
	        //权限
	        String allow = "";
	        if(!"".equals(num)) {
		        Map<String, Right> map = (Map<String, Right>)request.getSession().getAttribute(Constant.SESSION_ALLOW);
		        if(map!=null&&map.size()>0) {
		        	Right right = map.get(num);
		        	if(right!=null&&!"".equals(right.getAllow())) {
		        		allow = right.getAllow()+",";
		        	}
		        }
	        }
	        
			List list = Constant.codeMap.get(lookupCode);
			String str = "";
			LookupItem lookupItem = null;
			if(list!=null && list.size()>0) {
				String[] strArray =  null;
				if(type.equals("checkbox")||type.equals("texts")){
					if(!value.equals("")){
						strArray = value.split(",");
					}
				}
				for(int i=0;i<list.size();i++) {
					LookupCode vo = (LookupCode)list.get(i);
					lookupItem = vo.getLookupItem();
					boolean show = true;
					if(type.equals("select")) {
						if(!"".equals(allow)) {
							if((lookupItem.getValue()+",").indexOf(allow)<0) {
								show = false;
							}
						}
						if(show) {
							str = str + "<option value=\""+lookupItem.getValue()+"\"";
							if(lookupItem.getValue().equals(value)) {
								str = str + " selected=\"selected\"";
							}
							str = str +	">"+vo.getLookupItem().getName()+"</option>\n";
						}
					}else if(type.equals("radio")) {
						if(!"".equals(allow)) {
							if((lookupItem.getValue()+",").indexOf(allow)<0) {
								show = false;
							}
						}
						if(show) {
							str = str + "<input type=\"radio\"";
							str = str + " value=\""+lookupItem.getValue()+"\"";
							str = str + " name=\"" + name + "\"";
							str = str + " id=\"" + id + "\"";
							str = str + " class=\"" + className + "\"";
							str = str + " onClick=\"" + onClick + "\"";
							if(lookupItem.getValue().equals(value)) {
								str = str + " checked=\"checked\"";
							}
							str = str + "/>" + lookupItem.getName();
						}
					}else if(type.equals("checkbox")) {
						str = str + "<input type=\"checkbox\"";
						str = str + " value=\""+lookupItem.getValue()+"\"";
						str = str + " name=\"" + name + "\"";
						str = str + " id=\"" + id + "\"";
						str = str + " class=\"" + className + "\"";
						str = str + " onClick=\"" + onClick + "\"";
						if(strArray!=null&&strArray.length>0) {
							for(int m=0;m<strArray.length;m++) {
								if(lookupItem.getValue().equals(strArray[m])) {
									str = str + " checked=\"checked\"";
									break;
								}
							}
						}
						str = str + "/>" + lookupItem.getName();
					}else if(type.equals("text")) {
						if(lookupItem.getValue().equals(value)) {
							if(lookupItem.getColor()!=null&&!lookupItem.getColor().equals("NONE")) {
								str = str + "<a style=\"color:"+lookupItem.getColor()+";text-decoration:none;\">"+lookupItem.getName()+"</a>";
							} else {
								str = str + lookupItem.getName();
							}
							
						}
					}else if(type.equals("texts")) {
						if(strArray!=null&&strArray.length>0) {
							for(int m=0;m<strArray.length;m++) {
								if(lookupItem.getValue().equals(strArray[m])) {
									str = str + lookupItem.getName() + "(" + lookupItem.getValue() + ")、";
									break;
								}
							}
						}
					}
				}
				if(type.equals("texts")) {
					if(!str.equals("")) {
						str = str.substring(0, str.length()-1);
					}
				}
			}
			//env.setVariable(type, ObjectWrapper.DEFAULT_WRAPPER.wrap(str));
	        env.getOut().write(str);
	        env.getOut().flush();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
