package com.konka.common.template;

import java.io.IOException;
import java.io.Writer;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.Dept;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toDate")
public class ToDate implements TemplateDirectiveModel  {
	private String format = "";
	private String date = "";
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("format".equals(paramName)) {
	            	format = paramValue.toString().trim();
	            }else if("date".equals(paramName)) {
	            	date = paramValue.toString().trim();
	            }
	        }
	        String outd = "";
	        int ss = date.indexOf(".");
	        if(ss>0) {
	        	date = date.substring(0, ss);
	        }
	        if(!format.equals("")&&!date.equals("")) {
	        	String f = "yyyy-MM-dd HH:mm:ss";
		        	Date d = DateTool.formatStrToDate(f, date);
		        	outd = DateTool.formatDate(format, d);
	        }
	        if(!outd.equals("")) {
		        env.getOut().write(outd);
		        env.getOut().flush();
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
