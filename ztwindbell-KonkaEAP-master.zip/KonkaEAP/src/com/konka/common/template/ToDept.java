package com.konka.common.template;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.useradmin.model.Dept;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toDept")
public class ToDept implements TemplateDirectiveModel  {
	private String key;
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("key".equals(paramName)) {
	            	key = paramValue.toString().trim();
	            }
	        }
	        Dept dept = Constant.deptMap.get(key);
	        if(dept!=null) {
		        env.getOut().write(dept.getName());
		        env.getOut().flush();
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
