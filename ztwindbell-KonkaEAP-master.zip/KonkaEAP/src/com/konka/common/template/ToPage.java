package com.konka.common.template;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.konka.common.tool.Util;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toPage")
public class ToPage implements TemplateDirectiveModel  {
	private Integer numPerPage;
	private Integer result_count;
	private Integer pageNumShown;
	private Integer currentPage;
	private String targetType;
	private String rel;
	
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
			numPerPage=0;
			result_count=0;
			pageNumShown=0;
			currentPage=0;
			targetType="";
			rel = "";
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("numPerPage".equals(paramName)) {
	            	numPerPage = Integer.parseInt(paramValue.toString().trim());
	            }
	            if ("result_count".equals(paramName)) {
	            	result_count = Integer.parseInt(paramValue.toString().trim());
	            }
	            if ("pageNumShown".equals(paramName)) {
	            	pageNumShown = Integer.parseInt(paramValue.toString().trim());
	            }
	            if ("currentPage".equals(paramName)) {
	            	currentPage = Integer.parseInt(paramValue.toString().trim());
	            }
	            if ("targetType".equals(paramName)) {
	            	targetType = paramValue.toString().trim();
	            }
	            if ("rel".equals(paramName)) {
	            	rel = paramValue.toString().trim();
	            }
	        }
	        if(targetType==null||"".equals(targetType)) {
	        	targetType = "navTab";
	        }

	        if(pageNumShown==null||pageNumShown==0) {
	        	pageNumShown = 10;
	        }
	        String str = "";
	        str = str + "<div class=\"pages\">";
			str = str + "<span>显示</span>";
			str = str + "<select name=\"page.numPerPage\" onchange=\""+targetType+"PageBreak({numPerPage:this.value}";
			if(!"".equals(rel)) {
				str = str + ", '"+rel+"'";
			}
			str = str + ")\">";
			str = str + "<option value=\"10\" ";
			if(numPerPage==10)
				str = str + "selected=\"selected\"";
			str = str + ">10</option>";
			str = str + "<option value=\"20\" ";
			if(numPerPage==20)
				str = str + "selected=\"selected\"";
			str = str + ">20</option>";
			str = str + "<option value=\"50\" ";
			if(numPerPage==50)
				str = str + "selected=\"selected\"";
			str = str + ">50</option>";
			str = str + "<option value=\"100\" ";
			if(numPerPage==100)
				str = str + "selected=\"selected\"";
			str = str + ">100</option>";
			str = str + "<option value=\"200\" ";
			if(numPerPage==200)
				str = str + "selected=\"selected\"";
			str = str + ">200</option>";
			str = str + "<option value=\"500\" ";
			if(numPerPage==500)
				str = str + "selected=\"selected\"";
			str = str + ">500</option>";
			str = str + "</select>";
			str = str + "<span>条，共" + result_count + "条</span>";
			str = str + "</div>";
			str = str + "<div class=\"pagination\"";
			if(!"".equals(rel)) {
				str = str + " rel=\""+rel+"\"";
			}
			str = str + " targetType=\""+targetType+"\" totalCount=\"" + result_count + "\" numPerPage=\""
					  + numPerPage + "\" pageNumShown=\""+pageNumShown+"\" currentPage=\""+currentPage+"\"></div>";
	        if(!str.equals("")) {
		        env.getOut().write(str);
		        env.getOut().flush();
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
