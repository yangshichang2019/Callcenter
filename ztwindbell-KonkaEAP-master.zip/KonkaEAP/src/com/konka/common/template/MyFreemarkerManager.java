package com.konka.common.template;

import java.util.Map;

import javax.servlet.ServletContext;

import org.apache.struts2.views.freemarker.FreemarkerManager;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.konka.common.tool.Util;

import freemarker.template.Configuration;
import freemarker.template.TemplateDirectiveModel;

import freemarker.template.TemplateException;

public class MyFreemarkerManager extends FreemarkerManager {
	@Override
	protected Configuration createConfiguration(ServletContext servletContext) throws TemplateException {
		Configuration configuration = super.createConfiguration(servletContext);
		// ���ñ�ǩ����([]��<>),[]���ֱ�ǽ���Ҫ��Щ
		configuration.setTagSyntax(Configuration.AUTO_DETECT_TAG_SYNTAX);
		ApplicationContext applicationContext = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		Map<String, TemplateDirectiveModel> beans = applicationContext.getBeansOfType(TemplateDirectiveModel.class);
		
		for (String key : beans.keySet()) {
			Object obj = beans.get(key);
			if (obj != null && obj instanceof TemplateDirectiveModel) {
				configuration.setSharedVariable(key, obj);
			}
		}
		return configuration;
	}
}
