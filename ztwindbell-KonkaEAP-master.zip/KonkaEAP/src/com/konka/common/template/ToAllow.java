package com.konka.common.template;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.Dept;
import com.konka.useradmin.model.Right;
import com.konka.useradmin.model.User;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toAllow")
public class ToAllow implements TemplateDirectiveModel  {
	@Autowired
	private HttpServletRequest request;
	private String num;
	private String code;
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
			User user = (User)request.getSession().getAttribute(Constant.SESSION_USER);
			
			if(user!=null&&user.getUsername().equals("admin")) {
				body.render(env.getOut());
				return;
			}
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("num".equals(paramName)) {
	            	num = paramValue.toString().trim();
	            }else if ("code".equals(paramName)) {
	            	code = paramValue.toString().trim();
	            }
	        }
	        Map<String, Right> map = (Map<String, Right>)request.getSession().getAttribute(Constant.SESSION_ALLOW);
	        if(map!=null&&map.size()>0) {
	        	Right right = map.get(num);
	        	if(right!=null) {
	        		if(right.getAllow().indexOf(code)>=0) {
	        			body.render(env.getOut());
	        		}
	        	}
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
