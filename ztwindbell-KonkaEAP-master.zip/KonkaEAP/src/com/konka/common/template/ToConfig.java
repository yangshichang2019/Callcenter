package com.konka.common.template;

import java.io.IOException;
import java.io.Writer;
import java.util.Iterator;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toConfig")
public class ToConfig implements TemplateDirectiveModel  {
	private String key;
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("key".equals(paramName)) {
	            	key = paramValue.toString().trim();
	            }
	        }
	        String value = Constant.configMap.get(key);
	        if(value!=null ){
		        env.getOut().write(value);
		        env.getOut().flush();
	        }

		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
