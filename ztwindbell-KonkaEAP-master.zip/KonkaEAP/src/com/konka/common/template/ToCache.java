package com.konka.common.template;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;

import freemarker.core.Environment;
import freemarker.template.TemplateDirectiveBody;
import freemarker.template.TemplateDirectiveModel;
import freemarker.template.TemplateException;
import freemarker.template.TemplateModel;
@Component("toCache")
public class ToCache implements TemplateDirectiveModel {
	@Override
	public void execute(Environment env, Map params, TemplateModel[] loopVars,
			TemplateDirectiveBody body) throws TemplateException, IOException {
		try {
	        Iterator paramIter = params.entrySet().iterator();
	        Map.Entry ent;
	        String paramName;
	        TemplateModel paramValue;
	        
	        String code = "";
	        String key = "";
	        while (paramIter.hasNext()) {
	            ent = (Map.Entry) paramIter.next();
	            paramName = (String) ent.getKey();
	            paramValue = (TemplateModel) ent.getValue();
	            if ("code".equals(paramName)) {
	            	code = paramValue.toString().trim();
	            }else if("key".equals(paramName)) {
	            	key = paramValue.toString().trim();
	            }
	        }
			Map<String,String> map = Constant.cacheMap.get(code);
			if(map!=null) {
		        env.getOut().write(map.get(key));
		        env.getOut().flush();
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
