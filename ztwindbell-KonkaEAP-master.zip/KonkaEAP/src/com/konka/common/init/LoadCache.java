package com.konka.common.init;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.common.tool.RWProperties;
import com.konka.common.tool.Util;
import com.konka.database.model.ConfigInfo;
import com.konka.database.model.LookupCode;
import com.konka.database.model.Seat;
import com.konka.database.service.DataBaseService;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.service.InfoService;
import com.konka.sales.product.model.ProductClass;
import com.konka.sales.product.service.ProductService;
import com.konka.useradmin.model.Dept;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;
@Component
public class LoadCache {
	@Autowired
	private DataBaseService dataBaseService;
	@Autowired
	private UserAdminService userAdminService;
	@Autowired
	private InfoService infoService;
	@Autowired
	private ProductService productService;
	//缓存全部
	public void loadAll() {
		loadLookupCode();
		loadConfigCache();
		loadDeptCache();
		loadUserCache();
		loadInfoCache();
		loadSeat();
		loadCache();
	}
	public void loadCache(){
		try {
			ProductClass productClass = new ProductClass();
			List list = productService.getAllProductClassList(productClass);
			Map<String,String> map = new HashMap<String, String>();
			if(list.size()>0) {
				for(int i=0;i<list.size();i++) {
					productClass = (ProductClass)list.get(i);
					map.put(productClass.getId()+"", productClass.getName());
				}
			}
			Constant.cacheMap.put("PRODUCTCLASS_ID_NAME", map);
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//编码缓存
	public void loadLookupCode() {
		try {
			List list = dataBaseService.getLookupCodeForCache();
			List<LookupCode> codeList = new ArrayList<LookupCode>();
			Map<String, List<LookupCode>> map = new HashMap<String, List<LookupCode>>();
			Map<String, Map<String,String>> map2 = new HashMap<String, Map<String,String>>();
			
			LookupCode vo = new LookupCode();
			if(list.size()>0) {
				for(int i=0;i<list.size();i++) {
					vo = (LookupCode)list.get(i);
					Map<String,String> map3 = new HashMap<String, String>();
					if(map.get(vo.getCode())!=null) {
						codeList = map.get(vo.getCode());
						codeList.add(vo);
						map.put(vo.getCode(), codeList);
						
						map3 = map2.get(vo.getCode());
					}else {
						List <LookupCode> list2 = new ArrayList<LookupCode>();
						list2.add(vo);
						map.put(vo.getCode(), list2);
						
						map3.put(vo.getLookupItem().getValue(), vo.getLookupItem().getName());
						map2.put(vo.getCode(), map3);
					}
					map3.put(vo.getLookupItem().getValue(), vo.getLookupItem().getName());
					map2.put(vo.getCode(), map3);
				}
				Constant.codeMap.clear();
				Constant.codeMap.putAll(map);
				Constant.codeNameMap.clear();
				Constant.codeNameMap.putAll(map2);
				Util.echo("系统编码：："+Constant.codeMap.size());
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//座位
	public void loadSeat() {
		try {
			List list = dataBaseService.getAllSeatListForOpeneap();
			List<Seat> seatList = new ArrayList<Seat>();
			Map<String, Seat> map = new HashMap<String, Seat>();
			Seat vo = new Seat();
			if(list.size()>0) {
				for(int i=0;i<list.size();i++) {
					vo = (Seat)list.get(i);
					map.put(vo.getIp(), vo);
				}
				Constant.seatMap.clear();
				Constant.seatMap.putAll(map);
				Util.echo("坐席位置：："+Constant.seatMap.size());
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//获取配置缓存
	public void loadConfigCache() {
		try {
			RWProperties properties = new RWProperties(Constant.CONFIG_PROPERTIES);
			List<ConfigInfo> list =  properties.loadAllKeyAndValue();
			Map<String, String> map = new HashMap<String, String>();
			for(int i=0;i<list.size();i++) {
				ConfigInfo vo = (ConfigInfo)list.get(i);
				int m = vo.getKey().indexOf("][");
				int r = vo.getKey().length();
				if(m>=0) {
					String key = vo.getKey().substring(m+2, r-1);
					String value = vo.getValue();
					map.put(key, value);
				}
			}
			Constant.configMap.clear();
			Constant.configMap.putAll(map);
			Util.echo("系统配置：："+Constant.configMap.size());
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	//获取部门缓存
	public void loadDeptCache() {
		try {
			Dept dept = new Dept();
			List<Dept> list = userAdminService.getAllDeptList(dept);
			Map<String,Dept> map = new HashMap<String, Dept>();
			if(list!=null&&list.size()>0) {
				for(int i=0;i<list.size();i++) {
					Dept vo = (Dept)list.get(i);
					map.put(vo.getId()+"", vo);
				}
				Constant.deptMap.clear();
				Constant.deptMap.putAll(map);
				Util.echo("部门缓存：："+Constant.deptMap.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//获取人员缓存
	public void loadUserCache() {
		try {
			User user = new User();
			List<User> list = userAdminService.getAllUserList(user);
			Map<String,User> map = new HashMap<String, User>();
			if(list!=null&&list.size()>0) {
				for(int i=0;i<list.size();i++) {
					User vo = (User)list.get(i);
					map.put(vo.getUsername(),vo);
				}
				Constant.userMap.clear();
				Constant.userMap.putAll(map);
				Util.echo("人员缓存：："+Constant.userMap.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	//获取知识库类别缓存
	public void loadInfoCache() {
		try {
			List list = infoService.getDirectoryList(new InfoDirectory());
			Map<String,InfoDirectory> map = new HashMap<String, InfoDirectory>();
			if(list!=null&&list.size()>0) {
				InfoDirectory vo = null;
				for(int i=0;i<list.size();i++) {
					vo = new InfoDirectory();
					vo = (InfoDirectory)list.get(i);
					map.put(vo.getId()+"", vo);
				}
				Constant.knowMap.clear();
				Constant.knowMap.putAll(map);
				Util.echo("知识库类别缓存：："+Constant.knowMap.size());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void destoryCache() {
		Constant.codeMap.clear();
		Constant.configMap.clear();
		Constant.deptMap.clear();
		Constant.userMap.clear();
		Constant.knowMap.clear();
	}
}
