package com.konka.common.constant;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.konka.database.model.LookupCode;
import com.konka.database.model.Seat;
import com.konka.job.info.model.InfoDirectory;
import com.konka.office.talk.model.TalkMsg;
import com.konka.office.talk.model.TalkOnline;
import com.konka.useradmin.model.Dept;
import com.konka.useradmin.model.User;

public class Constant {
	//session用户名
	public static String SESSION_USER = "user";
	//session权限
	public static String SESSION_RIGHT = "rightList";
	//session许可
	public static String SESSION_ALLOW = "allowMap";
	public static enum ACTION_S {ajaxDone //ajax返回
		};
	public static enum CALLBACKTYPE {closeCurrent//ajax关闭
		,forward}
	//编码缓存
	public static Map<String, List<LookupCode>> codeMap = new HashMap<String, List<LookupCode>>();
	public static Map<String, Map<String,String>> codeNameMap = new HashMap<String, Map<String,String>>();
	//部门缓存
	public static Map<String,Dept> deptMap = new HashMap<String, Dept>();
	//人员缓存
	public static Map<String,User> userMap = new HashMap<String, User>();
	//知识库类别
	public static Map<String,InfoDirectory> knowMap = new HashMap<String, InfoDirectory>();
	//座位缓存
	public static Map<String,Seat> seatMap = new HashMap<String, Seat>();
	//配置文件
	public static String CONFIG_PROPERTIES = "/config.properties";
	//配置缓存
	public static Map<String,String> configMap = new HashMap<String, String>();
	//结果
	public static enum RESULT { FAILURE,SUCCESS}
	//系统、用户
	public static enum DATE_TYPE {SYSTEM,USER}
	//solr地址
	public static String SOLR_SERVER = "http://172.40.1.120:8983/solr";
	//public static String SOLR_SERVER = "http://172.40.1.88:8983/solr";
	//在线列表
	public static Map<String, TalkOnline> imOnline = new HashMap<String, TalkOnline>();
	//消息队列
	public static Map<String,List<TalkMsg>> userMsgMap = new HashMap<String, List<TalkMsg>>();
	public static Map<String,Map<String,String>> groupUserMap = new HashMap<String,Map<String,String>>();
	public static Map<String,Map<String,String>> cacheMap = new HashMap<String, Map<String,String>>();
	//知识库首页缓存
	public static Map<String,List> infoMap = new HashMap<String, List>();
	
	public static Map<String,Integer> remindNum = new HashMap<String,Integer>();
}
