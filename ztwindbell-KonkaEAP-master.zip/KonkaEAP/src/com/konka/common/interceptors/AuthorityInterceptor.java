package com.konka.common.interceptors;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.konka.common.tool.Util;
import com.konka.login.action.LoginAction;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class AuthorityInterceptor implements Interceptor{
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String intercept(ActionInvocation actionInvocation) throws Exception {
		ActionContext actionContext = actionInvocation.getInvocationContext();
		HttpServletRequest request = (HttpServletRequest)actionContext.get(ServletActionContext.HTTP_REQUEST);
		String currentURL = request.getRequestURI();
		String currentMethod = actionContext.getName();
		request.setAttribute("currentURL", currentURL);
		request.setAttribute("currentMethod", currentMethod);
		LoginAction action = new LoginAction();
		if(currentMethod.equals("sys_toUploadFile")||action.sessionCheck()){
			return actionInvocation.invoke();
		}else if(action.openeapLogin()){
			System.out.println("===========通过新太验证=========");
			return actionInvocation.invoke();
		}
		System.out.println("===========用户未登=========");
		return "timeOut";
	}
}
