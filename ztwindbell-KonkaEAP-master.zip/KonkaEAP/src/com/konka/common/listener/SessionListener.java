package com.konka.common.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;


import com.konka.common.constant.Constant;
import com.konka.common.tool.SpringContextHolder;
import com.konka.common.tool.Util;
import com.konka.system.model.SessionInfo;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;

public class SessionListener implements HttpSessionListener {
	//WebApplicationContext ctx = null;
	@Override
	public void sessionCreated(HttpSessionEvent event){
		// TODO Auto-generated method stub
		//不关心未登录访客
		
		Util.echo(event.getSession().getId()+"创建");
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent event) {
		// TODO Auto-generated method stub
		try {
			User user = (User)event.getSession().getAttribute(Constant.SESSION_USER);
			if(user!=null) {
				SystemService service = (SystemService)SpringContextHolder.getBean("systemService");
				SessionInfo sessionInfo = new SessionInfo();
				sessionInfo.setSessionId(event.getSession().getId());
				sessionInfo.setDestoryTime(Util.getTimestamp());
				Util.echo(sessionInfo.getSessionId()+"销毁");
				service.updateSessionInfo(sessionInfo,user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/*
	public Object getBean(String name) {
		if (ctx == null) {
			ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(ServletActionContext.getServletContext());
		}
		return ctx.getBean(name);
	}
	*/
}
