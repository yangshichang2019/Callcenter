package com.konka.common.timing;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServlet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.office.talk.model.TalkOnline;
import com.konka.system.model.Task;
import com.konka.system.service.SystemService;
import com.konka.system.service.TaskService;
@Component
public class DoTask extends HttpServlet {
	@Autowired
	private SystemService systemService;
	@Autowired
	private TaskService taskService;
	public void doCurrentTasks() throws Exception {
		List list = systemService.getCurrentTasks();
		Task task = null;
		for(int i=0;i<list.size();i++) {
			task = (Task)list.get(i);
			try {
				Class[] parms = new Class[1];
				parms[0] = task.getClass();
				Method m =taskService.getClass().getMethod(task.getDo_function(), parms);
				m.invoke(taskService,task);
				task.setPre_result(Constant.RESULT.SUCCESS.toString());
			} catch (Exception e) {
				task.setPre_result(Constant.RESULT.FAILURE.toString());
			}
			systemService.updateDoneTask(task);
			Util.echo("成功执行"+task.getDo_function());
		}
	}

	//执行更新操作
	public void checkOnlineUserList() throws Exception {
		TalkOnline t = null;
		Map<String, TalkOnline> map = Constant.imOnline;
		List<String> list = new ArrayList<String>();
		Integer online = 0;
		try {
			for (String key : map.keySet()){
				t = map.get(key);
				if(!DateTool.compareDate(t.getDate())){
					if(t.getStatus()!=null&&!t.getStatus().equals("EXIT")) {
						t.setStatus("EXIT");
						Constant.imOnline.put(key, t);
						Constant.userMsgMap.remove(key);
						Util.echo(key+"退出聊天系统！");
					}else {
						list.add(key);
					}
					for (String key2 : Constant.groupUserMap.keySet()){
						Constant.groupUserMap.get(key2).remove(key);
					}
				}else {
					online = online +1;
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		if(list.size()>0) {
			for(int i=0;i<list.size();i++) {
				Constant.imOnline.remove(list.get(i));
			}
		}
		
	}
}
