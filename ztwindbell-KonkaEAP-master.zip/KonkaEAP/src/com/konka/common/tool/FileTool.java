package com.konka.common.tool;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.Random;

import com.konka.useradmin.model.User;

public class FileTool {
	private static final int BUFFER_SIZE = 16*1024;
	//删除文件或文件夹
	public static boolean DeleteFolder(String sPath) {  
	    boolean flag = false;  
	    File file = new File(sPath);  
	    // 判断目录或文件是否存在  
	    if (!file.exists()) {  // 不存在返回 false  
	        return flag;  
	    } else {  
	        // 判断是否为文件  
	        if (file.isFile()) {  // 为文件时调用删除文件方法  
	            return deleteFile(sPath);  
	        } else {  // 为目录时调用删除目录方法  
	            return deleteDirectory(sPath);  
	        }  
	    }  
	}  
	//删除文件
	public static boolean deleteFile(String sPath) {  
		boolean flag = false;  
		File file = new File(sPath);  
	    // 路径为文件且不为空则进行删除  
	    if (file.isFile() && file.exists()) {  
	        file.delete();  
	        flag = true;  
	    }  
	    return flag;  
	}  
	//删除文件夹
	public static boolean deleteDirectory(String sPath) {  
	    //如果sPath不以文件分隔符结尾，自动添加文件分隔符  
	    if (!sPath.endsWith(File.separator)) {  
	        sPath = sPath + File.separator;  
	    }  
	    File dirFile = new File(sPath);  
	    //如果dir对应的文件不存在，或者不是一个目录，则退出  
	    if (!dirFile.exists() || !dirFile.isDirectory()) {  
	        return false;  
	    }  
	    boolean flag = true;  
	    //删除文件夹下的所有文件(包括子目录)  
	    File[] files = dirFile.listFiles();  
	    for (int i = 0; i < files.length; i++) {  
	        //删除子文件  
	        if (files[i].isFile()) {  
	            flag = deleteFile(files[i].getAbsolutePath());  
	            if (!flag) break;  
	        } //删除子目录  
	        else {  
	            flag = deleteDirectory(files[i].getAbsolutePath());  
	            if (!flag) break;  
	        }  
	    }  
	    if (!flag) return false;  
	    //删除当前目录  
	    if (dirFile.delete()) {  
	        return true;  
	    } else {  
	        return false;  
	    }  
	}  
	//新建文件夹
	public static void isExist(String p) {
		File file = new File(p);
		  //判断文件夹是否存在,如果不存在则创建文件夹
		if (!file.exists()) {
		   file.mkdirs();
		}
	}
	//获取后缀名
	public static String getExtention(String f) {
		int pos = f.lastIndexOf(".");
		return f.substring(pos+1).toLowerCase(); 
	}
	//保存文件
	public static boolean copy(File src,File dst) {
		InputStream in = null;
		OutputStream out = null;
		try {
			in = new BufferedInputStream(new FileInputStream(src),BUFFER_SIZE);
			out = new BufferedOutputStream(new FileOutputStream(dst),BUFFER_SIZE);
			byte []buffer = new byte[BUFFER_SIZE];
			int len=0;
			while((len=in.read(buffer))>0) {
				out.write(buffer,0,len);
			}
		}catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try{
				if(in!=null) {
					in.close();
					if(out!=null) {
						out.close();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		return true;
	}
	public static String getNewFileName(User user,String filename) {
		Random r = new Random();
		Integer id = 0;
		if(user!=null) {
			id = user.getId();
		}
		String newFileName = id + "_" +  (new Date()).getTime() + "_" + (r.nextInt(90)+10) + "." + getExtention(filename);
		return newFileName;
	}
}
