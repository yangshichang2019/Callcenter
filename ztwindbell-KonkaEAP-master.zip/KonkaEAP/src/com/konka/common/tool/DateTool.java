package com.konka.common.tool;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateTool {
	//日期加减
	public static Date dateAdd(Date date,String type,Integer nu) {
		if(date==null) date = new Date(); 
		GregorianCalendar gc = new GregorianCalendar(); 
		gc.setTime(date);
		if(type.equals("HOUR")) {
			gc.add(Calendar.HOUR_OF_DAY, nu);
		}else if(type.equals("DAY")) {
			gc.add(Calendar.DAY_OF_MONTH, nu);
		}else if(type.equals("WEEK")){
			gc.add(Calendar.WEEK_OF_YEAR,nu);
		}else if(type.equals("MONTH")) {
			gc.add(Calendar.MONTH, nu);
		}else if(type.equals("YEAR")) {
			gc.add(Calendar.YEAR,nu);
		}else if(type.equals("MINUTE")) {
			gc.add(Calendar.MINUTE,nu);
		}else if(type.equals("SECOND")) {
			gc.add(Calendar.SECOND,nu);
		}
		return gc.getTime();
	}
	//获取部分日期
	public static String getDatePart(Date date,String type) {
		if(date==null) date = new Date(); 
		GregorianCalendar g=new GregorianCalendar();
		g.setTime(date);
        String paty = "";
		if(type.equals("HOUR")) {
			paty = g.get(Calendar.HOUR_OF_DAY)+"";
		}else if(type.equals("DAY")) {
			paty = g.get(Calendar.DAY_OF_MONTH)+"";
		}else if(type.equals("WEEK")){
			paty = g.get(Calendar.WEEK_OF_YEAR)+"";
		}else if(type.equals("MONTH")) {
			paty = g.get(Calendar.MONTH)+"";
		}else if(type.equals("YEAR")) {
			paty = g.get(Calendar.YEAR)+"";
		}
        return paty;
	}
	//格式化日期
	public static String formatDate(String format,Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		if(date==null) {
			date = new Date();
		}
		return sdf.format(date);
	}
	public static String formatDateWithNull(String format,Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		if(date==null) {
			return null;
		}
		return sdf.format(date);
	}
	//字符串转日期
	public static Date formatStrToDate(String format,String str) {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date date = null;
		try {
			date = sdf.parse(str);
		}catch (Exception e) {
			// TODO: handle exception
		}
		return date;
	}
	//判断参数日期是否超过当前时间
	public static boolean compareDate(Date date) {
	    Date now = new Date();
		if (date.getTime()>now.getTime()) {
			return true;
		}else{
			return false;
		}

	}
	//判断参数日期是否超过当前时间
	public static boolean compareDate(Date date,Date date2) {
		if (date.getTime()>date2.getTime()) {
			return true;
		}else{
			return false;
		}

	}
	//判断今天是星期几
	public static String getWeekOfDate(int n) {
		//获取星期几，0今天，1明天，-1昨天
				    Date date = new Date();
					Calendar calendar = new GregorianCalendar();
					calendar.setTime(date);
					calendar.add(calendar.DATE,n);
					date=calendar.getTime();
			        String[] weekDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};
			        Calendar cal = Calendar.getInstance();
			        cal.setTime(date);
			        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
			        if (w < 0)
			            w = 0;
			        return weekDays[w];
			    }
	
}
