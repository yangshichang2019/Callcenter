package com.konka.common.tool;

import java.util.ArrayList;
import java.util.List;

import com.konka.common.base.TreeVO;
import com.konka.database.model.ConsultArea;
import com.konka.database.model.Series;
import com.konka.job.info.model.InfoDirectory;
import com.konka.useradmin.model.Right;

public class Tree {
	//获取所有下级菜单
	public static List getAllSubMenu(List list,String num) {
		List tempList = new ArrayList();
		for(int i=0;i<list.size();i++) {
			Right right = (Right)list.get(i);
			if(num=="") {
				if(right.getNum().length()==3) {
					tempList.add(right);	
				}
			}else {
				if(right.getNum().substring(0,num.length()).equals(num)) {
					tempList.add(right);
				}
			}
		}
		return tempList;
	}

	//左侧菜单
	public static String getLeftMenuTree(List list,Integer parent_id) throws Exception {
		String str = "";
		str = str + "<div class=\"accordion\" fillSpace=\"sidebar\">";
		for(int i=0;i<list.size();i++) {
			Right vo = (Right)list.get(i);
			if(vo.getParent_id().equals(parent_id)) {
				str = str + "<div class=\"accordionHeader\">";
				str = str + "<h2><span>Folder</span>"+vo.getName()+"</h2>";
				str = str + "</div>";
				str = str + "<div class=\"accordionContent\">";
				str = str + makeMenuTree(list,vo.getId(),0);
				str = str + "</div>";
			}
		}	
		str = str + "</div>";
		return str;
	}
	public static String makeMenuTree(List list,Integer parent_id,Integer level) {
		String str ="";
		if(level==0) {
			str = str + "<ul class=\"tree treeFolder\">";
		}else {
			str = str + "<ul>";
		}
		Integer n = 0;
		for(int i=0;i<list.size();i++) {
			Right vo = (Right)list.get(i);
			if(vo.getParent_id().equals(parent_id)) {
				n = n + 1;
				str = str + "<li><a";
				if(!"".equals(vo.getUrl())) {
					String url = Util.addParamer(vo.getUrl(),"navTabId="+vo.getNum());
					str = str + " target=\""+vo.getTarget()+"\" external=\""+vo.getShowType();
					str = str +"\" rel=\""+vo.getNum() + "\" fresh=\""+vo.getFresh()+"\"";
					str = str + " href=\"" + url + "\"";
				}
				str = str + ">" + vo.getName()+"</a>";
				str = str + makeMenuTree(list,vo.getId(),level+1);	
				str = str + "</li>";
			}
		}	
		str = str + "</ul>";
		if(n==0) {
			str = "";
		}
		return str;
	}
	//判断节点是否是父节点
	public static String treeIsParent(List list,String subnum) {
		int len = subnum.length();
		for(int i=0;i<list.size();i++) {
			TreeVO vo = (TreeVO)list.get(i);
			if(vo.getNum().length()==(len+3)) {
				if(vo.getNum().substring(0, len).equals(subnum)) {
					return "true";
				}
			}
		}
		return "false";
	}
	//过滤节点
	public static List treeFilter(List list,String num) {
		int len = num.length();
		int clen = 0;
		List templist = new ArrayList();
		TreeVO vo = null;
		for(int i=0;i<list.size();i++) {
			vo = (TreeVO)list.get(i);
			clen = vo.getNum().length()-len;
			if(clen==6||clen==3){
				templist.add(vo);
			}
		}
		return templist;
	}
	//组织返回参数
		public static String makeTree2(List list,String num) throws Exception {
			String str = "[";
			for(int i=0;i<list.size();i++) {
				ConsultArea vo = (ConsultArea)list.get(i);
				str = str + "{\"name\":\""+vo.getArea_desc()+"\",";
				str = str + "\"id\":\""+vo.getArea_id()+"\",";
				String flag = "false";
				if(vo.getArea_level()!=2){
					flag = "true";
				}
				str = str + "\"isParent\":\""+flag+"\"},";
			}
			if(!"[".equals(str)) {
				str = str.substring(0,str.length()-1);
				str = str + "]";
			}else {
				str = "";
			}
			return str;
		}
	
		//组织返回参数
				public static String makeTree3(List list,String num) throws Exception {
					String str = "[";
					for(int i=0;i<list.size();i++) {
						Series vo = (Series)list.get(i);
						str = str + "{\"name\":\""+vo.getSeries_name().replace("\"", "")+"\",";
						str = str + "\"id\":\""+vo.getSeries_id()+"\",";
						String flag = vo.getHas_children_flag();
						if(flag.equals("T")){
							flag = "true";
						}else{
							flag = "false";
						}
						str = str + "\"isParent\":\""+flag+"\"},";
					}
					if(!"[".equals(str)) {
						str = str.substring(0,str.length()-1);
						str = str + "]";
					}else {
						str = "";
					}
					return str;
				}
	
	
	
	
	
	//组织返回参数
	public static String makeTree(List list,String num,String rel,String navTabId,String view,String object) throws Exception {
		String str = "[";
		int len = num.length()+3;
		for(int i=0;i<list.size();i++) {
			TreeVO vo = (TreeVO)list.get(i);
			if(vo.getNum().length()==len) {
				str = str + "{\"name\":\""+vo.getName()+"\",";
				str = str + "\"id\":\""+vo.getNum()+"\",";
				str = str + "\"rel\":\""+rel+"\",";
				str = str + "\"href\":\""+view+"?"+object+".id="+vo.getId()+"&navTabId="+navTabId+"\",";
				str = str + "\"isParent\":\""+treeIsParent(list,vo.getNum())+"\"},";
			}
		}
		if(!"[".equals(str)) {
			str = str.substring(0,str.length()-1);
			str = str + "]";
		}else {
			str = "";
		}
		return str;
	}
	//知识库专用
	public static String makeTree(Integer id,List list) throws Exception {
		Integer n = 0;
		StringBuilder str = new StringBuilder("");
		if(id==0) {
			str = str.append("[");
		}else {
			str = str.append(",children:[");
		}
		for(int i=0;i<list.size();i++) {
			InfoDirectory vo = (InfoDirectory)list.get(i);
			if(vo.getParent_id().equals(id)) {
				n = n + 1 ;
				str = str.append("{name:\"");
				str = str.append(vo.getName()+"\",");
				str = str.append("type:\"");
				str = str.append(vo.getType()+"\",");
				str = str.append("num:\"");
				str = str.append(vo.getNum()+"\",");
				str = str.append("id:\"");
				str = str.append(vo.getId()+"\"");
				str = str.append(makeTree(vo.getId(),list));
				str = str.append("},");
			}
		}
		String s = str.substring(0, str.length()-1)+"]";
		if(n==0) {
			return "";
		}else {
			return s;
		}
	}
}
