package com.konka.common.tool;

public class Page {
	private Integer num = 1;
	private Integer numPerPage = 20;
	private Integer result_count = 0;
	//����
	private String orderField = "id";
	private String orderDirection = "desc";
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	public Integer getNumPerPage() {
		return numPerPage;
	}
	public void setNumPerPage(Integer numPerPage) {
		this.numPerPage = numPerPage;
	}
	public Integer getResult_count() {
		return result_count;
	}
	public void setResult_count(Integer result_count) {
		this.result_count = result_count;
	}
	public String getOrderField() {
		return orderField;
	}
	public void setOrderField(String orderField) {
		this.orderField = orderField;
	}
	public String getOrderDirection() {
		return orderDirection;
	}
	public void setOrderDirection(String orderDirection) {
		this.orderDirection = orderDirection;
	}
}
