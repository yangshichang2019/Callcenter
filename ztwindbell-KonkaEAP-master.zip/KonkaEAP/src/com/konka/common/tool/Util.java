package com.konka.common.tool;

import java.security.MessageDigest;
import java.sql.Timestamp;
import java.util.regex.*;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.konka.common.base.BaseVO;
import com.konka.useradmin.model.User;

public class Util {
    public static String MD5(String s) {
        char hexDigits[]={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};       
        try {
            byte[] btInput = s.getBytes();
            // 获得MD5摘要算法的 MessageDigest 对象
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            // 使用指定的字节更新摘要
            mdInst.update(btInput);
            // 获得密文
            byte[] md = mdInst.digest();
            // 把密文转换成十六进制的字符串形式
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = hexDigits[byte0 >>> 4 & 0xf];
                str[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
	
	//放入创建信息
	public static void setCreateToVO(BaseVO baseVO,User user) {
		Timestamp now = getTimestamp();
		baseVO.setCreate_dept(user.getDept_id());
		baseVO.setCreate_employee(user.getUsername());
		baseVO.setCreate_time(now);
	}
	//放入更新信息
	public static void setUpdateToVO(BaseVO baseVO,User user) {
		baseVO.setUpdate_dept(user.getDept_id());
		baseVO.setUpdate_employee(user.getUsername());
		baseVO.setUpdate_time(getTimestamp());
	}
	//放入更新信息(无用户)
	public static void setUpdateNoUserToVO(BaseVO baseVO) {
		baseVO.setUpdate_dept(0);
		baseVO.setUpdate_employee("SYSTEM");
		baseVO.setUpdate_time(Util.getTimestamp());
	}
	//放入新建信息(无用户)
	public static void setCreateNoUserToVO(BaseVO baseVO) {
		baseVO.setCreate_dept(0);
		baseVO.setCreate_employee("SYSTEM");
		baseVO.setCreate_time(Util.getTimestamp());
	}
	//输出
	public static void echo(String smg){
		System.out.println("=log::" + smg);
	}
	//获取当前时间
	public static Timestamp getTimestamp(){
		return new Timestamp(System.currentTimeMillis());
	}
	//更新分页数据
	public static void setPageNum(BaseVO baseVO, Page page) {
		baseVO.setStart((page.getNum()-1)*page.getNumPerPage());
		baseVO.setEnd(baseVO.getStart()+page.getNumPerPage());
		baseVO.setOrderField(page.getOrderField());
		baseVO.setOrderDirection(page.getOrderDirection());
	}
	//获取下个编号
	public static String getNextNum(String num,Integer length) {
		String returnStr = "";
		returnStr = (Integer.parseInt(num)+1)+"";
		if(returnStr.length()<length) {
			Integer n = length-returnStr.length();
			for(int i=0;i<n;i++) {
				returnStr = "0" + returnStr;
			}
		}
		return returnStr;
	}
	//添加地址参数
	public static String addParamer(String url,String par) {
		if(url.indexOf("?")>-1) {
			return url+"&"+par;
		}else {
			return url+"?"+par;
		}
	}
	//过滤html标签
	public static String Html2Text(String inputString) { 
        String htmlStr = inputString; //含html标签的字符串 
        String textStr =""; 
        Pattern p_script; 
        Matcher m_script; 
        Pattern p_style; 
        Matcher m_style; 
        Pattern p_html; 
        Matcher m_html; 
        try { 
        	String regEx_script = "<[\\s]*?script[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?script[\\s]*?>"; //定义script的正则表达式{或<script[^>]*?>[\\s\\S]*?<\\/script> } 
        	String regEx_style = "<[\\s]*?style[^>]*?>[\\s\\S]*?<[\\s]*?\\/[\\s]*?style[\\s]*?>"; //定义style的正则表达式{或<style[^>]*?>[\\s\\S]*?<\\/style> } 
        	String regEx_html = "<[^>]+>"; //定义HTML标签的正则表达式 
      
        	p_script = Pattern.compile(regEx_script,Pattern.CASE_INSENSITIVE); 
        	m_script = p_script.matcher(htmlStr); 
        	htmlStr = m_script.replaceAll(""); //过滤script标签 

        	p_style = Pattern.compile(regEx_style,Pattern.CASE_INSENSITIVE); 
        	m_style = p_style.matcher(htmlStr); 
        	htmlStr = m_style.replaceAll(""); //过滤style标签 
      
        	p_html = Pattern.compile(regEx_html,Pattern.CASE_INSENSITIVE); 
        	m_html = p_html.matcher(htmlStr); 
        	htmlStr = m_html.replaceAll(""); //过滤html标签 
      
        	textStr = htmlStr; 
      
        }catch(Exception e) { 
        	e.printStackTrace();
        } 
        return textStr;//返回文本字符串 
	}   
	//获取cookies值
	public static String getCookiesByName(HttpServletRequest request,String name) {
		 Cookie[] cookies = request.getCookies(); //先得到Cookie数组
		 String value = "";
		 if (cookies != null) {
			 for (int i = 0; i < cookies.length; i++)
			 {
				 Cookie newCookie = cookies[i];
				 if (name.equals(newCookie.getName())){
					 value = newCookie.getValue();
				 }
			 }
		 }	
		 return value;
	}
	//获取任务表表名	
	public static String getTask() {
		return "_TASK";
	}
	//获取任务结果表名	
	public static String getRESULT() {
		return "_RESULT";
	}
	public static String guolvGonghao(String username){
		if(username.indexOf("F")>-1) {
			username = username.replace("F", "");
		}
		if(username.indexOf("H")>-1) {
			username = username.replace("H", "");
		}
		if(username.indexOf("L")>-1) {
			username = username.replace("L", "");
		}
		if(username.indexOf("Q")>-1) {
			username = username.replace("Q", "");
		}
		if(username.indexOf("S")>-1) {
			username = username.replace("S", "");
		}
		if(username.indexOf("T")>-1) {
			username = username.replace("T", "");
		}
		if(username.indexOf("W")>-1) {
			username = username.replace("W", "");
		}
		if(username.indexOf("X")>-1) {
			username = username.replace("X", "");
		}
		if(username.indexOf("Y")>-1) {
			username = username.replace("Y", "");
		}
		if(username.indexOf("Z")>-1) {
			username = username.replace("Z", "");
		}
		return username;
	}
	public static boolean isNumeric(String str){
	    Pattern pattern = Pattern.compile("[0-9]*");
	    return pattern.matcher(str).matches();   
	 } 
	/**
	 * 获得请求的主机的真实IP
	 */
	public static String getIpAddr(HttpServletRequest request) throws Exception{    
	    String ip = request.getHeader("x-forwarded-for");    
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {    
	        ip = request.getHeader("Proxy-Client-IP");    
	    }    
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {    
	        ip = request.getHeader("WL-Proxy-Client-IP");    
	    }    
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {    
	        ip = request.getRemoteAddr();    
	    }    
	    if(ip==null) {
	    	ip="";
	    }
	    return ip;    
	} 
	public static String unescape(String src) {  
        StringBuffer tmp = new StringBuffer();  
        tmp.ensureCapacity(src.length());  
        int lastPos = 0, pos = 0;  
        char ch;  
        while (lastPos < src.length()) {  
            pos = src.indexOf("%", lastPos);  
            if (pos == lastPos) {  
                if (src.charAt(pos + 1) == 'u') {  
                    ch = (char) Integer.parseInt(src  
                            .substring(pos + 2, pos + 6), 16);  
                    tmp.append(ch);  
                    lastPos = pos + 6;  
                } else {  
                    ch = (char) Integer.parseInt(src  
                            .substring(pos + 1, pos + 3), 16);  
                    tmp.append(ch);  
                    lastPos = pos + 3;  
                }  
            } else {  
                if (pos == -1) {  
                    tmp.append(src.substring(lastPos));  
                    lastPos = src.length();  
                } else {  
                    tmp.append(src.substring(lastPos, pos));  
                    lastPos = pos;  
                }  
            }  
        }  
        return tmp.toString();  
    }  
}
