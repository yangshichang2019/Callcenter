package com.konka.common.solr;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.SolrQuery.ORDER;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;

import com.konka.common.constant.Constant;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoKnow;
import com.konka.job.info.model.InfoSearch;
public class SearchTool {
	private static HttpSolrServer sorlServer = null;
	private static HttpSolrServer askServer = null;
	static{
		sorlServer = new HttpSolrServer(Constant.SOLR_SERVER+"/know");
		sorlServer.setConnectionTimeout(100);
		sorlServer.setDefaultMaxConnectionsPerHost(100);
		sorlServer.setMaxTotalConnections(100);
		
		askServer = new HttpSolrServer(Constant.SOLR_SERVER+"/ask");
		askServer.setConnectionTimeout(100);
		askServer.setDefaultMaxConnectionsPerHost(100);
		askServer.setMaxTotalConnections(100);
	}
	//查询方法
	public static QueryResponse searchSolr(String queryStr, String hightlight,
	    		Page page,String pa,String pb) {
		SolrQuery query = new SolrQuery(queryStr);
		if(page!=null) {
	        query.setStart((page.getNum()-1)*page.getNumPerPage());
	        query.setRows(page.getNumPerPage());
		} else {
			query.setStart(0);
			query.setRows(5);
		}
        query.addFilterQuery("type:"+pa);
        query.addFilterQuery("dir_num:"+pb);
        query.set("defType","edismax");
        query.set("pf","title keywords describe");
        query.set("qf","title^1 keywords^0.3 describe^0.1");
        //设置高亮
        if (null != hightlight&&!"".equals(hightlight)) {
        	query.setHighlight(true); // 开启高亮组件
        	query.addHighlightField(hightlight);// 高亮字段
        	query.setHighlightSimplePre("<font color=\"red\">");// 标记
        	query.setHighlightSimplePost("</font>");
        	query.setHighlightSnippets(1);//结果分片数，默认为1
        	query.setHighlightFragsize(105);//每个分片的最大长度，默认为100
        	query.setHighlightRequireFieldMatch(true);
        }
	    try {
	    	return sorlServer.query(query);
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
	 }
	public static List searchInfoKnow(InfoSearch search,Page page) throws Exception {
		List list = new ArrayList();	
		String key = "";
		//过滤特殊字符
		search.setKeyword(search.getKeyword().replace("?", ""));
		search.setKeyword(search.getKeyword().replace("*", ""));
		if("".equals(search.getKeyword())||search.getKeyword()==null){
			key = "*";
		}else {
			key = search.getKeyword();
		}
		if(search.getDir_num()==null) {
			search.setDir_num("");
		}
		
		QueryResponse qr = searchSolr(key,"title,describe", page,search.getDir_type(),search.getDir_num()+"*");
		if(qr!=null) {
			SolrDocumentList sdoc = qr.getResults();  
			if(sdoc.getNumFound()==0) {
				key = search.getKeyword()+" or "+search.getKeyword()+"* or *"+search.getKeyword()+" or *"+search.getKeyword()+"*";
				qr = searchSolr(key,"title,describe", page,search.getDir_type(),search.getDir_num()+"*");
				if(qr==null) {
					return list;
				}else {
					sdoc = qr.getResults();  
				}
			}
			search.setCount(sdoc.getNumFound());
			if(page!=null) {

				Integer count = Integer.parseInt(sdoc.getNumFound()+"");
				if(count>200) 
					count = 200;
				page.setResult_count(count);
			}
			Map<String, Map<String, List<String>>> hightlighting = qr.getHighlighting();
	        for (SolrDocument doc : sdoc) {  
	        	InfoKnow vo = new InfoKnow();
	            vo.setId(Integer.parseInt(doc.getFieldValue("id").toString()));
	            vo.setNum(doc.getFieldValues("num").toString().substring(1, doc.getFieldValues("num").toString().length()-1));
	            vo.setDir_id(Integer.parseInt(doc.getFieldValue("dir_id").toString()));
	            vo.setKeywords(doc.getFieldValue("keywords").toString());
	            vo.setDestory_time(new Timestamp(new Date(doc.getFieldValue("destory_time").toString()).getTime()));
	            vo.setClick(Integer.parseInt(doc.getFieldValue("click").toString()));
	            vo.setIs_upload(doc.getFieldValues("is_upload").toString());
	            vo.setIs_new(doc.getFieldValue("is_new").toString());
	            vo.setIs_important(doc.getFieldValue("is_important").toString());
	            vo.setGood(Integer.parseInt(doc.getFieldValue("good").toString()));
	            vo.setBad(Integer.parseInt(doc.getFieldValue("bad").toString()));
	            vo.setWeight(Integer.parseInt(doc.getFieldValue("weight").toString()));
	            
	            vo.setCreate_time(new Timestamp(new Date(doc.getFieldValue("create_time").toString()).getTime()));
	            
	            String titles = "";
	            String title = "";
	            String desc = "";
	            if(hightlighting!=null&&!"".equals(search.getKeyword())) {
	            	Map<String, List<String>> numMap = hightlighting.get(doc.getFieldValue("num").toString());
	            	if(numMap.get("title")!=null){
		           		titles = numMap.get("title").toString().substring(1, numMap.get("title").toString().length()-1);
		           		if(numMap.get("describe")!=null){
		           			desc = numMap.get("describe").toString().substring(1, numMap.get("describe").toString().length()-1);
		           		}else{
		           			desc = doc.getFieldValue("describe").toString();
			               	if(desc.length()>110){
			               		desc = desc.substring(1,110);
			               	}
		           		}		            		
		           	}else if(numMap.get("describe")!=null) {
		           		titles = doc.getFieldValue("title").toString();
		           		desc = numMap.get("describe").toString().substring(1, numMap.get("describe").toString().length()-1);
		           	}else {
		           		titles = doc.getFieldValue("title").toString();
		           		desc = doc.getFieldValue("describe").toString();
		           		if(desc.length()>110){
		           			desc = desc.substring(0,110);
		           		}
		           	}
	            }else {
		           	titles = doc.getFieldValue("title").toString();
	            	desc = doc.getFieldValue("describe").toString();
	            	if(desc.length()>110){
	            		desc = desc.substring(0,110);
	            	}
	            }
	            title = doc.getFieldValue("title").toString();
            	vo.setTitle(title);
            	vo.setTitle_s(titles);
            	vo.setDescribe(desc);	
	            list.add(vo);
	        }
		}
		
		return list;
	}
	public static List searchInfoAsk(InfoSearch search,Page page) throws Exception {
		List list = new ArrayList();	
		String key = "";
		//过滤特殊字符
		search.setKeyword(search.getKeyword().replace("?", ""));
		search.setKeyword(search.getKeyword().replace("*", ""));
		if("".equals(search.getKeyword())||search.getKeyword()==null){
			key = "*";
		}else {
			key = search.getKeyword()+" or "+search.getKeyword()+"* or *"+search.getKeyword()+" or *"+search.getKeyword()+"*";
		}
		SolrQuery query = new SolrQuery(key);
		if(page!=null) {
	        query.setStart((page.getNum()-1)*page.getNumPerPage());
	        query.setRows(page.getNumPerPage());
		} else {
			query.setStart(0);
			query.setRows(5);
		}
		if(search.getDir_type().equals("ASK")) {
			query.addFilterQuery("dir_num:"+search.getDir_num()+"*");
		}
        query.set("defType","edismax");
        query.set("pf","title answer");
        query.set("qf","title^1 answer^0.8");
        //设置高亮
        query.setHighlight(true); // 开启高亮组件
        query.addHighlightField("title answer");// 高亮字段
        query.setHighlightSimplePre("<font color=\"red\">");// 标记
        query.setHighlightSimplePost("</font>");
        query.setHighlightSnippets(1);//结果分片数，默认为1
        query.setHighlightFragsize(105);//每个分片的最大长度，默认为100
        QueryResponse qr = null;
	    try {
	    	qr = askServer.query(query);
	    } catch (Exception e) {
	        e.printStackTrace();
	        return null;
	    }
		if(qr!=null) {
			SolrDocumentList sdoc = qr.getResults();  
			//专门搜索问答
			if(search.getDir_type().equals("ASK")) {
				search.setCount(sdoc.getNumFound());
			}
			if(page!=null) {
				Integer count = Integer.parseInt(sdoc.getNumFound()+"");
				if(count>200) 
					count = 200;
				page.setResult_count(count);
			}
			Map<String, Map<String, List<String>>> hightlighting = qr.getHighlighting();
			for (SolrDocument doc : sdoc) {  
	        	InfoAsk vo = new InfoAsk();
	           	vo.setId(Integer.parseInt(doc.getFieldValue("id").toString()));
	           	vo.setDir_num(doc.getFieldValues("dir_num").toString());
	           	vo.setDir_name(doc.getFieldValues("dir_name").toString());
	           	vo.setTitle(doc.getFieldValue("title").toString());
	           	vo.setDir_id(Integer.parseInt(doc.getFieldValue("dir_id").toString()));
	           	vo.setAnswer(doc.getFieldValues("answer").toString());
	           	vo.setAnswer_person(doc.getFieldValues("answer_person").toString());
	           	vo.setAnswer_time(new Timestamp(new Date(doc.getFieldValue("answer_time").toString()).getTime()));
	           	vo.setCreate_time(new Timestamp(new Date(doc.getFieldValue("create_time").toString()).getTime()));
	           	vo.setCreate_employee(doc.getFieldValues("create_employee").toString());
	           	vo.setClick(Integer.parseInt(doc.getFieldValue("click").toString()));
	           	String title = "";
	           	String titles = "";
            	String answer = "";
            	if(hightlighting!=null&&!"".equals(search.getKeyword())) {
            		Map<String, List<String>> numMap = hightlighting.get(doc.getFieldValue("id").toString());
            		if(numMap.get("title")!=null){
	            		titles = numMap.get("title").toString().substring(1, numMap.get("title").toString().length()-1);
	            		if(numMap.get("answer")!=null){
	            			answer = numMap.get("answer").toString().substring(1, numMap.get("answer").toString().length()-1);
	            		}else{
	            			answer = doc.getFieldValue("answer").toString();
		                	if(answer.length()>110){
		                		answer = answer.substring(1,110);
		                	}
	            		}		            		
	            	}else if(numMap.get("answer")!=null) {
	            		titles = doc.getFieldValue("title").toString();
	            		answer = numMap.get("answer").toString().substring(1, numMap.get("answer").toString().length()-1);
	            	}else {
	            		titles = doc.getFieldValue("title").toString();
	            		answer = doc.getFieldValue("answer").toString();
	            		if(answer.length()>110){
	            			answer = answer.substring(0,110);
	            		}
	            	}
            	}else {
            		titles = doc.getFieldValue("title").toString();
            		answer = doc.getFieldValue("answer").toString();
            		if(answer.length()>110){
            			answer = answer.substring(0,110);
            		}
            	}
        		title = doc.getFieldValue("title").toString();
        		vo.setTitle(title);
        		vo.setTitle_s(titles);
        		vo.setAnswer(answer);	
            	list.add(vo);
			}
		}
		return list;
	}
	//增加搜索
	public static void addKnowInfo(InfoKnow knowInfo,InfoDirectory infoDirectory) throws Exception  {
		KnowInfoField fields = new KnowInfoField(knowInfo,infoDirectory);
		sorlServer.addBean(fields);
		sorlServer.commit();
	}
	//删除搜索
	public static void deleteKnowInfo(InfoKnow knowInfo) throws Exception {
		sorlServer.deleteById(knowInfo.getNum());
		sorlServer.commit();
	}
	//更新搜索
	public static void updateKnowInfo(InfoKnow knowInfo,InfoDirectory infoDirectory) throws Exception  {
		deleteKnowInfo(knowInfo);
		addKnowInfo(knowInfo,infoDirectory);
	}
	public static void saveKnowInfo(InfoKnow knowInfo,InfoDirectory infoDirectory,String type) throws Exception  {
		if(type.equals("update")) {
			updateKnowInfo(knowInfo,infoDirectory);
		} else if(type.equals("insert")) {
			addKnowInfo(knowInfo,infoDirectory);
		} else if(type.equals("delete")) {
			deleteKnowInfo(knowInfo);
		}
	}
	//增加搜索
	public static void addInfoAsk(InfoAsk knowAsk,InfoDirectory infoDirectory) throws Exception  {
		InfoAskField fields = new InfoAskField(knowAsk,infoDirectory);
		askServer.addBean(fields);
		askServer.commit();
	}
	//删除搜索
	public static void deleteInfoAsk(InfoAsk knowAsk) throws Exception {
		askServer.deleteById(knowAsk.getId()+"");
		askServer.commit();
	}
	//更新搜索
	public static void updateInfoAsk(InfoAsk knowAsk,InfoDirectory infoDirectory) throws Exception  {
		deleteInfoAsk(knowAsk);
		addInfoAsk(knowAsk,infoDirectory);
	}
	public static void saveInfoAsk(InfoAsk knowAsk,InfoDirectory infoDirectory,String type) throws Exception  {
		if(type.equals("update")) {
			updateInfoAsk(knowAsk,infoDirectory);
		} else if(type.equals("insert")) {
			addInfoAsk(knowAsk,infoDirectory);
		} else if(type.equals("delete")) {
			deleteInfoAsk(knowAsk);
		}
	}
}
