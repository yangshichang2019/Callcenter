package com.konka.common.solr;

import java.sql.Timestamp;

import org.apache.solr.client.solrj.beans.Field;

import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoDirectory;

public class InfoAskField {
	private String id;
	private String dir_num;
	private String dir_name;
	private Integer dir_id;
	private String title;
	private String answer;
	private String answer_person;
	private Timestamp answer_time;
	private Timestamp create_time;
	private String create_employee;
	private Integer click;
	
	public InfoAskField(InfoAsk infoAsk,InfoDirectory infoDirectory){
		this.setId(infoAsk.getId()+"");
		this.setDir_num(infoDirectory.getNum());
		this.setDir_name(infoDirectory.getName());
		this.setDir_id(infoAsk.getDir_id());
		this.setTitle(infoAsk.getTitle());
		this.setAnswer(infoAsk.getAnswer());
		this.setAnswer_person(infoAsk.getAnswer_person());
		this.setAnswer_time(infoAsk.getAnswer_time());
		this.setCreate_time(infoAsk.getCreate_time());
		this.setCreate_employee(infoAsk.getCreate_employee());
		this.setClick(infoAsk.getClick());
	}
	public String getId() {
		return id;
	}
	@Field("id")
	public void setId(String id) {
		this.id = id;
	}
	public String getDir_num() {
		return dir_num;
	}
	@Field("dir_num")
	public void setDir_num(String dir_num) {
		this.dir_num = dir_num;
	}
	public String getDir_name() {
		return dir_name;
	}
	@Field("dir_name")
	public void setDir_name(String dir_name) {
		this.dir_name = dir_name;
	}
	public Integer getDir_id() {
		return dir_id;
	}
	@Field("dir_id")
	public void setDir_id(Integer dir_id) {
		this.dir_id = dir_id;
	}
	public String getTitle() {
		return title;
	}
	@Field("title")
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAnswer() {
		return answer;
	}
	@Field("answer")
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAnswer_person() {
		return answer_person;
	}
	@Field("answer_person")
	public void setAnswer_person(String answer_person) {
		this.answer_person = answer_person;
	}
	public Timestamp getAnswer_time() {
		return answer_time;
	}
	@Field("answer_time")
	public void setAnswer_time(Timestamp answer_time) {
		this.answer_time = answer_time;
	}
	public Timestamp getCreate_time() {
		return create_time;
	}
	@Field("create_time")
	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}
	public String getCreate_employee() {
		return create_employee;
	}
	@Field("create_employee")
	public void setCreate_employee(String create_employee) {
		this.create_employee = create_employee;
	}
	public Integer getClick() {
		return click;
	}
	@Field("click")
	public void setClick(Integer click) {
		this.click = click;
	}
}
