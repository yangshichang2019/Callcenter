package com.konka.common.solr;

import java.sql.Timestamp;

import org.apache.solr.client.solrj.beans.Field;

import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoKnow;

public class KnowInfoField{
	private String id;
	private String num;
	private String dir_num;
	private String type;//目录类型
	private Integer dir_id;
	private String title;//内容标题
	private String keywords;//内容描述
	private String describe;//内容描述
	private Timestamp destory_time;//内容描述
	private Integer click;
	private String is_upload;
	private String is_new;
	private String is_important;
	//满意度
	private Integer good;
	private Integer bad;
	private Integer weight;
	private Timestamp create_time;
	private String create_employee;
	
	public KnowInfoField() {
		
	}
	//初始化
	public KnowInfoField(InfoKnow knowInfo,InfoDirectory infoDirectory) {
		this.setId(knowInfo.getId()+"");
		this.setNum(knowInfo.getNum());
		this.setDir_num(infoDirectory.getNum());
		this.setType(infoDirectory.getType());
		this.setDir_id(knowInfo.getDir_id());
		this.setTitle(knowInfo.getTitle());
		this.setKeywords(knowInfo.getKeywords());
		this.setDescribe(knowInfo.getDescribe());
		this.setDestory_time(knowInfo.getDestory_time());
		this.setClick(knowInfo.getClick());
		this.setIs_upload(knowInfo.getIs_upload());
		this.setIs_new(knowInfo.getIs_new());
		this.setIs_important(knowInfo.getIs_important());
		this.setGood(knowInfo.getGood());
		this.setBad(knowInfo.getGood());
		this.setWeight(knowInfo.getWeight());
		this.setCreate_time(knowInfo.getCreate_time());
		this.setCreate_employee(knowInfo.getCreate_employee());
	}
	
	/**
	 * 操作的对象类型，可能是Message或者Attachment
	 * @return
	 */
	
	public String getType() {
		return type;
	}
	
	@Field("type")
	public void setType(String type) {
		this.type = type;
	}
	
	public String getId() {
		return id;
	}
	@Field
	public void setId(String id) {
		this.id = id;
	}

	public String getNum() {
		return num;
	}
	@Field("num")
	public void setNum(String num) {
		this.num = num;
	}

	public Integer getDir_id() {
		return dir_id;
	}
	@Field("dir_id")
	public void setDir_id(Integer dir_id) {
		this.dir_id = dir_id;
	}


	public String getTitle() {
		return title;
	}
	@Field("title")
	public void setTitle(String title) {
		this.title = title;
	}

	public String getKeywords() {
		return keywords;
	}
	@Field("keywords")
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public String getDescribe() {
		return describe;
	}
	@Field("describe")
	public void setDescribe(String describe) {
		this.describe = describe;
	}

	public String getIs_new() {
		return is_new;
	}
	@Field("is_new")
	public void setIs_new(String is_new) {
		this.is_new = is_new;
	}

	public String getIs_important() {
		return is_important;
	}
	@Field("is_important")
	public void setIs_important(String is_important) {
		this.is_important = is_important;
	}


	public Integer getGood() {
		return good;
	}
	@Field("good")
	public void setGood(Integer good) {
		this.good = good;
	}

	public Integer getBad() {
		return bad;
	}
	@Field("bad")
	public void setBad(Integer bad) {
		this.bad = bad;
	}
	
	public Timestamp getCreate_time() {
		return create_time;
	}
	@Field("create_time")
	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}
	
	public String getDir_num() {
		return dir_num;
	}
	@Field("dir_num")
	public void setDir_num(String dir_num) {
		this.dir_num = dir_num;
	}
	public Timestamp getDestory_time() {
		return destory_time;
	}
	@Field("destory_time")
	public void setDestory_time(Timestamp destory_time) {
		this.destory_time = destory_time;
	}
	public Integer getClick() {
		return click;
	}
	@Field("click")
	public void setClick(Integer click) {
		this.click = click;
	}
	public String getIs_upload() {
		return is_upload;
	}
	@Field("is_upload")
	public void setIs_upload(String is_upload) {
		this.is_upload = is_upload;
	}
	public Integer getWeight() {
		return weight;
	}
	@Field("weight")
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	public String getCreate_employee() {
		return create_employee;
	}
	@Field("create_employee")
	public void setCreate_employee(String create_employee) {
		this.create_employee = create_employee;
	}
}
