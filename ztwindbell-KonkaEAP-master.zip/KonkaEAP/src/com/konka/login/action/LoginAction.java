package com.konka.login.action;

import java.io.Writer;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Tree;
import com.konka.common.tool.Util;
import com.konka.system.model.SessionInfo;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.Right;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;
import com.opensymphony.xwork2.Action;
@Controller
@Scope("prototype")
public class LoginAction extends BaseAction {
	@Autowired
	private UserAdminService userAdminService;
	@Autowired
	private SystemService systemService;
	private String loginType = "";
	private User user = new User();
	private Right right = new Right();
	private String menuStr = "";
	

	private static Integer num = 1;
	private static Map<String,User> authToken = new HashMap<String, User>();
	public String thirdAuth() throws Exception{
		String callback = getRequest().getParameter("callback");
		super.getResponse().setContentType("text/plain;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String s = "";
		if(sessionCheck()) {
			num = num + 1;
			if(num>9999){
				num = 1;
			}
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			String token =Util.MD5(num+"_"+DateTool.formatDate("yyyyMMddHHmmss", new Date())+"_"+user.getUsername());
			authToken.put(token, user);
			s = callback+"({\"statusCode\":\"200\",\"token\":\""+token+"\"})";
		}else {
			s = callback+"({\"statusCode\":\"301\"})";
		}
		out.write(s);
		out.flush();
		out.close();
		return null;
	}
	public String authToken() throws Exception{
		super.getResponse().setContentType("text/plain;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String token = getRequest().getParameter("token");
		User user = (User)authToken.get(token);
		authToken.remove(token);
		String s = "{\"statusCode\":\"200\",\"username\":\""+user.getUsername()+"\",\"fullname\":\""+user.getFullname()+"\"}";
		out.write(s);
		out.flush();
		out.close();
		return null;
	}
	
	/**
	 * 登录首页
	 */
	public String index() throws Exception {
		if(sessionCheck()) {
			List list = (List)super.getSession().get(Constant.SESSION_RIGHT);
			if(list !=null&&list.size()>0) {
				dataList = Tree.getAllSubMenu(list, "");
				if(dataList.size()>0) {
					Right tempRight = (Right)dataList.get(0);
					menuStr = Tree.getLeftMenuTree(list,tempRight.getId());
				}
				user = (User)super.getSession().get(Constant.SESSION_USER);
				return "index";
			}
			super.getRequest().getSession().invalidate();
		}else {
			if(user.getUsername()!=null&&!user.getUsername().equals("")&&user.getPassword()!=null&&!user.getPassword().equals("")) {
				user = userAdminService.getUserForLogin(user);
				if(user!=null) {
					super.getSession().put(Constant.SESSION_USER, user);
					List list = userAdminService.getUserRight(user);
					if(list!=null&&list.size()>0) {
						super.getSession().put(Constant.SESSION_RIGHT, list);
						dataList = Tree.getAllSubMenu(list, "");
						Right tempRight = (Right)dataList.get(0);
						menuStr = Tree.getLeftMenuTree(list,tempRight.getId());
						Map<String,Right> map = userAdminService.getUserAllow(user);
						super.getSession().put(Constant.SESSION_ALLOW, map);
						Util.echo(user.getUsername()+"从主页登录");
						SessionInfo sessionInfo = new SessionInfo();
						sessionInfo.setSessionId(super.getRequest().getSession().getId());
						sessionInfo.setLoginTime(Util.getTimestamp());
						sessionInfo.setIp(getIpAddr());
						systemService.insertSessionInfo(sessionInfo, user);
						if("dialog".equals(loginType)) {
							return Constant.ACTION_S.ajaxDone.toString();
						}
						return "index";
					}else {
						error = "权限不足！";
						super.getSession().remove(Constant.SESSION_USER);
					}
				}else{
					error = "用户名或密码不正确!";
				}
				if("dialog".equals(loginType)) {
					super.toError(error);
					return Constant.ACTION_S.ajaxDone.toString();
				}
			}
		}
		return Action.LOGIN;
	}
	public boolean openeapLogin() throws Exception {
		String openeap = Util.getCookiesByName(super.getRequest(), "openeap.UserID");
		if(!"".equals(openeap)) {
			UserAdminService service = (UserAdminService)WebApplicationContextUtils.getRequiredWebApplicationContext(ServletActionContext.getServletContext()).getBean("userAdminService");
			List list = service.getAllUserListByUsernames("'"+openeap+"'");
			User user2 = null;
			if(list!=null&&list.size()>0) {
				user2 = (User)list.get(0);
			}else {
				user.setUsername(openeap);
				user = service.getOpeneapUser(user);
				if(user!=null) {
					user.setDept_id(0);
					user.setEmaill("");
					user.setEnable_flag("T");
					service.saveUser(user, user);
					user2 = service.getUserForLogin(user);

				}
			}
			if(user2!=null) {
				super.getSession().put(Constant.SESSION_USER, user2);
				//获取用户权限
				List rightlist = service.getUserRight(user2);
				if(rightlist!=null&&rightlist.size()>0) {
					super.getSession().put(Constant.SESSION_RIGHT, rightlist);
					//获取权限许可
					Map<String,Right> map = service.getUserAllow(user2);
					super.getSession().put(Constant.SESSION_ALLOW, map);	
				}
				Util.echo(user2.getUsername()+"从新太系统登录");
				//从新太登录的session失效时间较快，为了坐席监控更灵敏
				super.getRequest().getSession().setMaxInactiveInterval(90);
				//新建session记录
				SessionInfo sessionInfo = new SessionInfo();
				sessionInfo.setSessionId(super.getRequest().getSession().getId());
				sessionInfo.setLoginTime(Util.getTimestamp());
				sessionInfo.setIp(getIpAddr());
				SystemService service2 = (SystemService)WebApplicationContextUtils.getRequiredWebApplicationContext(ServletActionContext.getServletContext()).getBean("systemService");
				service2.insertSessionInfo(sessionInfo, user2);
				return true;
			}
		}
		return false;
	}
	//窗口登录
	public String dialog() throws Exception{
		return "dialog";
	}
	//获取子菜单
	public String toSubMenu() throws Exception {
		if(sessionCheck()) {
			List list = (List)super.getSession().get(Constant.SESSION_RIGHT);
			menuStr = Tree.getLeftMenuTree(list,right.getParent_id());
			return "toSubMenu";
		}else {
			return "timeOut";
		}

	}
	/**
	 * 退出
	 */
	public String logout() throws Exception {
		//super.getSession().remove(Constant.SESSION_USER);
		//super.getSession().remove(Constant.SESSION_RIGHT);
		super.getRequest().getSession().invalidate();
		return "out";
	}
	/**
	 * session检测
	 */
	public boolean sessionCheck() throws Exception {
		User tempUser = (User)super.getSession().get(Constant.SESSION_USER);
		if(tempUser == null) {
			return false;
		}else {
			return true;		
		}
	}
	/**
	 * 获得请求的主机的真实IP
	 */
	public String getIpAddr() throws Exception{    
	    String ip = super.getRequest().getHeader("x-forwarded-for");    
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {    
	        ip = super.getRequest().getHeader("Proxy-Client-IP");    
	    }    
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {    
	        ip = super.getRequest().getHeader("WL-Proxy-Client-IP");    
	    }    
	    if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {    
	        ip = super.getRequest().getRemoteAddr();    
	    }    
	    if(ip==null) {
	    	ip="无法识别";
	    }
	    return ip;    
	} 	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getMenuStr() {
		return menuStr;
	}
	public void setMenuStr(String menuStr) {
		this.menuStr = menuStr;
	}
	public Right getRight() {
		return right;
	}
	public void setRight(Right right) {
		this.right = right;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public String getLoginType() {
		return loginType;
	}
	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}
}
