package com.konka.database.dao;

import com.konka.common.base.BaseDAO;

public interface AreaCsmDAO extends BaseDAO {

}
