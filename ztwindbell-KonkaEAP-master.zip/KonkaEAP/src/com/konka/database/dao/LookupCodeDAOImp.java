package com.konka.database.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.database.model.LookupCode;
@Repository("lookupCodeDAO")
public class LookupCodeDAOImp extends BaseDAOImp implements LookupCodeDAO {
	public LookupCodeDAOImp() {
		super.setMapper("com.konka.database.model.LookupCode");
	}
	//�������
	public List getLookupCodeForCache() throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper() + ".getLookupCodeForCache");
	}
}
