package com.konka.database.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.database.model.LookupCode;

public interface LookupCodeDAO extends BaseDAO {
	//�������
	public List getLookupCodeForCache() throws Exception;
}
