package com.konka.database.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("areaDAO")
public class AreaDAOImp extends BaseDAOImp implements AreaDAO{
	public AreaDAOImp(){
		super.setMapper("com.konka.database.model.Area");
	}

}
