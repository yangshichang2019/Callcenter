package com.konka.database.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;

public interface ConsultAreaDAO extends BaseDAO {
}
