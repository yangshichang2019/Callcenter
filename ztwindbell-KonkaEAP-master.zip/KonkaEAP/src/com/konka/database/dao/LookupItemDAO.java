package com.konka.database.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.database.model.LookupCode;
import com.konka.database.model.LookupItem;

public interface LookupItemDAO extends BaseDAO {
	public List getLookupCodeItemList(LookupItem lookupItem) throws Exception;
	public List getAllListByCode(LookupCode lookupCode) throws Exception;
}
