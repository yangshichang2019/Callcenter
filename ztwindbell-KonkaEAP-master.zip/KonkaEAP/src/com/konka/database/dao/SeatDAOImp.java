package com.konka.database.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("seatDAO")
public class SeatDAOImp extends BaseDAOImp implements SeatDAO {
	public SeatDAOImp() {
		super.setMapper("com.konka.database.model.Seat");
	}
	public List getAllListForOpeneap() throws Exception {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getAllListForOpeneap");
	}
}
