package com.konka.database.dao;


import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;

@Repository("SeriesDAO")
public class SeriesDAOImp extends BaseDAOImp implements SeriesDAO {
	public SeriesDAOImp() {
		super.setMapper("com.konka.database.model.Series");
	}

}
