package com.konka.database.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;

public interface SeatDAO extends BaseDAO {
	public List getAllListForOpeneap() throws Exception;
}
