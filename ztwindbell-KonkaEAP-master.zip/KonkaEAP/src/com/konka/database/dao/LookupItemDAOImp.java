package com.konka.database.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.database.model.LookupCode;
import com.konka.database.model.LookupItem;
@Repository("lookupItemDAO")
public class LookupItemDAOImp extends BaseDAOImp implements LookupItemDAO {
	public LookupItemDAOImp() {
		super.setMapper("com.konka.database.model.LookupItem");
	}
	public List getLookupCodeItemList(LookupItem lookupItem) throws Exception {
		return super.getSqlSessionTemplate().selectList(super.getMapper() + ".getLookupCodeItemList", lookupItem);
	}
	public List getAllListByCode(LookupCode lookupCode) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper() + ".getAllListByCode", lookupCode);
	}
}
