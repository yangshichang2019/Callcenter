package com.konka.database.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("areaCsmDAO")
public class AreaCsmDAOImp extends BaseDAOImp implements AreaCsmDAO {
	public AreaCsmDAOImp(){
		super.setMapper("areaCsm");
	}
}
