package com.konka.database.dao;


import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("consultareaDAO")
public class ConsultAreaDAOImp extends BaseDAOImp implements ConsultAreaDAO {
	public ConsultAreaDAOImp() {
		super.setMapper("com.konka.database.model.ConsultArea");
	}

}
