package com.konka.database.action;

import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.init.LoadCache;
import com.konka.common.tool.RWProperties;
import com.konka.common.tool.Tree;
import com.konka.common.tool.Util;
import com.konka.common.tool.mail.MailInfo;
import com.konka.common.tool.mail.MailTool;
import com.konka.database.model.Area;
import com.konka.database.model.AreaCsm;
import com.konka.database.model.ConfigInfo;
import com.konka.database.model.ConsultArea;
import com.konka.database.model.LookupCode;
import com.konka.database.model.LookupItem;
import com.konka.database.model.Seat;
import com.konka.database.model.Series;
import com.konka.database.service.DataBaseService;
import com.konka.useradmin.model.User;
@Controller
@Scope("prototype")
public class DataBaseAction extends BaseAction {
	@Autowired
	private DataBaseService dataBaseService;
	@Autowired
	private LoadCache loadCache;
	private String type;
	private String toAddress;
	private LookupCode lookupCode = new LookupCode();
	private LookupItem lookupItem = new LookupItem();
	private ConfigInfo configInfo = new ConfigInfo();
	private Area area = new Area();
	private Seat seat = new Seat();
	private AreaCsm areaCsm = new AreaCsm();
	private Series series = new Series();
	private ConsultArea consultArea = new ConsultArea();
	private String param;
	private String param2;
	
	
	//获取编码列表
	public String toLookupCodeList() throws Exception {
		dataList = dataBaseService.getLookupCodeList(lookupCode,page);
		return "toLookupCodeList";
	}
	//添加编码
	public String toAddEditLookupCode() throws Exception {
		if(lookupCode.getId()!=null&&lookupCode.getId()>0) {
			lookupCode = dataBaseService.getLookupCodeInfo(lookupCode);
		}
		return "toAddEditLookupCode";
	}
	//保存编码
	public String toSaveLookupCode() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		if(dataBaseService.isExistLookupCode(lookupCode)) {
			super.toError("编码名称或引用编码已存在！");
		} else {
			dataBaseService.saveLookupCode(lookupCode,user);
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除编码（软）
	public String toDeleteLookupCode() throws Exception {
		lookupItem.setParent_id(lookupCode.getId());
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		dataList = dataBaseService.getAllLookupCodeItemList(lookupItem);
		if(dataList!=null&&dataList.size()>0) {
			super.toError("存在编码项不能删除");
		}else{
			dataBaseService.deleteLookupCode(lookupCode,user);
		}
		this.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//进入编码项列表
	public String toLookupCodeItemList() throws Exception {
		lookupCode.setId(lookupItem.getParent_id());
		lookupCode = dataBaseService.getLookupCodeInfo(lookupCode);
		dataList = dataBaseService.getAllLookupCodeItemList(lookupItem);
		return "toLookupCodeItemList";
	}
	//新建编辑编码项
	public String toAddEditLookupItem() throws Exception {
		if(lookupItem.getId()!=null&&lookupItem.getId()>0) {
			lookupItem = dataBaseService.getLookupItemInfo(lookupItem);
		}
		return "toAddEditLookupItem";
	}
	//保存编码项
	public String toSaveLookupItem() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		if(dataBaseService.isExistLookupItem(lookupItem)) {
			super.toError("存在相同编码项！");
		}else {
			dataBaseService.saveLookupItem(lookupItem,user);
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除编码项
	public String toDeleteLookupItem() throws Exception {
		dataBaseService.deleteLookupItem(lookupItem);
		this.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//进去配置页面
	public String toConfigInfoList() throws Exception {
		RWProperties properties = new RWProperties(Constant.CONFIG_PROPERTIES);
		List<ConfigInfo> list =  properties.loadAllKeyAndValue();
		for(int i=0;i<list.size();i++) {
			ConfigInfo vo = (ConfigInfo)list.get(i);
			int m = vo.getKey().indexOf("][");
			int r = vo.getKey().length();
			if(m<0) {
				vo.setParent("");
				vo.setKey(vo.getKey().substring(7, r-1));
			}else {
				Util.echo(vo.getKey());
				vo.setParent(vo.getKey().substring(7, m));
				vo.setKey(vo.getKey().substring(m+2, r-1));
			}
			dataList.add(vo);
		}
		return "toConfigInfoList";
	}
	//刷新缓存
	public String reLoadCache() throws Exception {
		return "reLoadCache";
	}
	//执行刷新
	public String doLoadCache() throws Exception {
		if("Lookup".equals(type)) {
			loadCache.loadLookupCode();
		}else if("Config".equals(type)) {
			loadCache.loadConfigCache();
		}else if("Dept".equals(type)) {
			loadCache.loadDeptCache();
		}else if("User".equals(type)) {
			loadCache.loadUserCache();
		}else if("Info".equals(type)){
			loadCache.loadInfoCache();
		}
		this.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//发送测试邮件
	public String sendTestMail() throws Exception {
		if(!MailTool.sendMail("text",toAddress,"这是一封测试邮件！"+Util.getTimestamp(),"测试邮件发送功能！"+Util.getTimestamp())){
			super.toError("邮件发送失败！");
		}
		this.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	

	//进入地区列表
	public String toAreaList() throws Exception {
		return "toAreaList";
	}
	//查看地区
	public String toViewArea() throws Exception {
		area = dataBaseService.getAreaInfo(area);
		return "toViewArea";
	}
	//进入添加修改地区信息
	public String toAddEditArea() throws Exception {
		if(area.getId()!=null&&area.getId()>0) {
			area = dataBaseService.getAreaInfo(area);
		}else {
			if(area.getParent_id()==null) {
				area.setParent_id(0);
			}
		}
		return "toAddEditArea";
	}
	//保存地区信息
	public String toSaveArea() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		dataBaseService.saveArea(area,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//获取子部门JSON
	public String toChildrenArea() throws Exception {
		dataList = dataBaseService.getAllAreaList(area);
		if(area.getNum()==null) {
			area.setNum("");
		}
		if(dataList!=null&&dataList.size()>0) {
			dataList = Tree.treeFilter(dataList, area.getNum());
			super.getResponse().setContentType("text/xml;charset=gbk");
			super.getResponse().setCharacterEncoding("GBK");
			Writer out = super.getResponse().getWriter();
			out.write(Tree.makeTree(dataList,area.getNum(),"subAreaListBox",navTabId,"db_toViewArea","area"));
			out.flush();
			out.close();
		}
		return null;
	}
	//====================================================
	//获取座位列表
	public String toSeatList() throws Exception {
		dataList = dataBaseService.getSeatList(seat,page);
		return "toSeatList";
	}
	//进入新建修改座位
	public String toAddEditSeat() throws Exception {
		if(seat.getId()!=null&&seat.getId()>0) {
			seat = dataBaseService.getSeatInfo(seat);
		}
		return "toAddEditSeat";
	}
	//保存座位
	public String toSaveSeat() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		dataBaseService.saveSeat(seat, user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除工位
	public String toDeleteSeat() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		dataBaseService.deleteSeat(seat,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	

	//获取子CSM地区
	public String toAppGetChildrenAreaCms() throws Exception {
		if(areaCsm.getParent_area_id()==null) {
			areaCsm.setParent_area_id(0);
		}
		dataList = dataBaseService.getAllAreaCsmList(areaCsm);
		super.getResponse().setContentType("text/xml;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String str = "";
		str = "{";
		AreaCsm ac = null;
		for(int i=0;i<dataList.size();i++){
			ac = (AreaCsm)dataList.get(i);
			str = str + "\""+ac.getArea_id()+"\":\""+ac.getArea_desc()+"\"";
			if(i<(dataList.size()-1)) {
				str = str + ",";
			}
		}
		str = str + "}";
		out.write(str);
		out.flush();
		out.close();
		return null;
	}
	//select联动CSM地区
	public String toSelectGetChildrenAreaCms() throws Exception {
		if(areaCsm.getParent_area_id()==null) {
			areaCsm.setParent_area_id(0);
		}
		dataList = dataBaseService.getAllAreaCsmList(areaCsm);
		super.getResponse().setContentType("text/xml;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String str = "";
		str = "[";
		AreaCsm ac = null;
		for(int i=0;i<dataList.size();i++){
			ac = (AreaCsm)dataList.get(i);
			str = str + "[\""+ac.getArea_id()+"\",\""+ac.getArea_desc()+"\"]";
			if(i<(dataList.size()-1)) {
				str = str + ",";
			}
		}
		str = str + "]";
		out.write(str);
		out.flush();
		out.close();
		return null;
	}
	
	
	
	public String getSeriesListForRepair() throws Exception {
		
		if(param!=null&&series.getParent_series_id()==null){
			series.setSeries_name(param);
			series.setParent_series_id(null);
		}
		
		if(param2!=null&&series.getParent_series_id()==null){
			if(param!=null){
				if(!param.equals("")){
				}else{
					if(!param2.equals("")){
						series.setParent_series_id(Integer.parseInt(param2));
					}else{
						series.setParent_series_id(-1);
					}
				}
			}
		}
		dataList = dataBaseService.getAllSeriesList(series);
		Series ser = new Series();
		ser.setSeries_name("不详");
		ser.setSeries_id(-2);
		ser.setHas_children_flag("F");
		if(dataList.size()>1||dataList.size()==0){
			dataList.add(ser);
		}
		
		if(dataList.size()>0) {
			super.getResponse().setContentType("text/plain;charset=utf-8");
			super.getResponse().setCharacterEncoding("UTF-8");
			Writer out = super.getResponse().getWriter();
			out.write(Tree.makeTree3(dataList,""));
			out.flush();
			out.close();
		}
		return null;
	}
	
	
	public String getAreaListForRepair() throws Exception {
		if(consultArea.getParent_area_id()==null&&param==null){
			consultArea.setParent_area_id(100);
			dataList = dataBaseService.getAllConsultAreaList(consultArea);
		}else if(consultArea.getParent_area_id()!=null){
			dataList = dataBaseService.getAllConsultAreaList(consultArea);
		}else if(consultArea.getParent_area_id()==null&&param!=null){
			if(!param.equals("")){
				consultArea.setArea_desc(param);
				dataList = dataBaseService.getAllConsultAreaList(consultArea);
			}else{
				consultArea.setParent_area_id(100);
				dataList = dataBaseService.getAllConsultAreaList(consultArea);
			}
		}
		ConsultArea con = new ConsultArea();
		con.setArea_desc("不详");
		con.setArea_id(-3);
		con.setArea_level(2);
		if(dataList.size()>1||dataList.size()==0){
			dataList.add(con);
		}
		
		if(dataList.size()>0) {
			super.getResponse().setContentType("text/plain;charset=utf-8");
			super.getResponse().setCharacterEncoding("UTF-8");
			Writer out = super.getResponse().getWriter();
			out.write(Tree.makeTree2(dataList,""));
			out.flush();
			out.close();
		}
		return null;
	}
	

	public LookupCode getLookupCode() {
		return lookupCode;
	}
	public void setLookupCode(LookupCode lookupCode) {
		this.lookupCode = lookupCode;
	}
	public LookupItem getLookupItem() {
		return lookupItem;
	}
	public void setLookupItem(LookupItem lookupItem) {
		this.lookupItem = lookupItem;
	}
	public ConfigInfo getConfigInfo() {
		return configInfo;
	}
	public void setConfigInfo(ConfigInfo configInfo) {
		this.configInfo = configInfo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getToAddress() {
		return toAddress;
	}
	public void setToAddress(String toAddress) {
		this.toAddress = toAddress;
	}
	public Area getArea() {
		return area;
	}
	public void setArea(Area area) {
		this.area = area;
	}
	public Seat getSeat() {
		return seat;
	}
	public void setSeat(Seat seat) {
		this.seat = seat;
	}
	public AreaCsm getAreaCsm() {
		return areaCsm;
	}
	public void setAreaCsm(AreaCsm areaCsm) {
		this.areaCsm = areaCsm;
	}
	public Series getSeries() {
		return series;
	}
	public void setSeries(Series series) {
		this.series = series;
	}
	public ConsultArea getConsultArea() {
		return consultArea;
	}
	public void setConsultArea(ConsultArea consultArea) {
		this.consultArea = consultArea;
	}
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
	public String getParam2() {
		return param2;
	}
	public void setParam2(String param2) {
		this.param2 = param2;
	}
	
	
}
