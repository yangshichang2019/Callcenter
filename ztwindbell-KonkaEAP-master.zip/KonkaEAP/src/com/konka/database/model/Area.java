package com.konka.database.model;

import com.konka.common.base.TreeVO;

public class Area extends TreeVO {

}
