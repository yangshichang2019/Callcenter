package com.konka.database.model;

import com.konka.common.base.BaseVO;

public class LookupCode extends BaseVO {
	private Integer id;
	private String name;
	private String code;
	private String module;
	private LookupItem lookupItem = new LookupItem();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getModule() {
		return module;
	}
	public void setModule(String module) {
		this.module = module;
	}
	public LookupItem getLookupItem() {
		return lookupItem;
	}
	public void setLookupItem(LookupItem lookupItem) {
		this.lookupItem = lookupItem;
	}
}
