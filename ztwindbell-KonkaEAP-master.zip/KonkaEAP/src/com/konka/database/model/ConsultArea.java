package com.konka.database.model;

import com.konka.common.base.BaseVO;


public class ConsultArea extends BaseVO {
	private Integer area_id;
	private String area_desc;
	private Integer parent_area_id;
	private Integer area_level;
	public Integer getArea_id() {
		return area_id;
	}
	public void setArea_id(Integer area_id) {
		this.area_id = area_id;
	}
	public String getArea_desc() {
		return area_desc;
	}
	public void setArea_desc(String area_desc) {
		this.area_desc = area_desc;
	}
	public Integer getParent_area_id() {
		return parent_area_id;
	}
	public void setParent_area_id(Integer parent_area_id) {
		this.parent_area_id = parent_area_id;
	}
	public Integer getArea_level() {
		return area_level;
	}
	public void setArea_level(Integer area_level) {
		this.area_level = area_level;
	}
}
