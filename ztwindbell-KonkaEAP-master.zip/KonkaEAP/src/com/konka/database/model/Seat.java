package com.konka.database.model;

import com.konka.common.base.BaseVO;

public class Seat extends BaseVO {
	private Integer id;
	private String area;
	private String name;
	private String postion;
	private String ip;
	private String mac;
	private String in_phone;
	private String out_phone;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getMac() {
		return mac;
	}
	public void setMac(String mac) {
		this.mac = mac;
	}
	public String getIn_phone() {
		return in_phone;
	}
	public void setIn_phone(String in_phone) {
		this.in_phone = in_phone;
	}
	public String getOut_phone() {
		return out_phone;
	}
	public void setOut_phone(String out_phone) {
		this.out_phone = out_phone;
	}
	public String getPostion() {
		return postion;
	}
	public void setPostion(String postion) {
		this.postion = postion;
	}
}
