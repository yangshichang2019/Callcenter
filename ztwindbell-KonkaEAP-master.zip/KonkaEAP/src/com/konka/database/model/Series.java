package com.konka.database.model;

import com.konka.common.base.BaseVO;


public class Series extends BaseVO {
	private Integer series_id;
	private String series_name;
	private Integer parent_series_id;
	private String has_children_flag;
	public Integer getSeries_id() {
		return series_id;
	}
	public void setSeries_id(Integer series_id) {
		this.series_id = series_id;
	}
	
	public String getSeries_name() {
		return series_name;
	}
	public void setSeries_name(String series_name) {
		this.series_name = series_name;
	}
	public Integer getParent_series_id() {
		return parent_series_id;
	}
	public void setParent_series_id(Integer parent_series_id) {
		this.parent_series_id = parent_series_id;
	}
	public String getHas_children_flag() {
		return has_children_flag;
	}
	public void setHas_children_flag(String has_children_flag) {
		this.has_children_flag = has_children_flag;
	}
	
	
	
}
