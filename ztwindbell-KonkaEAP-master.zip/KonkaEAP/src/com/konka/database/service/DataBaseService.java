package com.konka.database.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.database.model.Area;
import com.konka.database.model.AreaCsm;
import com.konka.database.model.ConsultArea;
import com.konka.database.model.LookupCode;
import com.konka.database.model.LookupItem;
import com.konka.database.model.Seat;
import com.konka.database.model.Series;
import com.konka.sales.product.model.ProductClass;
import com.konka.useradmin.model.User;

public interface DataBaseService {
	public List getLookupCodeList(LookupCode lookupCode, Page page) throws Exception;
	public LookupCode getLookupCodeInfo(LookupCode lookupCode) throws Exception;
	public void deleteLookupCode(LookupCode lookupCode,User user) throws Exception;
	public List getLookupCodeForCache() throws Exception;
	public boolean isExistLookupCode(LookupCode lookupCode) throws Exception;
	public void saveLookupCode(LookupCode lookupCode,User user) throws Exception;
	
	public List getAllLookupCodeItemList(LookupItem lookupItem) throws Exception;
	public LookupItem getLookupItemInfo(LookupItem lookupItem) throws Exception;
	public void deleteLookupItem(LookupItem lookupItem) throws Exception;
	public boolean isExistLookupItem(LookupItem lookupItem) throws Exception;
	public void saveLookupItem(LookupItem lookupItem,User user) throws Exception;
	public List getAllLookupItemByCode(LookupCode lookupCode) throws Exception;
	
	public List getAllAreaList(Area area) throws Exception;
	public Area getAreaInfo(Area area) throws Exception;
	public void saveArea(Area area,User user) throws Exception;
	
	public List getSeatList(Seat seat,Page page) throws Exception;
	public Seat getSeatInfo(Seat seat) throws Exception;
	public void saveSeat(Seat seat,User user) throws Exception;
	public void deleteSeat(Seat seat,User user) throws Exception;
	public List getAllSeatListForOpeneap() throws Exception;
	
	public List getAllAreaCsmList(AreaCsm areaCsm) throws Exception;
	
	public List getAllSeriesList(Series series) throws Exception;
	public List getAllConsultAreaList(ConsultArea consultArea)throws Exception;
}
