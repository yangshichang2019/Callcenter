package com.konka.database.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.database.dao.AreaCsmDAO;
import com.konka.database.dao.AreaDAO;
import com.konka.database.dao.ConsultAreaDAO;
import com.konka.database.dao.LookupCodeDAO;
import com.konka.database.dao.LookupItemDAO;
import com.konka.database.dao.SeatDAO;
import com.konka.database.dao.SeriesDAO;
import com.konka.database.model.Area;
import com.konka.database.model.AreaCsm;
import com.konka.database.model.ConsultArea;
import com.konka.database.model.LookupCode;
import com.konka.database.model.LookupItem;
import com.konka.database.model.Seat;
import com.konka.database.model.Series;
import com.konka.sales.product.dao.ProductClassDAO;
import com.konka.sales.product.model.ProductClass;
import com.konka.useradmin.model.Dept;
import com.konka.useradmin.model.User;
@Service("dataBaseService")
@Transactional 
public class DataBaseServiceImp implements DataBaseService {
	@Autowired
	private LookupCodeDAO lookupCodeDAO;
	@Autowired
	private LookupItemDAO lookupItemDAO;
	@Autowired
	private AreaDAO areaDAO;
	@Autowired
	private SeatDAO seatDAO;
	@Autowired
	private AreaCsmDAO areaCsmDAO;
	@Autowired
	private SeriesDAO seriesDAO;
	@Autowired
	private ConsultAreaDAO consultAreaDAO;
	//获取编码列表
	public List getLookupCodeList(LookupCode lookupCode, Page page) throws Exception {
		return lookupCodeDAO.getObjectList(lookupCode, page);
	}
	//获取编码
	public LookupCode getLookupCodeInfo(LookupCode lookupCode) throws Exception {
		return (LookupCode)lookupCodeDAO.getById(lookupCode.getId());
	}
	//删除编码（软）
	public void deleteLookupCode(LookupCode lookupCode,User user) throws Exception{
		lookupCode.setDelete_flag("T");
		Util.setUpdateToVO(lookupCode, user);
		lookupCodeDAO.update(lookupCode);
	}
	//缓存编码
	public List getLookupCodeForCache() throws Exception {
		return lookupCodeDAO.getLookupCodeForCache();
	}
	//判断编码是否已存在
	public boolean isExistLookupCode(LookupCode lookupCode) throws Exception {
		return lookupCodeDAO.isExist(lookupCode);
	}
	//保存编码
	public void saveLookupCode(LookupCode lookupCode,User user) throws Exception{
		if(lookupCode.getId()==null||lookupCode.getId()==0) {
			Util.setCreateToVO(lookupCode, user);
			lookupCodeDAO.insert(lookupCode);
		}else {
			Util.setUpdateToVO(lookupCode, user);
			lookupCodeDAO.update(lookupCode);
		}
	}
	//获取编码项
	public List getAllLookupCodeItemList(LookupItem lookupItem) throws Exception {
		return lookupItemDAO.getAllList(lookupItem);
	}
	//通过编码获取编码项
	public List getAllLookupItemByCode(LookupCode lookupCode) throws Exception{
		return lookupItemDAO.getAllListByCode(lookupCode);
	}
	//获取编码项
	public LookupItem getLookupItemInfo(LookupItem lookupItem) throws Exception {
		return (LookupItem)lookupItemDAO.getById(lookupItem.getId());
	}
	//删除编码项
	public void deleteLookupItem(LookupItem lookupItem) throws Exception{
		lookupItemDAO.delete(lookupItem.getId());
	}
	//相同编码项验证
	public boolean isExistLookupItem(LookupItem lookupItem) throws Exception {
		return lookupItemDAO.isExist(lookupItem);
	}
	//保存编码项
	public void saveLookupItem(LookupItem lookupItem,User user) throws Exception{
		if(lookupItem.getId()!=null&&lookupItem.getId()>0) {
			Util.setUpdateToVO(lookupItem, user);
			lookupItemDAO.update(lookupItem);
		}else {
			Util.setCreateToVO(lookupItem, user);
			lookupItemDAO.insert(lookupItem);
		}
	}
	//获取全部地区
	public List getAllAreaList(Area area) throws Exception{
		return areaDAO.getAllList(area);
	}
	//获取地区信息
	public Area getAreaInfo(Area area) throws Exception{
		return (Area)areaDAO.getById(area.getId());
	}
	//保存地区信息
	public void saveArea(Area area,User user) throws Exception {
		if(area.getId()!=null&&area.getId()>0) {
			Util.setUpdateToVO(area, user);
			areaDAO.update(area);
		} else {
			Area vo = getNewArea(area);
			if(area.getParent_id()==0) {
				if(vo==null) {
					area.setNum("001");
				}else {
					area.setNum(Util.getNextNum(vo.getNum(), 3));
				}
			}else {
				if(vo==null) {
					Area tempVO = new Area();
					tempVO.setId(area.getParent_id());
					tempVO = getAreaInfo(tempVO);
					area.setNum(tempVO.getNum() + "001");
				}else {
					area.setNum(Util.getNextNum(vo.getNum(), vo.getNum().length()));
				}
			}
			Util.setCreateToVO(area, user);
			areaDAO.insert(area);
		}
	}
	//获取最新同级
	public Area getNewArea(Area area) throws Exception {
		return (Area)areaDAO.getNewObject(area);
	}
	//==========================================================
	public List getSeatList(Seat seat,Page page) throws Exception{
		return seatDAO.getObjectList(seat, page);
	}
	public Seat getSeatInfo(Seat seat) throws Exception{
		return (Seat)seatDAO.getById(seat.getId());
	}
	public void saveSeat(Seat seat,User user) throws Exception{
		if(seat.getId()!=null&&seat.getId()>0) {
			Util.setUpdateToVO(seat, user);
			seatDAO.update(seat);
		} else {
			Util.setCreateToVO(seat, user);
			seatDAO.insert(seat);
		}
	}
	public void deleteSeat(Seat seat,User user) throws Exception{
		seatDAO.delete(seat.getId());
	}
	public List getAllSeatListForOpeneap() throws Exception {
		return seatDAO.getAllListForOpeneap();
	}
	//==============================================

	public List getAllAreaCsmList(AreaCsm areaCsm) throws Exception {
		return areaCsmDAO.getAllList(areaCsm);
	}
	@Override
	public List getAllSeriesList(Series series) throws Exception {
		return seriesDAO.getAllList(series); 
	}
	@Override
	public List getAllConsultAreaList(ConsultArea consultArea) throws Exception {
		return consultAreaDAO.getAllList(consultArea);
	}
}
