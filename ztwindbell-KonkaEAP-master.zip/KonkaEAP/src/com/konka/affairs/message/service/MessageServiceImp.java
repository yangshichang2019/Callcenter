package com.konka.affairs.message.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.affairs.message.dao.MessageDAO;
import com.konka.affairs.message.dao.ReceiverDAO;
import com.konka.affairs.message.dao.WriterDAO;
import com.konka.affairs.message.model.Message;
import com.konka.affairs.message.model.Receiver;
import com.konka.affairs.message.model.Writer;
import com.konka.common.tool.Page;
import com.konka.system.dao.UploadFileDAO;
import com.konka.useradmin.model.User;

@Service("MessageService")
@Transactional  
public class MessageServiceImp implements MessageService {
	@Autowired
	private MessageDAO messageDAO;
	@Autowired
	private WriterDAO writerDAO;
	@Autowired
	private ReceiverDAO receiverDAO;

	@Override
	public boolean insertWriter(Writer writer) throws Exception {
		if(writerDAO.insert(writer)==1){
			return true;
		}else{
			return false;
		}
	}

	@Override
	public boolean insertReceiver(List<Receiver> list) throws Exception {
		receiverDAO.insertBatch(list);
			return true;
	}

	@Override
	public boolean insert(Message message) throws Exception {
		if(messageDAO.insert(message)==1){
			return true;
			
		}else{
			
			return false;
		}
	}

	@Override
	public List<Message> getReceiveMessage(Message message, Page page) throws Exception {
		// TODO Auto-generated method stub
		return messageDAO.getReceiveMessage(message,page);
	}

	@Override
	public Message getMessage(int id) throws Exception {
		return messageDAO.getMessage(id);
	}

	@Override
	public List<Message> getSetMessage(Message message, Page page)
			throws Exception {
		return messageDAO.getSetMessage(message, page);
	}

	@Override
	public List<Message> getReceiveRoughMessage(Message msg, Page page) throws Exception {
		// TODO Auto-generated method stub
		return messageDAO.getRoughMessage(msg, page);
	}

	@Override
	public void DelMessage(int id) throws Exception {
		
		messageDAO.DelMessage(id);
		
	}

	@Override
	public String DeleteReceiverMessage(Message message) throws Exception {
		
		return messageDAO.DeleteReceiverMessage(message);
	}

	@Override
	public String DeleteSetMessage(Message message) throws Exception {
		return messageDAO.DeleteSetMessage(message);
	}

	@Override
	public String DeleteRoughMessage(Message message) throws Exception {
		// TODO Auto-generated method stub
		return messageDAO.DeleteRoughMessage(message);
	}

	@Override
	public List<Message> getCollectionMessage(Message message, Page page)
			throws Exception {
		return messageDAO.getCollectionMessage(message, page);
	}

	@Override
	public String DeleteMessage(Message message) throws Exception {
		// TODO Auto-generated method stub
		return messageDAO.DeleteMessage(message);
	}

	@Override
	public String UpdateMessage(Message message) throws Exception {
		return messageDAO.UpdateMessage(message);
	}



	@Override
	public int GetUnreadMessageNum(User user) throws Exception {
		return messageDAO.GetUnreadMessageNum(user);
	}

	@Override
	public void lightStar(User user){
		 try {
			messageDAO.lightStar(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void cancelStar(User user) {
		
		try {
			messageDAO.cancelStar(user);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


	@Override
	public List<Message> getStarMessage(Message message, Page page)
			throws Exception {
		return messageDAO.getStarMessage(message, page);
	}

	@Override
	public String DeleteStarMessage(Message message) throws Exception {
		
		return messageDAO.DeleteStarMessage(message);
	}

	@Override
	public String AddStarMessage(Message message) throws Exception {
		// TODO Auto-generated method stub
		return messageDAO.AddStarMessage(message);
	}

	@Override
	public List<Message> getAllSetMessage(User user) throws Exception {
		
		return messageDAO.getAllSetMessageList(user.getUsername());
	}

	@Override
	public String UpdateHfMessage(Message message) throws Exception {
		return messageDAO.UpdateHfMessage(message);
	}
	
	
	@Override
	public String UndoMessage(Integer id, String username) throws Exception {
	
		try{
			Message message = new Message();
			message.setId(id);
			message.setContent(username);
			if((messageDAO.getReceiver(message)).equals("F")){
				
				messageDAO.UndoMessage(message);
			}
			
		}catch(Exception e){ 
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Message getReceiverMessage(Message message) throws Exception {
		
		return messageDAO.getReceiverMessage(message);
	}



	
}
