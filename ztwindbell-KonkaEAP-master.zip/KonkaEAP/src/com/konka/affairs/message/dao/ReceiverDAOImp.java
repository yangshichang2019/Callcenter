package com.konka.affairs.message.dao;


import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("receiverDAO")
public class ReceiverDAOImp extends BaseDAOImp implements ReceiverDAO {
	public ReceiverDAOImp() {
		super.setMapper("com.konka.affairs.message.model.Receiver");
	}



	@Override
	public void setMessage(String receiver, String copyers, String theme,
			String description, String message_flag, String uploadfiles)
			throws Exception {
	
		
		
	}
	
}
