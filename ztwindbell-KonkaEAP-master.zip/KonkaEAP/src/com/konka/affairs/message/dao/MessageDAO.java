package com.konka.affairs.message.dao;


import java.util.List;

import com.konka.affairs.message.model.Message;
import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.useradmin.model.User;

public interface MessageDAO extends BaseDAO {
	
	
	public List<Message> getReceiveMessage(Message message, Page page) throws Exception ;
	
	public List<Message> getSetMessage(Message message, Page page) throws Exception ;
	
	public Message getMessage(int id) throws Exception;
	
	public Message getReceiverMessage(Message message) throws Exception;
	
	public List<Message> getRoughMessage(Message message, Page page) throws Exception ;
	
	public void DelMessage(int id) throws Exception;
	
	public String DeleteReceiverMessage(Message message)throws Exception;
	
	public String DeleteSetMessage(Message message) throws Exception ;
	
	public String DeleteRoughMessage(Message message)throws Exception;
	
	public String DeleteMessage(Message message)throws Exception;
	
	
	public String DeleteStarMessage(Message message) throws Exception ;
	
	public String UpdateMessage(Message message)throws Exception;
	
	public String UpdateHfMessage(Message message)throws Exception;
	
	public List<Message> getCollectionMessage(Message message, Page page) throws Exception;

	public List<Message> getAllSetMessageList(String  username)throws Exception;
	
	public int GetUnreadMessageNum(User user) throws Exception;
	
	public void lightStar(User user) throws Exception;
	
	public void cancelStar(User user) throws Exception;
	
	
	public String AddStarMessage(Message message) throws Exception ;
	
	public List<Message> getStarMessage(Message message, Page page) throws Exception ;
	
	public String getReceiver(Message message);
	
	public void UndoMessage(Message message);
}
