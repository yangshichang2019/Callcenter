package com.konka.affairs.message.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.useradmin.model.Group;
import com.konka.useradmin.model.Role;
import com.konka.useradmin.model.User;

public interface WriterDAO extends BaseDAO {
	
	public void setMessage(String receiver,String copyers,String theme,String description,String message_flag,String uploadfiles) throws Exception;
	
}
