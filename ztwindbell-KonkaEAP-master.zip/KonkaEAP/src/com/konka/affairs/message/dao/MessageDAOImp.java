package com.konka.affairs.message.dao;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.message.model.Message;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.User;
@Repository("messageDAO")
public class MessageDAOImp extends BaseDAOImp implements MessageDAO {
	public MessageDAOImp() {
		super.setMapper("com.konka.affairs.message.model.Message");
	}


	@Override
	public List<Message> getReceiveMessage(Message message, Page page) throws Exception {
		Util.setPageNum(message, page);
		List<Message> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList1", message);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
		
	}


	@Override
	public Message getMessage(int id) throws Exception {
		return  super.getSqlSessionTemplate().selectOne(super.getMapper()+".getById", id);
	}


	@Override
	public List<Message> getSetMessage(Message message, Page page)
			throws Exception {
		Util.setPageNum(message, page);
		List<Message> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList2", message);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}


	@Override
	public List<Message> getRoughMessage(Message message, Page page)
			throws Exception {
		Util.setPageNum(message, page);
		List<Message> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList3", message);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}


	@Override
	public void DelMessage(int id) throws Exception {
		System.out.println(id);
		super.getSqlSessionTemplate().update(this.getMapper() + ".toDeleteMessage", id);
	}


	@Override
	public String DeleteReceiverMessage(Message message) throws Exception {
		// TODO Auto-generated method stub
		super.getSqlSessionTemplate().update(this.getMapper() + ".deleteReceiver", message);
		return "";
	}


	@Override
	public String DeleteSetMessage(Message message) throws Exception {
		// TODO Auto-generated method stub
		super.getSqlSessionTemplate().update(this.getMapper() + ".deleteWriter", message);
		return "";
	}


	@Override
	public String DeleteRoughMessage(Message message) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".deleteRough", message);
		return "";
	}

	
	@Override
	public String DeleteStarMessage(Message message) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".cancelStarGroup", message);
		return "";
	}
	
	
	
	@Override
	public List<Message> getCollectionMessage(Message message, Page page)
			throws Exception {
		Util.setPageNum(message, page);
		List<Message> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList4", message);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}


	@Override
	public String DeleteMessage(Message message) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".deleteMessage", message);
		return "";
	}


	@Override
	public String UpdateMessage(Message message) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".UpdateMessage", message);
		return null;
	}


	@Override
	public List<Message> getAllSetMessageList(String username) throws Exception {
		List<Message> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".selectAllSetMessageList", username);
		return list;
	}


	@Override
	public int GetUnreadMessageNum(User user) throws Exception {
		String username = user.getUsername();
		return super.getSqlSessionTemplate().selectOne(super.getMapper()+".selectUnreadMessage", username);
	}


	@Override
	public void lightStar(User  user) throws Exception {
			
		super.getSqlSessionTemplate().update(this.getMapper() + ".lightStar", user);
	}


	@Override
	public void cancelStar(User  user) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".cancelStar", user);
		
	}




	@Override
	public List<Message> getStarMessage(Message message, Page page){
		Util.setPageNum(message, page);
		List<Message> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList5", message);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}


	@Override
	public String AddStarMessage(Message message) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".addStarGroup", message);
		return "";
	}


	@Override
	public String UpdateHfMessage(Message message) throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".UpdateHfMessage", message);
		return null;
	}


	@Override
	public String getReceiver(Message message) {
		
		return  super.getSqlSessionTemplate().selectOne(super.getMapper()+".getReceiver", message);
	}


	@Override
	public void UndoMessage(Message message) {
		super.getSqlSessionTemplate().update(this.getMapper() + ".UndoMessage", message);
		
	}


	@Override
	public Message getReceiverMessage(Message message) throws Exception {
		return  super.getSqlSessionTemplate().selectOne(super.getMapper()+".getByReceiver", message);
	}





	

}
