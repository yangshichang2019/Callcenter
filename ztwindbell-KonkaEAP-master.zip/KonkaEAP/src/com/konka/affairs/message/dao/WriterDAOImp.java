package com.konka.affairs.message.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.message.model.Message;
import com.konka.common.base.BaseDAOImp;
import com.konka.useradmin.model.Group;
import com.konka.useradmin.model.Role;
import com.konka.useradmin.model.User;
@Repository("writerDAO")
public class WriterDAOImp extends BaseDAOImp implements WriterDAO {
	public WriterDAOImp() {
		super.setMapper("com.konka.affairs.message.model.Writer");
	}



	@Override
	public void setMessage(String receiver, String copyers, String theme,
			String description, String message_flag, String uploadfiles)
			throws Exception {
		
	}







	
}

