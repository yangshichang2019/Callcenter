package com.konka.affairs.message.dao;


import com.konka.common.base.BaseDAO;

public interface ReceiverDAO extends BaseDAO {
	

	public void setMessage(String receiver,String copyers,String theme,String description,String message_flag,String uploadfiles) throws Exception;
	
	
}
