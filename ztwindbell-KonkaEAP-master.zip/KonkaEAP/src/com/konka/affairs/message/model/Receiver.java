package com.konka.affairs.message.model;


import com.konka.common.base.BaseVO;

public class Receiver extends BaseVO{
	private Integer id;//��������
	private String userName;//����
	private Integer INFO_ID ;//�ż�״̬  T �Ѷ�   Fδ��  C�ݸ�
	private String  is_read;
	private String  enable_flag;

	public String getEnable_flag() {
		return enable_flag;
	}
	public void setEnable_flag(String enable_flag) {
		this.enable_flag = enable_flag;
	}
	private String  delete_flag;//�Ƿ�ɾ��
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getINFO_ID() {
		return INFO_ID;
	}
	public void setINFO_ID(Integer iNFO_ID) {
		INFO_ID = iNFO_ID;
	}
	public String getDelete_flag() {
		return delete_flag;
	}
	public void setDelete_flag(String delete_flag) {
		this.delete_flag = delete_flag;
	}
	
	
	public String getIs_read() {
		return is_read;
	}
	public void setIs_read(String is_read) {
		this.is_read = is_read;
	}
	public Receiver() {
		// TODO Auto-generated constructor stub
	}
	public Receiver(String userName, Integer iNFO_ID, String is_read,
			String delete_flag,String enable_flag) {
		super();
		this.userName = userName;
		INFO_ID = iNFO_ID;
		this.is_read = is_read;
		this.delete_flag = delete_flag;
		this.enable_flag = enable_flag;
	}
	
	
	
}
