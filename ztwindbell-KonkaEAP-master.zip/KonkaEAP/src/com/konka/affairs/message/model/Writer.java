package com.konka.affairs.message.model;


import com.konka.common.base.BaseVO;

public class Writer extends BaseVO{
	private Integer id;//��������
	private String userName;//����
	private Integer INFO_ID ;//�ż�״̬  T �Ѷ�   Fδ��  C�ݸ�
	private String  delete_flag;//�Ƿ�ɾ��
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getINFO_ID() {
		return INFO_ID;
	}
	public void setINFO_ID(Integer iNFO_ID) {
		INFO_ID = iNFO_ID;
	}
	public String getDelete_flag() {
		return delete_flag;
	}
	public void setDelete_flag(String delete_flag) {
		this.delete_flag = delete_flag;
	}
	
	public Writer() {
		// TODO Auto-generated constructor stub
	}
	public Writer( String userName, Integer iNFO_ID,
			String delete_flag) {
		super();
		this.userName = userName;
		INFO_ID = iNFO_ID;
		this.delete_flag = delete_flag;
	}
	
	
	
}
