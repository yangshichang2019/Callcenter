package com.konka.affairs.message.model;


import com.konka.common.base.BaseVO;

public class Message extends BaseVO{
	private Integer id;//��������
	private String message_Type;//����
	private String title ;
	private String  content;
	private String receivers;
	private String copyers;
	private String  delete_flag;//�Ƿ�ɾ��
	private String  d1;
	private  String writer;
	private  String receiver;
	private  String is_Check;
	private  String receiversChina;
	private  String copyersChina;
	private String is_Star;
	private String employee_name;
	private  String  is_Retreat;
	private Integer is_rough;
	
	
	
	public Integer getIs_rough() {
		return is_rough;
	}
	public void setIs_rough(Integer is_rough) {
		this.is_rough = is_rough;
	}
	public String getIs_Retreat() {
		return is_Retreat;
	}
	public void setIs_Retreat(String is_Retreat) {
		this.is_Retreat = is_Retreat;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getIs_Star() {
		return is_Star;
	}
	public void setIs_Star(String is_Star) {
		this.is_Star = is_Star;
	}
	public String getReceiversChina() {
		return receiversChina;
	}
	public void setReceiversChina(String receiversChina) {
		this.receiversChina = receiversChina;
	}
	public String getCopyersChina() {
		return copyersChina;
	}
	public void setCopyersChina(String copyersChina) {
		this.copyersChina = copyersChina;
	}
	
	public String getIs_Check() {
		return is_Check;
	}
	public void setIs_Check(String is_Check) {
		this.is_Check = is_Check;
	}
	public String getD1() {
		return d1;
	}
	public void setD1(String d1) {
		this.d1 = d1;
	}

	
	
	public String getReceiver() {
		return receiver;
	}
	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getMessage_Type() {
		return message_Type;
	}
	public void setMessage_Type(String message_Type) {
		this.message_Type = message_Type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReceivers() {
		return receivers;
	}
	public void setReceivers(String receivers) {
		this.receivers = receivers;
	}
	public String getCopyers() {
		return copyers;
	}
	public void setCopyers(String copyers) {
		this.copyers = copyers;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}

	public String getDelete_flag() {
		return delete_flag;
	}
	public void setDelete_flag(String delete_flag) {
		this.delete_flag = delete_flag;
	}
	
	public Message() {
		// TODO Auto-generated constructor stub
	}
	public Message(Integer id, String content) {
		super();
		this.id = id;
		this.content = content;
	}
	
	
	
	
}
