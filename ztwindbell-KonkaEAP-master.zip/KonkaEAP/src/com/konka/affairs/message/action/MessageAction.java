package com.konka.affairs.message.action;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.affairs.message.model.Message;
import com.konka.affairs.message.model.Receiver;
import com.konka.affairs.message.model.Writer;
import com.konka.affairs.message.service.MessageService;
import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.system.model.UploadFile;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;
@Controller
@Scope("prototype")


public class MessageAction extends BaseAction {
	@Autowired
	private MessageService messageService;
	@Autowired
	private UserAdminService userAdminServince;
	@Autowired
	private SystemService systemServince;
	
	private int id;
	private String read_flag;
	private String uploadfiles;
	private Message msg = new Message();
	Timestamp today ;
	Timestamp yesterday; 
	Timestamp theDaybeforeYesterday ;
	Timestamp threeDaysAgo ;
	int todayflag = 0;
	int yesterdayflag = 0;
	int thedayflag = 0;
	int threeflag = 0;
	int gzflag = 0;
	private String thedayWeek;
	private String threedayWeek;
	private String wflag;
	private String specialFlag;
	
	
	
	
	
	
	
	

	public String getRead_flag() {
		return read_flag;
	}

	public void setRead_flag(String read_flag) {
		this.read_flag = read_flag;
	}
	public String getSpecialFlag() {
		return specialFlag;
	}

	public void setSpecialFlag(String specialFlag) {
		this.specialFlag = specialFlag;
	}

	public String getWflag() {
		return wflag;
	}

	public void setWflag(String wflag) {
		this.wflag = wflag;
	}

	public String getThedayWeek() {
		return thedayWeek;
	}

	public void setThedayWeek(String thedayWeek) {
		this.thedayWeek = thedayWeek;
	}

	public String getThreedayWeek() {
		return threedayWeek;
	}

	public void setThreedayWeek(String threedayWeek) {
		this.threedayWeek = threedayWeek;
	}

	public int getThedayflag() {
		return thedayflag;
	}

	public void setThedayflag(int thedayflag) {
		this.thedayflag = thedayflag;
	}

	public int getThreeflag() {
		return threeflag;
	}

	public void setThreeflag(int threeflag) {
		this.threeflag = threeflag;
	}

	public int getGzflag() {
		return gzflag;
	}

	public void setGzflag(int gzflag) {
		this.gzflag = gzflag;
	}

	public int getTodayflag() {
		return todayflag;
	}

	public void setTodayflag(int todayflag) {
		this.todayflag = todayflag;
	}

	public int getYesterdayflag() {
		return yesterdayflag;
	}

	public void setYesterdayflag(int yesterdayflag) {
		this.yesterdayflag = yesterdayflag;
	}



	public Timestamp getToday() {
		return today;
	}

	public void setToday(Timestamp today) {
		this.today = today;
	}

	public Timestamp getYesterday() {
		return yesterday;
	}

	public void setYesterday(Timestamp yesterday) {
		this.yesterday = yesterday;
	}

	public Timestamp getTheDaybeforeYesterday() {
		return theDaybeforeYesterday;
	}

	public void setTheDaybeforeYesterday(Timestamp theDaybeforeYesterday) {
		this.theDaybeforeYesterday = theDaybeforeYesterday;
	}

	public Timestamp getThreeDaysAgo() {
		return threeDaysAgo;
	}

	public void setThreeDaysAgo(Timestamp threeDaysAgo) {
		this.threeDaysAgo = threeDaysAgo;
	}
	
	
	public Message getMsg() {
		return msg;
	}

	public void setMsg(Message msg) {
		this.msg = msg;
	}

	public String getUploadfiles() {
		return uploadfiles;
	}

	public void setUploadfiles(String uploadfiles) {
		this.uploadfiles = uploadfiles;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public String toWriteMessage() throws Exception{
		if(wflag.equals("W")) {
			msg.setD1("W");
			return "toWriteMessage";
			
		}else if(wflag.equals("H")){
			setMsg(messageService.getMessage(msg.getId()));
			msg.setD1("H");
			return "toWriteMessage";
		}else if(wflag.equals("Z")){
			setMsg(messageService.getMessage(msg.getId()));
			msg.setD1("Z");
			return "toWriteMessage";
		}else{
			System.out.println(getId());
			setMsg(messageService.getMessage(getId()));
			System.out.println(msg.getReceiversChina());
			msg.setD1("R");
			return "toWriteMessage";
		}
	}


	@SuppressWarnings("rawtypes")
	public String toInsertMessage() throws Exception{
		
		//插入消息	
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		List receiverList = null;
		List copyerList = null;
		try{
			if(msg.getD1().equals("H")){
				Message message = new Message();
				message.setId(getId());
				message.setContent(user.getUsername());
				messageService.UpdateHfMessage(message);
			}
			if(!msg.getReceiversChina().equals("")){
				receiverList = userAdminServince.strToUserList(msg.getReceiversChina());
			}
			if(!msg.getCopyersChina().equals("")){
				 copyerList = userAdminServince.strToUserList(msg.getCopyersChina());
			}
				msg.setIs_rough(1);
				msg.setUpdate_dept(0);
				msg.setCreate_time(Util.getTimestamp());
				msg.setCreate_employee(user.getUsername());
				msg.setUpdate_employee(user.getFullname());
				messageService.insert(msg);//插入消息  insertMessage
				messageService.insertWriter( new Writer(user.getUsername(),msg.getId(),"F"));//发件表插入
				List<Receiver> list = new ArrayList<Receiver>();
				//收件人员插入
				for(Object ss: receiverList){
					Receiver	receiver = new Receiver(((User)ss).getUsername(),msg.getId(),"F","F","F");
					receiver.setUpdate_employee(msg.getIs_Retreat());
					list.add(receiver);
				}
				messageService.insertReceiver(list);
				list.clear();
				//ENABLE_FLAG作为是否是抄送
				if(copyerList==null){
				}else{
					for(Object ss: copyerList){
						//抄送人员的插入			
							list.add(new Receiver(((User)ss).getUsername(),msg.getId(),"F","F","T"));
						}
						messageService.insertReceiver(list);
				}
				UploadFile up = new UploadFile();
				up.setCreate_employee(user.getUsername());
				up.setModel("MESSAGE");
				up.setObject_id(0);
				List<Message> setlist =  messageService.getAllSetMessage(user);   
				List<UploadFile> uploadFileList = systemServince.getModelUploadFile(0,"MESSAGE","", user);
				for(UploadFile uf:uploadFileList){
					int flag=0;
					for(Message mes:setlist){
						if(mes.getContent().indexOf(uf.getPath()) != -1){
							flag=1;
						}
					}
					if(flag==0){
						systemServince.deleteUploadFile("MESSAGE","", uf.getPath(), user);
					}
				}
			}catch(Exception e){
				e.printStackTrace();
			}
			return Constant.ACTION_S.ajaxDone.toString();
		}

	

	public String toIframe() throws Exception{
		setMsg(messageService.getMessage(id));
		return "toIframe";
	}
	
	public String  toInsertCgMessage() throws Exception{
		//插入草稿件   
		try{
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			List receiverList = null;
			List copyerList = null;
			if(!msg.getReceiversChina().equals("")){
				receiverList = userAdminServince.strToUserList(msg.getReceiversChina());
			}
			if(!msg.getCopyersChina().equals("")){
				 copyerList = userAdminServince.strToUserList(msg.getCopyersChina());
			}
			msg.setCreate_time(Util.getTimestamp());
			msg.setCreate_employee(user.getFullname());
			msg.setUpdate_dept(1);
			messageService.insert(msg);//插入消息  insertMessage
			messageService.insertWriter(new Writer(user.getUsername(),msg.getId(),"F"));
			}catch(Exception e){
				e.printStackTrace();
			}
			return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toCollectionList() throws Exception{
		
		//查找回收箱
		try{
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			msg.setReceiver(user.getUsername());
			 dataList = messageService.getCollectionMessage(msg,page);
			 dataList = undoUsername(dataList);
			dataList = checkMessageList2(dataList);
		}catch(Exception e ){
			e.printStackTrace();
		}
		return "toCollectionList";
	}
	
	public String toReceiveList() throws Exception{
		try{
			setWeekDate();
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			msg.setReceiver(user.getUsername());
			dataList = messageService.getReceiveMessage(msg,page);
			dataList = checkMessageList(dataList)	;//消除格式问题
		}catch(Exception e ){
			e.printStackTrace();
		}
		return "toReceiveList";
	}
	
	public String toStarList() throws Exception{
		try{
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			msg.setReceiver(user.getUsername());
			dataList = messageService.getStarMessage(msg,page);
			System.out.println(dataList);
			dataList = checkMessageList2(dataList)	;//消除格式问题
		}catch(Exception e ){
			e.printStackTrace();
		}
		return "toStarList";
	}
	
	
	public String toRoughList() throws Exception{
		//查找 草稿箱
		try{
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			msg.setWriter(user.getUsername());
			dataList = messageService.getReceiveRoughMessage(msg,page);
			msg.setWriter("");
			dataList = undoUsername(dataList);
			dataList = checkMessageList2(dataList);
		}catch(Exception e ){
			e.printStackTrace();
		}
		return "toRoughList";
	}
	
	
	
	
	
	
	
	
	
	public String toSetList() throws Exception{
		//发件箱
		try{
			setWeekDate();
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			msg.setWriter(user.getUsername());
			dataList = messageService.getSetMessage(msg,page);
			msg.setWriter("");
			
			dataList = undoUsername(dataList);
			dataList = checkMessageList2(dataList);
		}catch(Exception e ){
			e.printStackTrace();
		}
		return "toSetList";
	}
	

	

	
	public String toFindMemberReceiver() throws Exception{
		//跳转查找员工
		return "toFindMemberReceiver";
	
	}
	
	
	
	
	public String toSpecialMessage() throws Exception{
		//查看收件箱具体某个信件
		
		if(getSpecialFlag().equals("receive")){
			try{
				User user = (User)super.getSession().get(Constant.SESSION_USER);
				setMsg(messageService.getReceiverMessage(new Message(id,user.getUsername())));
				msg.setReceivers(toStringUsername(msg.getReceivers()));
				msg.setCopyers(toStringUsername(msg.getCopyers()));
				if(msg.getIs_rough()==0){
					msg.setD1("hc");
					Message message1 = new Message();
					message1.setId(msg.getId());
					message1.setContent(user.getUsername());
					messageService.UpdateMessage(message1);
					return "toSpecialMessage";
				}
				setMsg(checkMessage(msg));//防止数据造成前台页面变形
				msg.setD1("receive");
				Message message = new Message();
				message.setId(msg.getId());
				message.setContent(user.getUsername());
				//发回执邮件
				if(msg.getIs_Retreat().equals("T")){
					Message msg2 = new Message();
					SimpleDateFormat bartDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss"); 
					Date  date = new Date();
					msg2.setContent(msg.getUpdate_employee()+"已在"+bartDateFormat.format(date)+"查看您标题为--------"+msg.getTitle()+"-------的邮件");
					msg2.setTitle("回执信息");
					msg2.setReceivers(msg.getUpdate_employee()+"["+msg.getCreate_employee()+"]");
					msg2.setUpdate_employee(user.getFullname());
					msg2.setMessage_Type("pleaseselect");
					msg2.setUpdate_dept(0);
					msg2.setIs_rough(0);
					msg2.setCopyers("");
					msg2.setCopyersChina("");
					msg2.setReceiversChina("");
					msg2.setCreate_time(Util.getTimestamp());
					msg2.setCreate_employee(user.getUsername());
					messageService.insert(msg2);//插入消息  insertMessage
					List list = new ArrayList<Receiver>();
					Receiver receiver = new Receiver(msg.getCreate_employee(),msg2.getId(),"F","F","F");
					receiver.setUpdate_employee("F");
					list.add(receiver);
					messageService.insertReceiver(list);
				}
				if(getSpecialFlag().equals("T")&&msg.getIs_Retreat().equals("F")){
					
				}else{
					messageService.UpdateMessage(message);
				}
				
				
			}catch(Exception e){
				e.printStackTrace();
			}
			return "toSpecialMessage";
		}else if(getSpecialFlag().equals("star")){
			try{
				User user = (User)super.getSession().get(Constant.SESSION_USER);
				setMsg(messageService.getReceiverMessage(new Message(id,user.getUsername())));
				msg.setReceivers(toStringUsername(msg.getReceivers()));
				msg.setCopyers(toStringUsername(msg.getCopyers()));
				setMsg(checkMessage(msg));//防止数据造成前台页面变形
				msg.setD1("star");
			}catch(Exception e){
				e.printStackTrace();
			}
			return "toSpecialMessage";
		}else if(getSpecialFlag().equals("set")){
			try{
				User user = (User)super.getSession().get(Constant.SESSION_USER);
				setMsg(messageService.getMessage(id));
				msg.setReceivers(toStringUsername(msg.getReceivers()));
				msg.setCopyers(toStringUsername(msg.getCopyers()));
				setMsg(checkMessage(msg));//防止数据造成前台页面变形
				msg.setD1("set");
			}catch(Exception e){
				e.printStackTrace();
			}
			return "toSpecialMessage";
		}else if(getSpecialFlag().equals("collection")){
			try{
				User user = (User)super.getSession().get(Constant.SESSION_USER);
				setMsg(messageService.getReceiverMessage(new Message(id,user.getUsername())));
				if(msg.getIs_rough()==0){
					msg.setD1("hc");
					return "toSpecialMessage";
				}
				msg.setReceivers(toStringUsername(msg.getReceivers()));
				msg.setCopyers(toStringUsername(msg.getCopyers()));
				setMsg(checkMessage(msg));//防止数据造成前台页面变形
				msg.setD1("collection");
			}catch(Exception e){
				e.printStackTrace();
			}
			return "toSpecialMessage";
		}
		return "toSpecialMessage";
		
	}
	


	public String toDeleteReceiverMessage() throws Exception {
//		删除收件箱信件
		try{
			msg.setValues(ids);
			messageService.DeleteReceiverMessage(msg);
			super.setCallbackType("");
			}catch(Exception e ){
				e.printStackTrace();
			}	
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	
	public String toDeleteSetMessage() throws Exception {
//	删除发件箱信件
		try{
			msg.setValues(ids);
			messageService.DeleteSetMessage(msg);
			super.setCallbackType("");
			}catch(Exception e ){
				e.printStackTrace();
			}	
	
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toDeleteRoughMessage() throws Exception {
//删除草稿箱信件
		try{
			msg.setValues(ids);
			messageService.DeleteRoughMessage(msg);
			super.setCallbackType("");
			}catch(Exception e ){
				e.printStackTrace();
			}	
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public void lightStar() throws Exception{
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		user.setId(getId());
		messageService.lightStar(user);
		
	}
	
	public void Star() throws Exception{
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		user.setId(getId());
		messageService.cancelStar(user);
	}
	
	
	public String toDeleteStarMessage() throws Exception {
		//删除星标邮件
				try{
					User user = (User)super.getSession().get(Constant.SESSION_USER);
					msg.setValues(ids);
					msg.setContent(user.getUsername());
					messageService.DeleteStarMessage(msg);
					super.setCallbackType("");
					}catch(Exception e ){
						e.printStackTrace();
					}	
				return Constant.ACTION_S.ajaxDone.toString();
			}
	
	
	public String toAddStarMessage() throws Exception {
		//删除星标邮件
				try{
					User user = (User)super.getSession().get(Constant.SESSION_USER);
					msg.setValues(ids);
					msg.setContent(user.getUsername());
					messageService.AddStarMessage(msg);
					super.setCallbackType("");
					}catch(Exception e ){
						e.printStackTrace();
					}	
				return Constant.ACTION_S.ajaxDone.toString();
			}
	
	
	public String toDeleteMessage() throws Exception {
//彻底删除信件 回收箱		
		try{
			msg.setValues(ids);
			messageService.DeleteMessage(msg);
			super.setCallbackType("");
			}catch(Exception e ){
				e.printStackTrace();
			}	
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toUndoMessage() throws Exception {
		//撤回邮件	
		
		List receiverList = null;
		List copyerList = null;
				try{
					User user = (User)super.getSession().get(Constant.SESSION_USER);
					String str[] = ids.split(",");
					for(String ss:str){
						setId(Integer.parseInt(ss));
						Message message = messageService.getMessage(id);
						receiverList = userAdminServince.strToUserList(message.getReceiversChina());
						if(!message.getCopyersChina().equals("")){
							copyerList = userAdminServince.strToUserList(message.getCopyersChina());
						}
						
						for(Object s : receiverList){
							messageService.UndoMessage(id, ((User)s).getUsername());
						}
						if(!message.getCopyersChina().equals("")){
							
							for(Object s : copyerList){
								messageService.UndoMessage(id, ((User)s).getUsername());
							}	
							
						}
											
						
					}
					
					super.setCallbackType("");
					}catch(Exception e ){
						e.printStackTrace();
					}	
				return Constant.ACTION_S.ajaxDone.toString();
			}
	
	
	
	public Message checkMessage(Message checkMsg){
		String ss[] = checkMsg.getReceivers().split(",");
		String str = "";
			if(ss.length>5){
				for(int i=0;i<=4;i++){
					str=str+ss[i]+",";
				}
				str=str+".......";
				checkMsg.setReceivers(str);
			}else{
			}
			if(!checkMsg.getCopyers().equals("")){
				String ss1[] = checkMsg.getCopyers().split(",");
				str="";
				if(ss1.length>5){
					for(int i=0;i<=4;i++){
						str=str+ss1[i]+",";
					}
					str=str+".......";
					checkMsg.setCopyers(str);
				}else{
				}
			}
		return checkMsg;
	}	
	
	public List checkMessageList(List checkList){
		for(int i =0 ;i < checkList.size();i++){
			if(((Message)(checkList.get(i))).getTitle().length()>39){
				((Message)(checkList.get(i))).setTitle(((Message)(checkList.get(i))).getTitle().substring(0, 38));
				((Message)(checkList.get(i))).setContent("");
			}else{
				int size = 50-((Message)(checkList.get(i))).getTitle().length();
				if(!((Message)(checkList.get(i))).getContent().equals("")){
					
					if(((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","").length()>size){
						((Message)(checkList.get(i))).setContent((((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","")).substring(0, size-1));
					}else{
						((Message)(checkList.get(i))).setContent((((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","")).substring(0, ((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","").length()-1));
					}
				}
				
			}
		}
		return checkList;
	}	
	//防止页面输出不正常
	public List checkMessageList2(List checkList){
		 for(int i =0 ;i < checkList.size();i++){
			 if(((Message)(checkList.get(i))).getContent()==null){
				 ((Message)(checkList.get(i))).setContent("");
			 }
				if(((Message)(checkList.get(i))).getTitle().length()>50){
					((Message)(checkList.get(i))).setTitle(((Message)(checkList.get(i))).getTitle().substring(0, 38));
					((Message)(checkList.get(i))).setContent("");
				}else{
					int size = 50-((Message)(checkList.get(i))).getTitle().length();
					if(!((Message)(checkList.get(i))).getContent().equals("")){
						
						if(((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","").length()>size){
							((Message)(checkList.get(i))).setContent((((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","")).substring(0, size-1));
						}else{
							((Message)(checkList.get(i))).setContent((((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","")).substring(0, ((Message)(checkList.get(i))).getContent().replaceAll("<.*?>","").length()-1));
						}
					}
					
				}
					String str="";
					String ss[] = ((Message)(checkList.get(i))).getReceivers().split(",");
					System.out.println(ss.length);
					if(ss.length>1){
						str=ss[0]+".......";
					}else{
						str = ss[0];
					}
					
					((Message)(checkList.get(i))).setReceivers(str);
					
			}
		return checkList;
	}

//给页面所需日期赋值	
	private void setWeekDate() {
		Calendar cal=Calendar.getInstance();   
		int y=cal.get(Calendar.YEAR)-1900;   
		int m=cal.get(Calendar.MONTH);    
		int d = cal.get(Calendar.DATE);
		String strDate = y+"-"+m+"-"+d;
		today = new Timestamp(y,m,d,0,0,0,0);
		yesterday = new Timestamp(y,m,d-1,0,0,0,0);
		theDaybeforeYesterday = new Timestamp(y,m,d-2,0,0,0,0);
		threeDaysAgo = new Timestamp(y,m,d-3,0,0,0,0);
		setThedayWeek(DateTool.getWeekOfDate(-2));
		setThreedayWeek(DateTool.getWeekOfDate(-3));
	}
	
public List undoUsername(List usernameList){
		
		for(int i=0 ; i < usernameList.size();i++){
			
			String str = ((Message)usernameList.get(i)).getReceivers();
			if(str.indexOf("#")==-1){
				String[] str1 = str.split(",");
				str="";
				for(String ss:  str1){
					str = str + ss.substring(0, ss.indexOf("["))+",";
				}
				str = str.substring(0, str.length()-1);
			}
			((Message)usernameList.get(i)).setReceivers(str);
		}
		
		return usernameList;
	}
	

private String toStringUsername(String username){
	
	if(!username.equals("")&&(username.indexOf("#")==(-1))){
		String str="";
		String str1[] = username.split(",");
		for(String ss:  str1){
			str = str + ss.substring(0, ss.indexOf("["))+",";
		}
		str = str.substring(0, str.length()-1);
		return str;
	}
	return username;
	
}



}
