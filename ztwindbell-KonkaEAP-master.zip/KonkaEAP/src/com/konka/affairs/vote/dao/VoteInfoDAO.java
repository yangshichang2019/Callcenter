package com.konka.affairs.vote.dao;

import com.konka.affairs.vote.model.VoteInfo;
import com.konka.common.base.BaseDAO;

public interface VoteInfoDAO extends BaseDAO {
	public void updateVoteInfoAttend(VoteInfo voteInfo) throws Exception;
	public void updateVoteInfoForDelete(VoteInfo voteInfo) throws Exception;
}
