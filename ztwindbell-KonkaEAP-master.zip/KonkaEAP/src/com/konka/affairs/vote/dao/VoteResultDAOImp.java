package com.konka.affairs.vote.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("voteResultDAO")
public class VoteResultDAOImp extends BaseDAOImp implements VoteResultDAO {
	public VoteResultDAOImp(){
		super.setMapper("com.konka.affairs.vote.model.VoteResult");
	}
}
