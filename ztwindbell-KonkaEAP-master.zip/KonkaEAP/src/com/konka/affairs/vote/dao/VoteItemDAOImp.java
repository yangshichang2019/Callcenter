package com.konka.affairs.vote.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.vote.model.VoteItem;
import com.konka.affairs.vote.model.VoteResult;
import com.konka.common.base.BaseDAOImp;
@Repository("voteItemDAO")
public class VoteItemDAOImp extends BaseDAOImp implements VoteItemDAO {
	public VoteItemDAOImp(){
		super.setMapper("com.konka.affairs.vote.model.VoteItem");
	}
	public void updateVoteItemNumber(VoteResult voteResult) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateVoteItemNumber", voteResult);
	}
	public void updateVoteItemForDelete(VoteResult voteResult) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateVoteItemForDelete", voteResult);
	}
	public List getAllVoteItemForPaihang(VoteItem voteItem) throws Exception {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getAllVoteItemForPaihang", voteItem);
	}
}
