package com.konka.affairs.vote.dao;

import org.springframework.stereotype.Repository;

import com.konka.affairs.vote.model.VoteInfo;
import com.konka.common.base.BaseDAOImp;
@Repository("voteInfoDAO")
public class VoteInfoDAOImp extends BaseDAOImp implements VoteInfoDAO {
	public VoteInfoDAOImp(){
		super.setMapper("com.konka.affairs.vote.model.VoteInfo");
	}
	public void updateVoteInfoAttend(VoteInfo voteInfo) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateVoteInfoAttend", voteInfo);
	}
	public void updateVoteInfoForDelete(VoteInfo voteInfo) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateVoteInfoForDelete", voteInfo);

	}
}
