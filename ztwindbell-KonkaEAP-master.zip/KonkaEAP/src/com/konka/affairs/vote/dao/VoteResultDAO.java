package com.konka.affairs.vote.dao;

import com.konka.common.base.BaseDAO;

public interface VoteResultDAO extends BaseDAO {

}
