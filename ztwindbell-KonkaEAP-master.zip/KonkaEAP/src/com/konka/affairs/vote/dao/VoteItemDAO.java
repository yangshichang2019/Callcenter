package com.konka.affairs.vote.dao;

import java.util.List;

import com.konka.affairs.vote.model.VoteItem;
import com.konka.affairs.vote.model.VoteResult;
import com.konka.common.base.BaseDAO;

public interface VoteItemDAO extends BaseDAO {
	public void updateVoteItemNumber(VoteResult voteResult) throws Exception;
	public void updateVoteItemForDelete(VoteResult voteResult) throws Exception;
	public List getAllVoteItemForPaihang(VoteItem voteItem) throws Exception;
}
