package com.konka.affairs.vote.service;

import java.util.List;

import com.konka.affairs.vote.model.VoteInfo;
import com.konka.affairs.vote.model.VoteItem;
import com.konka.affairs.vote.model.VoteResult;
import com.konka.common.tool.Page;
import com.konka.useradmin.model.User;

public interface VoteService {
	public List getVoteList(VoteInfo voteInfo,Page page) throws Exception;
	public VoteInfo getVoteInfo(VoteInfo voteInfo) throws Exception;
	public void saveVote(VoteInfo voteInfo,User user) throws Exception;
	public List getAllVoteList(VoteInfo voteInfo) throws Exception;
	public void updateVoteInfoAttend(VoteInfo voteInfo) throws Exception;
	public void updateVoteInfoForDelete(VoteInfo voteInfo) throws Exception;
	
	public void insertVoteItemBatch(List list) throws Exception;
	public List getAllVoteItemList(VoteItem voteItem) throws Exception;
	public void updateVoteItemNumber(VoteResult voteResult) throws Exception;
	public void updateVoteItemForDelete(VoteResult voteResult) throws Exception;
	public List getAllVoteItemForPaihang(VoteItem voteItem) throws Exception;
	
	public VoteResult getVoteResultByVO(VoteResult voteResult) throws Exception;
	public void insertVoteResult(VoteResult voteResult,User user) throws Exception;
	public List getVoteResultList(VoteResult voteResult,Page page) throws Exception;
	public VoteResult getVoteResult(VoteResult voteResult) throws Exception;
	public void deleteVoteResult(VoteResult voteResult) throws Exception;
	
}
