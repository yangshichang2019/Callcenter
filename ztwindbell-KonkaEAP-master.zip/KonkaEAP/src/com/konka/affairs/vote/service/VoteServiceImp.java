package com.konka.affairs.vote.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.affairs.vote.dao.VoteInfoDAO;
import com.konka.affairs.vote.dao.VoteItemDAO;
import com.konka.affairs.vote.dao.VoteResultDAO;
import com.konka.affairs.vote.model.VoteInfo;
import com.konka.affairs.vote.model.VoteItem;
import com.konka.affairs.vote.model.VoteResult;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.User;

@Service("voteService")  
@Transactional 
public class VoteServiceImp implements VoteService {
	@Autowired
	private VoteInfoDAO voteInfoDAO;
	@Autowired
	private VoteItemDAO voteItemDAO;
	@Autowired
	private VoteResultDAO voteResultDAO;
	public List getVoteList(VoteInfo voteInfo,Page page) throws Exception{
		return voteInfoDAO.getObjectList(voteInfo, page);
	}

	public VoteInfo getVoteInfo(VoteInfo voteInfo) throws Exception{
		return (VoteInfo)voteInfoDAO.getById(voteInfo.getId());
	}
	public void saveVote(VoteInfo voteInfo,User user) throws Exception{
		if(voteInfo.getId()!=null&&voteInfo.getId()>0) {
			Util.setUpdateToVO(voteInfo, user);
			voteInfoDAO.update(voteInfo);
		}else {
			Util.setCreateToVO(voteInfo, user);
			voteInfoDAO.insert(voteInfo);
		}
	}
	public void updateVoteInfoAttend(VoteInfo voteInfo) throws Exception{
		voteInfoDAO.updateVoteInfoAttend(voteInfo);
	}

	public List getAllVoteList(VoteInfo voteInfo) throws Exception{
		return voteInfoDAO.getAllList(voteInfo);
	}
	
	public void insertVoteItemBatch(List list) throws Exception {
		voteItemDAO.insertBatch(list);
	}
	public List getVoteResultList(VoteResult voteResult,Page page) throws Exception {
		return voteResultDAO.getObjectList(voteResult, page);
	}
	
	public List getAllVoteItemList(VoteItem voteItem) throws Exception{
		return voteItemDAO.getAllList(voteItem);
	}
	public void updateVoteItemNumber(VoteResult voteResult) throws Exception {
		voteItemDAO.updateVoteItemNumber(voteResult);
	}
	
	public VoteResult getVoteResultByVO(VoteResult voteResult) throws Exception {
		return (VoteResult)voteResultDAO.getByObject(voteResult);
	}
	public void insertVoteResult(VoteResult voteResult,User user) throws Exception{
		Util.setCreateToVO(voteResult, user);
		voteResultDAO.insert(voteResult);
	}
	public VoteResult getVoteResult(VoteResult voteResult) throws Exception {
		return (VoteResult)voteResultDAO.getById(voteResult.getId());
	}
	public void deleteVoteResult(VoteResult voteResult) throws Exception {
		voteResultDAO.delete(voteResult.getId());
	}
	public void updateVoteInfoForDelete(VoteInfo voteInfo) throws Exception {
		voteInfoDAO.updateVoteInfoForDelete(voteInfo);
	}
	public void updateVoteItemForDelete(VoteResult voteResult) throws Exception {
		voteItemDAO.updateVoteItemForDelete(voteResult);
	}
	public List getAllVoteItemForPaihang(VoteItem voteItem) throws Exception {
		return voteItemDAO.getAllVoteItemForPaihang(voteItem);
	}
}
