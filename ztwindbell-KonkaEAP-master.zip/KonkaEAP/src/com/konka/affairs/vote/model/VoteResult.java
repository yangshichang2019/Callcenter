package com.konka.affairs.vote.model;

import java.util.ArrayList;
import java.util.List;

import com.konka.common.base.BaseVO;

public class VoteResult extends BaseVO {
	private Integer id;
	private Integer info_id;
	private String fullname;
	private String result;
	private List resultList = new ArrayList();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public Integer getInfo_id() {
		return info_id;
	}
	public void setInfo_id(Integer info_id) {
		this.info_id = info_id;
	}
	public List getResultList() {
		return resultList;
	}
	public void setResultList(List resultList) {
		this.resultList = resultList;
	}
}
