package com.konka.affairs.vote.model;

import com.konka.common.base.BaseVO;

public class VoteInfo extends BaseVO {
	private Integer id;
	private String title;
	private String des;
	private Integer max_choice;
	private Integer min_choice;
	private String is_public;//�Ƿ񹫿����
	private String is_remark;
	private String begin_time;
	private String over_time;
	private String attend_user;//�ݲ�ʹ��
	
	private Integer have_attend;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public String getIs_public() {
		return is_public;
	}
	public void setIs_public(String is_public) {
		this.is_public = is_public;
	}
	public String getIs_remark() {
		return is_remark;
	}
	public void setIs_remark(String is_remark) {
		this.is_remark = is_remark;
	}
	public String getBegin_time() {
		return begin_time;
	}
	public void setBegin_time(String begin_time) {
		this.begin_time = begin_time;
	}
	public String getOver_time() {
		return over_time;
	}
	public void setOver_time(String over_time) {
		this.over_time = over_time;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAttend_user() {
		return attend_user;
	}
	public void setAttend_user(String attend_user) {
		this.attend_user = attend_user;
	}
	public Integer getHave_attend() {
		return have_attend;
	}
	public void setHave_attend(Integer have_attend) {
		this.have_attend = have_attend;
	}
	public Integer getMax_choice() {
		return max_choice;
	}
	public void setMax_choice(Integer max_choice) {
		this.max_choice = max_choice;
	}
	public Integer getMin_choice() {
		return min_choice;
	}
	public void setMin_choice(Integer min_choice) {
		this.min_choice = min_choice;
	}
}
