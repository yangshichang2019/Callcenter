package com.konka.affairs.vote.action;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.affairs.vote.model.VoteInfo;
import com.konka.affairs.vote.model.VoteItem;
import com.konka.affairs.vote.model.VoteResult;
import com.konka.affairs.vote.service.VoteService;
import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.system.model.Remark;
import com.konka.system.model.UploadFile;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
@Controller
@Scope("prototype")
public class VoteAction extends BaseAction {
	private VoteInfo voteInfo = new VoteInfo();
	private VoteItem voteItem = new VoteItem();
	private VoteResult voteResult = new VoteResult();
	private Remark remark = new Remark();
	@Autowired
	private VoteService voteService;
	@Autowired
	private SystemService systemService;
	private List itemList = new ArrayList(); 
	private List resultList = new ArrayList(); 
	public String toVoteList() throws Exception {
		dataList = voteService.getVoteList(voteInfo,page);
		return "toVoteList";
	}
	public String toAddEditVote() throws Exception {
		if(voteInfo.getId()!=null&&voteInfo.getId()>0) {
			voteInfo = voteService.getVoteInfo(voteInfo);
			voteItem.setInfo_id(voteInfo.getId());
			dataList = voteService.getAllVoteItemList(voteItem);
		}
		return "toAddEditVote";
		
	}
	public String toSaveVote() throws Exception {
		Boolean is_have = false;
		if(voteInfo.getId()==null||voteInfo.getId()==0) {
			if(itemList.size()==0) {
				super.toError("没有投票选项！");
				return Constant.ACTION_S.ajaxDone.toString();
			}else {
				for(int i=0;i<itemList.size();i++){
					if(!(itemList.get(i).toString().equals(""))) {
						is_have = true;
						break;
					}
				}
				if(!is_have) {
					super.toError("没有投票选项！");
					return Constant.ACTION_S.ajaxDone.toString();
				}
			}
		}
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		voteService.saveVote(voteInfo,user);
		//更新附件信息
		try{
			systemService.deleteUserUnuserUploadFile(voteInfo.getDes(),voteInfo.getId(),new UploadFile(0, "VOTE", "toAddEditVote", user.getUsername()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(is_have){
			for(int i=0;i<itemList.size();i++){
				VoteItem vo = new VoteItem();
				if(!(itemList.get(i).toString().equals(""))) {
					vo.setInfo_id(voteInfo.getId());
					vo.setTitle(itemList.get(i).toString());
					dataList.add(vo);
				}
			}
			voteService.insertVoteItemBatch(dataList);
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public String toUserVoteList() throws Exception {
		dataList = voteService.getAllVoteList(voteInfo);
		
		return "toUserVoteList";
		
	}
	public String toUserVote() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		voteResult.setFullname(user.getFullname());
		voteResult.setInfo_id(voteInfo.getId());
		voteResult = voteService.getVoteResultByVO(voteResult);
		//if(voteResult!=null) {
		//	super.toError(voteResult.getFullname()+"("+voteResult.getCreate_employee()+")已于"+voteResult.getCreate_time()+"完成本次投票");
		//	return Constant.ACTION_S.ajaxDone.toString();
		//}
		voteInfo = voteService.getVoteInfo(voteInfo);
		voteItem.setInfo_id(voteInfo.getId());
		dataList = voteService.getAllVoteItemList(voteItem);
		
		//评论列表
		remark.setObject_id(voteInfo.getId());
		remark.setModel("VOTE");
		List remarkList = systemService.getRemarkList(remark, page);
		super.getRequest().setAttribute("remarkList",remarkList);
		
		return "toUserVote";
		
	}
	public String toSaveUserVote() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		voteResult.setFullname(user.getFullname());
		voteResult.setInfo_id(voteInfo.getId());
		voteResult = voteService.getVoteResultByVO(voteResult);
		if(voteResult!=null) {
			super.toError(voteResult.getFullname()+"(工号："+voteResult.getCreate_employee()+")已于"+voteResult.getCreate_time()+"完成本次投票");
			return Constant.ACTION_S.ajaxDone.toString();
		}
		voteInfo = voteService.getVoteInfo(voteInfo);
		String result = "";
		if(resultList.size()<voteInfo.getMin_choice()||resultList.size()>voteInfo.getMax_choice()) {
			super.toError("投票选项选择数量不正确！");
			return Constant.ACTION_S.ajaxDone.toString();
		}else {
			
			for(int i=0;i<resultList.size();i++) {
				result = result + resultList.get(i).toString() +",";
			}
			result = result.substring(0,result.length()-1);
		}
		voteResult = new VoteResult();
		voteResult.setInfo_id(voteInfo.getId());
		voteResult.setFullname(user.getFullname());
		voteResult.setResult(result);
		voteService.insertVoteResult(voteResult,user);
		
		voteService.updateVoteItemNumber(voteResult);
		
		voteService.updateVoteInfoAttend(voteInfo);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public String toVoteResultList() throws Exception {
		dataList = voteService.getVoteResultList(voteResult, page);
		return "toVoteResultList";
		
	}
	public String toDeleteVoteResult() throws Exception {
		voteResult = voteService.getVoteResult(voteResult);
		voteService.deleteVoteResult(voteResult);
		voteService.updateVoteItemForDelete(voteResult);
		voteInfo.setId(voteResult.getInfo_id());
		voteService.updateVoteInfoForDelete(voteInfo);
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public String toVoteItemList() throws Exception {
		dataList = voteService.getAllVoteItemForPaihang(voteItem);
		return "toVoteItemList";
	}
	public String toRemarkList() throws Exception {
		dataList = systemService.getRemarkList(remark, page);
		return "toRemarkList";
	}
	//进入新建评论
	public String toAddRemark() throws Exception {
		voteInfo = voteService.getVoteInfo(voteInfo);
		return "toAddRemark";
	}
	//保存评论
	public String toSaveRemark() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		systemService.insertRemark(remark, user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public VoteInfo getVoteInfo() {
		return voteInfo;
	}
	public void setVoteInfo(VoteInfo voteInfo) {
		this.voteInfo = voteInfo;
	}
	public List getItemList() {
		return itemList;
	}
	public void setItemList(List itemList) {
		this.itemList = itemList;
	}
	public VoteItem getVoteItem() {
		return voteItem;
	}
	public void setVoteItem(VoteItem voteItem) {
		this.voteItem = voteItem;
	}
	public VoteResult getVoteResult() {
		return voteResult;
	}
	public void setVoteResult(VoteResult voteResult) {
		this.voteResult = voteResult;
	}
	public List getResultList() {
		return resultList;
	}
	public void setResultList(List resultList) {
		this.resultList = resultList;
	}
	public Remark getRemark() {
		return remark;
	}
	public void setRemark(Remark remark) {
		this.remark = remark;
	}
}
