package com.konka.affairs.staff.model;

import java.util.Date;

import com.konka.common.base.BaseVO;

public class Attend extends BaseVO  {
    private Integer id;

    private Integer dept_id;

    private String username;

    private String fullname;

    private Date fromedate;

    private Date todate;

    private String leavetype;

    private Double totalday;

    private String reason;

    private String other;

    private String flow;

    private Integer process;

    private Integer auditstatus;

    private String emaill;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getDept_id() {
		return dept_id;
	}

	public void setDept_id(Integer dept_id) {
		this.dept_id = dept_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public Date getFromedate() {
		return fromedate;
	}

	public void setFromedate(Date fromedate) {
		this.fromedate = fromedate;
	}

	public Date getTodate() {
		return todate;
	}

	public void setTodate(Date todate) {
		this.todate = todate;
	}

	public String getLeavetype() {
		return leavetype;
	}

	public void setLeavetype(String leavetype) {
		this.leavetype = leavetype;
	}

	public Double getTotalday() {
		return totalday;
	}

	public void setTotalday(Double totalday) {
		this.totalday = totalday;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getOther() {
		return other;
	}

	public void setOther(String other) {
		this.other = other;
	}

	public String getFlow() {
		return flow;
	}

	public void setFlow(String flow) {
		this.flow = flow;
	}

	public Integer getProcess() {
		return process;
	}

	public void setProcess(Integer process) {
		this.process = process;
	}

	public Integer getAuditstatus() {
		return auditstatus;
	}

	public void setAuditstatus(Integer auditstatus) {
		this.auditstatus = auditstatus;
	}

	public String getEmaill() {
		return emaill;
	}

	public void setEmaill(String emaill) {
		this.emaill = emaill;
	}


  
}