package com.konka.affairs.staff.service;

import java.util.List;

import com.konka.affairs.staff.model.Attend;
import com.konka.common.tool.Page;
import com.konka.useradmin.model.User;

public interface StaffService {

	public List getAttendList(Attend attend, Page page) throws Exception;

	public Attend getAttendInfo(Attend attend) throws Exception;

	public void saveAttend(Attend attend, User suser) throws Exception;

}
