package com.konka.affairs.staff.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.affairs.staff.dao.AttendDAO;
import com.konka.affairs.staff.model.Attend;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.User;



@Service("staffService")  
@Transactional 
public class StaffServiceImp implements StaffService {
	@Autowired
	private AttendDAO attendDAO;
	
	//��ȡ�û��б�
	@Override
	public List getAttendList(Attend attend, Page page) throws Exception {
		return attendDAO.getObjectList(attend, page);
	}

	@Override
	public Attend getAttendInfo(Attend attend) throws Exception {
		
		return (Attend)attendDAO.getById(attend.getId());
	}

	@Override
	public void saveAttend(Attend attend, User suser) throws Exception {
		
		if(attend.getId()==null||attend.getId()==0) {
			Util.setCreateToVO(attend, suser);
			attendDAO.insert(attend);
		}else {
			Util.setUpdateToVO(attend, suser);
			attendDAO.update(attend);
		}
		
	}

}
