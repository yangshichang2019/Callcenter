package com.konka.affairs.staff.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;



import com.konka.affairs.staff.model.Attend;
import com.konka.affairs.staff.service.StaffService;
import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.database.service.DataBaseService;
import com.konka.system.service.SystemService;
import com.konka.system.service.SystemServiceImp;
import com.konka.useradmin.model.User;

@Controller
@Scope("prototype")
public class StaffAction extends BaseAction {
	@Autowired
	public StaffService staffService;
	@Autowired
	public DataBaseService dataBaseService;
	@Autowired
	public SystemServiceImp systemServiceImp;
	
	public Attend attend = new Attend();
	public List attendList = new ArrayList();  
	
	//����
	public String model = "ATTEND";
	
		//����ٵ��б�
		public String toAttendList() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			Util.setCreateToVO(attend, Suser);
			dataList = staffService.getAttendList(attend,page);
			return "toAttendList";
		}
		//��ѯ�ٵ��б�
			public String toSearchAttend() throws Exception {
				dataList = staffService.getAttendList(attend,page);
				return "toSearchAttend";
			}
		//��ѯ������¼
			public String toRecordAttend() throws Exception {
				if(attend.getId()!=null&&attend.getId()>0) {
					dataList = systemServiceImp.getModelRecord(attend.getId(), model);
				}
				return "toRecordAttend";
			}
		//��Ӽٵ�
		public String toAddEditAttend() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			if(attend.getId()!=null&&attend.getId()>0) {
				attend = staffService.getAttendInfo(attend);
				
			}
			return "toAddEditAttend";
		}
		//�鿴�ٵ�
				public String toShowAttend() throws Exception {
					if(attend.getId()!=null&&attend.getId()>0) {
						attend = staffService.getAttendInfo(attend);
					}
					return "toShowAttend";
				}
		//����ٵ�
		public String toSaveAttend() throws Exception {
			
			//���˷Ƿ������������
			int diffDays = getDiffDays(attend.getFromedate(), attend.getTodate());
			if( attend.getTotalday() > diffDays){
				super.toError("�����������ڷ�Χ��");
				super.setCallbackType("");
				return Constant.ACTION_S.ajaxDone.toString();
			}
			
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			String content = "";
			String method = "toSaveAttend"; 
			//�޸Ĳ���
			if(attend.getId()!=null&&attend.getId()>0) {
				Attend tempattend = staffService.getAttendInfo(attend);
//				if(!DateTool.compareDate(	tempattend.getFromedate())) {
//						if(!attend.getFullname().equals(tempattend.getFullname())  || !attend.getFromedate().equals(tempattend.getFromedate()) || !attend.getTodate().equals(tempattend.getTodate()) || !attend.getLeavetype().equals(tempattend.getLeavetype()) || !attend.getTotalday().equals(tempattend.getTotalday()) || !attend.getDept_id().equals(tempattend.getDept_id()) || !attend.getReason().equals(tempattend.getReason()))	{							
//							super.toError("����Ϣ�޷��޸ģ���������Ч����ע˵����");
//							super.setCallbackType("");
//							return Constant.ACTION_S.ajaxDone.toString();
//						}else if (attend.getEnable_flag().equals("F")) {
//							Attend invalidattend = new Attend();
//							invalidattend.setId(attend.getId());
//							invalidattend.setOther(attend.getOther());
//							invalidattend.setEnable_flag(attend.getEnable_flag());
//							attend = invalidattend;
//						}else{
//							super.toError("�������Ч֮���𣬴���Ϣ���޷��޸ģ�");
//							super.setCallbackType("");
//							return Constant.ACTION_S.ajaxDone.toString();
//						}
//				}
				
				//ϵͳ��¼ ��ɼ�¼��ʱ����
				content = compareRecord(attend , tempattend );
			//��������
			}else{
				
				//ϵͳ��¼ ��ɼ�¼��ʱ����
				content = "��ӣ�" + dateToString(attend.getFromedate())+" ~ "+dateToString(attend.getTodate())+" "+attend.getFullname()+" "+toLeaveType(attend)+" "+attend.getTotalday()+" ��" ;
			}
			staffService.saveAttend(attend,Suser);
			
			//ϵͳ��¼����
			systemServiceImp.insertRecord(attend.getId(), model, method, content, Suser);
			
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
		//ϵͳ��¼
		public String compareRecord(Attend attend , Attend tempattend) {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);

			String content = "";

				if(!attend.getFromedate().equals(tempattend.getFromedate())){
					content += "�޸Ŀ�ʼ���ڣ�"+dateToString(tempattend.getFromedate())+" �� "+dateToString(attend.getFromedate()) +"��";
				}
				if(!attend.getTodate().equals(tempattend.getTodate())){
					content += "�޸Ľ������ڣ�"+dateToString(tempattend.getTodate())+" �� "+dateToString(attend.getTodate())  +"��";
				}
				if(!attend.getLeavetype().equals(tempattend.getLeavetype())){
					content += "�޸�������ͣ�"+toLeaveType(tempattend)+" �� "+toLeaveType(attend) +"��";
				}
				if(!attend.getTotalday().equals(tempattend.getTotalday())){
					content += "�޸�����"+tempattend.getTotalday()+" �� "+attend.getTotalday() +"��";
				}
				if(!attend.getDept_id().equals(tempattend.getDept_id())){
					content += "�޸Ĳ��ţ�"+tempattend.getDept_id()+" �� "+attend.getDept_id() +"��";
				}
				if(!attend.getReason().equals(tempattend.getReason())){
					content += "�޸����ɣ�"+tempattend.getReason()+" �� "+attend.getReason() +"��";
				}
				if(!attend.getOther().equals(tempattend.getOther())){
					content += "�޸ı�ע��"+tempattend.getOther()+" ��"+attend.getOther() +"��";
				}
				if(!attend.getEnable_flag().equals(tempattend.getEnable_flag())){
					if(attend.getEnable_flag().equals("F")){
						content += "�޸�״̬������" +"��";
					}else{
						content += "�޸�״̬������" +"��";
					}
					
				}
				

			return content;
			
			
		}
		
		public static String dateToString( Date date ) {
			SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
			String dateStr=sdf.format(date);
			return dateStr;
			
		}
		
		public static String toLeaveType( Attend attend ){
			String leaveType = "";
			if(attend.getLeavetype().equals("casualleave")){
				leaveType = "�¼�";
			}else if(attend.getLeavetype().equals("sickleave")){
				leaveType = "����";
			}else if(attend.getLeavetype().equals("annulleave")){
				leaveType = "���ݼ�";
			}else if(attend.getLeavetype().equals("marriageleave")){
				leaveType = "���";
			}else if(attend.getLeavetype().equals("workinjuryleave")){
				leaveType = "���˼�";
			}else if(attend.getLeavetype().equals("funeralleave")){
				leaveType = "ɥ��";
			}else if(attend.getLeavetype().equals("childbearingleave")){
				leaveType = "���";
			}else if(attend.getLeavetype().equals("other")){
				leaveType = "����";
			}else if(attend.getLeavetype().equals("overtime")){
				leaveType = "�Ӱ�";
			}else if(attend.getLeavetype().equals("rest")){
				leaveType = "����";
			}
//			leaveType = "��"+leaveType;
			return leaveType;
		}
		
		//�����
		public int getDiffDays(Date sd,Date ed){
			return (int) ((DateTool.dateAdd(ed, "DAY", 1).getTime()-sd.getTime())/(3600*24*1000)) ;
			}
		
		
}
