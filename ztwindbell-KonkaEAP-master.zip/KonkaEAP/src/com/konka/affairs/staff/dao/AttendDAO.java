package com.konka.affairs.staff.dao;

import com.konka.common.base.BaseDAO;

public interface AttendDAO extends BaseDAO {

}
