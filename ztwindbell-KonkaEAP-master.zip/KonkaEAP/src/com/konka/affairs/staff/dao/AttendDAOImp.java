package com.konka.affairs.staff.dao;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.konka.common.base.BaseDAOImp;
@Repository("attendDAO")
public class AttendDAOImp extends BaseDAOImp implements AttendDAO {
	public AttendDAOImp(){  
		super.setMapper("com.konka.affairs.attend.model.Attend");
	}
	
}
