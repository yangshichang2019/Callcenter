package com.konka.affairs.workers.model;

import java.sql.Timestamp;

import com.konka.common.base.BaseVO;

public class Employees extends BaseVO {
	
	private String batchnum;//����
	private String transfertime_start;//ת�ڿ�ʼʱ��
	private String transfertime_end;//ת�ڽ���ʱ��
	private String contract_starttime;
	private String contract_endtime;
	private String transferscore;//ת�ڳɼ�
	private Integer dept_id;//���ڲ���
	private String jobname;//��λ����
	private String jobskill;//���ܵȼ�
	private String nation;//����
	private String edution;//ѧ��
	private String filesnum;//������
	private String household;//����
	private String marry_flag;//�Ƿ���
	private String born_flag;//�Ƿ�����
	private String quit_flag;//�Ƿ���ְ
	private String political;//������ò
	private String height;//����
	private String identitynum;//����֤
	private String census;//��������
	private String prejob;//ԭ������λ
	private String at_job_time;//�μӹ���ʱ��
	private String at_insure_time;//�α�����
	private String major;//רҵ
	private String education_school;//��ҵԺУ
	private String jobtitle;//ְ��
	private String workskill;//ְҵ����
	private String language;//����ˮƽ
	private String identity_address;//����֤��ַ
	private String bank_num;//���п���
	private String leave_reason="";//��ְԭ��
	private String leave_num="";//��ְ����
	private String happentime;
	private String endtime;
	
	
	
	
	private Integer id;
	private String username;
	private String sex;
	private String age;
	private String birthday;
	private String home_call;
	private String private_call;
	private String office_call;
	private String entry_time;
	private String quit_time;
	
	
	private String quit_start;//�����ֶ� ������ְʱ�� �����ѯ
	private String quit_end;//�����ֶ� ������ְʱ�� �����ѯ
	private String entry_start;//�����ֶ� ������˾ʱ�� �����ѯ
	private String entry_end;//�����ֶ� ������˾ʱ�� �����ѯ
	private String bir_start;//�����ֶ� ���ڳ���ʱ�� �����ѯ
	private String bir_end;//�����ֶ� ���ڳ���ʱ�� �����ѯ
	private String insure_start;//�����ֶ� ���ڳ���ʱ�� �����ѯ
	private String insure_end;//�����ֶ� ���ڳ���ʱ�� �����ѯ
	
	
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getLeave_num() {
		return leave_num;
	}
	public void setLeave_num(String leave_num) {
		this.leave_num = leave_num;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getHome_call() {
		return home_call;
	}
	public void setHome_call(String home_call) {
		this.home_call = home_call;
	}
	public String getPrivate_call() {
		return private_call;
	}
	public void setPrivate_call(String private_call) {
		this.private_call = private_call;
	}
	public String getOffice_call() {
		return office_call;
	}
	public void setOffice_call(String office_call) {
		this.office_call = office_call;
	}
	public String getQuit_time() {
		return quit_time;
	}
	public void setQuit_time(String quit_time) {
		this.quit_time = quit_time;
	}
	public String getEntry_time() {
		return entry_time;
	}
	public void setEntry_time(String entry_time) {
		this.entry_time = entry_time;
	}
	
	public String getInsure_start() {
		return insure_start;
	}
	public void setInsure_start(String insure_start) {
		this.insure_start = insure_start;
	}
	public String getInsure_end() {
		return insure_end;
	}
	public void setInsure_end(String insure_end) {
		this.insure_end = insure_end;
	}
	public String getLeave_reason() {
		return leave_reason;
	}
	public void setLeave_reason(String leave_reason) {
		this.leave_reason = leave_reason;
	}
	public String getBatchnum() {
		return batchnum;
	}
	public void setBatchnum(String batchnum) {
		this.batchnum = batchnum;
	}
	public String getTransferscore() {
		return transferscore;
	}
	public void setTransferscore(String transferscore) {
		this.transferscore = transferscore;
	}
	
	public String getTransfertime_start() {
		return transfertime_start;
	}
	public void setTransfertime_start(String transfertime_start) {
		this.transfertime_start = transfertime_start;
	}
	public String getTransfertime_end() {
		return transfertime_end;
	}
	public void setTransfertime_end(String transfertime_end) {
		this.transfertime_end = transfertime_end;
	}
	public String getContract_starttime() {
		return contract_starttime;
	}
	public void setContract_starttime(String contract_starttime) {
		this.contract_starttime = contract_starttime;
	}
	public String getContract_endtime() {
		return contract_endtime;
	}
	public void setContract_endtime(String contract_endtime) {
		this.contract_endtime = contract_endtime;
	}
	public Integer getDept_id() {
		return dept_id;
	}
	public void setDept_id(Integer dept_id) {
		this.dept_id = dept_id;
	}
	public String getJobname() {
		return jobname;
	}
	public void setJobname(String jobname) {
		this.jobname = jobname;
	}
	public String getJobskill() {
		return jobskill;
	}
	public void setJobskill(String jobskill) {
		this.jobskill = jobskill;
	}
	public String getNation() {
		return nation;
	}
	public void setNation(String nation) {
		this.nation = nation;
	}
	public String getEdution() {
		return edution;
	}
	public void setEdution(String edution) {
		this.edution = edution;
	}
	public String getFilesnum() {
		return filesnum;
	}
	public void setFilesnum(String filesnum) {
		this.filesnum = filesnum;
	}
	public String getHousehold() {
		return household;
	}
	public void setHousehold(String household) {
		this.household = household;
	}
	public String getMarry_flag() {
		return marry_flag;
	}
	public void setMarry_flag(String marry_flag) {
		this.marry_flag = marry_flag;
	}
	public String getBorn_flag() {
		return born_flag;
	}
	public void setBorn_flag(String born_flag) {
		this.born_flag = born_flag;
	}
	public String getPolitical() {
		return political;
	}
	public void setPolitical(String political) {
		this.political = political;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getIdentitynum() {
		return identitynum;
	}
	public void setIdentitynum(String identitynum) {
		this.identitynum = identitynum;
	}
	public String getCensus() {
		return census;
	}
	public void setCensus(String census) {
		this.census = census;
	}
	public String getPrejob() {
		return prejob;
	}
	public void setPrejob(String prejob) {
		this.prejob = prejob;
	}
	public String getAt_job_time() {
		return at_job_time;
	}
	public void setAt_job_time(String at_job_time) {
		this.at_job_time = at_job_time;
	}
	public String getAt_insure_time() {
		return at_insure_time;
	}
	public void setAt_insure_time(String at_insure_time) {
		this.at_insure_time = at_insure_time;
	}
	public String getMajor() {
		return major;
	}
	public void setMajor(String major) {
		this.major = major;
	}
	public String getEducation_school() {
		return education_school;
	}
	public void setEducation_school(String education_school) {
		this.education_school = education_school;
	}
	public String getJobtitle() {
		return jobtitle;
	}
	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}
	public String getWorkskill() {
		return workskill;
	}
	public void setWorkskill(String workskill) {
		this.workskill = workskill;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getIdentity_address() {
		return identity_address;
	}
	public void setIdentity_address(String identity_address) {
		this.identity_address = identity_address;
	}
	public String getBank_num() {
		return bank_num;
	}
	public void setBank_num(String bank_num) {
		this.bank_num = bank_num;
	}
	public Employees() {
		// TODO Auto-generated constructor stub
	}
	public String getHappentime() {
		return happentime;
	}
	public void setHappentime(String happentime) {
		this.happentime = happentime;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getQuit_flag() {
		return quit_flag;
	}
	public void setQuit_flag(String quit_flag) {
		this.quit_flag = quit_flag;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getQuit_start() {
		return quit_start;
	}
	public void setQuit_start(String quit_start) {
		this.quit_start = quit_start;
	}
	public String getQuit_end() {
		return quit_end;
	}
	public void setQuit_end(String quit_end) {
		this.quit_end = quit_end;
	}
	public String getEntry_start() {
		return entry_start;
	}
	public void setEntry_start(String entry_start) {
		this.entry_start = entry_start;
	}
	public String getEntry_end() {
		return entry_end;
	}
	public void setEntry_end(String entry_end) {
		this.entry_end = entry_end;
	}
	public String getBir_start() {
		return bir_start;
	}
	public void setBir_start(String bir_start) {
		this.bir_start = bir_start;
	}
	public String getBir_end() {
		return bir_end;
	}
	public void setBir_end(String bir_end) {
		this.bir_end = bir_end;
	}
	
	
}
