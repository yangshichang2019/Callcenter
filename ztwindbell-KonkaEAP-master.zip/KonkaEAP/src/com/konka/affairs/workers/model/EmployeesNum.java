package com.konka.affairs.workers.model;


import com.konka.common.base.BaseVO;

public class EmployeesNum extends BaseVO {
	private Integer id;
	private String num;
	private String numType;
	private Integer eid;
	
	
	public Integer getEid() {
		return eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNum() {
		return num;
	}

	public void setNum(String num) {
		this.num = num;
	}

	public String getNumType() {
		return numType;
	}

	public void setNumType(String numType) {
		this.numType = numType;
	}

	public EmployeesNum() {
		// TODO Auto-generated constructor stub
	}
}
