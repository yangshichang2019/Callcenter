package com.konka.affairs.workers.model;


import com.konka.common.base.BaseVO;

public class KeyEvent extends BaseVO {
	private Integer id;
	private String content;
	private String keyType;
	private Integer eid;
	private String happentime;
	private String endtime;
	private String username;
	private Integer upload_id;
    private String path;
	
    
    
    private String contract_starttime;
	private String contract_endtime;
    
	public Integer getUpload_id() {
		return upload_id;
	}

	public void setUpload_id(Integer upload_id) {
		this.upload_id = upload_id;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getHappentime() {
		return happentime;
	}

	public void setHappentime(String happentime) {
		this.happentime = happentime;
	}

	public Integer getEid() {
		return eid;
	}

	public void setEid(Integer eid) {
		this.eid = eid;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getKeyType() {
		return keyType;
	}

	public void setKeyType(String keyType) {
		this.keyType = keyType;
	}
	
	public String getEndtime() {
		return endtime;
	}

	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getContract_starttime() {
		return contract_starttime;
	}

	public void setContract_starttime(String contract_starttime) {
		this.contract_starttime = contract_starttime;
	}

	public String getContract_endtime() {
		return contract_endtime;
	}

	public void setContract_endtime(String contract_endtime) {
		this.contract_endtime = contract_endtime;
	}

	public KeyEvent() {
		// TODO Auto-generated constructor stub
	}
}
