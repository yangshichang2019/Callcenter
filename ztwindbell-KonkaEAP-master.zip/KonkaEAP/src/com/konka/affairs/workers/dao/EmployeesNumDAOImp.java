package com.konka.affairs.workers.dao;

import org.springframework.stereotype.Repository;

import com.konka.affairs.workers.model.EmployeesNum;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.base.BaseDAOImp;
@Repository("employeesNumDAO")
public class EmployeesNumDAOImp extends BaseDAOImp implements EmployeesNumDAO {
	public EmployeesNumDAOImp(){
		super.setMapper("com.konka.affairs.workers.model.EmployeesNum");
	}
	@Override
	public void deleteEmployeesNumbyId(EmployeesNum employeesNum) {
		// TODO Auto-generated method stub
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteIds2", employeesNum);
	}
	@Override
	public void deleteEmployeesNumbyEid(EmployeesNum employeesNum) {
		// TODO Auto-generated method stub
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteIds", employeesNum);
	}
}
