package com.konka.affairs.workers.dao;

import java.util.List;

import com.konka.affairs.workers.model.Employees;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;

public interface EmployeesDAO extends BaseDAO {
	
	public void deleteEmployee(Employees employees);
	
	
	public void updateBatch(Employees employees);
	
	public void updateBatchJob(Employees employees);
	
	
	public List getMonitorList1( Employees employees);
	
	public List getMonitorList2( Employees employees);
	
	
	public List getMonitorList3( Employees employees);
	
	public List getMonitorList4( Employees employees);


	public List getObjectList1(Employees employees, Page page);
	
}
