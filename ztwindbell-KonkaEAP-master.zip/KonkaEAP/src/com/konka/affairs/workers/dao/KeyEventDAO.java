package com.konka.affairs.workers.dao;

import java.util.List;

import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;

public interface KeyEventDAO extends BaseDAO {
	
	public void deleteKeyEvent(KeyEvent keyEvent);
	
	public void deleteKeyEvents(KeyEvent keyEvent);
	
	
	public List getContractList(KeyEvent keyEvent);
	
	public List getContractListByPage(KeyEvent keyEvent,Page page);
}
