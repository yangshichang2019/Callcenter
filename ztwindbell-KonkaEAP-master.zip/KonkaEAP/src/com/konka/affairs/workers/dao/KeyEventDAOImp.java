package com.konka.affairs.workers.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
@Repository("keyEventDAO")
public class KeyEventDAOImp extends BaseDAOImp implements KeyEventDAO {
	public KeyEventDAOImp(){
		super.setMapper("com.konka.affairs.workers.model.KeyEvent");
	}
	
	@Override
	public void deleteKeyEvent(KeyEvent keyEvent) {
			this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteIds", keyEvent);
	}

	@Override
	public void deleteKeyEvents(KeyEvent keyEvent) {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteIds2", keyEvent);
	}

	@Override
	public List getContractList(KeyEvent keyEvent) {
		// TODO Auto-generated method stub
		 return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getAllListByContract", keyEvent);
	}

	@Override
	public List getContractListByPage(KeyEvent keyEvent, Page page) {
		Util.setPageNum(keyEvent, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList1", keyEvent);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
}
