package com.konka.affairs.workers.dao;

import com.konka.affairs.workers.model.EmployeesNum;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.base.BaseDAO;

public interface EmployeesNumDAO extends BaseDAO {
	
	public void deleteEmployeesNumbyId(EmployeesNum employeesNum);
	
	public void deleteEmployeesNumbyEid(EmployeesNum employeesNum);
	
}
