package com.konka.affairs.workers.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.workers.model.Employees;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
@Repository("employeesDAO")
public class EmployeesDAOImp extends BaseDAOImp implements EmployeesDAO {
	public EmployeesDAOImp(){
		super.setMapper("com.konka.affairs.workers.model.Employees");
	}

	@Override
	public void deleteEmployee(Employees employees) {
			this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteIds", employees);
	}

	@Override
	public List getMonitorList1(Employees employees) {
		// TODO Auto-generated method stub
		 return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getMonitor1", employees);
	}
	
	@Override
	public List getMonitorList2(Employees employees) {
		// TODO Auto-generated method stub
		 return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getMonitor2", employees);
	}

	@Override
	public List getMonitorList3(Employees employees) {
		// TODO Auto-generated method stub
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getMonitor3", employees);
	}
	
	@Override
	public List getMonitorList4(Employees employees) {
		// TODO Auto-generated method stub
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getMonitor4", employees);
	}

	@Override
	public void updateBatch(Employees employees) {
		this.getSqlSessionTemplate().update(this.getMapper() + ".updateBatch", employees);
	}

	@Override
	public void updateBatchJob(Employees employees) {
		// TODO Auto-generated method stub
		this.getSqlSessionTemplate().update(this.getMapper() + ".updateBatchJob", employees);
	}

	@Override
	public List getObjectList1(Employees employees, Page page) {
		// TODO Auto-generated method stub
		Util.setPageNum(employees, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList1", employees);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

}
