package com.konka.affairs.workers.action;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.affairs.workers.model.Employees;
import com.konka.affairs.workers.model.EmployeesNum;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.affairs.workers.service.WorkersService;
import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResField;
import com.konka.system.model.ExeclCell;
import com.konka.system.model.ExeclImport;
import com.konka.system.model.UploadFile;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;

@Controller
@Scope("prototype")
public class WorkersAction extends BaseAction {
	
	@Autowired
	private WorkersService workersService;
	@Autowired
	private SystemService systemService;
	
	private Employees employees = new Employees();
	private KeyEvent keyEvent =  new KeyEvent();
	private EmployeesNum employeesNum = new EmployeesNum();
	private ExeclImport execlImport = new ExeclImport();
	private File file;
	private List keylist = new ArrayList();
	private List awardlist = new ArrayList();
	private List desclist = new ArrayList();
	private List contrlist = new ArrayList();
	public UploadFile uploadfile = new UploadFile();
	
//=================Ա������=====================================	


		//��ת������Ա��ҳ��
		public String toManageEmployees() throws Exception{
			page.setOrderField("ENTRY_TIME");
			dataList = workersService.getEmployeesList(employees, page);
			return "toManageEmployees";
		}
		
		//�߼�����
		public String toSearchAdvanced() throws Exception{
			return "toSearchAdvanced";
		}
		//�߼�����
		public String toSearchAdvancedInfo() throws Exception{
			return "toSearchAdvancedInfo";
		}
		//���������
		public String toUpdateBatchNum() throws Exception{
			return "toUpdateBatchNum";
		}
		//���������
		public String toUpdateBat() throws Exception{
			
			if(employees.getValues().equals("")){
				
			}else{
				employees.setValues(employees.getValues().substring(0,employees.getValues().length()-1 ));
				workersService.updateBatch(employees);
			}
			
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//�����ĸ�λ
		public String toUpdateJob() throws Exception{
			return "toUpdateJob";
		}	
		
		public String toUpdateJobName() throws Exception{
			
			if(employees.getValues().equals("")){
				
			}else{
				employees.setValues(employees.getValues().substring(0,employees.getValues().length()-1 ));
				workersService.updateBatchJob(employees);
			}
			
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
		//��ת������Ա��ҳ��
		public String toManageEmpInfo() throws Exception{
			page.setOrderField("ENTRY_TIME");
			dataList = workersService.getEmployeesList(employees, page);
			return "toManageEmpInfo";
		}
		//��ת������Ա��ҳ��
		public String toManageKeyEvent() throws Exception{
			dataList = workersService.getKeyEventList(keyEvent, page);
			return "toManageKeyEvent";
		}
		//��ת������Ա��ҳ��
		public String toManageContract() throws Exception{
			page.setOrderField("HAPPENTIME");
			dataList = workersService.getContractList(keyEvent, page);
			return "toManageContract";
		}
		
		//��ݼ��
		public String toMonitorData() throws Exception{
//			select COUNT(*) from (select * from KK_WORKERS_EMPLOYEES where quit_flag='��ְ'
//			AND (ISMANAGER='������Ա' OR ISMANAGER='������Ա'))  C  GROUP BY   DEPTID
			employees.setValues("���?��");
			List mdlist1 = workersService.getMonitorList(employees);
			for(int i=0;i<mdlist1.size();i++){
				Employees employees = (Employees)mdlist1.get(i);
				super.getRequest().setAttribute("glfz"+i, employees.getId());
			}
			
			employees.setValues("ר��");
			List mdlist2 = workersService.getMonitorList(employees);
			for(int i=0;i<mdlist2.size();i++){
				Employees employees = (Employees)mdlist2.get(i);
				super.getRequest().setAttribute("zj"+i, employees.getId());
			}
			
			employees.setValues("����");
			List mdlist3 = workersService.getMonitorList(employees);
			for(int i=0;i<mdlist3.size();i++){
				Employees employees = (Employees)mdlist3.get(i);
				super.getRequest().setAttribute("ex"+i, employees.getId());
			}
			
			employees.setValues("������");
			List mdlist4 = workersService.getMonitorList(employees);
			for(int i=0;i<mdlist4.size();i++){
				Employees employees = (Employees)mdlist4.get(i);
				super.getRequest().setAttribute("djn"+i, employees.getId());
			}
			
			employees.setValues("˫����");
			List mdlist5 = workersService.getMonitorList(employees);
			for(int i=0;i<mdlist5.size();i++){
				Employees employees = (Employees)mdlist5.get(i);
				super.getRequest().setAttribute("sjn"+i, employees.getId());
			}
			
			
			
			
			employees.setValues("�����Ա");
			employees.setValues2("15");
			List mdlist6 = workersService.getMonitorList2(employees);
			super.getRequest().setAttribute("mdlist6", ((Employees)(mdlist6.get(0))).getId());
			
			employees.setValues("�����Ա");
			employees.setValues2("4");
			List mdlist7 = workersService.getMonitorList2(employees);
			super.getRequest().setAttribute("mdlist7", ((Employees)(mdlist7.get(0))).getId());
			
			employees.setValues("�����ܣ��ӱ���");
			employees.setValues2("12");
			List mdlist8 = workersService.getMonitorList2(employees);
			super.getRequest().setAttribute("mdlist8", ((Employees)(mdlist8.get(0))).getId());
			
			
			employees.setValues2("4");
			mdlist8 = workersService.getMonitorList3(employees);
			super.getRequest().setAttribute("cwrs", ((Employees)(mdlist8.get(0))).getId());
			
			employees.setValues2("12");
			mdlist8 = workersService.getMonitorList3(employees);
			super.getRequest().setAttribute("yyrs", ((Employees)(mdlist8.get(0))).getId());
			
			employees.setValues2("15");
			mdlist8 = workersService.getMonitorList3(employees);
			super.getRequest().setAttribute("zhrs", ((Employees)(mdlist8.get(0))).getId());
			
			mdlist8 = workersService.getMonitorList4(employees);
			super.getRequest().setAttribute("hjzxrs", ((Employees)(mdlist8.get(0))).getId());
			
			
			
			
			
			return "toMonitorData";
		}
		
		
		
	
		//�����Ա������޸�Ա��
		public String toAddEditEmployees() throws Exception {
			if (employees.getId() == null) {
				return "toAddEditEmployees";
			} else {
				keyEvent.setEid(employees.getId());
				employees = workersService.getEmployeesByid(employees);
				List list = workersService.getKeyEventList(keyEvent);
				if(list.size()>0){
					getListca(list);
				}
				return "toAddEditEmployees";
			}
		}	
		
				public String toLookEmployees() throws Exception {
						keyEvent.setEid(employees.getId());
						employees = workersService.getEmployeesByid(employees);
						List list = workersService.getKeyEventList(keyEvent);
						if(list.size()>0){
							getListca(list);
						}
						return "toLookEmployees";
				}	
		
		
		public void getListca(List list){
			desclist.clear();
			awardlist.clear();
			contrlist.clear();
			keylist.clear();
			for(Object object: list){
				KeyEvent keyEvent = (KeyEvent)object;
				if(keyEvent.getKeyType().equals("reward")||keyEvent.getKeyType().equals("punishment")){
					awardlist.add(object);
				}else if(keyEvent.getKeyType().equals("keyhiatus")||keyEvent.getKeyType().equals("keycontribution")){
					keylist.add(object);
				}else if(keyEvent.getKeyType().equals("remark")){
					desclist.add(object);
				}else{
					contrlist.add(object);
				}
			}
		}
		
		
		//����Ա��
		public String toSaveEmployees() throws Exception{
			User user = (User) super.getSession().get(Constant.SESSION_USER);
			workersService.saveEmployees(employees,user);
			return Constant.ACTION_S.ajaxDone.toString();
		}	
		//ɾ��Ա��
		public String toDeleteEmployees() throws Exception{
			workersService.DeleteEmployees(ids);
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
		//��ת���ؼ��¼�����ҳ��
		public String toShowKeyEvent() throws Exception{
			dataList = workersService.getKeyEventList(keyEvent, page);
			return "toShowKeyEvent";
		}
		//��ת���鿴��ͬҳ��
		public String toShowContract() throws Exception{
			dataList = workersService.getKeyEventListByContract(keyEvent);
			return "toShowContract";
		}
			
		//����¹ؼ��¼����޸Ĺؼ��¼�
		public String toAddEditKeyEvent() throws Exception {
			if (keyEvent.getId() == null) {
				return "toAddEditKeyEvent";
			} else {
				keyEvent = workersService.getKeyEventByid(keyEvent);
				return "toAddEditKeyEvent";
			}
		}	
		
		//����¹ؼ��¼����޸Ĺؼ��¼�
		public String toLookKeyEvent() throws Exception {
				keyEvent = workersService.getKeyEventByid(keyEvent);
				return "toLookKeyEvent";
		}	
		
		//����¹ؼ��¼����޸Ĺؼ��¼�
				public String toLookContract() throws Exception {
						keyEvent = workersService.getKeyEventByid(keyEvent);
						return "toLookContract";
		}	
		
		//����¹ؼ��¼����޸Ĺؼ��¼�
				public String toAddEditContract() throws Exception {
					if (keyEvent.getId() == null) {
						return "toAddEditContract";
					} else {
						keyEvent = workersService.getKeyEventByid(keyEvent);
						return "toAddEditContract";
					}
				}	
		
		//����ؼ��¼�
		public String toSaveKeyEvent() throws Exception{
			User user = (User) super.getSession().get(Constant.SESSION_USER);
			if(!keyEvent.getKeyType().equals("CONTRACT_FI")&&!keyEvent.getKeyType().equals("CONTRACT_SE")
					&&!keyEvent.getKeyType().equals("CONTRACT_TH")&&!keyEvent.getKeyType().equals("CONTRACT_THU")
					&&!keyEvent.getKeyType().equals("CONTRACT_WU")&&!keyEvent.getKeyType().equals("CONTRACT_SIX")){
				if(keyEvent.getUpload_id()==null||keyEvent.getUpload_id()==0) {
					super.toError("δ�ϴ��ļ���");
					super.setCallbackType("");
					return Constant.ACTION_S.ajaxDone.toString();
				}
				uploadfile.setId(keyEvent.getUpload_id());
				uploadfile =systemService.getUploadFileInfo(uploadfile);
				keyEvent.setPath(uploadfile.getPath());
			}else{
				keyEvent.setPath("");
			}
			workersService.saveKeyEvent(keyEvent, user);
			return Constant.ACTION_S.ajaxDone.toString();
		}	
		
		
		
		//ɾ��ؼ��¼�
		public String toDeleteKeyEvent() throws Exception{
			workersService.DeleteKeyEvent(ids);
			return Constant.ACTION_S.ajaxDone.toString();
		}		
		
		
		//��ת���Ź���
		public String toShowEmployeesNum() throws Exception{
			dataList = workersService.getEmployeesNumList(employeesNum, page);
			return "toShowEmployeesNum";
		}
			
		//����¹��Ż��޸Ĺ���
		public String toAddEditEmployeesNum() throws Exception {
			if (employeesNum.getId() == null) {
				return "toAddEditEmployeesNum";
			} else {
				employeesNum = workersService.getEmployeesNumByid(employeesNum);
				return "toAddEditEmployeesNum";
			}
		}	
		
		//���湤��
		public String toSaveEmployeesNum() throws Exception{
			User user = (User) super.getSession().get(Constant.SESSION_USER);
			workersService.saveEmployeesNum(employeesNum, user);
			return Constant.ACTION_S.ajaxDone.toString();
		}	
		
		
		
		//ɾ���
		public String toDeleteEmployeesNum() throws Exception{
			workersService.DeleteEmployeesNum(ids);
			return Constant.ACTION_S.ajaxDone.toString();
		}		
		
		//�����ϴ�Ա�� ҳ��
		public String toUploadEmployees() throws Exception{
			return "toUploadEmployees";
		}
		//�����ϴ�Ա������
		public String toInsertImport() throws Exception{
			User user = (User) super.getSession().get(Constant.SESSION_USER);
			try {
				user = (User) super.getSession().get(Constant.SESSION_USER);
				execlImport.setTable("KK_WORKERS_EMPLOYEES");
				execlImport.setId(0);
				String sql = "";
				if(execlImport.getValues2().equals("LEAVE")){
					 sql = "QUIT_TIME:String,LEAVE_NUM:String,LEAVE_REASON:String,USERNAME:String,BATCHNUM:String,TRANSFERTIME_START:String,TRANSFERTIME_END:String,TRANSFERSCORE:String,DEPTID:Integer,JOBNAME:String,JOBSKILL:String,SEX:String,BIRTHDAY:String,NATION:String,EDUCATION:String,FILESNUM:String,HOUSEHOLD:String,MARRY_FLAG:String,BORN_FLAG:String,POLITICAL:String,HEIGHT:String,IDENTITYNUM:String,CENSUS:String,PREJOB:String,AT_JOB_TIME:String,ENTRY_TIME:String,AT_INSURE_TIME:String,MAJOR:String,EDUCATION_SCHOOL:String,JOBTITLE:String,WORKERSKILL:String,LANGUAGE:String,IDENTITY_ADDRESS:String,PRIVATE_CALL:String,HOME_CALL:String"
							+",BANK_NUM:String,QUIT_FLAG:String";
				}else{
					 sql = "USERNAME:String,ENTRY_TIME:String,BATCHNUM:String,TRANSFERTIME_START:String,TRANSFERTIME_END:String,TRANSFERSCORE:String,DEPTID:Integer,JOBNAME:String,JOBSKILL:String,SEX:String,BIRTHDAY:String,NATION:String,EDUCATION:String,FILESNUM:String,HOUSEHOLD:String,MARRY_FLAG:String,BORN_FLAG:String,POLITICAL:String,HEIGHT:String,IDENTITYNUM:String,CENSUS:String,PREJOB:String,AT_JOB_TIME:String,AT_INSURE_TIME:String,MAJOR:String,EDUCATION_SCHOOL:String,JOBTITLE:String,WORKERSKILL:String,LANGUAGE:String,IDENTITY_ADDRESS:String,PRIVATE_CALL:String,HOME_CALL:String"
							+",BANK_NUM:String,QUIT_FLAG:String";
				}
				
				String str[] = sql.split(",");
				List fieldList = new ArrayList();
				ExeclCell execlCell = null;
				for(int i=0;i<str.length;i++){
					String strs[] = str[i].split(":");
					execlCell = new ExeclCell();
					execlCell.setTable_column(strs[0]);
					execlCell.setExecl_column(i);
					execlCell.setType(strs[1]);
					fieldList.add(execlCell);
				}
				execlImport = systemService.insertBatchExeclData(file,
						execlImport, fieldList, user);
			} catch (Exception e) {
				super.toError("����ʧ�ܣ�");
				e.printStackTrace();
			}
			 
			return Constant.ACTION_S.ajaxDone.toString();
		}	
		
		
		
		public EmployeesNum getEmployeesNum() {
			return employeesNum;
		}

		public void setEmployeesNum(EmployeesNum employeesNum) {
			this.employeesNum = employeesNum;
		}

		public Employees getEmployees() {
			return employees;
		}
		public void setEmployees(Employees employees) {
			this.employees = employees;
		}
		public KeyEvent getKeyEvent() {
			return keyEvent;
		}

		public void setKeyEvent(KeyEvent keyEvent) {
			this.keyEvent = keyEvent;
		}

		public ExeclImport getExeclImport() {
			return execlImport;
		}

		public void setExeclImport(ExeclImport execlImport) {
			this.execlImport = execlImport;
		}

		public File getFile() {
			return file;
		}

		public void setFile(File file) {
			this.file = file;
		}

		public List getKeylist() {
			return keylist;
		}

		public void setKeylist(List keylist) {
			this.keylist = keylist;
		}

		public List getAwardlist() {
			return awardlist;
		}

		public void setAwardlist(List awardlist) {
			this.awardlist = awardlist;
		}

		public List getDesclist() {
			return desclist;
		}

		public void setDesclist(List desclist) {
			this.desclist = desclist;
		}

		public List getContrlist() {
			return contrlist;
		}

		public void setContrlist(List contrlist) {
			this.contrlist = contrlist;
		}


		public UploadFile getUploadfile() {
			return uploadfile;
		}


		public void setUploadfile(UploadFile uploadfile) {
			this.uploadfile = uploadfile;
		}
		
		
}
