package com.konka.affairs.workers.service;

import java.util.List;

import com.konka.affairs.workers.model.Employees;
import com.konka.affairs.workers.model.EmployeesNum;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.tool.Page;
import com.konka.useradmin.model.User;

public interface WorkersService {
	//Ա��������Ϣ����
	public List getEmployeesList(Employees employees, Page page) throws Exception;
	
	public List getEmployeesList1(Employees employees, Page page) throws Exception;
	
	
	public List getContractList(KeyEvent keyEvent, Page page) throws Exception;
	
	public Employees getEmployeesByid(Employees employees) throws Exception;
	
	public void saveEmployees(Employees employees,User user) throws Exception;
	
	public void DeleteEmployees(String  ids) throws Exception;
	
	public void updateBatch(Employees employees) throws Exception;
	
	public void updateBatchJob(Employees employees) throws Exception;
	
	//�ؼ��¼�����
	public List getKeyEventList(KeyEvent keyEvent, Page page) throws Exception;
	
	public List getKeyEventList(KeyEvent keyEvent) throws Exception;
	
	public List getKeyEventListByContract(KeyEvent keyEvent) throws Exception;
	
	public KeyEvent getKeyEventByid(KeyEvent keyEvent) throws Exception;
	
	public void saveKeyEvent(KeyEvent keyEvent,User user) throws Exception;
	
	public void DeleteKeyEvent(String  ids) throws Exception;
	
	
	//���Ź���
	public List getEmployeesNumList(EmployeesNum employeesNum, Page page) throws Exception;
	
	public EmployeesNum getEmployeesNumByid(EmployeesNum employeesNum) throws Exception;
	
	public void saveEmployeesNum(EmployeesNum employeesNum,User user) throws Exception;
	
	public void DeleteEmployeesNum(String  ids) throws Exception;
	
//	��ȡ�������1
	public List getMonitorList(Employees employees) throws Exception;
//	��ȡ�������2
	public List getMonitorList2(Employees employees) throws Exception;	
//	��ȡ�������3
	public List getMonitorList3(Employees employees) throws Exception;	
//	��ȡ�������4
	public List getMonitorList4(Employees employees) throws Exception;
}
