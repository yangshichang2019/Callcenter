package com.konka.affairs.workers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.affairs.workers.dao.EmployeesDAO;
import com.konka.affairs.workers.dao.EmployeesNumDAO;
import com.konka.affairs.workers.dao.KeyEventDAO;
import com.konka.affairs.workers.model.Employees;
import com.konka.affairs.workers.model.EmployeesNum;
import com.konka.affairs.workers.model.KeyEvent;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.User;

@Service("workersService")
@Transactional 
public class WorkersServiceImp implements WorkersService {

	@Autowired
	private EmployeesDAO employeesDAO;
	@Autowired
	private KeyEventDAO keyEventDAO;
	@Autowired
	private EmployeesNumDAO employeesNumDAO;
	
	@Override
	public List getEmployeesList(Employees employees, Page page)
			throws Exception {
		// TODO Auto-generated method stub
		return employeesDAO.getObjectList(employees, page);
	}

	@Override
	public Employees getEmployeesByid(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		return (Employees) employeesDAO.getById(employees.getId());
	}

	@Override
	public void saveEmployees(Employees employees, User user) throws Exception {
		if(employees.getId()!=null){
			employees.setUpdate_time(Util.getTimestamp());
			employees.setUpdate_employee(user.getUsername());
			employeesDAO.update(employees);
		}else{
			employees.setCreate_time(Util.getTimestamp());
			employees.setCreate_employee(user.getUsername());
			employeesDAO.insert(employees);
		}
		
	}

	@Override
	public List getKeyEventList(KeyEvent keyEvent, Page page) throws Exception {
		return keyEventDAO.getObjectList(keyEvent, page);
	}

	@Override
	public KeyEvent getKeyEventByid(KeyEvent keyEvent) throws Exception {
		return (KeyEvent) keyEventDAO.getById(keyEvent.getId());
	}

	@Override
	public void saveKeyEvent(KeyEvent keyEvent, User user) throws Exception {
		if(keyEvent.getId()!=null){
			keyEvent.setUpdate_time(Util.getTimestamp());
			keyEvent.setUpdate_employee(user.getUsername());
			keyEventDAO.update(keyEvent);
		}else{
			keyEvent.setCreate_time(Util.getTimestamp());
			keyEvent.setCreate_employee(user.getUsername());
			keyEventDAO.insert(keyEvent);
		}
	}

	@Override
	public void DeleteEmployees(String  ids) throws Exception {
		Employees employees = new Employees();
		KeyEvent event = new KeyEvent();
		EmployeesNum em = new EmployeesNum();
		em.setValues(ids);
		employees.setValues(ids);
		event.setValues(ids);
		employeesDAO.deleteEmployee(employees);
		keyEventDAO.deleteKeyEvent(event);
		employeesNumDAO.deleteEmployeesNumbyEid(em);
	}

	@Override
	public void DeleteKeyEvent(String ids) throws Exception {
		KeyEvent event = new KeyEvent();
		event.setValues(ids);
		keyEventDAO.deleteKeyEvents(event);
	}

	@Override
	public List getEmployeesNumList(EmployeesNum employeesNum, Page page)
			throws Exception {
		// TODO Auto-generated method stub
		return employeesNumDAO.getObjectList(employeesNum, page);
	}

	@Override
	public EmployeesNum getEmployeesNumByid(EmployeesNum employeesNum)
			throws Exception {
		// TODO Auto-generated method stub
		return (EmployeesNum) employeesNumDAO.getById(employeesNum.getId());
	}

	@Override
	public void saveEmployeesNum(EmployeesNum employeesNum, User user)
			throws Exception {
		if(employeesNum.getId()!=null){
			employeesNum.setUpdate_time(Util.getTimestamp());
			employeesNum.setUpdate_employee(user.getUsername());
			employeesNumDAO.update(employeesNum);
		}else{
			employeesNum.setCreate_time(Util.getTimestamp());
			employeesNum.setCreate_employee(user.getUsername());
			employeesNumDAO.insert(employeesNum);
		}
		
	}

	@Override
	public void DeleteEmployeesNum(String ids) throws Exception {
		EmployeesNum employeesNum = new EmployeesNum();
		employeesNum.setValues(ids);
		employeesNumDAO.deleteEmployeesNumbyId(employeesNum);
	}

	@Override
	public List getKeyEventList(KeyEvent keyEvent) throws Exception {
		// TODO Auto-generated method stub
		return keyEventDAO.getAllList(keyEvent);
	}

	@Override
	public List getKeyEventListByContract(KeyEvent keyEvent) throws Exception {
		// TODO Auto-generated method stub
		return keyEventDAO.getContractList(keyEvent);
	}


	@Override
	public List getContractList(KeyEvent keyEvent, Page page) throws Exception {
		// TODO Auto-generated method stub
		return  keyEventDAO.getContractListByPage(keyEvent, page);
	}

	@Override
	public List getMonitorList(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		return employeesDAO.getMonitorList1(employees);
	}

	@Override
	public List getMonitorList2(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		return employeesDAO.getMonitorList2(employees);
	}

	@Override
	public List getMonitorList3(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		return employeesDAO.getMonitorList3(employees);
	}
	
	@Override
	public List getMonitorList4(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		return employeesDAO.getMonitorList4(employees);
	}

	@Override
	public void updateBatch(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		 employeesDAO.updateBatch(employees);
	}

	@Override
	public void updateBatchJob(Employees employees) throws Exception {
		// TODO Auto-generated method stub
		 employeesDAO.updateBatchJob(employees);
	}

	@Override
	public List getEmployeesList1(Employees employees, Page page)
			throws Exception {
		// TODO Auto-generated method stub
		return employeesDAO.getObjectList1(employees, page);
	}



}
