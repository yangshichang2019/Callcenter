package com.konka.affairs.survey.action;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;













import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.affairs.message.model.Message;
import com.konka.affairs.survey.model.*;
import com.konka.affairs.survey.service.SurveyService;
import com.konka.affairs.survey.service.SurveyServiceImp;
import com.konka.common.tool.Page;
import com.konka.database.model.ConfigInfo;
import com.konka.system.service.SystemServiceImp;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;

@Controller
@Scope("prototype")
public class SurveyAction extends BaseAction {

	@Autowired
	public SurveyService surveyService;
	
	public Survey survey = new Survey();
	public List surveyList = new ArrayList(); 
	
	public Qst qst = new Qst();
	public List qstList = new ArrayList(); 
	
	public Asw asw = new Asw();
	public List aswList = new ArrayList();
	
	public Usur usur = new Usur();
	public List usurList = new ArrayList();

	//问卷管理列表
	public String toSurveyList() throws Exception {
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		Util.setCreateToVO(survey, Suser);
		dataList = surveyService.getSurveyList(survey, page);
		return "toSurveyList";
	}
	//添加修改问卷
	public String toAddEditSurvey() throws Exception {
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		if(survey.getId()!=null&&survey.getId()>0) {
			Util.echo(survey.getId().toString());
			survey = surveyService.getSurveyInfo(survey);			
		}
		return "toAddEditSurvey";
	}
	//查看问卷--fighting this step
		public String toViewSurvey() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			if(survey.getId()!=null&&survey.getId()>0) {
				Util.echo(survey.getId().toString());
				survey = surveyService.getSurveyInfo(survey);			
			}
			//参与人数
			joinNum = surveyService.getSurveyUserList(survey).size();
			//作答人数
			answerNum = surveyService.getSurveyAnsweredUserList(survey).size();;
			
			
			return "toViewSurvey";
		}
	
	
	
	//新增保存问卷
	public String toSaveSurvey() throws Exception {
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		surveyService.saveSurvey(survey,Suser);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	//调查人员问卷列表
	public String toUserSurveyList() throws Exception {
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		dataList = surveyService.getUserSurveyList(Suser, page);
		
		return "toUserSurveyList";
	}
	
	//人员答题列表
	public String toSurveyQstList() throws Exception {
		User suser = (User)super.getSession().get(Constant.SESSION_USER);
		
		
		
		//获取问题
		if(survey.getId()!=null&&survey.getId()>0) {
			survey = surveyService.getSurveyInfo(survey);
			
			//判断是否答过题
			asw.setA_id(  survey.getId()  );
			asw.setCreate_employee(  suser.getUsername()  );
			List tmpAswList=surveyService.getAllAswList(asw);
			//检查回答记录数判断是否作答
			if(tmpAswList.size() > 0){
				super.toError("该问卷您已经提交！");
				//super.setCallbackType("");
				return Constant.ACTION_S.ajaxDone.toString();
			}
			
			dataList = surveyService.getSurveyQstList(survey);
		}
		return "toSurveyQstList";
	}
	
	//保存答题toSavaAswList
	public String toSavaAswList() throws Exception {
		User suser = (User)super.getSession().get(Constant.SESSION_USER);
		//循环问题查看是否有空白未填题
		for(int i =0 ;i < aswList.size();i++){
			Asw vo = (Asw)aswList.get(i);
			//如果答案选项int为null则有未填,返回错误信息
			if(vo.getO_id()==null){
				if(vo.getAnswer()==null){
					super.toError("问卷还有未填写的题目！");
					return Constant.ACTION_S.ajaxDone.toString();
				}
			}						
		}
		usur.setA_id(survey.getId());
		usur.setUname(suser.getUsername());
		Usur repeat = surveyService.getSurveyUser(usur);
		if(repeat!=null&&repeat.getStatus().equals("answered")) {
			super.toError("请勿重复提交！");
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//没有空白未填题执行插入
		System.out.println("回答的问题数："+aswList.size());
		surveyService.insertAswBatch(aswList,suser);
		//更新是否作答字段
		usur.setStatus("answered");
		surveyService.updateUsur(usur,suser);
		return Constant.ACTION_S.ajaxDone.toString();
		
		
	}

		
	
	
	public List<Asw> getAswList() {
		return aswList;
	}
	public void setAswList(List<Asw> aswList) {
		this.aswList = aswList;
	}
	//下载文件时的文件名
	private String fileName="";
	//下载文件时的输入流
	private InputStream inputStream=null;
	//参与人数
	public int joinNum = 0;
	//作答人数
	public int answerNum = 0;
}
