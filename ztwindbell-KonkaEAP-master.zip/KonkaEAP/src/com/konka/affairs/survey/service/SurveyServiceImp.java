package com.konka.affairs.survey.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.affairs.staff.dao.AttendDAO;
import com.konka.affairs.survey.model.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.system.model.Remind;
import com.konka.useradmin.model.Right;
import com.konka.useradmin.model.User;



import com.konka.affairs.survey.dao.*;
import com.konka.affairs.survey.model.*;
import com.konka.useradmin.service.UserAdminService;


@Service("surveyService")  
@Transactional 
public class SurveyServiceImp implements SurveyService {

	@Autowired
	private SurveyDAO surveyDAO;
	@Autowired
	private AswDAO aswDAO;
	@Autowired
	private QstDAO qstDAO;
	@Autowired
	private OptDAO optDAO;
	@Autowired
	private UsurDAO usurDAO;
	
	@Autowired
	public UserAdminService userAdminService;
	
	//保存问卷
	public void saveSurvey(Survey survey, User suser) throws Exception{
		if(survey.getId()!=null&&survey.getId()>0) {
			
			Util.setUpdateToVO(survey, suser);
			
			Survey tempSurvey=getSurveyInfo(survey);
			
			surveyDAO.update(survey);
			
			if(!survey.getQes().equals(tempSurvey.getQes())){
				qstDAO.delete(survey.getId());
				optDAO.delete(survey.getId());
				
				saveQst(survey, suser);
			}
			saveUsur(survey, suser);			
		}else {
			Util.setCreateToVO(survey, suser);
			
			surveyDAO.insert(survey);
			saveQst(survey, suser);
			saveUsur(survey, suser);	
		}
	}
	//问卷信息
	public Survey getSurveyInfo(Survey survey) throws Exception {
		return (Survey)surveyDAO.getById(survey.getId());
	}
	//问卷列表
	public List getSurveyList(Survey survey,Page page) throws Exception{
		return (List)surveyDAO.getObjectList(survey,page);
	}
	//删除问卷
	public void deleteSurvey(Survey survey) throws Exception {
		surveyDAO.delete(survey.getId());
	}
	
	//保存问题
	public void saveQst(Survey survey, User user) throws Exception{
		//获取批量生成的问题文本
		String qesArrayStr = survey.getQes();

			
			
			//将问题整段文本分割成问题数组
			String[] qesArray=null;
			
			//问题数组
			qesArray = convertStrToArray(qesArrayStr,"\r\n\r\n");
			int test = qesArray.length;
			//循环插入
			for(int i=0;i<qesArray.length;i++){
				String[] question=null;
				question = convertStrToArray(qesArray[i],"\r\n");
				//新建一个问题
				Qst qst = new Qst();
				//设置映射问卷ID
				qst.setA_id(survey.getId());
				//正则提取题目标题
				qst.setTitle(question[0].replaceAll("^\\d+\\.", "").replaceAll("\\[.*\\]", ""));
				//正则提取题目分类
				qst.setType(	convertQesType(	question[0].replaceAll("^.*\\[", "").replaceAll("\\].*", "")));
				//insert
				Util.setCreateToVO(qst, user);
				qstDAO.insert(qst);	
				
				int test2 = question.length;
				
				for(int j=1;j<question.length;j++){
					//新建一个选项模板
					Opt opt = new Opt();
					//设置映射问题ID
					opt.setQ_id(qst.getId());
					opt.setA_id(qst.getA_id());
					
					//正则提取题目标题
					opt.setContent(question[j].replaceAll("<.*", ""));
					
					//正则提取题目分值 整数
					if(question[j].indexOf("<")!=-1 || question[j].indexOf(">")!=-1){
						opt.setType("score");
						opt.setScore(s2i(question[j].replaceAll("^.*<", "").replaceAll(">.*", "")));
					}else{
						opt.setType("noscore");
						opt.setScore(0);
					}
					
					//insert
					Util.setCreateToVO(opt, user);
					optDAO.insert(opt);	
					
				}
			   
				 
			}
		
	}
	
	//保存人员
	public void saveUsur(Survey survey, User suser) throws Exception{
		//未修改成员 uids为“” 修改后有值  录入用户记录表
		if(!survey.getUids().equals("")){
			usurDAO.delete(survey.getId());
			List userList = new ArrayList();
			userList = userAdminService.strToUserList(survey.getUids());
			for(int i=0;i<userList.size();i++){
				User user = (User)userList.get(i);
				//保存USER信息
				Usur usur = new Usur();
				Util.setCreateToVO(usur, suser);
				usur.setUname(user.getUsername());
				usur.setA_id(survey.getId());
				usur.setStatus("noanswer");
				usurDAO.insert(usur);
			}
		}
	}
	
	
	//使用String的split 方法   
    public String[] convertStrToArray(String str,String split){   
        String[] strArray = null;   
        strArray = str.split(split); //拆分字符,然后把结果交给数组strArray 
        return strArray;
    }
   //使用String的split 方法   
    public String convertQesType(String str){ 
    	String tempStr="";
    	if(str.equals("文本")){
    		tempStr="text";
    	}else if(str.equals("单选")){
    		tempStr="radio";
    	}else if(str.equals("多选")){
    		tempStr="checkbox";
    	}else if(str.equals("选框")){
    		tempStr="select";
    	}else{
    		tempStr="unknown";
    	}
        return tempStr;
    }

    //string to int
    public static int s2i(String intstr)
	{
	    Integer integer;
	    integer = Integer.valueOf(intstr);
	    return integer.intValue();
	}
    
    //调查人员问卷列表
	public List getUserSurveyList(User suser, Page page) throws Exception {
		List dataList = new ArrayList();
		List tmpList = (List)surveyDAO.getUserSurveyList(suser,page);
		for(int i=0;i<tmpList.size();i++) {
			Survey vo = (Survey)tmpList.get(i);
			//suser获取是否回答
			Usur tmpUsur = new Usur();
			tmpUsur.setA_id(vo.getId());
			tmpUsur.setUname(suser.getUsername());
			vo.setUsur((Usur) usurDAO.getByObject(tmpUsur));
			//加入返回list
			dataList.add(vo);
		}
			
		
		
		return dataList;
	}

	//获取问卷调查的人员
	public List getSurveyUserList(Survey survey) throws Exception {
		return (List)usurDAO.getByAid(survey.getId());
	}
	//获取问卷调查的人员
	public Usur getSurveyUser(Usur usur) throws Exception {
		return usurDAO.getByAUid(usur);
	}
	
	//获取已回答问卷的人员
	public List getSurveyAnsweredUserList(Survey survey) throws Exception {
		return (List)usurDAO.getByAidAnswered(survey.getId());
	}
	
	//获取问卷问题及选项
	public List getSurveyQstList(Survey survey) {
		List qstList = (List)qstDAO.getSurveyQstList(survey);
		List dataList = new ArrayList();
		for(int i=0;i<qstList.size();i++) {
			Qst qst =(Qst)qstList.get(i);
			//把qst type转换成html
			//qst.setType(    optListToCode(qst,i ) );
			//获取opt
			qst.setOptList(    (List)optDAO.getByQid(qst.getId())   );
			dataList.add(qst);
		}
		return dataList;
	}
	
	//optList转换code
	public String optListToCode(Qst qst,int i) {
		String html = "";
		List optList = (List)optDAO.getByQid(qst.getId()); 
			//asw隐藏Q_ID与A_ID
			html+="<input type=\"hidden\" name=\"aswList["+i+"].a_id\" value=\""	+qst.getA_id()+	"\" id=\"asw_id\">";
			html+="<input type=\"hidden\" name=\"aswList["+i+"].q_id\" value=\""	+qst.getId()+	"\" id=\"asw_id\">";
			
			//文本input
			if(qst.getType().equals("text")){
				html+="<dd><textarea name=\"aswList["+i+"].answer\" class=\"required\" cols=\"80\" rows=\"2\"></textarea></dd>";
			}
			//单选radio
			if(qst.getType().equals("radio")){
				for(int j=0;j<optList.size();j++) {
					html+="<label><input type=\"radio\" value=\"1\" name=\"r1\" class=\"required\" />选择1</label>";
				}			
			}
			//多选checkbox
			if(qst.getType().equals("checkbox")){
				for(int k=0;k<optList.size();k++) {
					
				}	
			}
			//多选checkbox
			if(qst.getType().equals("unknown")){
				
				html+="此题无法生成，请联系出卷人检查试题！";
				
			}
			
		
			
		return html;
	}
	//保存回答
	public void saveAsw(Asw asw, User suser) throws Exception {
		if(asw.getId()!=null&&asw.getId()>0) {			
			Util.setUpdateToVO(asw, suser);
			aswDAO.update(asw);			
		}else {
			Util.setCreateToVO(asw, suser);			
			aswDAO.insert(asw);	
			
		}
		
	}
	
	// 批量新建回答记录
	public void insertAswBatch(List aswList, User suser) throws Exception {
		List list = new ArrayList();
		
		for (int i = 0; i < aswList.size(); i++) {
			Asw vo = new Asw();
			vo = (Asw) aswList.get(i);
			
			Util.setCreateToVO(vo, suser);
			
			//分数写入asw数据库
			//如果是单选,有分数,写入分数
			if(vo.getAnswer()==null){
		
				Opt tempOpt = (Opt) optDAO.getById(vo.getO_id());
				vo.setScore(tempOpt.getScore());
			}else{
				vo.setScore(0);
				vo.setO_id(0);
			}
			
			//回答写入数据库
			//如果是单选,没有回答,写入回答
			if(vo.getAnswer()==null){
				Opt tempOpt = new Opt();
				tempOpt = (Opt) optDAO.getById(vo.getO_id());
				vo.setAnswer(tempOpt.getContent());
			}else{
				
			}
			
			
			vo.setU_id(  suser.getUsername()  );
			
			list.add(vo);
		}
		aswDAO.insertBatch(list);
		List test = new ArrayList();
	}

	//获取所有回答
	public List<Asw> getAllAswList(Asw asw) throws Exception {
		
		return (List)aswDAO.getAllList(asw);
	}

	//更新用户答题状态
	public void updateUsur(Usur usur, User suser) throws Exception {
		Util.setUpdateToVO(usur, suser);
		usurDAO.update(usur);
		
	}

	//获得回答信息
	public Asw getAswInfo(Asw asw) throws Exception {
		return (Asw)aswDAO.getByObject(asw);
	}

	

}
