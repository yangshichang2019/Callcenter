package com.konka.affairs.survey.service;

import java.util.List;

import com.konka.affairs.staff.model.Attend;
import com.konka.affairs.survey.model.Asw;
import com.konka.affairs.survey.model.Qst;
import com.konka.affairs.survey.model.Survey;
import com.konka.affairs.survey.model.Usur;
import com.konka.common.tool.Page;
import com.konka.useradmin.model.User;



public interface SurveyService {

	public void saveSurvey(Survey survey, User user) throws Exception;
	public Survey getSurveyInfo(Survey survey) throws Exception;
	public List getSurveyList(Survey survey,Page page) throws Exception;
	public void deleteSurvey(Survey survey) throws Exception;
	public List getUserSurveyList(User suser, Page page) throws Exception;
	public List getSurveyQstList(Survey survey);
	public String[] convertStrToArray(String answer, String string);
	public void saveAsw(Asw asw, User suser) throws Exception;
	public void insertAswBatch(List<Asw> aswList, User suser) throws Exception;
	public List<Asw> getAllAswList(Asw asw)throws Exception;
	void updateUsur(Usur usur, User suser) throws Exception;
	public List getSurveyUserList(Survey survey) throws Exception;
	public List getSurveyAnsweredUserList(Survey survey) throws Exception;
	public Asw getAswInfo(Asw asw) throws Exception;
	
	public Usur getSurveyUser(Usur usur) throws Exception;

}