package com.konka.affairs.survey.model;

import java.util.Date;

import com.konka.common.base.BaseVO;

public class Usur extends BaseVO {
    private Integer id;

    private String uname;

    private Integer a_id;

    private String status;

 

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

   

    

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public Integer getA_id() {
		return a_id;
	}

	public void setA_id(Integer a_id) {
		this.a_id = a_id;
	}

	public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

   
}