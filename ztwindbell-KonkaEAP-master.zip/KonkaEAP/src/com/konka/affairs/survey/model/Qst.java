package com.konka.affairs.survey.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.konka.common.base.BaseVO;
import com.konka.useradmin.model.User;
public class Qst extends BaseVO{
    private Integer id;

    private String title;

    private String type;

    private Integer o_id;

    private Integer a_id;

    private List optList = new ArrayList();

    
    
   

	

	public List getOptList() {
		return optList;
	}

	public void setOptList(List optList) {
		this.optList = optList;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

	public Integer getO_id() {
		return o_id;
	}

	public void setO_id(Integer o_id) {
		this.o_id = o_id;
	}

	public Integer getA_id() {
		return a_id;
	}

	public void setA_id(Integer a_id) {
		this.a_id = a_id;
	}



}