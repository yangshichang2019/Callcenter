package com.konka.affairs.survey.model;

import java.util.Date;

import com.konka.common.base.BaseVO;

public class Survey extends BaseVO  {
    private Integer id;

    private String title;

    private Date starttime;

    private Date endtime;
    
    private String qes;

    private String uids;

    private String users;
    
    Usur usur = new Usur();
    

    public Usur getUsur() {
		return usur;
	}

	public void setUsur(Usur usur) {
		this.usur = usur;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }
    

    public String getQes() {
		return qes;
	}

	public void setQes(String qes) {
		this.qes = qes;
	}

	public String getUids() {
        return uids;
    }

    public void setUids(String uids) {
        this.uids = uids;
    }

    public String getUsers() {
        return users;
    }

    public void setUsers(String users) {
        this.users = users;
    }

}