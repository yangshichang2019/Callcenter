package com.konka.affairs.survey.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.useradmin.model.User;
@Repository("surveyDAO")
public class SurveyDAOImp extends BaseDAOImp implements SurveyDAO {
	public SurveyDAOImp(){  
		super.setMapper("com.konka.affairs.survey.model.Survey");
	}

	@Override
	public List getUserSurveyList(User suser, Page page) {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getUserSurveyList", suser);
	}
	
}


