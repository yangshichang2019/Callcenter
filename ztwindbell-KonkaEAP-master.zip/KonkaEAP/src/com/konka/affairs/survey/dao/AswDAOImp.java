package com.konka.affairs.survey.dao;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
@Repository("aswDAO")
public class AswDAOImp extends BaseDAOImp implements AswDAO {
	public AswDAOImp(){  
		super.setMapper("com.konka.affairs.survey.model.Asw");
	}
	
}


