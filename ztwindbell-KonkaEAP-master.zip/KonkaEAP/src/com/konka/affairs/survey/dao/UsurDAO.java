package com.konka.affairs.survey.dao;

import java.util.List;

import com.konka.affairs.survey.model.Usur;
import com.konka.common.base.BaseDAO;

public interface UsurDAO extends BaseDAO {

	List getByAid(Integer id);
	Usur getByAUid(Usur user);

	List getByAidAnswered(Integer id);

}