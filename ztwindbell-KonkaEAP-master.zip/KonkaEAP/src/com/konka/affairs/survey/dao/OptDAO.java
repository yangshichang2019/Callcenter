package com.konka.affairs.survey.dao;

import java.util.List;

import com.konka.affairs.survey.model.Survey;
import com.konka.common.base.BaseDAO;

public interface OptDAO extends BaseDAO {

	List getByQid(Integer id);
}