package com.konka.affairs.survey.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.useradmin.model.User;


public interface SurveyDAO extends BaseDAO {

	List getUserSurveyList(User suser, Page page);

}









