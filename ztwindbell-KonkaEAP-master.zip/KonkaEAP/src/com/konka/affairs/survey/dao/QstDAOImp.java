package com.konka.affairs.survey.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.survey.model.Survey;
import com.konka.common.base.BaseDAOImp;
@Repository("qstDAO")
public class QstDAOImp extends BaseDAOImp implements QstDAO {
	public QstDAOImp(){  
		super.setMapper("com.konka.affairs.survey.model.Qst");
	}

	@Override
	public List getSurveyQstList(Survey survey) {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getSurveyQstList", survey);
	}
	
}


