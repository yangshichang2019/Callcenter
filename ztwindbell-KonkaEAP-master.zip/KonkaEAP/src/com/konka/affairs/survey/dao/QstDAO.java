package com.konka.affairs.survey.dao;

import java.util.List;

import com.konka.affairs.survey.model.Survey;
import com.konka.common.base.BaseDAO;

public interface QstDAO extends BaseDAO {

	List getSurveyQstList(Survey survey);

}