package com.konka.affairs.survey.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("optDAO")
public class OptDAOImp extends BaseDAOImp implements OptDAO {
	public OptDAOImp(){  
		super.setMapper("com.konka.affairs.survey.model.Opt");
	}

	@Override
	public List getByQid(Integer id) {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getByQid", id);
	}
	
}


