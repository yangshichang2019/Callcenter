package com.konka.affairs.survey.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.survey.model.Usur;
import com.konka.common.base.BaseDAOImp;
@Repository("usurDAO")
public class UsurDAOImp extends BaseDAOImp implements UsurDAO {
	public UsurDAOImp(){  
		super.setMapper("com.konka.affairs.survey.model.Usur");
	}

	@Override
	public List getByAid(Integer id) {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getByAid", id);
	}
	@Override
	public Usur getByAUid(Usur usur) {
		return super.getSqlSessionTemplate().selectOne(super.getMapper()+".getByAUid", usur);
	}

	@Override
	public List getByAidAnswered(Integer id) {
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getByAidAnswered", id);
	}


	
}


