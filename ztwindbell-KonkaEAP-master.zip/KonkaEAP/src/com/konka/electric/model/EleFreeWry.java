package com.konka.electric.model;

import com.konka.common.base.BaseVO;

public class EleFreeWry extends BaseVO {
	private Integer id;
	private String status;//状态：待填写-A、待核验-B、核验通过-C、核验失败-D
	private String order_num;
	private String name;//客户姓名
	private String contact_call;//联系电话
	private String invoice;//发票编号
	private String invoice_pic;//发票图片地址
	private String address;//联系地址
	private String product_num;//产品型号
	private String buy_date;//购买日期
	private String remark;//访客备注
	private String remark_check;//核验备注
	
	private String start_time1;
	private String end_time1;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrder_num() {
		return order_num;
	}
	public void setOrder_num(String order_num) {
		this.order_num = order_num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact_call() {
		return contact_call;
	}
	public void setContact_call(String contact_call) {
		this.contact_call = contact_call;
	}
	public String getInvoice() {
		return invoice;
	}
	public void setInvoice(String invoice) {
		this.invoice = invoice;
	}
	public String getInvoice_pic() {
		return invoice_pic;
	}
	public void setInvoice_pic(String invoice_pic) {
		this.invoice_pic = invoice_pic;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getProduct_num() {
		return product_num;
	}
	public void setProduct_num(String product_num) {
		this.product_num = product_num;
	}
	public String getBuy_date() {
		return buy_date;
	}
	public void setBuy_date(String buy_date) {
		this.buy_date = buy_date;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getRemark_check() {
		return remark_check;
	}
	public void setRemark_check(String remark_check) {
		this.remark_check = remark_check;
	}
	public String getStart_time1() {
		return start_time1;
	}
	public void setStart_time1(String start_time1) {
		this.start_time1 = start_time1;
	}
	public String getEnd_time1() {
		return end_time1;
	}
	public void setEnd_time1(String end_time1) {
		this.end_time1 = end_time1;
	}
	

}
