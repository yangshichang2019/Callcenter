package com.konka.electric.model;

import com.konka.system.model.ExeclImport;

public class EleImport extends ExeclImport {

}
