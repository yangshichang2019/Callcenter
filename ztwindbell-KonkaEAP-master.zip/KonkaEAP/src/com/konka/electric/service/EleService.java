package com.konka.electric.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.electric.model.EleFreeWry;
import com.konka.electric.model.EleImport;
import com.konka.electric.model.EleOrder;
import com.konka.useradmin.model.User;

public interface EleService {
	public List getOrderList(EleOrder eleOrder,Page page) throws Exception;
	public void saveEleImport(EleImport eleImport,User user) throws Exception;
	public List getImportList(EleImport eleImport,Page page) throws Exception;
	public void deleteOrderByObject(EleOrder eleOrder) throws Exception;
	public List getFreeWryList(EleFreeWry eleFreeWry, Page page) throws Exception;
	public EleFreeWry getFreeWry(EleFreeWry eleFreeWry) throws Exception;
	public EleFreeWry deleteFreeWry(EleFreeWry eleFreeWry) throws Exception;
	public void updateWry(EleFreeWry eleFreeWry)throws Exception;
	public EleFreeWry saveFreeWry(EleFreeWry eleFreeWry, User user);
	public EleFreeWry UpdateSuccessFreeWry(EleFreeWry eleFreeWry);
}
