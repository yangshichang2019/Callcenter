package com.konka.electric.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.electric.dao.EleFreeWryDAO;
import com.konka.electric.dao.EleImportDAO;
import com.konka.electric.dao.EleOrderDAO;
import com.konka.electric.model.EleFreeWry;
import com.konka.electric.model.EleImport;
import com.konka.electric.model.EleOrder;
import com.konka.useradmin.model.User;

@Service("eleService")
@Transactional  
public class EleServiceImp implements EleService {
	@Autowired
	private EleOrderDAO eleOrderDAO;
	@Autowired
	private EleImportDAO eleImportDAO;
	@Autowired
	private EleFreeWryDAO eleFreeWryDAO;
	
	
	
	
	public List getOrderList(EleOrder eleOrder,Page page) throws Exception {
		return eleOrderDAO.getObjectList(eleOrder, page);
	}
	public void saveEleImport(EleImport eleImport,User user) throws Exception {
		if(eleImport.getId()!=null&&eleImport.getId()>0) {
			Util.setUpdateToVO(eleImport, user);
			eleImportDAO.update(eleImport);
		}else {
			Util.setCreateToVO(eleImport, user);
			eleImportDAO.insert(eleImport);
		}
	}

	public List getImportList(EleImport eleImport,Page page) throws Exception {
		return eleImportDAO.getObjectList(eleImport, page);
	}
	public void deleteOrderByObject(EleOrder eleOrder) throws Exception {
		eleOrderDAO.deleteByObject(eleOrder);
	}
	public List getFreeWryList(EleFreeWry eleFreeWry, Page page) throws Exception {
		return eleFreeWryDAO.getObjectList(eleFreeWry, page);
	}
	@Override
	public EleFreeWry getFreeWry(EleFreeWry eleFreeWry) throws Exception {
		return (EleFreeWry) eleFreeWryDAO.getById(eleFreeWry.getId());
	}

	
	@Override
	public void updateWry(EleFreeWry eleFreeWry) throws Exception {
		eleFreeWryDAO.updateWry(eleFreeWry);
		
	}
	@Override
	public EleFreeWry saveFreeWry(EleFreeWry eleFreeWry,User user) {
		Util.setUpdateToVO(eleFreeWry, user);
		eleFreeWryDAO.saveWry(eleFreeWry);
		return null;
	}
	
	
	public EleFreeWry UpdateSuccessFreeWry(EleFreeWry eleFreeWry) {
		int i=0;
		if(eleFreeWry.getValues().contains("A")){
			i++;
		}if(eleFreeWry.getValues().contains("C")){
			i++;
		}if(eleFreeWry.getValues().contains("D")){
			i++;
		}
		
		if(i==0){
			String strs[] = eleFreeWry.getValues().split(",");
			String values = "";
			for(String str :strs){
				 str = str.substring(0,str.indexOf(":") );
				 values = values+str+",";
			}
			eleFreeWry.setValues(values.substring(0,values.length()-1));
			eleFreeWryDAO.updateWry(eleFreeWry);
			eleFreeWry.setEnable_flag("T");
		}else{
			eleFreeWry.setEnable_flag("G");
		}
		
		return eleFreeWry;
	}
	
	
	public EleFreeWry deleteFreeWry(EleFreeWry eleFreeWry) throws Exception {
		String strs[] = eleFreeWry.getValues().split(",");
		String values = "";
		for(String str :strs){
			 str = str.substring(0,str.indexOf(":") );
			 values = values+str+",";
		}
		eleFreeWry.setValues(values.substring(0,values.length()-1));
		eleFreeWryDAO.deleteWry(eleFreeWry);
		return null;
	}
}
