package com.konka.electric.action;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.FileTool;
import com.konka.electric.model.EleFreeWry;
import com.konka.electric.model.EleImport;
import com.konka.electric.model.EleOrder;
import com.konka.electric.service.EleService;
import com.konka.job.research.model.ResField;
import com.konka.system.model.ExeclCell;
import com.konka.system.model.ExeclImport;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
@Controller
@Scope("prototype")
public class EleAction extends BaseAction {
	@Autowired
	private EleService eleService;
	@Autowired
	private SystemService systemService;
	
	private File filedata;
    private String filedataFileName;  
    private String wry_ids; 
	private EleOrder eleOrder = new EleOrder();
	private EleImport eleImport = new EleImport();
	private EleFreeWry eleFreeWry = new EleFreeWry();
	private List tableColumnList = new ArrayList();
	private List execlColumnList = new ArrayList();
	private List typeList = new ArrayList();
	public String toPublicOrderList() throws Exception {
		if(first!=null&&first.equals("T")) {
			
		} else {
			if(!eleOrder.getOrder_num().equals("")||!eleOrder.getCust_name().equals("")||!eleOrder.getPhone().equals("")) {
				if(!eleOrder.getPhone().equals("")) {
					if(eleOrder.getPhone().length()<10) {
						super.toError("电话号码不能少于10位");
						return Constant.ACTION_S.ajaxDone.toString();
					}
				}
				dataList = eleService.getOrderList(eleOrder,page);
			}
		}
		return "toPublicOrderList";
	}
	public String toOrderList() throws Exception {
		if(first!=null&&first.equals("T")) {
			eleOrder.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00", DateTool.dateAdd(null, "MONTH", -3)) );
			eleOrder.setEnd_time(DateTool.formatDate("yyyy-MM-dd 23:59:59", null ));
		} else {
			dataList = eleService.getOrderList(eleOrder,page);
		}
		return "toOrderList";
	}
	public String toImportList() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		eleImport.setEnable_flag("T");
		eleImport.setCreate_employee(user.getUsername());
		dataList = eleService.getImportList(eleImport,page);
		return "toImportList";
	}
	public String toUploadExecl() throws Exception {
	
		return "toUploadExecl";
	}
	public String toSaveUploadExecl() throws Exception {

		User user = (User)super.getSession().get(Constant.SESSION_USER);
		if(FileTool.getExtention(filedataFileName).equals("xls")) {
			try {
				
				eleService.saveEleImport(eleImport,user);
				List fieldList = new ArrayList();
				ExeclCell execlCell = null;
				for(int i=0;i<tableColumnList.size();i++) {
					if(!((String)tableColumnList.get(i)).equals("")) {
						execlCell = new ExeclCell();
						execlCell.setTable_column((String)tableColumnList.get(i));
						execlCell.setExecl_column(Integer.parseInt((String)execlColumnList.get(i)));
						execlCell.setType((String)typeList.get(i));
						fieldList.add(execlCell);
					}
				}
				if(fieldList.size()>0) {
					eleImport = (EleImport) systemService.insertBatchExeclData(filedata,eleImport,fieldList,user);
				}

				if(eleImport.getResult()!=null&&!eleImport.getResult().equals("")){
					super.toError(eleImport.getResult());
				}else {
					eleService.saveEleImport(eleImport, user);
				}
			} catch (Exception e) {
				super.toError("导入失败！");
				e.printStackTrace();
			}
		}else {
			super.toError("上传文件格式不正确！");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toBatchDeleteOrder() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		eleImport.setEnable_flag("F");
		eleService.saveEleImport(eleImport, user);
		eleOrder.setImport_id(eleImport.getId());
		eleService.deleteOrderByObject(eleOrder);
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	
	public String toInsertImport() throws Exception{
		if(FileTool.getExtention(filedataFileName).equals("xls")) {
			User user = (User) super.getSession().get(Constant.SESSION_USER);
			ExeclImport execlImport = new ExeclImport();
			execlImport.setTable("KK_ELECTRIC_FREEWRY");
			execlImport.setCreate_info("T");
			execlImport.setInsert_limit(20000);
			List fieldList = new ArrayList();
			ExeclCell execlCell = new ExeclCell();
			execlCell.setTable_column("ORDER_NUM");
			execlCell.setExecl_column(0);
			execlCell.setType("String");
			fieldList.add(execlCell);
			
			if (fieldList.size() > 0) {
				systemService.insertBatchExeclData(filedata,execlImport, fieldList, user);
			}
			if(execlImport.getResult()!=null&&!execlImport.getResult().equals("")) {
				super.toError(execlImport.getResult());
			}
		}else{
			super.toError("上传文件格式不正确！");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toUploadFreeWry() throws Exception {
		return "toUploadFreeWry";
	}
	
	public String toFreewryList() throws Exception {
		if(first!=null&&first.equals("T")) {
			eleFreeWry.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00", DateTool.dateAdd(null, "MONTH", -3)) );
			eleFreeWry.setEnd_time(DateTool.formatDate("yyyy-MM-dd 23:59:59", null ));
		}else{
			dataList = eleService.getFreeWryList(eleFreeWry,page);
		}
		return "toFreewryList";
	}
	
	
	public String toAddEditWry() throws Exception {
		eleFreeWry = eleService.getFreeWry(eleFreeWry);
		return "toAddEditWry";
	}
	
	public String toSaveWry() throws Exception {
		
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		eleFreeWry = eleService.saveFreeWry(eleFreeWry,user);
		 return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toUpdateSuccess() throws Exception {
		eleFreeWry.setValues(wry_ids);
		eleFreeWry.setStatus("C");
		eleFreeWry = eleService.UpdateSuccessFreeWry(eleFreeWry);
		if(eleFreeWry.getEnable_flag().equals("G")){
			super.toError("请选择状态为待核验的单据");
		}else{
			super.setCallbackType("");
		}
	    return Constant.ACTION_S.ajaxDone.toString();
	}
	
	
	public String toUpdateFalse() throws Exception {
		eleFreeWry.setValues(wry_ids);
		eleFreeWry.setStatus("D");
		eleFreeWry = eleService.UpdateSuccessFreeWry(eleFreeWry);
		if(eleFreeWry.getEnable_flag().equals("G")){
			super.toError("请选择状态为待核验的单据");
		}else{
			super.setCallbackType("");
		}
	    return Constant.ACTION_S.ajaxDone.toString();
	}
	
	
	public String toDeleteWry() throws Exception {
		eleFreeWry.setValues(wry_ids);
		eleService.deleteFreeWry(eleFreeWry);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public EleOrder getEleOrder() {
		return eleOrder;
	}
	public void setEleOrder(EleOrder eleOrder) {
		this.eleOrder = eleOrder;
	}
	public File getFiledata() {
		return filedata;
	}
	public void setFiledata(File filedata) {
		this.filedata = filedata;
	}
	public String getFiledataFileName() {
		return filedataFileName;
	}
	public void setFiledataFileName(String filedataFileName) {
		this.filedataFileName = filedataFileName;
	}
	public EleImport getEleImport() {
		return eleImport;
	}
	public void setEleImport(EleImport eleImport) {
		this.eleImport = eleImport;
	}
	public List getTableColumnList() {
		return tableColumnList;
	}
	public void setTableColumnList(List tableColumnList) {
		this.tableColumnList = tableColumnList;
	}
	public List getExeclColumnList() {
		return execlColumnList;
	}
	public void setExeclColumnList(List execlColumnList) {
		this.execlColumnList = execlColumnList;
	}
	public List getTypeList() {
		return typeList;
	}
	public void setTypeList(List typeList) {
		this.typeList = typeList;
	}
	public EleFreeWry getEleFreeWry() {
		return eleFreeWry;
	}
	public void setEleFreeWry(EleFreeWry eleFreeWry) {
		this.eleFreeWry = eleFreeWry;
	}
	public String getWry_ids() {
		return wry_ids;
	}
	public void setWry_ids(String wry_ids) {
		this.wry_ids = wry_ids;
	}
	
}
