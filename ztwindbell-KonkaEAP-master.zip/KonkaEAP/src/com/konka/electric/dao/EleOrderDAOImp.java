package com.konka.electric.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("eleOrderDAO")
public class EleOrderDAOImp extends BaseDAOImp implements EleOrderDAO {
	public EleOrderDAOImp(){
		super.setMapper("com.konka.electric.model.EleOrder");
	}
}
