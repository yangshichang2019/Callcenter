package com.konka.electric.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.electric.model.EleFreeWry;
@Repository("EleFreeWryDAO")
public class EleFreeWryDAOImp extends BaseDAOImp implements EleFreeWryDAO {
	public EleFreeWryDAOImp(){
		super.setMapper("com.konka.electric.model.EleFreeWry");
	}

	@Override
	public Object deleteWry(EleFreeWry eleFreeWry) {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteWry", eleFreeWry);
		return null;
	}

	@Override
	public void updateWry(EleFreeWry eleFreeWry) {
		this.getSqlSessionTemplate().update(this.getMapper() + ".updateWry", eleFreeWry);
	}

	@Override
	public void saveWry(EleFreeWry eleFreeWry) {
		this.getSqlSessionTemplate().update(this.getMapper() + ".saveWry", eleFreeWry);
	}
}
