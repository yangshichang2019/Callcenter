package com.konka.electric.dao;

import com.konka.common.base.BaseDAO;

public interface EleOrderDAO extends BaseDAO {

}
