package com.konka.electric.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("eleImportDAO")
public class EleImportDAOImp extends BaseDAOImp implements EleImportDAO {
	public EleImportDAOImp() {
		super.setMapper("com.konka.electric.model.EleImport");
	}
}
