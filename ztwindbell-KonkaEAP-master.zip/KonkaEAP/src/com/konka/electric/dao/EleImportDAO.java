package com.konka.electric.dao;

import com.konka.common.base.BaseDAO;

public interface EleImportDAO extends BaseDAO {

}
