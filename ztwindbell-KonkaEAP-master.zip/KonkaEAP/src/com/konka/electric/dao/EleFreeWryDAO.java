package com.konka.electric.dao;

import com.konka.common.base.BaseDAO;
import com.konka.electric.model.EleFreeWry;

public interface EleFreeWryDAO extends BaseDAO {
	public Object deleteWry(EleFreeWry eleFreeWry);

	public void updateWry(EleFreeWry eleFreeWry);

	public void saveWry(EleFreeWry eleFreeWry);
	
	
}
