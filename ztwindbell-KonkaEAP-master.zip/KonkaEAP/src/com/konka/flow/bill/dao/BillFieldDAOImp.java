package com.konka.flow.bill.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("billFieldDAO")
public class BillFieldDAOImp extends BaseDAOImp implements BillFieldDAO {
	public BillFieldDAOImp() {
		super.setMapper("com.konka.flow.bill.model.BillField");
	}
}
