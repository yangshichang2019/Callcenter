package com.konka.flow.bill.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("billTypeDAO")
public class BillTypeDAOImp extends BaseDAOImp implements BillTypeDAO {
	public BillTypeDAOImp() {
		super.setMapper("com.konka.flow.bill.model.BillType");
	}
}
