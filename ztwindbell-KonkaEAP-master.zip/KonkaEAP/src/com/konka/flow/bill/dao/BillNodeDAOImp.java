package com.konka.flow.bill.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("billNodeDAO")
public class BillNodeDAOImp extends BaseDAOImp implements BillNodeDAO {
	public BillNodeDAOImp() {
		super.setMapper("com.konka.flow.bill.model.BillNode");
	}
}
