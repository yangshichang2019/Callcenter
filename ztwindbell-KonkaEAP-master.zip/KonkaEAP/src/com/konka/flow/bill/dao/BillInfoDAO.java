package com.konka.flow.bill.dao;

import com.konka.common.base.BaseDAO;
import com.konka.flow.bill.model.BillInfo;

public interface BillInfoDAO extends BaseDAO {
	public BillInfo getBillInfoCount(BillInfo billInfo) throws Exception;
}
