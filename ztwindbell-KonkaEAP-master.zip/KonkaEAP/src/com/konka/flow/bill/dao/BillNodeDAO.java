package com.konka.flow.bill.dao;

import com.konka.common.base.BaseDAO;

public interface BillNodeDAO  extends BaseDAO{

}
