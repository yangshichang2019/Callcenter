package com.konka.flow.bill.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.flow.bill.model.BillInfo;
@Repository("billInfoDAO")
public class BillInfoDAOImp extends BaseDAOImp implements BillInfoDAO {
	public BillInfoDAOImp() {
		super.setMapper("com.konka.flow.bill.model.BillInfo");
	}
	public BillInfo getBillInfoCount(BillInfo billInfo) throws Exception {
		return (BillInfo)super.getSqlSessionTemplate().selectOne(super.getMapper()+".getBillInfoCount", billInfo);
	}
}
