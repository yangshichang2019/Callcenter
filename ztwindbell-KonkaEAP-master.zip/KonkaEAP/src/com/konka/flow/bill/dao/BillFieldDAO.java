package com.konka.flow.bill.dao;

import com.konka.common.base.BaseDAO;

public interface BillFieldDAO extends BaseDAO {

}
