package com.konka.flow.bill.action;

import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.asm.commons.Remapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.flow.bill.model.BillField;
import com.konka.flow.bill.model.BillInfo;
import com.konka.flow.bill.model.BillNode;
import com.konka.flow.bill.model.BillType;
import com.konka.flow.bill.service.BillService;
import com.konka.system.model.Record;
import com.konka.system.model.Remark;
import com.konka.system.model.Remind;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.Group;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;
@Controller
@Scope("prototype")
public class BillAction extends BaseAction {
	@Autowired
	private BillService billService;
	@Autowired
	private SystemService systemService;
	@Autowired
	private UserAdminService userAdminService;
	private BillType billType = new BillType();
	private BillField billField = new BillField();
	private BillInfo billInfo = new BillInfo();
	private BillNode billNode = new BillNode();
	private Record record = new Record();
	private Remark remark = new Remark();
	private Integer submit_times = 0;
	//进入转单类型列表
	public String toBillTypeList() throws Exception {
		dataList = billService.getBillTypeList(billType,page);
		return "toBillTypeList";
	}
	//进入新建修改转单类型
	public String toAddEditBillType() throws Exception {
		if(billType.getId()!=null&&billType.getId()>0) {
			billType = billService.getBillTypeInfo(billType);	
		}
		return "toAddEditBillType";
	}
	//保存转单类型
	public String toSaveBillType() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		if(billType.getAdd_count_b()>0) {
			if(billType.getAdd_count_a()>billType.getAdd_count_b()) {
				super.toError("较急补话次数必须小于紧急补话次数！");
			}
		}
		billService.saveBillType(billType,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//发起转单
	public String toUserBillTypeList() throws Exception {
		List typeList = Constant.codeMap.get("BILL_TYPE");
		super.getRequest().setAttribute("typeList", typeList);
		billType.setEnable_flag("T");
		dataList = billService.getAllBillTypeList(billType);

		String phoneNum = Util.getCookiesByName(super.getRequest(), "openeap.Caller");
		if(!"".equals(phoneNum)) {
			billInfo.setFromCall(phoneNum);
			billInfo.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00",DateTool.dateAdd(null, "MONTH", -1)));
			List infoList = billService.getBillInfoList(billInfo, page);
			super.getRequest().setAttribute("infoList", infoList);
		}
		
		billInfo = new BillInfo();
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billInfo.setCreate_employee(user.getUsername());
		billInfo = billService.getBillInfoCount(billInfo);

		return "toUserBillTypeList";
	}
	//========================================================
	//进入字段列表
	public String toBillTypeFieldList() throws Exception{
		dataList = billService.getAllBillFieldList(billField);
		return "toBillTypeFieldList";
	}
	//进入修改字段信息
	public String toAddEditBillField() throws Exception {
		if(billField.getId()!=null&&billField.getId()>0) {
			billField = billService.getBillFieldInfo(billField);
		}else {
			billField.setNode_id(0);
		}
		billNode.setType_id(billField.getType_id());
		dataList = billService.getAllBillNodeList(billNode);
		return "toAddEditBillField";
	}
	//保存字段信息
	public String toSaveBillField() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billService.saveBillField(billField,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//========================================================
	//创建修改转单(新转单)
	public String toAddEditBillInfo() throws Exception {
		List fieldList = new ArrayList();
		//修改
		if(billInfo.getId()!=null&&billInfo.getId()>0) {
			billInfo = billService.getBillInfo(billInfo);
			billType.setId(billInfo.getType_id());
			billType = billService.getBillTypeInfo(billType);
			if(billInfo.getNode_id().equals(0)) {
				//显示下级节点
				BillNode vo = new BillNode();
				vo.setType_id(billType.getId());
				vo.setParent_id(0);
				vo.setEnable_flag("T");
				dataList = billService.getAllBillNodeList(vo);	
			}
			fieldList = toGetBillInfoFieldData(billInfo,0);

		}else {
			billType.setId(billInfo.getType_id());
			billType = billService.getBillTypeInfo(billType);
			//显示下级节点
			BillNode vo = new BillNode();
			vo.setType_id(billType.getId());
			vo.setParent_id(0);
			vo.setEnable_flag("T");
			dataList = billService.getAllBillNodeList(vo);		
			
			billField.setEnable_flag("T");
			billField.setType_id(billInfo.getType_id());
			billField.setNode_id(0);
			fieldList = billService.getAllBillFieldList(billField);
			
			String phoneNum = Util.getCookiesByName(super.getRequest(), "openeap.Caller");
			if(!"".equals(phoneNum)) {
				BillInfo info = new BillInfo();
				info.setFromCall(phoneNum);
				info.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00",DateTool.dateAdd(null, "MONTH", -1)));
				List infoList = billService.getBillInfoList(info, page);
				super.getRequest().setAttribute("infoList", infoList);
			}
			
			
		}
		super.getRequest().setAttribute("fieldList", fieldList);
		return "toAddEditBillInfo";
	}
	
	
	
	//========================================================
			//获取联系电话ajax以往转单信息(新转单)
		
		public String getContactInfo() throws Exception {
			
			String  phoneNum = billInfo.getValues() ;
			BillInfo info = new BillInfo();
			info.setFromCall(phoneNum);
			info.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00",DateTool.dateAdd(null, "MONTH", -1)));
			List infoList = billService.getBillInfoList(info, page);
			super.getResponse().setContentType("text/xml;charset=utf-8");
			super.getResponse().setCharacterEncoding("UTF-8");
			JSONArray jsonArray=new JSONArray();
		
			if(infoList!=null && infoList.size()>0 ) {
				 PrintWriter out= super.getResponse().getWriter();
				 JSONObject obj=null;
				 for(int i=0;i<infoList.size();i++){
					 BillInfo info1 = (BillInfo) infoList.get(i);
					 obj = new JSONObject();
					 obj.put("name",info1.getBillType().getName());
					 obj.put("id", info1.getId());
					 obj.put("num", info1.getNum());
					 if(info1.getBill_status().equals("READY")){
						 obj.put("bill_status", "<a style='color:red;text-decoration:none;'>待受理</a>");
					 }else if(info1.getBill_status().equals("ACCEPT")){
						 obj.put("bill_status", "<a style='color:green;text-decoration:none;'>已受理</a>");
					 }else if(info1.getBill_status().equals("DESTORY")){
						 obj.put("bill_status", "<a style='color:grey;text-decoration:none;'>废弃</a>");
					 }else if(info1.getBill_status().equals("COMPLET")){
						 obj.put("bill_status", "<a style='color:green;text-decoration:none;'>办结</a>");
					 }else if(info1.getBill_status().equals("BACKED")){
						 obj.put("bill_status", "<a style='color:red;text-decoration:none;'>驳回</a>");
					 }
					 obj.put("create_time", info1.getCreate_time().toString().substring(0,info1.getCreate_time().toString().length()-4 ));
					 jsonArray.add(obj);
				 }
				 out.println(jsonArray.toString());
				 out.close();
			}
			return null;
		}
	
	
	
	
	
	
	
	
	//获取单据扩展字段信息
	public List toGetBillInfoFieldData(BillInfo bill,Integer node_id) throws Exception {
		BillField vo = new BillField();
		vo.setEnable_flag("T");
		vo.setType_id(bill.getType_id());
		if(node_id!=null) {
			vo.setNode_id(node_id);
		}
		List tempList = billService.getAllBillFieldList(vo);
		List list = new ArrayList();
		if(tempList!=null&&tempList.size()>0) {
			for(int i=0;i<tempList.size();i++) {
				BillField tempVO = (BillField)tempList.get(i);
				if(tempVO.getKey().equals("a")) {
					if(bill.getA()!=null) {
						tempVO.setValue(bill.getA());
					}
				}else if(tempVO.getKey().equals("b")) {
					if(bill.getB()!=null) {
						tempVO.setValue(bill.getB());
					}
				}else if(tempVO.getKey().equals("c")) {
					if(bill.getC()!=null) {
						tempVO.setValue(bill.getC());
					}
				}else if(tempVO.getKey().equals("d")) {
					if(bill.getD()!=null) {
						tempVO.setValue(bill.getD());
					}
				}else if(tempVO.getKey().equals("e")) {
					if(bill.getE()!=null) {
						tempVO.setValue(bill.getE());
					}
				}else if(tempVO.getKey().equals("f")) {
					if(bill.getF()!=null) {
						tempVO.setValue(bill.getF());
					}
				}else if(tempVO.getKey().equals("g")) {
					if(bill.getG()!=null) {
						tempVO.setValue(bill.getG());
					}
				}else if(tempVO.getKey().equals("h")) {
					if(bill.getH()!=null) {
						tempVO.setValue(bill.getH());
					}
				}else if(tempVO.getKey().equals("i")) {
					if(bill.getI()!=null) {
						tempVO.setValue(bill.getI());
					}
				}else if(tempVO.getKey().equals("j")) {
					if(bill.getJ()!=null) {
						tempVO.setValue(bill.getJ());
					}
				}else if(tempVO.getKey().equals("k")) {
					if(bill.getK()!=null) {
						tempVO.setValue(bill.getK());
					}
				}else if(tempVO.getKey().equals("l")) {
					if(bill.getL()!=null) {
						tempVO.setValue(bill.getL());
					}
				}else if(tempVO.getKey().equals("m")) {
					if(bill.getM()!=null) {
						tempVO.setValue(bill.getM());
					}
				}else if(tempVO.getKey().equals("n")) {
					if(bill.getN()!=null) {
						tempVO.setValue(bill.getN());
					}
				}else if(tempVO.getKey().equals("o")) {
					if(bill.getO()!=null) {
						tempVO.setValue(bill.getO());
					}
				}else if(tempVO.getKey().equals("p")) {
					if(bill.getP()!=null) {
						tempVO.setValue(bill.getP());
					}
				}else if(tempVO.getKey().equals("q")) {
					if(bill.getQ()!=null) {
						tempVO.setValue(bill.getQ());
					}
				}else if(tempVO.getKey().equals("r")) {
					if(bill.getR()!=null) {
						tempVO.setValue(bill.getR());
					}
				}else if(tempVO.getKey().equals("s")) {
					if(bill.getS()!=null) {
						tempVO.setValue(bill.getS());
					}
				}else if(tempVO.getKey().equals("t")) {
					if(bill.getT()!=null) {
						tempVO.setValue(bill.getT());
					}
				}
				list.add(tempVO);
			}
		}
		return list;
	}
	//保存转单
	public String toSaveBillInfo() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
	
		//新建单据
		if(billInfo.getId()==null||billInfo.getId()==0) {
			if(submit_times==1) {
				BillInfo info = new BillInfo();
				info.setFromCall(billInfo.getContactCall());
				info.setType_id(billInfo.getType_id());
				info.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00",DateTool.dateAdd(null, "MONTH", -1)));
				List infoList = billService.getBillInfoList(info, page);
				if(infoList.size()>0) {
					BillInfo infot = (BillInfo)infoList.get(0);
					super.toError("存在相同联系电话的此类转单:"+infot.getNum()+"，请确定是否需要提交！");
					return Constant.ACTION_S.ajaxDone.toString();
				}
			}
			billInfo.setNum(systemService.getNextNum("Z", "KK_BILL_NUM_S", 4));
			billInfo.setRecord_id(Util.getCookiesByName(super.getRequest(), "openeap.RecordId"));
			billService.saveBillInfo(billInfo,user);
			//操作记录
			if(billInfo.getNode_id()>0) {
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveBillInfo", "创建", "0", billInfo.getNode_id()+"","","READY","F"), user);
				
			} else {
				//不转出
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveBillInfo", "暂留", "0", billInfo.getNode_id()+"","","ACCEPT","F"), user);
			}
		} else {
			//修改后转出
			if(billInfo.getNode_id()>0) {
				BillInfo vo = billService.getBillInfo(billInfo);
				billInfo.setBill_status("READY");
				billInfo.setNode_id(billInfo.getNode_id());
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveBillInfo", "修改后转出", vo.getNode_id()+"", billInfo.getNode_id()+"",vo.getBill_status(),"READY","F"), user);
			} else {
				//继续修改
				BillInfo vo = billService.getBillInfo(billInfo);
				billInfo.setBill_status("ACCEPT");
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveBillInfo", "暂留", vo.getNode_id()+"", "0",vo.getBill_status(),"ACCEPT","F"), user);
			}
			billService.saveBillInfo(billInfo,user);
		}
		//提醒工作组
		if(billInfo.getNode_id()>0) {
			billNode.setId(billInfo.getNode_id());
			billNode = billService.getBillNodeInfo(billNode);
			if("T".equals(billNode.getIs_remind())) {
				List userList = userAdminService.strToUserList("{\"group\":\""+billNode.getDeal_group()+"\"}");
				systemService.insertRemind("BILL", billInfo.getId(),"新转单等待处理", "由 "+user.getUsername()+" 创建的用户转单 "+billInfo.getNum()+" 等待处理中。", null, null, userList, user);
			}
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//待处理工单列表
	public String toDealBillInfoList() throws Exception {
		if(billInfo.getStart_time()!=null&&!billInfo.getStart_time().equals("")) {
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			if(billInfo.getUser_id()==null||billInfo.getUser_id()==0) {
				billInfo.setUser_id(user.getId());
			}
			dataList = billService.getBillInfoList(billInfo,page);
		}else {
			billInfo.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00",DateTool.dateAdd(null, "MONTH", -1)));
		}
		return "toDealBillInfoList";
	}
	//开始处理
	public String toDealBillInfo() throws Exception {
		
		billInfo = billService.getBillInfo(billInfo);
		List fieldList = toGetBillInfoFieldData(billInfo,null);
		super.getRequest().setAttribute("fieldList", fieldList);
		//显示下级节点
		BillNode vo = new BillNode();
		vo.setType_id(billInfo.getType_id());
		vo.setParent_id(billInfo.getNode_id());
		vo.setEnable_flag("T");
		List nodeList = billService.getAllBillNodeList(vo);		
		super.getRequest().setAttribute("nodeList", nodeList);
		
		billNode.setId(billInfo.getNode_id());
		billNode = billService.getBillNodeInfo(billNode);
		
		billType.setId(billInfo.getType_id());
		billType = billService.getBillTypeInfo(billType);
		
		dataList = systemService.getRecordForModel(billInfo.getId(),"BILL");
		
		List remarkList = systemService.getModelRemark(billInfo.getId(), "BILL");
		super.getRequest().setAttribute("remarkList", remarkList);
		
		List imList = systemService.getRecordForModel(billInfo.getId(),"BILL","T");
		super.getRequest().setAttribute("imList", imList);
		
		return "toDealBillInfo";
	}
	//保存受理结果
	public String toSaveDealBillInfo() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		BillInfo vo = new BillInfo();
		vo.setId(billInfo.getId());
		vo = billService.getBillInfo(vo);
		billInfo.setRemark_flag(vo.getRemark_flag());//为处理等级提供参数
		billInfo.setComplet(record.getContent());//收集完成意见
		//获取当前节点
		billNode.setId(vo.getNode_id());
		billNode = billService.getBillNodeInfo(billNode);
		//如果此节点允许记录录音编号
		if("T".equals(billNode.getIs_record_id())) {
			String record_id = Util.getCookiesByName(super.getRequest(), "openeap.RecordId");
			if(record_id!="") {
				if(vo.getDeal_record_id()!=null&&!vo.getDeal_record_id().equals("")) {
					if(billInfo.getDeal_record_id()!=null&&billInfo.getDeal_record_id().equals("T")) {
						billInfo.setDeal_record_id(record_id);
					}
				}else {
					billInfo.setDeal_record_id(record_id);
				}
			}
		}
		
		//办结
		if(("COMPLET").equals(record.getNow_node())) {
			billInfo.setBill_status("COMPLET");
			billInfo.setOver_time(Util.getTimestamp());
			billService.saveBillInfo(billInfo, user);
			systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveDealBillInfo", record.getContent(), vo.getNode_id()+"", vo.getNode_id()+"",vo.getBill_status(),billInfo.getBill_status(),"T"), user);
			
			systemService.insertRemind("BILL",billInfo.getId(), "转单已办结", user.getUsername()+" 办结了你创建的用户转单 "+vo.getNum()+" 。", null, null, vo.getCreate_employee(), user);
			
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//作废
		if(("DESTORY").equals(record.getNow_node())) {
			billInfo.setBill_status("DESTORY");
			billInfo.setOver_time(Util.getTimestamp());
			billService.saveBillInfo(billInfo, user);
			systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveDealBillInfo", record.getContent(), vo.getNode_id()+"", vo.getNode_id()+"",vo.getBill_status(),billInfo.getBill_status(),"T"), user);
			
			systemService.insertRemind("BILL",billInfo.getId(), "转单已作废", user.getUsername()+" 作废了你创建的用户转单 "+vo.getNum()+" 。", null, null, vo.getCreate_employee(), user);
			
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//跟踪处理
		if((vo.getNode_id()+"").equals(record.getNow_node())) {
			billInfo.setBill_status(vo.getBill_status());//为处理等级提供参数
			billService.saveBillInfo(billInfo, user);
			//跟踪处理进度
			systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveDealBillInfo", record.getContent(), vo.getNode_id()+"", vo.getNode_id()+"",vo.getBill_status(),"ACCEPT","T"), user);
		}else {

			//下个节点是父节点，也可能是0
			if(record.getNow_node().equals(billNode.getParent_id()+"")) {
				billInfo.setAccept_user("");
				billInfo.setNode_id(Integer.parseInt(record.getNow_node()));
				billInfo.setBill_status("BACKED");
				billService.saveBillInfo(billInfo, user);
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveDealBillInfo", record.getContent(), vo.getNode_id()+"",billInfo.getNode_id()+"",vo.getBill_status(),billInfo.getBill_status(),"T"), user);
			
				if(billNode.getParent_id().equals(0)) {
					systemService.insertRemind("BILL",billInfo.getId(), "转单被驳回", user.getUsername()+" 驳回了用户转单 "+vo.getNum()+" 。", null, null, vo.getCreate_employee(), user);
				}else {
					BillNode Bvo = new BillNode();
					Bvo.setId(billNode.getParent_id());
					Bvo = billService.getBillNodeInfo(Bvo);
					List userList = userAdminService.strToUserList("{\"group\":\""+Bvo.getDeal_group()+"\"}");
					systemService.insertRemind("BILL",billInfo.getId(), "转单被驳回", user.getUsername()+" 驳回了用户转单 "+vo.getNum()+" 。", null, null, userList, user);
				}
			//下个节点是正常节点
			} else {
				billInfo.setAccept_user("");
				billInfo.setNode_id(Integer.parseInt(record.getNow_node()));
				billInfo.setBill_status("READY");
				billService.saveBillInfo(billInfo, user);
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveDealBillInfo", record.getContent(), vo.getNode_id()+"",record.getNow_node(),vo.getBill_status(),"READY","T"), user);

				BillNode Bvo = new BillNode();
				Bvo.setId(billInfo.getNode_id());
				Bvo = billService.getBillNodeInfo(Bvo);
				if("T".equals(Bvo.getIs_remind())) {
					List userList = userAdminService.strToUserList("{\"group\":\""+Bvo.getDeal_group()+"\"}");
					systemService.insertRemind("BILL",billInfo.getId(), "新转单等待处理", "由 "+vo.getCreate_employee()+" 创建的用户转单 "+vo.getNum()+" 等待处理中。", null, null, userList, user);
				}
			}
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//受理单据
	public String toAcceptBillInfo() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billInfo = billService.getBillInfo(billInfo);
		if(Integer.parseInt(record.getNow_node())==billInfo.getNode_id()) {
			if(billInfo.getBill_status().equals("ACCEPT")) {
				super.toError("单据已被受理！");
			}else {
				if(billInfo.getNode_id()>0) {
					billNode.setId(billInfo.getNode_id());
					billNode = billService.getBillNodeInfo(billNode);
					Group group = new Group();
					group.setId(billNode.getDeal_group());
					group.getUser().setId(user.getId());
					group = userAdminService.isInGroup(group);
					if(group==null) {
						super.toError("没有权限受理此单据！");
					}else {
						BillInfo vo = new BillInfo();
						vo.setId(billInfo.getId());
						vo.setRemark_flag(billInfo.getRemark_flag());//为处理等级提供依据
						vo.setBill_status("ACCEPT");
						vo.setAccept_user(user.getUsername());
						if(billInfo.getReceive_time()==null) {
							vo.setReceive_time(Util.getTimestamp());
						}
						billService.saveBillInfo(vo, user);
						systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toAcceptBillInfo", "受理", billInfo.getNode_id()+"", billInfo.getNode_id()+"",billInfo.getBill_status(),vo.getBill_status(),"F"), user);
						//是提醒记录失效
						Remind re = new Remind();
						re.setModel("BILL");
						re.setObject_id(billInfo.getId());
						re.setRemind_end_time(DateTool.formatDate("yyyy-MM-dd HH:mm:ss", null));
						systemService.updateRemindBatch(re, user);
					}
				}else {
					super.toError("单据未转出！");
				}
			}
		} else {
			super.toError("单据已转出！");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//切换受理人
	public String toChangeAcceptBillInfo() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billInfo = billService.getBillInfo(billInfo);
		
		if(billInfo.getBill_status().equals("ACCEPT")&&!billInfo.getAccept_user().equals("")){
			billNode.setId(billInfo.getNode_id());
			billNode = billService.getBillNodeInfo(billNode);
			Group g = new Group();
			g.setId(billNode.getDeal_group());
			User u = new User();
			u.setUsername(billInfo.getAccept_user());
			u = userAdminService.getUserByObject(u);
			g.getUser().setId(u.getId());
			g = userAdminService.isInGroup(g);
			if(g==null) {
				g = new Group();
				g.setId(billNode.getDeal_group());
				g.getUser().setId(user.getId());
				g = userAdminService.isInGroup(g);
				if(g!=null) {
					BillInfo vo = new BillInfo();
					vo.setId(billInfo.getId());
					vo.setAccept_user(user.getUsername());
					billService.saveBillInfo(vo, user);
					systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toChangeAcceptBillInfo", "变更受理人", billInfo.getNode_id()+"", billInfo.getNode_id()+"",billInfo.getBill_status(),billInfo.getBill_status(),"F"), user);
				}else {
					super.toError("你没有权限处理！");
				}
			}else {
				super.toError("当前受理人仍在工作组！");
			}
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//取消受理
	public String toNotAcceptBillInfo() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billInfo = billService.getBillInfo(billInfo);
		if(billInfo.getAccept_user().equals(user.getUsername())) {
			BillInfo vo = new BillInfo();
			vo.setId(billInfo.getId());
			vo.setRemark_flag(billInfo.getRemark_flag());//为处理等级提供依据
			vo.setBill_status("READY");
			vo.setAccept_user("");
			billService.saveBillInfo(vo, user);
			systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toNotAcceptBillInfo", "取消受理", billInfo.getNode_id()+"", billInfo.getNode_id()+"",billInfo.getBill_status(),vo.getBill_status(),"F"), user);
		}else {
			super.toError("非当前受理人！");
		}
		
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//更新标记
	public String toUpdateBillRemarkFlag() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billInfo = billService.getBillInfo(billInfo);
		if(billInfo.getRemark_flag().equals("T")) {
			BillInfo vo = new BillInfo();
			vo.setId(billInfo.getId());
			vo.setRemark_flag("F");
			vo.setBill_status(billInfo.getBill_status());//为改变优先级
			billService.saveBillInfo(vo, user);
		}
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//补话
	public String toAddRemark() throws Exception {
		billInfo.setId(remark.getObject_id());
		billInfo = billService.getBillInfo(billInfo);		
		return "toAddRemark";
	}
	public String toSaveRemark() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		remark.setRecord_id(Util.getCookiesByName(super.getRequest(), "openeap.RecordId"));
		systemService.insertRemark(remark,user);
		
		billInfo.setId(remark.getObject_id());
		billInfo = billService.getBillInfo(billInfo);
		billType.setId(billInfo.getType_id());
		billType = billService.getBillTypeInfo(billType);
		BillInfo vo = new BillInfo();
		vo.setId(billInfo.getId());
		vo.setAdd_count(billInfo.getAdd_count()+1);
		if(billType.getAdd_count_a()>0) {
			if(vo.getAdd_count()>=billType.getAdd_count_a()) {
				vo.setRemind_status("B");
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveRemark", "升级为较急", billInfo.getNode_id()+"",billInfo.getNode_id()+"",billInfo.getBill_status(),billInfo.getBill_status(),"T"), user);
			}
		}
		if(billType.getAdd_count_b()>0) {
			if(vo.getAdd_count()>=billType.getAdd_count_b()) {
				vo.setRemind_status("C");
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toSaveRemark", "升级为紧急", billInfo.getNode_id()+"",billInfo.getNode_id()+"",billInfo.getBill_status(),billInfo.getBill_status(),"T"), user);
			}
		}
		vo.setRemark_flag("T");
		billService.saveBillInfo(vo, user);
		
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//撤回转单
	public String toBackBillInfo() throws Exception {
		billInfo = billService.getBillInfo(billInfo);
		if(!billInfo.getBill_status().equals("READY")) {
			super.toError("单据状态必须为未受理！");
		}else if(billInfo.getNode_id()==0) {
			super.toError("单据必须已流转出去！");
		}else{
			billNode.setId(billInfo.getNode_id());
			billNode = billService.getBillNodeInfo(billNode);
			if(billNode.getParent_id()!=0) {
				super.toError("此单据已无法撤回！");
			}else {
				User user = (User)super.getSession().get(Constant.SESSION_USER);
				BillInfo vo = new BillInfo();
				vo.setId(billInfo.getId());
				vo.setNode_id(0);
				vo.setRemark_flag(billInfo.getRemark_flag());//为处理等级提供依据
				vo.setBill_status("ACCEPT");
				billService.saveBillInfo(vo, user);
				systemService.insertRecord(new Record(billInfo.getId(),"BILL", "toBackBillInfo", "撤回", billInfo.getNode_id()+"", "0",billInfo.getBill_status(),"ACCEPT","F"), user);
			}
		}
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//转单查看
	public String toViewBillInfo() throws Exception {
		billInfo = billService.getBillInfo(billInfo);
		
		List fieldList = toGetBillInfoFieldData(billInfo,null);
		super.getRequest().setAttribute("fieldList", fieldList);
		
		billType.setId(billInfo.getType_id());
		billType = billService.getBillTypeInfo(billType);
		dataList = systemService.getRecordForModel(billInfo.getId(),"BILL");
		List remarkList = systemService.getModelRemark(billInfo.getId(), "BILL");
		super.getRequest().setAttribute("remarkList", remarkList);
		
		List imList = systemService.getRecordForModel(billInfo.getId(),"BILL","T");
		super.getRequest().setAttribute("imList", imList);
		
		return "toViewBillInfo";
	}
	//进入用户转单列表
	public String toUserBillInfoList() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billInfo.setCreate_employee(user.getUsername());
		dataList = billService.getBillInfoList(billInfo,page);
		return "toUserBillInfoList";
	}
	//进入公开转单信息查询列表
	public String toPublicBillInfoList() throws Exception {
		//billInfo.getBillType().setIs_public("T");
		/*if(billInfo.getNum()==null||billInfo.getNum().equals("")) {
			if(billInfo.getCust_name()==null||billInfo.getCust_name().equals("")){
				if(billInfo.getFromCall()==null||billInfo.getFromCall().equals("")){
					if(billInfo.getBill_status()==null||billInfo.getBill_status().equals("")){
						if(billInfo.getStart_time()==null||billInfo.getStart_time().equals("")) {
							if(billInfo.getEnd_time()==null||billInfo.getEnd_time().equals("")) {
								if(billInfo.getType_id()==null||billInfo.getType_id()==0){
									billInfo.setStart_time(DateTool.formatDate("yyyy-MM-dd", DateTool.dateAdd(null, "DAY", -3))+" 00:00:00");
									billInfo.setEnd_time(DateTool.formatDate("yyyy-MM-dd", null)+" 23:59:59");
								}
							}
						}
					}
				}
			}
		}*/
		if(super.getFirst()==null||super.getFirst().equals("")) {
			dataList = billService.getBillInfoList(billInfo, page);
		}else {
			billInfo.setStart_time(DateTool.formatDate("yyyy-MM-dd 00:00:00",DateTool.dateAdd(null, "MONTH", -1)));
		}

		return "toPublicBillInfoList";
	}
	//删除用户转单
	public String toUserDeleteBillInfo() throws Exception {
		billInfo = billService.getBillInfo(billInfo);
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		if(billInfo.getCreate_employee().equals(user.getUsername())&&billInfo.getNode_id().equals(0)) {
			billService.deleteBillInfo(billInfo);
		} else {
			super.toError("单据不允许删除！");
		}
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//选择转单类型
	public String toLookupBillType() throws Exception {
		billType.setEnable_flag("T");
		dataList = billService.getAllBillTypeList(billType);
		return "toLookupBillType";
	}
	//========================================================
	//进入类型节点列表
	public String toBillTypeNodeList() throws Exception {
		
		dataList = billService.getAllBillNodeList(billNode);
		return "toBillTypeNodeList";
	}
	//添加删除节点
	public String toAddEditBillNode() throws Exception {
		if(billNode.getId()!=null&&billNode.getId()>0) {
			billNode = billService.getBillNodeInfo(billNode);
			Group group = new Group();
			group.setId(billNode.getDeal_group());
			group = userAdminService.getGroupInfo(group);
			super.getRequest().setAttribute("billNode_names", group.getName());
		}
		return "toAddEditBillNode";
	}
	//保存节点
	public String toSaveBillNode() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		billService.saveBillNode(billNode,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除节点
	public String toDeleteBillNode() throws Exception {
		BillNode vo = new BillNode();
		vo.setParent_id(billNode.getId());
		dataList = billService.getAllBillNodeList(vo);
		if(dataList!=null&&dataList.size()>0) {
			super.toError("含有子节点不允许删除！");
		}else {
			billService.deleteBillNode(billNode);
			super.setCallbackType("");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//========================================================
	//

	//========================================================
	//========================================================
	public BillType getBillType() {
		return billType;
	}

	public void setBillType(BillType billType) {
		this.billType = billType;
	}
	public BillField getBillField() {
		return billField;
	}
	public void setBillField(BillField billField) {
		this.billField = billField;
	}
	public BillInfo getBillInfo() {
		return billInfo;
	}
	public void setBillInfo(BillInfo billInfo) {
		this.billInfo = billInfo;
	}
	public BillNode getBillNode() {
		return billNode;
	}
	public void setBillNode(BillNode billNode) {
		this.billNode = billNode;
	}
	public Record getRecord() {
		return record;
	}
	public void setRecord(Record record) {
		this.record = record;
	}
	public Remark getRemark() {
		return remark;
	}
	public void setRemark(Remark remark) {
		this.remark = remark;
	}
	public Integer getSubmit_times() {
		return submit_times;
	}
	public void setSubmit_times(Integer submit_times) {
		this.submit_times = submit_times;
	}
}
