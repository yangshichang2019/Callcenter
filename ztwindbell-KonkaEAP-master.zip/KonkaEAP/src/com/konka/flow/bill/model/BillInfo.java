package com.konka.flow.bill.model;

import java.sql.Timestamp;

import com.konka.common.base.BaseVO;
//用户转单
public class BillInfo extends BaseVO {
	private Integer id;
	private Integer type_id;
	private String type_name;
	private String num;
	private String bill_status;//待受理READY、已受理ACCEPT、废弃DESTORY、办结COMPLET、驳回BACKED
	private String remind_status;//紧急程度：普通A、较急B、紧急C
	private Integer node_id;//当前节点

	private String cust_id;//客户编号
	private String cust_name;
	private String fromCall;
	private String contactCall;
	private String record_id;//录音编号
	
	private String deal_record_id;//处理录音id
	
	private String remark;//描述备注
	
	private Integer add_count;//补话次数
	private String remark_flag;//补话标记
	private String time_limit_end;//根据时限推算出的截止日期
	
	private String accept_user;
	
	private Integer deal_level;//处理等级
	
	private BillType billType = new BillType();
	private BillNode billNode = new BillNode();
	private Integer user_id;
	private Integer pre_node_id;
	
	//基础扩展字段
	private String address;//用户地址
	private String fix_num;//关联工单
	//产品部分
	private String product_series;
	private String product_num;
	private String buy_date;
	private String company;//归属分公司
	//用户需求
	private String recall;//要求回电
	
	//预留字段
	private String a;
	private String b;
	private String c;
	private String d;
	private String e;
	private String f;
	private String g;
	private String h;
	private String i;
	private String j;
	private String k;
	private String l;
	private String m;
	private String n;
	private String o;
	private String p;
	private String q;
	private String r;
	private String s;
	private String t;
	
	//考核相关
	private Timestamp receive_time;//受理时间
	private Timestamp over_time;//办结时间
	private String complet;//完成意见
	private Integer count_all;//受理工单总数
	private Integer count_ready;//未发出工单总数
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public Integer getType_id() {
		return type_id;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
	public BillType getBillType() {
		return billType;
	}
	public void setBillType(BillType billType) {
		this.billType = billType;
	}
	public String getCust_id() {
		return cust_id;
	}
	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public String getFromCall() {
		return fromCall;
	}
	public void setFromCall(String fromCall) {
		this.fromCall = fromCall.trim();
	}
	public String getContactCall() {
		return contactCall;
	}
	public void setContactCall(String contactCall) {
		this.contactCall = contactCall.trim();
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getAccept_user() {
		return accept_user;
	}
	public void setAccept_user(String accept_user) {
		this.accept_user = accept_user;
	}
	public Integer getAdd_count() {
		return add_count;
	}
	public void setAdd_count(Integer add_count) {
		this.add_count = add_count;
	}
	public String getRemind_status() {
		return remind_status;
	}
	public void setRemind_status(String remind_status) {
		this.remind_status = remind_status;
	}
	public String getTime_limit_end() {
		return time_limit_end;
	}
	public void setTime_limit_end(String time_limit_end) {
		this.time_limit_end = time_limit_end;
	}
	public String getBill_status() {
		return bill_status;
	}
	public void setBill_status(String bill_status) {
		this.bill_status = bill_status;
	}
	public Integer getNode_id() {
		return node_id;
	}
	public void setNode_id(Integer node_id) {
		this.node_id = node_id;
	}
	public String getRecord_id() {
		return record_id;
	}
	public void setRecord_id(String record_id) {
		this.record_id = record_id;
	}
	public BillNode getBillNode() {
		return billNode;
	}
	public void setBillNode(BillNode billNode) {
		this.billNode = billNode;
	}
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public Integer getPre_node_id() {
		return pre_node_id;
	}
	public void setPre_node_id(Integer pre_node_id) {
		this.pre_node_id = pre_node_id;
	}

	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getD() {
		return d;
	}
	public void setD(String d) {
		this.d = d;
	}
	public String getE() {
		return e;
	}
	public void setE(String e) {
		this.e = e;
	}
	public String getF() {
		return f;
	}
	public void setF(String f) {
		this.f = f;
	}
	public String getG() {
		return g;
	}
	public void setG(String g) {
		this.g = g;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getFix_num() {
		return fix_num;
	}
	public void setFix_num(String fix_num) {
		this.fix_num = fix_num;
	}
	public String getProduct_num() {
		return product_num;
	}
	public void setProduct_num(String product_num) {
		this.product_num = product_num;
	}
	public String getBuy_date() {
		return buy_date;
	}
	public void setBuy_date(String buy_date) {
		this.buy_date = buy_date;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getRecall() {
		return recall;
	}
	public void setRecall(String recall) {
		this.recall = recall;
	}
	public String getProduct_series() {
		return product_series;
	}
	public void setProduct_series(String product_series) {
		this.product_series = product_series;
	}
	public Integer getCount_all() {
		return count_all;
	}
	public void setCount_all(Integer count_all) {
		this.count_all = count_all;
	}
	public Integer getCount_ready() {
		return count_ready;
	}
	public void setCount_ready(Integer count_ready) {
		this.count_ready = count_ready;
	}
	public String getRemark_flag() {
		return remark_flag;
	}
	public void setRemark_flag(String remark_flag) {
		this.remark_flag = remark_flag;
	}
	public String getType_name() {
		return type_name;
	}
	public void setType_name(String type_name) {
		this.type_name = type_name;
	}
	public Timestamp getOver_time() {
		return over_time;
	}
	public void setOver_time(Timestamp over_time) {
		this.over_time = over_time;
	}
	public Timestamp getReceive_time() {
		return receive_time;
	}
	public void setReceive_time(Timestamp receive_time) {
		this.receive_time = receive_time;
	}
	public Integer getDeal_level() {
		return deal_level;
	}
	public void setDeal_level(Integer deal_level) {
		this.deal_level = deal_level;
	}
	public String getDeal_record_id() {
		return deal_record_id;
	}
	public void setDeal_record_id(String deal_record_id) {
		this.deal_record_id = deal_record_id;
	}
	public String getComplet() {
		return complet;
	}
	public void setComplet(String complet) {
		this.complet = complet;
	}
	public String getH() {
		return h;
	}
	public void setH(String h) {
		this.h = h;
	}
	public String getI() {
		return i;
	}
	public void setI(String i) {
		this.i = i;
	}
	public String getJ() {
		return j;
	}
	public void setJ(String j) {
		this.j = j;
	}
	public String getK() {
		return k;
	}
	public void setK(String k) {
		this.k = k;
	}
	public String getL() {
		return l;
	}
	public void setL(String l) {
		this.l = l;
	}
	public String getM() {
		return m;
	}
	public void setM(String m) {
		this.m = m;
	}
	public String getN() {
		return n;
	}
	public void setN(String n) {
		this.n = n;
	}
	public String getO() {
		return o;
	}
	public void setO(String o) {
		this.o = o;
	}
	public String getP() {
		return p;
	}
	public void setP(String p) {
		this.p = p;
	}
	public String getQ() {
		return q;
	}
	public void setQ(String q) {
		this.q = q;
	}
	public String getR() {
		return r;
	}
	public void setR(String r) {
		this.r = r;
	}
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	public String getT() {
		return t;
	}
	public void setT(String t) {
		this.t = t;
	}

}
