package com.konka.flow.bill.model;

import com.konka.common.base.BaseVO;

public class BillType extends BaseVO {
	private Integer id;
	private String type;//ת���������
	private String name;
	private String is_public;//�Ƿ񹫿�
	private Integer sort;
	private String remark;
	
	private Integer add_count_a; //����ϼ���������
	private Integer add_count_b;//���������������
	
	private String address_flag;
	private String fix_flag;
	private String product_flag;
	private String company_flag;
	private String recall_flag;
	
	private String is_common;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIs_public() {
		return is_public;
	}
	public void setIs_public(String is_public) {
		this.is_public = is_public;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getAdd_count_a() {
		return add_count_a;
	}
	public void setAdd_count_a(Integer add_count_a) {
		this.add_count_a = add_count_a;
	}
	public Integer getAdd_count_b() {
		return add_count_b;
	}
	public void setAdd_count_b(Integer add_count_b) {
		this.add_count_b = add_count_b;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getAddress_flag() {
		return address_flag;
	}
	public void setAddress_flag(String address_flag) {
		this.address_flag = address_flag;
	}
	public String getFix_flag() {
		return fix_flag;
	}
	public void setFix_flag(String fix_flag) {
		this.fix_flag = fix_flag;
	}
	public String getProduct_flag() {
		return product_flag;
	}
	public void setProduct_flag(String product_flag) {
		this.product_flag = product_flag;
	}
	public String getRecall_flag() {
		return recall_flag;
	}
	public void setRecall_flag(String recall_flag) {
		this.recall_flag = recall_flag;
	}
	public String getCompany_flag() {
		return company_flag;
	}
	public void setCompany_flag(String company_flag) {
		this.company_flag = company_flag;
	}
	public String getIs_common() {
		return is_common;
	}
	public void setIs_common(String is_common) {
		this.is_common = is_common;
	}
}
