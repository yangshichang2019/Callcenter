package com.konka.flow.bill.model;

import com.konka.common.base.BaseVO;

public class BillNode extends BaseVO {
	private Integer id;
	private Integer type_id;
	private String name;
	private Integer parent_id;

	private Integer deal_group;
	
	private Integer time_limit;
	
	private String is_complet;
	private String is_destory;
	
	private String explain;//�ڵ�˵��
	
	private String is_remind;//�Ƿ���Ҫ����
	
	private String is_record_id;//�Ƿ�������¼¼�����
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getType_id() {
		return type_id;
	}
	public void setType_id(Integer type_id) {
		this.type_id = type_id;
	}
	public String getExplain() {
		return explain;
	}
	public void setExplain(String explain) {
		this.explain = explain;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getParent_id() {
		return parent_id;
	}
	public void setParent_id(Integer parent_id) {
		this.parent_id = parent_id;
	}
	public Integer getDeal_group() {
		return deal_group;
	}
	public void setDeal_group(Integer deal_group) {
		this.deal_group = deal_group;
	}
	public Integer getTime_limit() {
		return time_limit;
	}
	public void setTime_limit(Integer time_limit) {
		this.time_limit = time_limit;
	}
	public String getIs_complet() {
		return is_complet;
	}
	public void setIs_complet(String is_complet) {
		this.is_complet = is_complet;
	}
	public String getIs_destory() {
		return is_destory;
	}
	public void setIs_destory(String is_destory) {
		this.is_destory = is_destory;
	}
	public String getIs_remind() {
		return is_remind;
	}
	public void setIs_remind(String is_remind) {
		this.is_remind = is_remind;
	}
	public String getIs_record_id() {
		return is_record_id;
	}
	public void setIs_record_id(String is_record_id) {
		this.is_record_id = is_record_id;
	}
}
