package com.konka.flow.bill.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.DateTool;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.flow.bill.dao.BillFieldDAO;
import com.konka.flow.bill.dao.BillInfoDAO;
import com.konka.flow.bill.dao.BillNodeDAO;
import com.konka.flow.bill.dao.BillTypeDAO;
import com.konka.flow.bill.model.BillField;
import com.konka.flow.bill.model.BillInfo;
import com.konka.flow.bill.model.BillNode;
import com.konka.flow.bill.model.BillType;
import com.konka.useradmin.model.User;

@Service("billService")
@Transactional  
public class BillServiceImp implements BillService {
	@Autowired
	private BillTypeDAO billTypeDAO;
	@Autowired
	private BillFieldDAO billFieldDAO;
	@Autowired
	private BillInfoDAO billInfoDAO;
	@Autowired
	private BillNodeDAO billNodeDAO;
	//转单类型列表
	public List getBillTypeList(BillType billType,Page page) throws Exception{
		return billTypeDAO.getObjectList(billType, page);
	}
	//获取转单类型信息
	public BillType getBillTypeInfo(BillType billType) throws Exception{
		return (BillType)billTypeDAO.getById(billType.getId());
	}
	//保存转单类型
	public void saveBillType(BillType billType,User user) throws Exception{
		if(billType.getId()!=null&&billType.getId()>0) {
			Util.setUpdateToVO(billType, user);
			billTypeDAO.update(billType);
		} else {
			Util.setCreateToVO(billType, user);
			billTypeDAO.insert(billType);
		}
	}
	//获取全部转单类型
	public List getAllBillTypeList(BillType billType) throws Exception{
		return billTypeDAO.getAllList(billType);
	}
	
	//获取转单字段列表
	public List getAllBillFieldList(BillField billField) throws Exception{
		return billFieldDAO.getAllList(billField);
	}
	//获取字段信息
	public BillField getBillFieldInfo(BillField billField) throws Exception{
		return (BillField)billFieldDAO.getById(billField.getId());
	}
	//保存字段信息
	public void saveBillField(BillField billField,User user) throws Exception{
		if(billField.getId()!=null&&billField.getId()>0) {
			Util.setUpdateToVO(billField, user);
			billFieldDAO.update(billField);
		}else {
			Util.setCreateToVO(billField, user);
			billFieldDAO.insert(billField);
		}
	}
	
	//获取转单信息列表
	public List getBillInfoList(BillInfo billInfo,Page page) throws Exception{
		return billInfoDAO.getObjectList(billInfo, page);
	}
	//获取转单信息
	public BillInfo getBillInfo(BillInfo billInfo) throws Exception{
		return (BillInfo)billInfoDAO.getById(billInfo.getId());
	}
	//保存转单信息
	public void saveBillInfo(BillInfo billInfo,User user) throws Exception{
		if(billInfo.getId()!=null&&billInfo.getId()>0) {
			makeDealLevel(billInfo);
			Util.setUpdateToVO(billInfo, user);
			billInfoDAO.update(billInfo);
		} else {
			billInfo.setRemind_status("A");
			if(billInfo.getNode_id()>0) {
				billInfo.setAccept_user("");
				billInfo.setBill_status("READY");
				BillNode billNode = new BillNode();
				billNode.setId(billInfo.getNode_id());
				billNode = getBillNodeInfo(billNode);
				if(billNode.getTime_limit()>0) {
					billInfo.setTime_limit_end(DateTool.formatDate("yyyy-MM-dd HH:mm:ss",DateTool.dateAdd(null, "HOUR", billNode.getTime_limit())));
				}
			} else {
				billInfo.setAccept_user("");
				billInfo.setTime_limit_end("");
				billInfo.setBill_status("ACCEPT");
			}
			makeDealLevel(billInfo);
			Util.setCreateToVO(billInfo, user);
			billInfoDAO.insert(billInfo);
		}
	}
	public void makeDealLevel(BillInfo info) throws Exception {
		Integer level = 0;
		if("T".equals(info.getRemark_flag())) {
			level = 14;
		} else {
			if("READY".equals(info.getBill_status())) {
				level = 10;
			}else if("ACCEPT".equals(info.getBill_status())) {
				level = 10;
			}else if ("BACKED".equals(info.getBill_status())) {
				level = 12;
			}else {
				level = 6;
			}
		}
		info.setDeal_level(level);
	}
	public void deleteBillInfo(BillInfo billInfo) throws Exception{
		billInfoDAO.delete(billInfo.getId());
	}
	//获取节点信息
	public List getAllBillNodeList(BillNode billNode) throws Exception{
		return billNodeDAO.getAllList(billNode);
	}
	
	public BillNode getBillNodeInfo(BillNode billNode) throws Exception{
		return (BillNode)billNodeDAO.getById(billNode.getId());
	}
	public void saveBillNode(BillNode billNode,User user) throws Exception {
		if(billNode.getId()!=null&&billNode.getId()>0) {
			Util.setUpdateToVO(billNode, user);
			billNodeDAO.update(billNode);
		}else {
			Util.setCreateToVO(billNode, user);
			billNodeDAO.insert(billNode);
		}
	}
	public void deleteBillNode(BillNode billNode) throws Exception {
		billNodeDAO.delete(billNode.getId());
	}
	public BillInfo getBillInfoCount(BillInfo billInfo) throws Exception{
		return billInfoDAO.getBillInfoCount(billInfo);
	}
}
