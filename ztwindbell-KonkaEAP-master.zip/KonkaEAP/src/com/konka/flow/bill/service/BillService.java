package com.konka.flow.bill.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.flow.bill.model.BillField;
import com.konka.flow.bill.model.BillInfo;
import com.konka.flow.bill.model.BillNode;
import com.konka.flow.bill.model.BillType;
import com.konka.useradmin.model.User;

public interface BillService {
	//转单类型
	public List getBillTypeList(BillType billType,Page page) throws Exception;
	public BillType getBillTypeInfo(BillType billType) throws Exception;
	public void saveBillType(BillType billType,User user) throws Exception;
	public List getAllBillTypeList(BillType billType) throws Exception;
	
	//转单字段
	public List getAllBillFieldList(BillField billField) throws Exception;
	public BillField getBillFieldInfo(BillField billField) throws Exception;
	public void saveBillField(BillField billField,User user) throws Exception;
	
	//转单信息列表
	public List getBillInfoList(BillInfo billInfo,Page page) throws Exception;
	public BillInfo getBillInfo(BillInfo billInfo) throws Exception;
	public void saveBillInfo(BillInfo billInfo,User user) throws Exception;
	public void deleteBillInfo(BillInfo billInfo) throws Exception;
	public BillInfo getBillInfoCount(BillInfo billInfo) throws Exception;
	
	//节点
	public List getAllBillNodeList(BillNode billNode) throws Exception;
	public BillNode getBillNodeInfo(BillNode billNode) throws Exception;
	public void saveBillNode(BillNode billNode,User user) throws Exception;
	public void deleteBillNode(BillNode billNode) throws Exception;
}
