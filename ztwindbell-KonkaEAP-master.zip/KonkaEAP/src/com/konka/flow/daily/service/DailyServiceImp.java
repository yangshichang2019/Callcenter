package com.konka.flow.daily.service;

import java.util.Date;
import java.util.List;























import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.flow.daily.model.Dinspect;
import com.konka.flow.daily.model.Inspect;
import com.konka.flow.daily.model.Repair;
import com.konka.flow.daily.dao.DinspectDAO;
import com.konka.flow.daily.dao.InspectDAO;
import com.konka.flow.daily.dao.RepairDAO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;

import com.konka.useradmin.model.User;



@Service("dailyService")  
@Transactional 
public class DailyServiceImp implements DailyService {
	@Autowired
	private RepairDAO repairDAO;
	@Autowired
	private InspectDAO inspectDAO;
	@Autowired
	private DinspectDAO dinspectDAO;

	@Override
	public List getRepairList(Repair repair, Page page) throws Exception {
		return repairDAO.getObjectList(repair, page);
	}

	@Override
	public Repair getRepairInfo(Repair repair) throws Exception {
		return (Repair)repairDAO.getById(repair.getId());
	}

	@Override
	public void saveRepair(Repair repair, User suser) throws Exception {
		
		if(repair.getId()==null||repair.getId()==0) {
			Util.setCreateToVO(repair, suser);
			repair.setSend_time(repair.getCreate_time());
			repairDAO.insert(repair);
		}else {
			if(repair.getFix_man()==null){
				repair.setFix_time(new Date());
				Util.setUpdateToVO(repair, suser);
			}
			
			repairDAO.update(repair);
		}
	
		
	}
	
	
	
	//---------------------------------------------------
	@Override
	public List getDinspectList(Dinspect dinspect) throws Exception {
		return dinspectDAO.getAllList(dinspect);
	}

	@Override
	public Dinspect getDinspectInfo(Dinspect dinspect) throws Exception {
		return (Dinspect)dinspectDAO.getById(dinspect.getId());
	}

	@Override
	public void saveDinspect(Dinspect dinspect, User user) throws Exception {
		if(dinspect.getId()==null||dinspect.getId()==0) {
			Dinspect vo = getNewDinspect(dinspect);
			if(dinspect.getParent_id()==0) {
				if(vo==null) {
					dinspect.setNum("001");
				}else {
					dinspect.setNum(Util.getNextNum(vo.getNum(), 3));
				}
			}else {
				if(vo==null) {
					Dinspect tempVO = new Dinspect();
					tempVO.setId(dinspect.getParent_id());
					tempVO = getDinspectInfo(tempVO);
					dinspect.setNum(tempVO.getNum() + "001");
				}else {
					dinspect.setNum(Util.getNextNum(vo.getNum(), vo.getNum().length()));
				}
			}
			Util.setCreateToVO(dinspect, user);
			dinspectDAO.insert(dinspect);
		}else {
			Util.setUpdateToVO(dinspect, user);
			dinspectDAO.update(dinspect);
		}
		
	}

	private Dinspect getNewDinspect(Dinspect dinspect) throws Exception {
		return (Dinspect)dinspectDAO.getNewObject(dinspect);
	}

	@Override
	public List getInspectList(Inspect inspect, Page page) throws Exception {
		return inspectDAO.getObjectList(inspect, page);
	}

	@Override
	public void deleteDinspect(Dinspect dinspect) throws Exception {
		dinspectDAO.delete(dinspect.getId());
		
	}



	@Override
	public List getAllInspect(Inspect inspect) throws Exception {
		return inspectDAO.getAllList(inspect);
	}

	@Override
	public void saveInspect(Inspect inspect, User user) throws Exception {
		if(inspect.getId()!=null&&inspect.getId()>0) {
			Util.setUpdateToVO(inspect, user);
			inspectDAO.update(inspect);
		}else {
			Util.setCreateToVO(inspect, user);
			inspectDAO.insert(inspect);
		}
		
	}

	@Override
	public Inspect getInspectInfo(Inspect inspect) throws Exception {
		return (Inspect)inspectDAO.getById(inspect.getId());
	}

	@Override
	public void deleteInspect(Inspect inspect) throws Exception {
		inspectDAO.delete(inspect.getId());
	}


}
