package com.konka.flow.daily.service;

import java.util.List;










import com.konka.common.tool.Page;
import com.konka.flow.daily.model.Dinspect;
import com.konka.flow.daily.model.Inspect;
import com.konka.flow.daily.model.Repair;
import com.konka.useradmin.model.User;

public interface DailyService {

	public List getRepairList(Repair repair, Page page) throws Exception;

	public Repair getRepairInfo(Repair repair) throws Exception;

	public void saveRepair(Repair repair, User suser) throws Exception;

	
	
	
	public List getDinspectList(Dinspect dinspect) throws Exception;

	public Dinspect getDinspectInfo(Dinspect dinspect) throws Exception;

	public void saveDinspect(Dinspect dinspect, User user) throws Exception;

	public List getInspectList(Inspect inspect, Page page) throws Exception;

	public void deleteDinspect(Dinspect dinspect) throws Exception;

	public Inspect getInspectInfo(Inspect inspect) throws Exception;

	public List getAllInspect(Inspect inspect) throws Exception;

	public void saveInspect(Inspect inspect, User user) throws Exception;

	public void deleteInspect(Inspect inspect) throws Exception;



}
