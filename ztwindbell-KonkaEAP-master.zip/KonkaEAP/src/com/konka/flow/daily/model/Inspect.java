package com.konka.flow.daily.model;

import java.util.Date;

import com.konka.common.base.BaseVO;

public class Inspect extends BaseVO {
    private Integer id;

    private String num;

    private String type;

    private Integer dir_id;

    private String title;

    private Integer upload_id;

    private String path;

    private String other;

    private Date record_time;

   
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

  

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

	public Integer getDir_id() {
		return dir_id;
	}

	public void setDir_id(Integer dir_id) {
		this.dir_id = dir_id;
	}

	public Integer getUpload_id() {
		return upload_id;
	}

	public void setUpload_id(Integer upload_id) {
		this.upload_id = upload_id;
	}

	public Date getRecord_time() {
		return record_time;
	}

	public void setRecord_time(Date record_time) {
		this.record_time = record_time;
	}

   

   
}