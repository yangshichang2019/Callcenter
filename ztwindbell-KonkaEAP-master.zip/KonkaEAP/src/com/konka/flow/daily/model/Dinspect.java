package com.konka.flow.daily.model;

import java.util.Date;

import com.konka.common.base.BaseVO;
import com.konka.common.base.TreeVO;

public class Dinspect extends TreeVO {



   
   
}