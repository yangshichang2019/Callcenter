package com.konka.flow.daily.model;

import java.util.Date;

import com.konka.common.base.BaseVO;

public class Repair extends BaseVO  {
    private Integer id;
    private String position;
    private String desc;
    private String dept;
    private String fix_man;
    private Date send_time;
    private Date fix_time;
    private String result;
    private String other;
    private Integer totaltime;
    private String fix_result;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getFix_man() {
		return fix_man;
	}
	public void setFix_man(String fix_man) {
		this.fix_man = fix_man;
	}
	public Date getSend_time() {
		return send_time;
	}
	public void setSend_time(Date send_time) {
		this.send_time = send_time;
	}
	public Date getFix_time() {
		return fix_time;
	}
	public void setFix_time(Date fix_time) {
		this.fix_time = fix_time;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getOther() {
		return other;
	}
	public void setOther(String other) {
		this.other = other;
	}
	public Integer getTotaltime() {
		return totaltime;
	}
	public void setTotaltime(Integer totaltime) {
		this.totaltime = totaltime;
	}
	public String getFix_result() {
		return fix_result;
	}
	public void setFix_result(String fix_result) {
		this.fix_result = fix_result;
	}
    
    

	

  
}