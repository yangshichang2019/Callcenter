package com.konka.flow.daily.action;

import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;














import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.solr.SearchTool;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Tree;
import com.konka.common.tool.Util;
import com.konka.database.service.DataBaseService;
import com.konka.flow.daily.service.DailyService;
import com.konka.flow.daily.service.DailyServiceImp;
import com.konka.flow.daily.model.Dinspect;
import com.konka.flow.daily.model.Inspect;
import com.konka.flow.daily.model.Repair;
import com.konka.system.model.UploadFile;
import com.konka.system.service.SystemService;
import com.konka.system.service.SystemServiceImp;
import com.konka.useradmin.model.Dept;
import com.konka.useradmin.model.User;


@Controller
@Scope("prototype")
public class DailyAction extends BaseAction {
	@Autowired
	public DailyService dailyService;
	@Autowired
	public DailyServiceImp dailyServiceImp;
	@Autowired
	public DataBaseService dataBaseService;
	@Autowired
	public SystemServiceImp systemServiceImp;
	
	public Repair repair = new Repair();
	public List repairList = new ArrayList(); 
	
	public Dinspect dinspect = new Dinspect();
	public List dinspectList = new ArrayList();
	
	public Inspect inspect = new Inspect();
	public List inspectList = new ArrayList();
	
	public UploadFile file = new UploadFile();

	
	
		//�鿴
		public String toRepairApply() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			Util.setCreateToVO(repair, Suser);
			dataList = dailyService.getRepairList(repair,page);
			return "toRepairApply";
		}
		
		
		//��ѯ
		public String toRepairSearch() throws Exception {
			dataList = dailyService.getRepairList(repair,page);
			return "toRepairSearch";
		}
			
		//����
		public String toRepairList() throws Exception {
			dataList = dailyService.getRepairList(repair,page);
			return "toRepairList";
		}

		//����
		public String toAddEditRepair() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			if(repair.getId()!=null&&repair.getId()>0) {
				repair = dailyService.getRepairInfo(repair);
				
			}
			return "toAddEditRepair";
		}
		//ȷ��
		public String toConfirmRepair() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			if(repair.getId()!=null&&repair.getId()>0) {
				repair = dailyService.getRepairInfo(repair);
				
			}
			return "toConfirmRepair";
				
	
		}
		//����
		public String toSaveRepair() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);

			dailyService.saveRepair(repair,Suser);
				
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//ɾ��	
		public String toDeleteRepair() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			
			
			repair = dailyService.getRepairInfo(repair);
			repair.setDelete_flag("T");
			
			if( !repair.getFix_result().equals("P")){
				super.toError("��ǰ״̬����ɾ����");
				return Constant.ACTION_S.ajaxDone.toString();
			}
			dailyService.saveRepair(repair,Suser);
			super.setCallbackType("");
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//�鿴
		public String toShowRepair() throws Exception {
			if(repair.getId()!=null&&repair.getId()>0) {
				repair = dailyService.getRepairInfo(repair);
			}
			return "toShowRepair";
		}
		
		//---------------------------------------------------------------------------------
		//---------------------------------------------------------------------------------
		//Ѳ�����
		public String toDinspectList() throws Exception {
			return "toDinspectList";
		}
		
		//��ȡѲ����Ŀ¼
		public String toChildrenDinspectList() throws Exception {
			dataList = dailyService.getDinspectList(dinspect);
			if(dinspect.getNum()==null) {
				dinspect.setNum("");
			}
			if(dataList!=null&&dataList.size()>0) {
				dataList = Tree.treeFilter(dataList,dinspect.getNum());
				
				super.getResponse().setContentType("text/plain;charset=gbk");
				super.getResponse().setCharacterEncoding("GBK");
				Writer out = super.getResponse().getWriter();
				out.write(Tree.makeTree(dataList,dinspect.getNum(),"subInspectListBox",navTabId,"flow/daily_toViewInspectList","dinspect"));
				out.flush();
				out.close();
			}
			return null;
		}
		
		//����Ŀ¼
		public String toAddEditDinspect() throws Exception {
			if(dinspect.getId()!=null&&dinspect.getId()>0) {
				dinspect = dailyService.getDinspectInfo(dinspect);
			}else {
				if(dinspect.getParent_id()==null||dinspect.getParent_id()==0) {
					dinspect.setParent_id(0);
				}
			}
			return "toAddEditDinspect";
		}
		
		//����Ŀ¼
		public String toSaveDinspect() throws Exception {
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			dailyService.saveDinspect(dinspect,user);
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
		//ɾ��Ŀ¼
		public String toDeleteDinspect() throws Exception {
			Dinspect vo = new Dinspect();
			vo.setParent_id(dinspect.getId());
			dataList = dailyService.getDinspectList(vo);
			if(dataList!=null&&dataList.size()>0) {
				super.toError("�����ӽڵ㣬������ɾ����");
			} else {
				inspect.setDir_id(dinspect.getId());
				dataList = dailyService.getInspectList(inspect, page);
				if(dataList!=null&&dataList.size()>0) {
					super.toError("�������ĵ���������ɾ����");
				} else {
					dailyService.deleteDinspect(dinspect);
				}
			}
			this.setCallbackType("");
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
		//��ȡѲ���ļ��б�
		public String toViewInspectList() throws Exception {
			inspect.setDir_id(dinspect.getId());
			dataList = dailyService.getInspectList(inspect,page);
			return "toViewInspectList";
		}
		
		
		//-----------------------------------------------------
		
		//�����޸�Ѳ����Ϣ
		public String toAddEditInspect() throws Exception {
			if(inspect.getId()!=null&&inspect.getId()>0) {
				inspect = dailyService.getInspectInfo(inspect);
			}
			return "toAddEditInspect";
			
		}
		//�鿴Ѳ����Ϣ
		public String toViewInspect() throws Exception {
			if(inspect.getId()!=null&&inspect.getId()>0) {
				inspect = dailyService.getInspectInfo(inspect);
			}
			file.setId(inspect.getUpload_id());
			file =systemServiceImp.getUploadFileInfo(file);
			return "toViewInspect";
			
		}
		//����������
		public String toAddEditSearchInspect() throws Exception {
			inspect.setTitle(new String(inspect.getTitle().getBytes("iso-8859-1"),"UTF-8"));
			if(inspect.getTitle()!=null&&!inspect.getTitle().equals("")) {
				dataList = dailyService.getAllInspect(inspect);
			}
			return "toAddEditSearchInspect";
		}
		
		//����Ѳ����Ϣ
		public String toSaveInspect() throws Exception {
			if(inspect.getUpload_id()==null||inspect.getUpload_id()==0) {
				super.toError("δ�ϴ��ļ���");
				super.setCallbackType("");
				return Constant.ACTION_S.ajaxDone.toString();
			}
			User user = (User)super.getSession().get(Constant.SESSION_USER);
			if(inspect.getNum().equals("")) {
				inspect.setNum(systemServiceImp.getNextNum("KI", "KK_INSPECT_INFO_S", 4));
			}
			//����·��
			file.setId(inspect.getUpload_id());
			file =systemServiceImp.getUploadFileInfo(file);
			inspect.setPath(file.getPath());
			
			dailyService.saveInspect(inspect, user);
			
			

			systemServiceImp.updateUploadFileObjectIds(inspect.getId(), inspect.getUpload_id().toString());
			return Constant.ACTION_S.ajaxDone.toString();
		}
		//ɾ��Ѳ����Ϣ
		public String toDeleteInspect() throws Exception {
			inspect = dailyService.getInspectInfo(inspect);
			
			dailyService.deleteInspect(inspect);
			
			
			file.setId(inspect.getUpload_id());
			systemServiceImp.deleteUploadFile(file);

			super.setCallbackType("");
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
}
