package com.konka.flow.daily.dao;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.konka.common.base.BaseDAOImp;
@Repository("repairDAO")
public class RepairDAOImp extends BaseDAOImp implements RepairDAO {
	public RepairDAOImp(){  
		super.setMapper("com.konka.flow.daily.model.Repair");
	}
	
}
