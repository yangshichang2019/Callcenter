package com.konka.flow.daily.dao;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.konka.common.base.BaseDAOImp;
@Repository("dinspectDAO")
public class DinspectDAOImp extends BaseDAOImp implements DinspectDAO {
	public DinspectDAOImp(){  
		super.setMapper("com.konka.flow.daily.model.Dinspect");
	}
	
}
