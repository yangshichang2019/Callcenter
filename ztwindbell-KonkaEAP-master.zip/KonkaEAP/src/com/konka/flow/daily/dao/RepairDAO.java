package com.konka.flow.daily.dao;

import com.konka.common.base.BaseDAO;

public interface RepairDAO extends BaseDAO {

}
