package com.konka.office.calen.dao;

import java.util.List;
import java.util.Map;

import com.konka.common.base.BaseDAO;
import com.konka.office.calen.model.Calen;

public interface CalenDAO extends BaseDAO{

	public List getByUid(Map map) throws Exception;

	public void deleteCalen(Calen calen);

	public void updateCalen(Calen calen);

	public void insertuserlist(Map map);

	public Calen getByCid(Calen calen);


	
}
