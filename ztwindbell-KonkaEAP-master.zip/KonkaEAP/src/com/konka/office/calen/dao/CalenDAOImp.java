package com.konka.office.calen.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.office.calen.model.Calen;
@Repository("calenDAO")  
public class CalenDAOImp extends BaseDAOImp implements CalenDAO {
	public CalenDAOImp() {
		super.setMapper("com.konka.office.calen.model.Calen");
	}

	@Override
	public List getByUid(Map map) throws Exception {
		
		return super.getSqlSessionTemplate().selectList( super.getMapper()+".getByUid", map );
	}

	@Override
	public void deleteCalen(Calen calen) {
		
		super.getSqlSessionTemplate().update( super.getMapper()+".deleteCalen", calen );
//		super.getSqlSessionTemplate().update( super.getMapper()+".deleteRemind", calen );
		
	}

	@Override
	public void updateCalen(Calen calen) {

		super.getSqlSessionTemplate().update( super.getMapper()+".updateCalen", calen );
//		super.getSqlSessionTemplate().update( super.getMapper()+".updateRemind", calen );
		
	}

	@Override
	public void insertuserlist(Map map) {

		super.getSqlSessionTemplate().update( super.getMapper()+".insertuserlist", map );
		
	}

	@Override
	public Calen getByCid(Calen calen) {
		return super.getSqlSessionTemplate().selectOne( super.getMapper()+".getByCid", calen );
	}


}
