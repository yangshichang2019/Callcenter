package com.konka.office.calen.service;

import java.util.List;
import java.util.Map;

import com.konka.common.tool.Page;
import com.konka.office.calen.model.Calen;
import com.konka.system.model.Feedback;
import com.konka.system.model.Record;
import com.konka.system.model.Remind;
import com.konka.system.model.SessionInfo;
import com.konka.system.model.Task;
import com.konka.useradmin.model.User;

public interface CalenService {

	public void saveCalen(Calen Calen,User user, List list) throws Exception;

	public List getCalenList(Map map) throws Exception;

	public void deleteCalen(Calen calen) throws Exception;

	public void updateCalen(Calen calen);

	public Calen getByCid(Calen calen);
	

}
