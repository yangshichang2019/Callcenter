package com.konka.office.calen.action;


import java.io.*;
import java.sql.Timestamp;
import java.text.*;
import com.konka.office.calen.*;
import java.util.*;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;


import com.konka.office.calen.model.Calen;
import com.konka.office.calen.service.CalenService;
import com.konka.system.service.SystemService;
import com.konka.system.service.SystemServiceImp;
import com.konka.useradmin.model.Right;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;























@Controller
@Scope("prototype")
public class CalenAction extends BaseAction{
	
	
	
	
	
	
	
	
	
	@Autowired
	public CalenService calenService;
	public Calen calen = new Calen();
	public List<Calen> calendarList = new ArrayList<Calen>();
	
	public Map map = new HashMap();
	public long start_date_long;
	public long end_date_long;
	@Autowired
	public UserAdminService userAdminService;
	@Autowired
	public SystemServiceImp SystemServiceImp;
	
	
	
	
	
	
	
	

	//��ʾ�ճ���ҳ
	public String index( ) throws Exception {
		/**
		 * �õ�ǰʱ��Date	��ǰ��ͼmonth
		 * ���qstartʱ���  qendʱ���
		 * �ӽ���ݿ� ���events���
		 * ƴ��json
		 * ������ģ��
		 */
		Date showday = new Date();
		String Ymd =  dateToStringType(showday, "yyyy-MM-dd");
		showday = stringToDate(Ymd, "yyyy-MM-dd");

		String view_Type = "month";
		
		Map index_map = new HashMap();
		
		index_map = GetCalendarViewTypeTimestamp( view_Type,  showday);
		start_date_long = (Long) index_map.get("start_date");
		end_date_long 	= (Long) index_map.get("end_date");
		
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		int uid = Suser.getId();
		String username = Suser.getUsername();
		//��ѯ��ݿ�
		index_map.put("uid", uid);
		index_map.put("username", username);
		index_map.put("qstart", new Timestamp(start_date_long) );
		index_map.put("qend",  new Timestamp(end_date_long));

		calendarList = calenService.getCalenList(index_map);
		
		if(calendarList != null){
			for ( Calen cal : calendarList) {

				cal.setStarttime_long(cal.getStarttime().getTime());
				cal.setEndtime_long(cal.getEndtime().getTime());
			
				if (	eq(dateToStringType(cal.getStarttime(), "yyyy-MM-dd"), dateToStringType(cal.getEndtime(), "yyyy-MM-dd"))	) {
					cal.setIsalldayevent(0);
				}else{
					cal.setIsalldayevent(1);
				}

			}
		}
		
		return "index";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	//�����ճ�
	public String quickAdd( ) throws Exception {
		/********************************************
		POST�����������
		CalendarEndTime	2013-8-21 13:00
		CalendarStartTime	2013-8-21 10:00
		CalendarTitle	����
		IsAllDayEvent	0
		timezone	8
		
		
		json�����������
		{"IsSuccess":true,"Msg":"�����ɹ�","Data":"60"}
				
		IsSuccess	true 
		Msg			�����ɹ�
		Data		������ݿⷵ�����
		
		********************************************************/
		
		
		
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		Util.setCreateToVO(calen, Suser);
		
		List tempList = new ArrayList();
		
		
		if (I("CalendarTitle") != null) {
			
			calen.setSubject(	I("CalendarTitle")		);//�ճ̱���
			calen.setStarttime(	T( I("CalendarStartTime") )	);//��ʼʱ��
			calen.setEndtime(	T( I("CalendarEndTime") )	);//����ʱ��
			calen.setIsalldayevent(	Integer.parseInt( I("IsAllDayEvent") ) );//�Ƿ�ȫ���ճ�
			calen.setMasterid(	Integer.parseInt(I("timezone"))	);//ʱ��ID
			calen.setCalendartype(1);//�ճ�����\r\n            1	�����ճ�\r\n            2	�����ճ�
			calen.setInstancetype(0);//ʵ������\r\n            0	Single��һ���ճ̣�\r\n            1	Master��ѭ�����ճ̣�\r\n            2	Instance��ѭ��ʵ���ճ̣�\r\n            3	Exception ������\r\n            4	MeetingRequest�����鰲�ţ�'
			calen.setUpaccount( Suser.getId());//�������˺�
			calen.setUpname(Suser.getUsername());//����������
			calen.setAttendees(	Suser.getFullname()+"("+Suser.getUsername()+")"	);//����������
			calen.setAttendeenames(	"{\"user\":\""+Suser.getUsername()+"\"}"	);//����������
			Date date = new Date();//��ǰʱ��
			calen.setUptime( new Date(date.getTime()));//���һ�θ���ʱ��
			
			tempList = userAdminService.strToUserList("{\"user\":\""+ Suser.getUsername() +"\"}");
			

			
		} else {

			tempList = userAdminService.strToUserList(super.getIds());



			
			
			
			
			
			
			
			
			calen.setIsalldayevent(	0 );//�Ƿ�ȫ���ճ�
			calen.setMasterid(	8	);//ʱ��ID
			calen.setCalendartype(1);//�ճ�����\r\n            1	�����ճ�\r\n            2	�����ճ�
			calen.setInstancetype(0);//ʵ������\r\n            0	Single��һ���ճ̣�\r\n            1	Master��ѭ�����ճ̣�\r\n            2	Instance��ѭ��ʵ���ճ̣�\r\n            3	Exception ������\r\n            4	MeetingRequest�����鰲�ţ�'
			calen.setUpaccount( Suser.getId());//�������˺�
			calen.setUpname(Suser.getUsername());//����������
			Date date = new Date();//��ǰʱ��
			calen.setUptime( new Date(date.getTime()));//���һ�θ���ʱ��
			calen.setAttendeenames(		I("ids")		);//ʱ��ID
			
			
			
		}
		

		
		
		calenService.saveCalen(calen, Suser, tempList);

		SystemServiceImp.insertRemind("CALEN",calen.getId(), calen.getSubject(), calen.getSubject()+"<br />��ʼʱ�䣺"+dateToStringType(calen.getStarttime(), "yyyy-MM-dd HH:mm:ss")+" <br /> ����ʱ�䣺"+dateToStringType(calen.getEndtime(), "yyyy-MM-dd HH:mm:ss"), date_modify(calen.getStarttime()), calen.getEndtime(), tempList, Suser);
		
		
		//�����ݿ�ɹ�����json
		return "success";
	}
	
	//ɾ���ճ�
	public String quickDelete() throws Exception {

		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		Util.setUpdateToVO(calen, Suser);
		

		calen.setId(	s2i(	I("calendarId")	  )	  );
		
		Calen tempcalen = new Calen();
		tempcalen.setId(	s2i(	I("calendarId")	  )	  );
		tempcalen = calenService.getByCid(tempcalen);
		
		if (tempcalen.getUpaccount().equals(Suser.getId())) {
			calenService.deleteCalen(calen);
			
			List tempList = new ArrayList();
			tempList = userAdminService.strToUserList(tempcalen.getAttendeenames());
			
			SystemServiceImp.insertRemind("CALEN",calen.getId(), "�ճ�ɾ��֪ͨ��"+tempcalen.getSubject()+"[��ɾ��]", tempcalen.getSubject()+"<br />��ʼʱ�䣺"+dateToStringType(tempcalen.getStarttime(), "yyyy-MM-dd HH:mm:ss")+" <br /> ����ʱ�䣺"+dateToStringType(tempcalen.getEndtime(), "yyyy-MM-dd HH:mm:ss"), date_modify(tempcalen.getStarttime()), tempcalen.getEndtime(), tempList, Suser);
			return "success";
		}else{
			
			return "error";
		}
		
	}
	
	
	//�޸��ճ�
	public String quickUpdate() throws Exception {
		
		calen.setId(	s2i(	I("calendarId")	  )	  );
		calen.setStarttime(	T( I("CalendarStartTime") )	);//��ʼʱ��
		calen.setEndtime(	T( I("CalendarEndTime") )	);//����ʱ��
		
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		Util.setUpdateToVO(calen, Suser);
		
		Calen tempcalen = new Calen();
		tempcalen.setId(	s2i(	I("calendarId")	  )	  );
		tempcalen = calenService.getByCid(tempcalen);
		
		if (tempcalen.getUpaccount().equals(Suser.getId())) {
			calenService.updateCalen(calen);
			calen = calenService.getByCid(calen);
			
			List tempList = new ArrayList();
			tempList = userAdminService.strToUserList(calen.getAttendeenames());
			
			SystemServiceImp.insertRemind("CALEN",calen.getId(), "�ճ��޸�֪ͨ��"+calen.getSubject()+"[���޸�]", calen.getSubject()+"<br />��ʼʱ�䣺"+dateToStringType(calen.getStarttime(), "yyyy-MM-dd HH:mm:ss")+" <br /> ����ʱ�䣺"+dateToStringType(calen.getEndtime(), "yyyy-MM-dd HH:mm:ss"), date_modify(calen.getStarttime()), calen.getEndtime(), tempList, Suser);
			return "success";
		}else{
			
			return "error";
		}

	}
	
	
	
	
	
	//��ȡ �ճ��б�
	@SuppressWarnings("unchecked")
	public String get() throws Exception {
		
		//����json���
		String view_Type = I("viewtype"); // week,month,day
		String str_show_day = I("showdate"); // ��ǰ����һ�� 

		int clientzone = Integer.parseInt( I("timezone") );
		int serverzone= 8;
		int zonediff = serverzone - clientzone ; 
		Date showday = stringToDate(str_show_day + " 0:0:0");

		/******************************************
		 * view_Type = week or day or month
		 * timestamp = ��ǰʱ���ʱ���
		 *******************************************/
		long timestamp = date_timestamp_get(showday);
		
		/**
		 * view_Type = week or day or month
		 * showday  Date��ʽ��ǰ���
		 * ����start":"\/Date(1374940800000)\/","end":"\/Date(1378569599000)\/",ʱ���
		 */
		
		map = GetCalendarViewTypeTimestamp( view_Type,  showday);
		start_date_long = (Long) map.get("start_date");
		end_date_long 	= (Long) map.get("end_date");

		
		//����json ret
		Map ret = new HashMap();
		Map events = new HashMap();
		ret.put("start", "/Date("+start_date_long+")/");
		ret.put("end", "/Date("+end_date_long+")/");
		ret.put("error", null);
		ret.put("issort", true);
		ret.put("events",events);
		
		User Suser = (User)super.getSession().get(Constant.SESSION_USER);
		int uid = Suser.getId();
		String username = Suser.getUsername();
		
		//��ѯ��ݿ�
		map.put("uid", uid);
		map.put("username", username);
		map.put("qstart", new Timestamp(start_date_long) );
		map.put("qend",  new Timestamp(end_date_long));

		calendarList = calenService.getCalenList(map);
		
		
		//���������

		if(calendarList != null){
			for ( Calen cal : calendarList) {

				
				cal.setStarttime_long(cal.getStarttime().getTime());
				cal.setEndtime_long(cal.getEndtime().getTime());
				
				
				if (	eq(dateToStringType(cal.getStarttime(), "yyyy-MM-dd"), dateToStringType(cal.getEndtime(), "yyyy-MM-dd"))	) {
					cal.setIsalldayevent(0);
				}else{
					cal.setIsalldayevent(1);
				}
				
			}
		}
		return "get";
	}
	

	
	
		//��̨�½��ճ�
		public String toAddCalen() throws Exception {
			return "toAddCalen";
		}
		//��̨�޸��ճ�
		public String toEditCalen() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			calen.setId(	s2i(	I("calid")	  )	  );
			calen = calenService.getByCid(calen);
			return "toEditCalen";
			
		}
		//�����ճ�
		public String toSaveCalen() throws Exception {
			User Suser = (User)super.getSession().get(Constant.SESSION_USER);
			Util.setUpdateToVO(calen, Suser);
			
			Calen tempcalen = new Calen();
			tempcalen.setId(	calen.getId()	  );
			tempcalen = calenService.getByCid(tempcalen);
			
			if (tempcalen.getUpaccount().equals(Suser.getId())) {
				calenService.deleteCalen(calen);


				
				////////////////////////////////////////////////////////////////////

				
				List tempList = new ArrayList();


					tempList = userAdminService.strToUserList(super.getIds());


					
					
					calen.setIsalldayevent(	0 );//�Ƿ�ȫ���ճ�
					calen.setMasterid(	8	);//ʱ��ID
					calen.setCalendartype(1);//�ճ�����\r\n            1	�����ճ�\r\n            2	�����ճ�
					calen.setInstancetype(0);//ʵ������\r\n            0	Single��һ���ճ̣�\r\n            1	Master��ѭ�����ճ̣�\r\n            2	Instance��ѭ��ʵ���ճ̣�\r\n            3	Exception ������\r\n            4	MeetingRequest�����鰲�ţ�'
					calen.setUpaccount( Suser.getId());//�������˺�
					calen.setUpname(Suser.getUsername());//����������
					Date date = new Date();//��ǰʱ��
					calen.setUptime( new Date(date.getTime()));//���һ�θ���ʱ��
					calen.setAttendeenames(		I("ids")		);//ʱ��ID
					
					
		
				
				
				calenService.saveCalen(calen, Suser, tempList);
//				SystemServiceImp.insertRemind("calen_"+calen.getId().toString(), calen.getSubject(), calen.getSubject(), calen.getStarttime(), calen.getEndtime(), tempList, Suser);
				SystemServiceImp.insertRemind("CALEN",calen.getId(), "�ճ��޸�֪ͨ��"+calen.getSubject()+"[���޸�]", calen.getSubject()+"<br />��ʼʱ�䣺"+dateToStringType(calen.getStarttime(), "yyyy-MM-dd HH:mm:ss")+" <br /> ����ʱ�䣺"+dateToStringType(calen.getEndtime(), "yyyy-MM-dd HH:mm:ss"), date_modify(calen.getStarttime()), calen.getEndtime(), tempList, Suser);
				////////////////////////////////////////////////////////////////////////////////
				
				
				
				
				return "success";
			}else{
				
				return "error";
			}
		}
	
	
	
	
	
	
	
		public static String dateToStringType( Date date, String type ) {
			SimpleDateFormat sdf= new SimpleDateFormat(type);
			String dateStr=sdf.format(date);
			return dateStr;
			
		}
		public static Date stringToDate( String str, String type ) throws ParseException {
			SimpleDateFormat sdf= new SimpleDateFormat(type);
			Date date= sdf.parse(str);
			return date;

		}
		public static Map GetCalendarViewTypeTimestamp(String viewType, Date showdate) throws ParseException{
			
			//���忪ʼʱ����ͽ���ʱ���
			String start_date_str;
			String end_date_str;
			long start_date_long = 0;
			long end_date_long = 0;
			Date date = showdate;
			Calendar cal = dateToCalendar(showdate);
			
			

			/**
			 * ���ò��� date cal
			 */
			//�ж���������ͼ ���� start endʱ���
			Map map=new HashMap();

			//����ͼ 2013-8-21	��õ���2013-8-21 0:0:0  2013-8-21 23:59:59
			if ( eq(viewType, "day") ) {	
				
				//��ʼʱ���	start_date_long
				start_date_str = dateToString(calendarToDate(mktime(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE), 0, 0, 0)));
				start_date_long = dateToUnixDate(start_date_str) ;
				
				//����ʱ���	end_date_long
				end_date_str = dateToString(calendarToDate(mktime(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE)+1, 0, 0, -1)));
				end_date_long = dateToUnixDate(end_date_str) ;
			}
			
			//����ͼ2013-8-21	�����������һ ������	2013��8��19�� 0:00:00	2013��8��25�� 23:59:59
			if ( eq(viewType, "week") ) {	
				
				//week_num ������ܼ�
				int week_num = getWeekDay( date );
				
				//w ���� ��ǰ������ -w �ɵ�����һ
				int w = 0 - week_num + 1;
				if (w > 0) w = w - 7;
				
				//��ʼʱ���	start_date_long
				start_date_str = dateToString(calendarToDate(mktime(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE) + w, 0, 0, 0)));
//				p(cal.get(Calendar.YEAR));	p(cal.get(Calendar.MONTH));	p(cal.get(Calendar.DATE));
				start_date_long = dateToUnixDate(start_date_str) ;
				
				//����ʱ���	end_date_long
				end_date_str = dateToString(calendarToDate(mktime(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DATE) + w + 7, 0, 0, -1)));
//				p(cal.get(Calendar.YEAR));	p(cal.get(Calendar.MONTH));	p(cal.get(Calendar.DATE));
				end_date_long = dateToUnixDate(end_date_str) ;
								
			}
			
			//����ͼ2013-8-21 ��õ���һ�ź����һ��
			if ( eq(viewType, "month") ) {
//				date = stringToDate("2014-5-8 14:1:3");
				//��õ���1��
				String first_date_str = getMonthFirstDay(date);
				Date first_date = stringToDate(first_date_str);
				Calendar first_date_cal = dateToCalendar(first_date);
				
				//week_num ������ܼ�
				int week_num = getWeekDay( first_date );
				
				//w ���� ��ǰ������ -w �ɵ�����һ
				int w = 0 - week_num;
				if (w >= 0) w = w - 7;
				
				//��ʼʱ���	start_date_long
				start_date_str = dateToString(calendarToDate(mktime(first_date_cal.get(Calendar.YEAR), first_date_cal.get(Calendar.MONTH), first_date_cal.get(Calendar.DATE) + w, 0, 0, 0)));
				start_date_long = dateToUnixDate(start_date_str) ;
				
				//����ʱ���	end_date_long
				end_date_str = dateToString(calendarToDate(mktime(first_date_cal.get(Calendar.YEAR), first_date_cal.get(Calendar.MONTH), first_date_cal.get(Calendar.DATE) + 37, 23, 59, 59)));
				end_date_long = dateToUnixDate(end_date_str) ;

				
			}
			
			
			//����start_date_long��end_date_long
			map.put("start_date", start_date_long);
			map.put("end_date", end_date_long);
			
			
			return map;
		}
		public static <T> boolean eq(T t, T val){
			
			if (t.equals(val)) {
				return true;
			}else{
				return false;
			}
		}
		public String I (String val){
			return getRequest().getParameter(val);
		}
		public static Date stringToDate( String str ) throws ParseException {
			SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date= sdf.parse(str);
			return date;		
		}
		public static Date calendarToDate( Calendar cal ) {			
			Date date=cal.getTime();
			return date;
		} 
		
		public static Calendar dateToCalendar( Date date ) {	
			Calendar cal=Calendar.getInstance();
			cal.setTime(date);
			return cal;
		} 
		public static String unixDateToDate(String unixDate) throws ParseException {  
		    
			SimpleDateFormat fm1 = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");  
			   SimpleDateFormat fm2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			   long unixLong = 0;  
			   String date = "";  
			   try {  
			   unixLong = Long.parseLong(unixDate) * 1000;  
			   } catch(Exception ex) {  
			   }  
			  
			   try {  
			   date = fm1.format(unixLong);  
			   date = fm2.format(new Date(date));  
			   } catch(Exception ex) {  
			   }  
			   return date;

		} 

		public static long dateToUnixDate( String date_str) throws ParseException{  
		    
			   Date date1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")  
			        .parse(	date_str);  
			        Date date2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")  
			        .parse("1970-01-01 08:00:00");  
			        long l = date1.getTime() - date2.getTime() > 0 ? date1.getTime()  
			        - date2.getTime() : date2.getTime() - date1.getTime();  
			        long rand = (int)(Math.random()*1000);  
			         
			        return l;  
			}  
	
		public static Calendar mktime(int year, int month, int date, int hourOfDay, int minute, int second) throws ParseException{
			Calendar cal=Calendar.getInstance();
			cal.set(year, month, date, hourOfDay, minute, second);
			return cal;
		}
		public static String dateToString( Date date ) {
			SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String dateStr=sdf.format(date);
			return dateStr;
			
		}
		public static String getMonthFirstDay(Date date) {
			//����calendar
			Calendar calendar;
			
			//���û��������㵱ǰ�����·ݵ�һ��
			if(date == null){
				calendar = Calendar.getInstance();
			//����в����������������·ݵ�һ��
			}else{
				calendar = dateToCalendar(date);
			}
		         
		    calendar.set(Calendar.DAY_OF_MONTH, calendar     
		            .getActualMinimum(Calendar.DAY_OF_MONTH));     
		    
		    return dateToString( calendar.getTime() );    
		}     
		    
		/**   
		 * �õ����µ����һ��   
		 *    
		 * @return   
		 */    
		public static String getMonthLastDay(Date date) {  
			//����calendar
			Calendar calendar;
			
			//���û��������㵱ǰ�����·ݵ�һ��
			if(date == null){
				calendar = Calendar.getInstance();
			//����в����������������·ݵ�һ��
			}else{
				calendar = dateToCalendar(date);
			}

		    calendar.set(Calendar.DAY_OF_MONTH, calendar     
		            .getActualMaximum(Calendar.DAY_OF_MONTH));     
		    return dateToString( calendar.getTime() ); 
		} 
		
		/**   
		 * �õ����µ����һ��   
		 *    
		 * @return   
		 */    
		public static int getWeekDay(Date date) {		
//			Date date = stringToDate("2013-8-31 12:00:00");//����������
			Calendar cal = dateToCalendar(date);
			int weekday = cal.get(Calendar.DAY_OF_WEEK);

			if(weekday==1){

//				p("������");
			}else{

//				p("����"+(weekday-1));
				
			}
//			p(weekday-1);
			
			return weekday -1;		
		} 
		public static int s2i(String intstr)
		{
		    Integer integer;
		    integer = Integer.valueOf(intstr);
		    return integer.intValue();
		}
		public long date_timestamp_get(Date date) {
			
			return date.getTime();
		}
		public Timestamp T (String time) throws IOException, ParseException{
			Format f = new SimpleDateFormat("yyyy-MM-dd HH:mm");
			Date d = (Date) f.parseObject(time);
			Timestamp ts = new Timestamp(d.getTime());
			return ts;
			
			}
		public Date date_modify (Date date) throws IOException, ParseException{
			Calendar cal=Calendar.getInstance();
			cal.setTime(date);

			cal.add(Calendar.MINUTE, -15);
			return cal.getTime();
	
		}
	
	
	
	
	
	
	
	
	

		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	
	
	
	
}
