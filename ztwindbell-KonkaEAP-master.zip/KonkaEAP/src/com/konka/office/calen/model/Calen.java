package com.konka.office.calen.model;

import java.util.Date;

import com.konka.common.base.BaseVO;
import com.konka.useradmin.model.User;

public class Calen extends BaseVO {
	
	User user;  
	
	private String username;
	
	private Integer calen_id;
	
    private Integer id;

    private String subject;

    private String location;

    private Integer masterid;

    private String description;

    private Integer calendartype;

    private Date starttime;

    private Date endtime;

    private Integer isalldayevent;

    private Integer hasattachment;

    private String category;

    private Integer instancetype;

    private String attendees;

    private String attendeenames;

    private String otherattendee;

    private Integer upaccount;

    private String upname;

    private Date uptime;

	private String recurringrule;

    private Date createTime;

    private String createEmployee;

    private Integer createDept;

    private Date updateTime;

    private String updateEmployee;

    private Integer updateDept;

    private String enableFlag;

    private String deleteFlag;
    
    private long starttime_long;

    private long endtime_long;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Integer getMasterid() {
		return masterid;
	}

	public void setMasterid(Integer masterid) {
		this.masterid = masterid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getCalendartype() {
		return calendartype;
	}

	public void setCalendartype(Integer calendartype) {
		this.calendartype = calendartype;
	}

	public Date getStarttime() {
		return starttime;
	}

	public void setStarttime(Date starttime) {
		this.starttime = starttime;
	}

	public Date getEndtime() {
		return endtime;
	}

	public void setEndtime(Date endtime) {
		this.endtime = endtime;
	}

	public Integer getIsalldayevent() {
		return isalldayevent;
	}

	public void setIsalldayevent(Integer isalldayevent) {
		this.isalldayevent = isalldayevent;
	}

	public Integer getHasattachment() {
		return hasattachment;
	}

	public void setHasattachment(Integer hasattachment) {
		this.hasattachment = hasattachment;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Integer getInstancetype() {
		return instancetype;
	}

	public void setInstancetype(Integer instancetype) {
		this.instancetype = instancetype;
	}

	public String getAttendees() {
		return attendees;
	}

	public void setAttendees(String attendees) {
		this.attendees = attendees;
	}

	public String getAttendeenames() {
		return attendeenames;
	}

	public void setAttendeenames(String attendeenames) {
		this.attendeenames = attendeenames;
	}

	public String getOtherattendee() {
		return otherattendee;
	}

	public void setOtherattendee(String otherattendee) {
		this.otherattendee = otherattendee;
	}

	public Integer getUpaccount() {
		return upaccount;
	}

	public void setUpaccount(Integer upaccount) {
		this.upaccount = upaccount;
	}

	public String getUpname() {
		return upname;
	}

	public void setUpname(String upname) {
		this.upname = upname;
	}

	public Date getUptime() {
		return uptime;
	}

	public void setUptime(Date uptime) {
		this.uptime = uptime;
	}

	public String getRecurringrule() {
		return recurringrule;
	}

	public void setRecurringrule(String recurringrule) {
		this.recurringrule = recurringrule;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreateEmployee() {
		return createEmployee;
	}

	public void setCreateEmployee(String createEmployee) {
		this.createEmployee = createEmployee;
	}

	public Integer getCreateDept() {
		return createDept;
	}

	public void setCreateDept(Integer createDept) {
		this.createDept = createDept;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getUpdateEmployee() {
		return updateEmployee;
	}

	public void setUpdateEmployee(String updateEmployee) {
		this.updateEmployee = updateEmployee;
	}

	public Integer getUpdateDept() {
		return updateDept;
	}

	public void setUpdateDept(Integer updateDept) {
		this.updateDept = updateDept;
	}

	public String getEnableFlag() {
		return enableFlag;
	}

	public void setEnableFlag(String enableFlag) {
		this.enableFlag = enableFlag;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public long getStarttime_long() {
		return starttime_long;
	}

	public void setStarttime_long(long starttime_long) {
		this.starttime_long = starttime_long;
	}

	public long getEndtime_long() {
		return endtime_long;
	}

	public void setEndtime_long(long endtime_long) {
		this.endtime_long = endtime_long;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getCalen_id() {
		return calen_id;
	}

	public void setCalen_id(Integer calen_id) {
		this.calen_id = calen_id;
	}

   
}