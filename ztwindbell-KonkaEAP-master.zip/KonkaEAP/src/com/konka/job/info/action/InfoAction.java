package com.konka.job.info.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.Writer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.solr.SearchTool;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.FileTool;
import com.konka.common.tool.Tree;
import com.konka.common.tool.Util;
import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoFavorite;
import com.konka.job.info.model.InfoKnow;
import com.konka.job.info.model.InfoNote;
import com.konka.job.info.model.InfoRecord;
import com.konka.job.info.model.InfoSearch;
import com.konka.job.info.model.InfoSearchClick;
import com.konka.job.info.service.InfoService;
import com.konka.system.model.ExeclCell;
import com.konka.system.model.ExeclImport;
import com.konka.system.model.Remark;
import com.konka.system.model.UploadFile;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
@Controller
@Scope("prototype")
public class InfoAction extends BaseAction {
	private InfoDirectory infoDirectory = new InfoDirectory();
	private InfoKnow infoKnow = new InfoKnow();
	private InfoRecord infoRecord = new InfoRecord();
	private Remark remark = new Remark();
	private InfoSearch infoSearch = new InfoSearch();
	private InfoSearchClick infoSearchClick = new InfoSearchClick();
	private InfoFavorite infoFavorite = new InfoFavorite();
	private InfoAsk infoAsk = new InfoAsk();
	private InfoNote infoNote = new InfoNote();
	private File filedata;
    private String filedataFileName;   
	@Autowired
	private InfoService infoService;
	@Autowired
	private SystemService systemService;
	//知识库首页
	public String index() throws Exception {
		if(infoDirectory.getType()==null||infoDirectory.getType().equals("")) {
			infoDirectory.setType("STUDY");
		}
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		
		//收藏夹列表
		infoFavorite.setCreate_employee(user.getUsername());
		List favoriteList = infoService.getFavoriteForIndex(infoFavorite);
		super.getRequest().setAttribute("favoriteList", favoriteList);
		
		//记事本列表
		infoNote.setCreate_employee(user.getUsername());
		List noteList = infoService.getNoteForIndex(infoNote);
		super.getRequest().setAttribute("noteList", noteList);
		
		//月榜单
		infoKnow.setCreate_time(new Timestamp(DateTool.dateAdd(null, "MONTH", -1).getTime()));
		List monthList = infoService.getBangList(infoKnow);
		super.getRequest().setAttribute("monthList", monthList);
		
		//年榜单
		infoKnow.setCreate_time(new Timestamp(DateTool.dateAdd(null, "YEAR", -1).getTime()));
		List yearList = Constant.infoMap.get("yearList");
		if(yearList==null) {
			yearList = infoService.getBangList(infoKnow);
			Constant.infoMap.put("yearList", yearList);
		}
		super.getRequest().setAttribute("yearList", yearList);
		//推荐知识点
		infoKnow.setCreate_time(new Timestamp(DateTool.dateAdd(null, "MONTH", -6).getTime()));
		List bestList = Constant.infoMap.get("bestList");
		if(bestList==null) {
			bestList = infoService.getBestKnowList(infoKnow);
			Constant.infoMap.put("bestList", bestList);
		}
		super.getRequest().setAttribute("bestList", bestList);
		
		//热门搜索
		infoSearch.setCreate_time(new Timestamp(DateTool.dateAdd(null, "MONTH", -6).getTime()));
		infoSearch.setDir_type("STUDY");
		List mostSearchList = Constant.infoMap.get("mostSearchList");
		if(mostSearchList==null) {
			mostSearchList = infoService.getMostSearchList(infoSearch);
			Constant.infoMap.put("mostSearchList", mostSearchList);
		}
		super.getRequest().setAttribute("mostSearchList", mostSearchList);
		
		//最新回答
		List newAskList = infoService.getNewsAskList(infoAsk);
		super.getRequest().setAttribute("newAskList", newAskList);
		
		//最新知识点数量
		infoKnow = new InfoKnow();
		infoKnow.setIs_new("T");
		Integer newCount = infoService.getKnowCount(infoKnow);
		super.getRequest().setAttribute("newCount", newCount);
		
		infoKnow = new InfoKnow();
		infoKnow.setIs_important("T");
		Integer importantCount = infoService.getKnowCount(infoKnow);
		super.getRequest().setAttribute("importantCount", importantCount);
		
		//此时间需传送到页面，不能删除
		infoKnow = new InfoKnow();
		infoKnow.setCreate_time(new Timestamp(DateTool.dateAdd(null, "DAY", -7).getTime()));
		Integer weekCount = infoService.getKnowCount(infoKnow);
		super.getRequest().setAttribute("weekCount", weekCount);
		
		
		return "index";
	}
	//获取下级目录
	public String toInfoDir() throws Exception {
		infoDirectory.setEnable_flag("T");
		dataList = infoService.getDirectoryList(infoDirectory);
		if(dataList!=null&&dataList.size()>0) {
			super.getRequest().setAttribute("nodes", Tree.makeTree(0,dataList)) ;
		}
		return "toInfoDir";
	}
	//获取目录全部知识点
	public String toKnowList() throws Exception {
		if("T".equals(first)) {
			page.setNumPerPage(10);
		}
		if(page.getOrderField().equals("id")) {
			page.setOrderField("weight");
		}
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoKnow.setCreate_employee(user.getUsername());
		dataList = infoService.getDirKnowInfoList(infoKnow,page);
		return "toKnowList";
	}
	//进入知识管理首页
	public String toManageKnow() throws Exception {
		dataList = infoService.getDirectoryList(infoDirectory);
		if(dataList!=null&&dataList.size()>0) {
			super.getRequest().setAttribute("nodes", Tree.makeTree(0,dataList)) ;
		}
		return "toManageKnow";
	}
	public String toAddEditInfoDir() throws Exception {
		if(infoDirectory.getId()!=null&&infoDirectory.getId()>0) {
			infoDirectory = infoService.getInfoDir(infoDirectory);
		}
		if(infoDirectory.getParent_id()!=null&&infoDirectory.getParent_id()>0) {
			InfoDirectory vo = new InfoDirectory();
			vo.setId(infoDirectory.getParent_id());
			vo = infoService.getInfoDir(vo);
			infoDirectory.setType(vo.getType());
		}
		return "toAddEditInfoDir";
	}
	//保存
	public String toSaveInfoDir() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoService.saveInfoDir(infoDirectory,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除
	public String toDeleteInfoDir() throws Exception {
		infoDirectory = infoService.getInfoDir(infoDirectory);
		infoKnow.getInfoDirectory().setNum(infoDirectory.getNum());
		dataList = infoService.getDirKnowInfoList(infoKnow,page);
		if(dataList.size()>0) {
			super.toError("目录下存在知识，请删除后再删除本目录！");
		}else {
			InfoDirectory vo = new InfoDirectory();
			vo.setParent_id(infoDirectory.getId());
			dataList = infoService.getDirectoryList(vo);
			if(dataList.size()>0) {
				super.toError("目录下存在子目录，请删除后再删除本目录！");
			}else {
				infoService.deleteInfoDir(infoDirectory);
			}
		}
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//进入目录的知识管理
	public String toManageDirKnow() throws Exception {
		infoDirectory = infoService.getInfoDir(infoDirectory);
		infoKnow.getInfoDirectory().setNum(infoDirectory.getNum());
		dataList = infoService.getInfoKnowList(infoKnow,page);
		return "toManageDirKnow";
	}
	
	
	//新增知识
	public String toAddEditKnow() throws Exception {
		if(infoKnow.getId()!=null&&infoKnow.getId()>0) {
			infoKnow = infoService.getInfoKnow(infoKnow);
		}
		if(infoKnow.getRelevant()!=null&&!infoKnow.getRelevant().equals("")){
			InfoKnow vo = new InfoKnow();
			vo.setRelevant(infoKnow.getRelevant());
			dataList = infoService.getAllKnowInfo(vo);
		}
		return "toAddEditKnow";
	}
	//保存知识
	public String toSaveKnow() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoKnow.setDescribe(Util.Html2Text(infoKnow.getContent()).trim());
		if(infoKnow.getShort_desc()==null||infoKnow.getShort_desc().equals("")) {
			if(infoKnow.getDescribe().trim().length()>90){
				infoKnow.setShort_desc(infoKnow.getDescribe().trim().substring(0,90));
			}else {
				infoKnow.setShort_desc(infoKnow.getDescribe().trim());
			}
		}else if(infoKnow.getShort_desc().length()>90){
			infoKnow.setShort_desc(infoKnow.getShort_desc().trim().substring(0,90));
		}
		if(infoKnow.getDestory_time()==null||infoKnow.getDestory_time().equals("")) {
			infoKnow.setDestory_time(Timestamp.valueOf("2099-12-31 23:59:59"));
		}
		if(infoKnow.getNum()==null||infoKnow.getNum().equals("")) {
			infoKnow.setNum(systemService.getNextNum("IK", "KK_KNOW_S", 4));
		}
		//是否包含附件
		infoKnow.setIs_upload("F");
		if(infoKnow.getContent().indexOf("up_toUserShowFile")>-1) {
			infoKnow.setIs_upload("T");
		}
		
		infoService.saveInfoKnow(infoKnow,user);
		//更新附件信息
		try{
			systemService.deleteUserUnuserUploadFile(infoKnow.getContent(),infoKnow.getId(),new UploadFile(0, "INFO", "toAddEditKnow", user.getUsername()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//快捷更新状态
	public String toUpdateState() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		if(infoKnow.getIs_review()!=null) {
			infoKnow.setReview_person(user.getUsername());
			infoKnow.setReview_time(Util.getTimestamp());
		}
		infoService.saveInfoKnow(infoKnow,user);
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除知识
	public String toDeleteInfoKnow() throws Exception {
		infoKnow = infoService.getInfoKnow(infoKnow);
		//删除所有附件
		infoService.deleteKnow(infoKnow);
		systemService.deleteObjectAllFile("INFO",infoKnow.getId(),"toAddEditKnow");
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public String toViewKnow() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoKnow = infoService.getInfoKnow(infoKnow);
		if(!infoKnow.getRelevant().equals("")){
			InfoKnow vo = new InfoKnow();
			//已审核的知识才允许相关展现
			vo.setIs_review("T");
			vo.setRelevant(infoKnow.getRelevant());
			dataList = infoService.getAllKnowInfo(vo);
		}
		
		//上篇、下篇
		InfoKnow pre_info = infoService.getPreKnow(infoKnow);
		InfoKnow next_info = infoService.getNextKnow(infoKnow);
		super.getRequest().setAttribute("pre_info", pre_info);
		super.getRequest().setAttribute("next_info", next_info);
		
		//文件清单
		if(infoKnow.getIs_upload().equals("T")) {
			List uploadList = new ArrayList();
			uploadList = systemService.getModelUploadFile(infoKnow.getId(), "INFO", "toAddEditKnow");
			super.getRequest().setAttribute("uploadList", uploadList);
		}
		//访问记录
		InfoRecord ir = new InfoRecord();
		ir.setKnow_id(infoKnow.getId());
		ir.setCreate_employee(user.getUsername());
		ir.setCreate_time(Timestamp.valueOf(DateTool.formatDate("yyyy-MM-dd", null)+" 00:00:00"));
		ir = infoService.getInfoRecord(ir);

		if(ir==null) {
			infoRecord.setKnow_id(infoKnow.getId());
			infoService.saveInfoRecord(infoRecord,user);

		}else {
			ir.setClick(ir.getClick()+1);
			infoService.saveInfoRecord(ir,user);
			infoRecord = ir;
		}
		//更新访问次数
		infoService.updateKnowClick(infoKnow);
		//评论列表
		remark.setObject_id(infoKnow.getId());
		remark.setModel("INFO");
		List remarkList = systemService.getRemarkList(remark, page);
		super.getRequest().setAttribute("remarkList",remarkList);
		//搜索点击记录
		if(infoSearchClick.getSearch_id()!=null&&infoSearchClick.getSearch_id()>0) {
			infoSearchClick.setKnow_id(infoKnow.getId());
			infoService.saveSearchClick(infoSearchClick,user);
		}
		return "toViewKnow";
	}
	public String toViewKnowOut() throws Exception {
		infoKnow = infoService.getInfoKnow(infoKnow);
		return "toViewKnowOut";
	}
	//查找带回目录
	public String toLookUpDirectory() throws Exception {
		dataList = infoService.getDirectoryList(infoDirectory);
		if(dataList!=null&&dataList.size()>0) {
			super.getRequest().setAttribute("nodes", Tree.makeTree(0,dataList)) ;
		}
		return "toLookUpDirectory";
	}
	//按标题搜索
	public String toAddEditSearchKnowInfo() throws Exception {
		if(infoKnow.getTitle()!=null&&!infoKnow.getTitle().equals("")) {
			dataList = infoService.getAllKnowInfo(infoKnow);
		}
		return "toAddEditSearchKnowInfo";
	}
	//审核列表
	public String toReviewList() throws Exception {
		infoKnow.setIs_review("F");
		dataList = infoService.getInfoKnowList(infoKnow, page);
		return "toReviewList";
	}
	//关闭知识点
	public String toLeaveInfoKnow() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoRecord.setCreate_employee(user.getUsername());
		infoService.updateInfoRecordForLeave(infoRecord);
		return null;
	}
	//用户点评
	public String toDianPing() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		InfoRecord vorecord = infoService.getInfoRecordById(infoRecord);
		infoKnow.setId(infoRecord.getKnow_id());
		infoKnow = infoService.getInfoKnow(infoKnow);
		InfoKnow vo = new InfoKnow();
		vo.setId(infoKnow.getId());
		if(vorecord.getIs_useful()==null) {
			if(infoRecord.getIs_useful().equals("T")) {
				vo.setGood(infoKnow.getGood()+1);
				vo.setNormal(infoKnow.getNormal());
				vo.setBad(infoKnow.getBad());
				vo.setAngry(infoKnow.getAngry());
				vo.setCommon(infoKnow.getCommon());
				vo.setWeight(infoKnow.getWeight()+5);
			}else if(infoRecord.getIs_useful().equals("N")) {
				vo.setGood(infoKnow.getGood());
				vo.setNormal(infoKnow.getNormal()+1);
				vo.setBad(infoKnow.getBad());
				vo.setAngry(infoKnow.getAngry());
				vo.setCommon(infoKnow.getCommon());
				vo.setWeight(infoKnow.getWeight()+4);
			}else if(infoRecord.getIs_useful().equals("C")) {
				vo.setGood(infoKnow.getGood());
				vo.setAngry(infoKnow.getAngry());
				vo.setCommon(infoKnow.getCommon()+1);
				vo.setNormal(infoKnow.getNormal());
				vo.setBad(infoKnow.getBad());
				vo.setWeight(infoKnow.getWeight()+3);
			}else if(infoRecord.getIs_useful().equals("V")) {
				vo.setGood(infoKnow.getGood());
				vo.setAngry(infoKnow.getAngry()+1);
				vo.setCommon(infoKnow.getCommon());
				vo.setNormal(infoKnow.getNormal());
				vo.setBad(infoKnow.getBad());
				vo.setWeight(infoKnow.getWeight()+1);
			}else {
				vo.setGood(infoKnow.getGood());
				vo.setNormal(infoKnow.getNormal());
				vo.setAngry(infoKnow.getAngry());
				vo.setCommon(infoKnow.getCommon());
				vo.setBad(infoKnow.getBad()+1);
				vo.setWeight(infoKnow.getWeight()+2);
			}
			infoService.saveInfoRecord(infoRecord,user);
			infoService.updateKnowPingjia(vo);
		}else {
			if(!infoRecord.getIs_useful().equals(vorecord.getIs_useful())) {
				if(vorecord.getIs_useful().equals("T")) {
					 vo.setGood(infoKnow.getGood()-1);
					 vo.setWeight(infoKnow.getWeight()-5);
					 if(infoRecord.getIs_useful().equals("N")){
						 vo.setNormal(infoKnow.getNormal()+1);
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+4);
					 }else if(infoRecord.getIs_useful().equals("C")){
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon()+1);
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+3);
					 }else if(infoRecord.getIs_useful().equals("V")){
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry()+1);
						 vo.setWeight(vo.getWeight()+1);
					 }else{
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad()+1);
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+2);
					 }
				}else if(vorecord.getIs_useful().equals("N")) {
					vo.setNormal(infoKnow.getNormal()-1);
					vo.setWeight(infoKnow.getWeight()-4);
					if(infoRecord.getIs_useful().equals("T")){
						 vo.setGood(infoKnow.getGood()+1);
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+5);
					 }else if(infoRecord.getIs_useful().equals("C")){
						 vo.setGood(infoKnow.getGood());
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon()+1);
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+3);
					 }else if(infoRecord.getIs_useful().equals("V")){
						 vo.setGood(infoKnow.getGood());
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry()+1);
						 vo.setWeight(vo.getWeight()+1);
					 }else{
						 vo.setGood(infoKnow.getGood());
						 vo.setBad(infoKnow.getBad()+1);
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+2);
					 }
				}else if(vorecord.getIs_useful().equals("C")) {
					vo.setCommon(infoKnow.getCommon()-1);
					vo.setWeight(infoKnow.getWeight()-3);
					if(infoRecord.getIs_useful().equals("T")){
						 vo.setGood(infoKnow.getGood()+1);
						 vo.setBad(infoKnow.getBad());
						 vo.setNormal(infoKnow.getNormal());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+5);
					 }else if(infoRecord.getIs_useful().equals("N")){
						 vo.setNormal(infoKnow.getNormal()+1);
						 vo.setBad(infoKnow.getBad());
						 vo.setGood(infoKnow.getGood());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+4);
					 }else if(infoRecord.getIs_useful().equals("V")){
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad());
						 vo.setGood(infoKnow.getGood());
						 vo.setAngry(infoKnow.getAngry()+1);
						 vo.setWeight(vo.getWeight()+1);
					 }else{
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad()+1);
						 vo.setGood(infoKnow.getGood());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+2);
					 }
				}else if(vorecord.getIs_useful().equals("V")) {
					vo.setAngry(infoKnow.getAngry()-1);
					vo.setWeight(infoKnow.getWeight()-1);
					if(infoRecord.getIs_useful().equals("T")){
						 vo.setGood(infoKnow.getGood()+1);
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setNormal(infoKnow.getNormal());
						 vo.setWeight(vo.getWeight()+5);
					 }else if(infoRecord.getIs_useful().equals("N")){
						 vo.setNormal(infoKnow.getNormal()+1);
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setGood(infoKnow.getGood());
						 vo.setWeight(vo.getWeight()+4);
					 }else if(infoRecord.getIs_useful().equals("C")){
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad());
						 vo.setCommon(infoKnow.getCommon()+1);
						 vo.setGood(infoKnow.getGood());
						 vo.setWeight(vo.getWeight()+3);
					 }else{
						 vo.setNormal(infoKnow.getNormal());
						 vo.setBad(infoKnow.getBad()+1);
						 vo.setCommon(infoKnow.getCommon());
						 vo.setGood(infoKnow.getGood());
						 vo.setWeight(vo.getWeight()+2);
					 }
				}else{
					vo.setBad(infoKnow.getBad()-1);
					vo.setWeight(infoKnow.getWeight()-2);
					if(infoRecord.getIs_useful().equals("T")){
						 vo.setGood(infoKnow.getGood()+1);
						 vo.setNormal(infoKnow.getNormal());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+5);
					 }else if(infoRecord.getIs_useful().equals("N")){
						 vo.setNormal(infoKnow.getNormal()+1);
						 vo.setGood(infoKnow.getGood());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+4);
					 }else if(infoRecord.getIs_useful().equals("C")){
						 vo.setNormal(infoKnow.getNormal());
						 vo.setGood(infoKnow.getGood());
						 vo.setCommon(infoKnow.getCommon()+1);
						 vo.setAngry(infoKnow.getAngry());
						 vo.setWeight(vo.getWeight()+3);
					 }else{
						 vo.setNormal(infoKnow.getNormal());
						 vo.setGood(infoKnow.getGood());
						 vo.setCommon(infoKnow.getCommon());
						 vo.setAngry(infoKnow.getAngry()+1);
						 vo.setWeight(vo.getWeight()+1);
					 }
				}
				infoService.saveInfoRecord(infoRecord,user);
				infoService.updateKnowPingjia(vo);
			}else {
				vo.setGood(infoKnow.getGood());
				vo.setNormal(infoKnow.getNormal());
				vo.setBad(infoKnow.getBad());
				vo.setWeight(infoKnow.getWeight());
			}
		}

		super.getResponse().setContentType("text/plain;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String s = "<a href=\"#\" onclick=\"dianping(this,"+infoRecord.getKnow_id()+","+infoRecord.getId()+",'T')\">非常满意("+vo.getGood()+")</a>&nbsp;&nbsp;<a href=\"#\" onclick=\"dianping(this,"+infoRecord.getKnow_id()+","+infoRecord.getId()+",'N')\">满意("+vo.getNormal()+")</a>&nbsp;&nbsp;<a href=\"#\" onclick=\"dianping(this,"+infoRecord.getKnow_id()+","+infoRecord.getId()+",'C')\">一般("+vo.getCommon()+")</a>&nbsp;&nbsp;<a href=\"#\" onclick=\"dianping(this,"+infoRecord.getKnow_id()+","+infoRecord.getId()+",'F')\">不满意("+vo.getBad()+")</a>&nbsp;&nbsp;<a href=\"#\" onclick=\"dianping(this,"+infoRecord.getKnow_id()+","+infoRecord.getId()+",'V')\">非常不满意("+vo.getAngry()+")</a>";
		out.write(s);
		out.flush();
		out.close();
		return null;
	}
	//进入新建评论
	public String toAddRemark() throws Exception {
		infoKnow = infoService.getInfoKnow(infoKnow);
		return "toAddRemark";
	}
	//保存评论
	public String toSaveRemark() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		systemService.insertRemark(remark, user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public String toRemarkList() throws Exception {
		dataList = systemService.getRemarkList(remark, page);
		return "toRemarkList";
	}
	//评论管理列表
	public String toManageRemarkList() throws Exception {
		dataList = systemService.getRemarkList(remark, page);
		return "toManageRemarkList";
	}
	//搜索
	public String toSearch() throws Exception {
		if("T".equals(first)) {
			page.setNumPerPage(10);
		}
		long startTime=System.currentTimeMillis();
		
		infoSearch.setKeyword(infoSearch.getKeyword().trim());
		if(infoSearch.getKeyword().length()>50){
			infoSearch.setKeyword(infoSearch.getKeyword().substring(0,50));
		}
		
		if(!infoSearch.getDir_type().equals("ASK")){
			dataList = SearchTool.searchInfoKnow(infoSearch, page);
			if(page.getNum()==1&&infoSearch.getIs_ask().equals("T")&&!infoSearch.getKeyword().equals("")) {
				List askList = new ArrayList();
				askList = SearchTool.searchInfoAsk(infoSearch,null);
				super.getRequest().setAttribute("askList", askList);
			}
		}else {
			dataList = SearchTool.searchInfoAsk(infoSearch,page);
		}
		
		infoSearch.setTime((float)(System.currentTimeMillis()-startTime)/1000f);

		//新建搜索记录,首次进入页面才进行操作，翻页不操作
		if("T".equals(first)) {
			User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
			if(infoSearch.getKeyword()!=null&&!"".equals(infoSearch.getKeyword())) {
				InfoSearch is = new InfoSearch();
				is.setKeyword(infoSearch.getKeyword());
				//is.setDir_num(infoSearch.getDir_num());//不再区分搜索目录
				is.setDir_type(infoSearch.getDir_type());
				is.setCreate_employee(user.getUsername());
				is.setCreate_time(Timestamp.valueOf(DateTool.formatDate("yyyy-MM-dd", null)+" 00:00:00"));
				is = infoService.getSearchByObject(is);
				if(is!=null) {
					is.setClick(is.getClick()+1);
					infoService.saveSearch(is, user);
					infoSearch.setId(is.getId());
					infoSearch.setManyi(is.getManyi());
				}else {
					infoSearch.setManyi(0);//页面需要判断此值
					infoService.saveSearch(infoSearch,user);
				}
			}
		}
		//相关搜索词
		if(!"".equals(infoSearch.getKeyword())) {
			InfoSearch info = new InfoSearch();
			info.setCreate_time(new Timestamp(DateTool.dateAdd(null, "MONTH", -6).getTime()));
			info.setDir_type(infoSearch.getDir_type());
			info.setKeyword(infoSearch.getKeyword());
			List xiangguan = infoService.getMostSearchList(info);
			super.getRequest().setAttribute("xiangguan", xiangguan);
		}
		return "toSearch";
	}
	//搜索满意度
	public String toManyi() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		//未考虑安全性
		infoService.saveSearch(infoSearch, user);
		super.getResponse().setContentType("text/plain;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String s = "感谢您的评价！";
		out.write(s);
		out.flush();
		out.close();
		return null;
	}
	//收藏
	public String toAddFavorite() throws Exception {
		super.getResponse().setContentType("text/plain;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		Writer out = super.getResponse().getWriter();
		String s = "";
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoFavorite.setCreate_employee(user.getUsername());
		InfoFavorite ifa = infoService.getFavoriteByObject(infoFavorite);
		if(ifa!=null) {
			s = "已存在，无需重复收藏！";
		}else {
			infoService.saveFavorite(infoFavorite,user);
			s = "添加成功！";
		}
		out.write(s);
		out.flush();
		out.close();
		return null;
	}
	public String toMyFavorite() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		if("T".equals(first)) {
			page.setNumPerPage(10);
		}
		infoFavorite.setCreate_employee(user.getUsername());
		List tempList = infoService.getFavoriteKnowList(infoFavorite,page);
		if(infoFavorite.getInfoKnow().getTitle()!=null&&!infoFavorite.getInfoKnow().getTitle().equals("")) {
			for(int i=0;i<tempList.size();i++) {
				InfoFavorite favorite = (InfoFavorite)tempList.get(i);
				String t = favorite.getInfoKnow().getTitle();
				t = t.replace(infoFavorite.getInfoKnow().getTitle(), "<font style='color:red'>"+infoFavorite.getInfoKnow().getTitle()+"</font>");
				favorite.getInfoKnow().setTitle(t);
				dataList.add(favorite);
			}
		}else {
			dataList.addAll(tempList);
		}
		return "toMyFavorite";
	}
	//修改收藏排序
	public String toUpdateFavSort() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoService.saveFavorite(infoFavorite,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//删除收藏，未做归属验证
	public String toDeleteFavorite() throws Exception {
		infoService.deleteFavorite(infoFavorite);
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//搜索关键词
	public String toSearchKeyword() throws Exception {
		infoSearch.setFetch_count(8);
		infoSearch.setCreate_time(new Timestamp(DateTool.dateAdd(null, "YEAR", -1).getTime()));
		dataList = infoService.getMostSearchList(infoSearch);
		infoKnow.setFetch_count(8);
			infoKnow.setTitle(infoSearch.getKeyword());
			List tempList = infoService.getAllKnowInfo(infoKnow);
			if(tempList.size()>0){
				InfoKnow know = null;
				for(int i=0;i<tempList.size();i++){
					know = (InfoKnow)tempList.get(i);
					InfoSearch search = new InfoSearch();
					search.setKeyword(know.getTitle());
					dataList.add(search);
				}
			}
		
		return "toSearchKeyword";
	}
	public String toHistorySearch() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoSearch.setCreate_employee(user.getUsername());
		infoSearch.setCreate_time(Timestamp.valueOf(DateTool.formatDate("yyyy-MM-dd", null)+" 00:00:00"));
		dataList = infoService.getSearchList(infoSearch,page);
		return "toHistorySearch";
	}
	//历史访问记录
	public String toHistoryVisite() throws Exception {
		if("T".equals(first)) {
			page.setNumPerPage(10);
		}
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoRecord.setCreate_employee(user.getUsername());
		infoRecord.setCreate_time(Timestamp.valueOf(DateTool.formatDate("yyyy-MM-dd", null)+" 00:00:00"));
		infoRecord.setEnable_flag("T");
		dataList = infoService.getRecordList(infoRecord,page);
		return "toHistoryVisite";
	}
	
	//查看公开问题
	public String toPublicAskList() throws Exception{
		infoAsk.setEnable_flag("T");
		dataList = infoService.getDirInfoAskList(infoAsk,page);
		return "toPublicAskList";
	}
	//问答管理
	public String toManageDirAsk() throws Exception {
		dataList = infoService.getAskList(infoAsk, page);
		return "toManageDirAsk";
	}
	public String toDeleteInfoAsk() throws Exception {
		infoService.deleteAsk(infoAsk);
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//提出问题
	public String toAddAsk() throws Exception {
		
		return "toAddAsk";
	}
	//保存问题
	public String toSaveAsk() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);

		infoService.saveAsk(infoAsk,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//修改问题
	public String toEditAsk() throws Exception {
		infoAsk = infoService.getInfoAsk(infoAsk);

		return "toEditAsk";
	}
	//
	public String toUpdateAskState() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		InfoAsk ia = infoService.getInfoAsk(infoAsk);
		if(ia.getAnswer_person()!=null&&!ia.getAnswer_person().equals("")) {
			infoService.saveAsk(infoAsk, user);
		}else {
			super.toError("问题未回答，不能修改此状态！");
		}
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//问题查看
	public String toViewAsk() throws Exception {
		infoAsk = infoService.getInfoAsk(infoAsk);
		infoService.updateAskForView(infoAsk);
		return "toViewAsk";
	}
	public String toMyAsk() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoAsk.setCreate_employee(user.getUsername());
		dataList = infoService.getAskList(infoAsk, page);
		return "toMyAsk";
	}
	
	public String toMyNote() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		if("T".equals(first)) {
			page.setNumPerPage(10);
		}
		
		infoNote.setCreate_employee(user.getUsername());
		List tempList = infoService.getNoteList(infoNote,page);
		if(infoNote.getTitle()!=null&&!infoNote.getTitle().equals("")) {
			for(int i=0;i<tempList.size();i++) {
				InfoNote note = (InfoNote)tempList.get(i);
				String t = note.getTitle();
				t = t.replace(infoNote.getTitle(), "<font style='color:red'>"+infoNote.getTitle()+"</font>");
				note.setTitle(t);
				dataList.add(note);
			}
		}else {
			dataList.addAll(tempList);
		}
		return "toMyNote";
	}
	//查看记事内容
	public String toViewNote() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoNote.setCreate_employee(user.getUsername());
		infoNote = infoService.getNoteByObject(infoNote);
		return "toViewNote";
	}
	//添加记事内容
	public String toAddEditNote() throws Exception {
		if(infoNote.getId()!=null&&infoNote.getId()>0) {
			User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
			infoNote.setCreate_employee(user.getUsername());
			infoNote = infoService.getNoteByObject(infoNote);			
		}
		return "toAddEditNote";
	}
	//保存
	public String toSaveNote() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);

		String desc = Util.Html2Text(infoNote.getContent());
		if(desc.length()>50) {
			infoNote.setDescribe(desc.substring(0,50));
		}else {
			infoNote.setDescribe(desc);
		}
		
		infoService.saveNote(infoNote,user);
		//更新附件信息
		try{
			systemService.deleteUserUnuserUploadFile(infoNote.getContent(),infoNote.getId(),new UploadFile(0, "INFO", "toAddEditInfoNote", user.getUsername()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	public String toDeleteNote() throws Exception {
		//删除所有附件
		infoService.deleteNote(infoNote);
		systemService.deleteObjectAllFile("INFO",infoNote.getId(),"toAddEditInfoNote");
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//修改排序(免于更新附件)
	public String toUpdateNoteSort() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		infoService.saveNote(infoNote,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//
	public String toInfoRemarkList() throws Exception {
		dataList = systemService.getModelRemark(0, "INFO","info_toSaveRemark", page);
		return "toInfoRemarkList";
	}
	public String toUpdateRemarkState() throws Exception {
		User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
		systemService.updateRemark(remark, user);
		super.setCallbackType("");
		return Constant.ACTION_S.ajaxDone.toString();
	}
	//批量导入知识点
	public String toBatchAddKnow() throws Exception {
		
		return "toBatchAddKnow";
	}
	/*
	//批量导入知识点
	public String toBatchSaveKnow() throws Exception {
		ExeclImport execlImport = new ExeclImport();
		execlImport.setTable("OPENEAP.KK_INFO_KNOW");
		execlImport.setCreate_info("T");
		if(FileTool.getExtention(filedataFileName).equals("xls")) {
			try {
				User user = (User)super.getRequest().getSession().getAttribute(Constant.SESSION_USER);
				InfoKnow info = null;
				HSSFRow row = null;
				HSSFSheet sheet = (HSSFSheet) (new HSSFWorkbook(new FileInputStream(filedata))).getSheetAt(0);
				for(int i=1;i<sheet.getLastRowNum()+1;i++) {
					info = new InfoKnow();
					row = sheet.getRow(i);
					if(systemService.getCellValue(row.getCell(0))!="") {
						
						Double d = Double.parseDouble(systemService.getCellValue(row.getCell(0)));
						info.setDir_id(Integer.valueOf(d.intValue()));
						info.setTitle(systemService.getCellValue(row.getCell(1)));
						info.setKeywords(systemService.getCellValue(row.getCell(2)));
						info.setContent(systemService.getCellValue(row.getCell(3)));
						info.setDescribe(Util.Html2Text(info.getContent()).trim());
						if(info.getDescribe().trim().length()>90){
							info.setShort_desc(info.getDescribe().trim().substring(0,90));
						}else {
							info.setShort_desc(info.getDescribe().trim());
						}
						info.setDestory_time(Timestamp.valueOf("2099-12-31 23:59:59"));
						info.setNum(systemService.getNextNum("IK", "KK_KNOW_S", 4));
						info.setIs_upload("F");
						info.setFastnav("");
						info.setIs_new("F");
						info.setIs_important("F");
						info.setIs_review("F");
						info.setRelevant("");
						info.setWeight(0);
						info.setEnable_flag("T");
						infoService.insertInfoKnow(info,user);
						
					}
				}
				
			} catch (Exception e) {
				super.toError("导入失败！");
				e.printStackTrace();
			}
		}else {
			super.toError("上传文件格式不正确！");
		}
		if(!"".equals(execlImport.getResult())){
			super.toError(execlImport.getResult());
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}
	*/
	public InfoDirectory getInfoDirectory() {
		return infoDirectory;
	}
	public void setInfoDirectory(InfoDirectory infoDirectory) {
		this.infoDirectory = infoDirectory;
	}
	public InfoKnow getInfoKnow() {
		return infoKnow;
	}
	public void setInfoKnow(InfoKnow infoKnow) {
		this.infoKnow = infoKnow;
	}
	public InfoRecord getInfoRecord() {
		return infoRecord;
	}
	public void setInfoRecord(InfoRecord infoRecord) {
		this.infoRecord = infoRecord;
	}
	public Remark getRemark() {
		return remark;
	}
	public void setRemark(Remark remark) {
		this.remark = remark;
	}
	public InfoSearch getInfoSearch() {
		return infoSearch;
	}
	public void setInfoSearch(InfoSearch infoSearch) {
		this.infoSearch = infoSearch;
	}
	public InfoFavorite getInfoFavorite() {
		return infoFavorite;
	}
	public void setInfoFavorite(InfoFavorite infoFavorite) {
		this.infoFavorite = infoFavorite;
	}
	public InfoAsk getInfoAsk() {
		return infoAsk;
	}
	public void setInfoAsk(InfoAsk infoAsk) {
		this.infoAsk = infoAsk;
	}
	public InfoNote getInfoNote() {
		return infoNote;
	}
	public void setInfoNote(InfoNote infoNote) {
		this.infoNote = infoNote;
	}
	public File getFiledata() {
		return filedata;
	}
	public void setFiledata(File filedata) {
		this.filedata = filedata;
	}
	public String getFiledataFileName() {
		return filedataFileName;
	}
	public void setFiledataFileName(String filedataFileName) {
		this.filedataFileName = filedataFileName;
	}
	public InfoSearchClick getInfoSearchClick() {
		return infoSearchClick;
	}
	public void setInfoSearchClick(InfoSearchClick infoSearchClick) {
		this.infoSearchClick = infoSearchClick;
	}
}
