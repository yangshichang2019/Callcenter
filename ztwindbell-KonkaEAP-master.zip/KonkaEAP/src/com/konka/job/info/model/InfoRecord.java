package com.konka.job.info.model;

import com.konka.common.base.BaseVO;

public class InfoRecord extends BaseVO {
	private Integer id;
	private Integer know_id;
	private String is_useful;//�Ƿ�����
	private Integer click;//�����������ʼΪ1��ÿ��ͬһ����ֻ����һ����¼
	private InfoKnow infoKnow = new InfoKnow();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getKnow_id() {
		return know_id;
	}
	public void setKnow_id(Integer know_id) {
		this.know_id = know_id;
	}
	public String getIs_useful() {
		return is_useful;
	}
	public void setIs_useful(String is_useful) {
		this.is_useful = is_useful;
	}
	public Integer getClick() {
		return click;
	}
	public void setClick(Integer click) {
		this.click = click;
	}
	public InfoKnow getInfoKnow() {
		return infoKnow;
	}
	public void setInfoKnow(InfoKnow infoKnow) {
		this.infoKnow = infoKnow;
	}
	
}
