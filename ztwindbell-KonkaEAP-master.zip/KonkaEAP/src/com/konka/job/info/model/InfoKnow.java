package com.konka.job.info.model;

import java.sql.Timestamp;

import com.konka.common.base.BaseVO;

public class InfoKnow extends BaseVO {
	private Integer id;
	private String num;
	private Integer dir_id;
	private String dir_name;
	private String title;
	private String title_s;//搜索标题
	private String keywords;
	private String content;
	private String describe; //用于存储过滤标签后的文本
	private String short_desc;
	private Timestamp destory_time;//过期时间
	
	private String fastnav;
	
	private Timestamp last_click_time;
	private Integer click;
	//标识
	private String is_upload;//是否有附件
	private String is_new;
	private String is_important;
	private String is_review;//是否已审核
	//审核
	private String review_person;
	private Timestamp review_time;
	
	private Integer good;//非常满意
	private Integer normal;//满意
	private Integer common;//一般
	private Integer bad;//不满意
	private Integer angry;//非常不满意
	
	//相关知识
	private String relevant;
	//权重
	private Integer weight;
	private InfoDirectory infoDirectory = new InfoDirectory();
	private Integer record_id;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getDir_id() {
		return dir_id;
	}
	public void setDir_id(Integer dir_id) {
		this.dir_id = dir_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getKeywords() {
		return keywords;
	}
	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getIs_new() {
		return is_new;
	}
	public void setIs_new(String is_new) {
		this.is_new = is_new;
	}
	public String getIs_important() {
		return is_important;
	}
	public void setIs_important(String is_important) {
		this.is_important = is_important;
	}
	public String getReview_person() {
		return review_person;
	}
	public void setReview_person(String review_person) {
		this.review_person = review_person;
	}
	public Timestamp getReview_time() {
		return review_time;
	}
	public void setReview_time(Timestamp review_time) {
		this.review_time = review_time;
	}
	public String getIs_upload() {
		return is_upload;
	}
	public void setIs_upload(String is_upload) {
		this.is_upload = is_upload;
	}
	public Timestamp getDestory_time() {
		return destory_time;
	}
	public void setDestory_time(Timestamp destory_time) {
		this.destory_time = destory_time;
	}
	public Timestamp getLast_click_time() {
		return last_click_time;
	}
	public void setLast_click_time(Timestamp last_click_time) {
		this.last_click_time = last_click_time;
	}
	public String getRelevant() {
		return relevant;
	}
	public void setRelevant(String relevant) {
		this.relevant = relevant;
	}
	public Integer getGood() {
		return good;
	}
	public void setGood(Integer good) {
		this.good = good;
	}
	public Integer getBad() {
		return bad;
	}
	public void setBad(Integer bad) {
		this.bad = bad;
	}
	public String getIs_review() {
		return is_review;
	}
	public void setIs_review(String is_review) {
		this.is_review = is_review;
	}
	public String getNum() {
		return num;
	}
	public void setNum(String num) {
		this.num = num;
	}
	public Integer getClick() {
		return click;
	}
	public void setClick(Integer click) {
		this.click = click;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	public InfoDirectory getInfoDirectory() {
		return infoDirectory;
	}
	public void setInfoDirectory(InfoDirectory infoDirectory) {
		this.infoDirectory = infoDirectory;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getFastnav() {
		return fastnav;
	}
	public void setFastnav(String fastnav) {
		this.fastnav = fastnav;
	}
	public String getShort_desc() {
		return short_desc;
	}
	public void setShort_desc(String short_desc) {
		this.short_desc = short_desc;
	}
	public String getTitle_s() {
		return title_s;
	}
	public void setTitle_s(String title_s) {
		this.title_s = title_s;
	}
	public String getDir_name() {
		return dir_name;
	}
	public void setDir_name(String dir_name) {
		this.dir_name = dir_name;
	}
	public Integer getRecord_id() {
		return record_id;
	}
	public void setRecord_id(Integer record_id) {
		this.record_id = record_id;
	}
	public Integer getNormal() {
		return normal;
	}
	public void setNormal(Integer normal) {
		this.normal = normal;
	}
	public Integer getCommon() {
		return common;
	}
	public void setCommon(Integer common) {
		this.common = common;
	}
	public Integer getAngry() {
		return angry;
	}
	public void setAngry(Integer angry) {
		this.angry = angry;
	}
	
	
}
