package com.konka.job.info.model;

import com.konka.common.base.TreeVO;

public class InfoDirectory extends TreeVO {
	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
