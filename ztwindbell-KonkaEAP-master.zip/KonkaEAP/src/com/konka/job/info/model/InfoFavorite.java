package com.konka.job.info.model;

import com.konka.common.base.BaseVO;

public class InfoFavorite extends BaseVO {
	private Integer id;
	private Integer know_id;
	private Integer sort;
	private InfoKnow infoKnow = new InfoKnow();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getKnow_id() {
		return know_id;
	}
	public void setKnow_id(Integer know_id) {
		this.know_id = know_id;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public InfoKnow getInfoKnow() {
		return infoKnow;
	}
	public void setInfoKnow(InfoKnow infoKnow) {
		this.infoKnow = infoKnow;
	}
}
