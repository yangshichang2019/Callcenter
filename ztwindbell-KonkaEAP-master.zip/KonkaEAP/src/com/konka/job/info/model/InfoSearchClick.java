package com.konka.job.info.model;

import com.konka.common.base.BaseVO;

public class InfoSearchClick extends BaseVO {
	private Integer id;
	private Integer search_id;
	private Integer index;
	private Integer know_id;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getSearch_id() {
		return search_id;
	}
	public void setSearch_id(Integer search_id) {
		this.search_id = search_id;
	}
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	public Integer getKnow_id() {
		return know_id;
	}
	public void setKnow_id(Integer know_id) {
		this.know_id = know_id;
	}
}
