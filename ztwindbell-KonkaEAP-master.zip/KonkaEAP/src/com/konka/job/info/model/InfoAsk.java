package com.konka.job.info.model;

import java.sql.Timestamp;

import com.konka.common.base.BaseVO;

public class InfoAsk extends BaseVO {
	private Integer id;
	private Integer dir_id;
	private String dir_name;
	private String dir_num;
	private String title;
	private String title_s;//�������ı���
	private String answer;
	private String answer_person;
	private Timestamp answer_time;
	private Integer click;
	private InfoDirectory infoDirectory = new InfoDirectory();
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getAnswer_person() {
		return answer_person;
	}
	public void setAnswer_person(String answer_person) {
		this.answer_person = answer_person;
	}
	public Timestamp getAnswer_time() {
		return answer_time;
	}
	public void setAnswer_time(Timestamp answer_time) {
		this.answer_time = answer_time;
	}
	public Integer getClick() {
		return click;
	}
	public void setClick(Integer click) {
		this.click = click;
	}
	public Integer getDir_id() {
		return dir_id;
	}
	public void setDir_id(Integer dir_id) {
		this.dir_id = dir_id;
	}
	public InfoDirectory getInfoDirectory() {
		return infoDirectory;
	}
	public void setInfoDirectory(InfoDirectory infoDirectory) {
		this.infoDirectory = infoDirectory;
	}
	public String getDir_name() {
		return dir_name;
	}
	public void setDir_name(String dir_name) {
		this.dir_name = dir_name;
	}
	public String getDir_num() {
		return dir_num;
	}
	public void setDir_num(String dir_num) {
		this.dir_num = dir_num;
	}
	public String getTitle_s() {
		return title_s;
	}
	public void setTitle_s(String title_s) {
		this.title_s = title_s;
	}
}
