package com.konka.job.info.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoFavorite;
import com.konka.job.info.model.InfoKnow;
import com.konka.job.info.model.InfoNote;
import com.konka.job.info.model.InfoRecord;
import com.konka.job.info.model.InfoSearch;
import com.konka.job.info.model.InfoSearchClick;
import com.konka.useradmin.model.User;

public interface InfoService {
	public List getDirectoryList(InfoDirectory infoDirectory) throws Exception;
	public InfoDirectory getInfoDir(InfoDirectory infoDirectory) throws Exception;
	public void saveInfoDir(InfoDirectory infoDirectory,User user) throws Exception;
	public void deleteInfoDir(InfoDirectory infoDirectory) throws Exception;
	
	public List getDirKnowInfoList(InfoKnow infoKnow,Page page) throws Exception;
	public List getInfoKnowList(InfoKnow infoKnow,Page page) throws Exception;
	public InfoKnow getInfoKnow(InfoKnow infoKnow) throws Exception;
	public void saveInfoKnow(InfoKnow infoKnow,User user) throws Exception;
	public List getAllKnowInfo(InfoKnow infoKnow) throws Exception;
	public void deleteKnow(InfoKnow infoKnow) throws Exception;
	public InfoKnow getPreKnow(InfoKnow infoKnow) throws Exception;
	public InfoKnow getNextKnow(InfoKnow infoKnow) throws Exception;
	public void updateKnowClick(InfoKnow infoKnow) throws Exception;
	public void updateKnowPingjia(InfoKnow infoKnow) throws Exception;
	public List getBangList(InfoKnow infoKnow) throws Exception;
	public List getBestKnowList(InfoKnow infoKnow) throws Exception;
	public List getFavoriteKnowList(InfoFavorite infoFavorite,Page page) throws Exception;
	public Integer getKnowCount(InfoKnow infoKnow) throws Exception;
	public void insertInfoKnow(InfoKnow infoKnow,User user) throws Exception;
	
	public InfoRecord getInfoRecord(InfoRecord infoRecord) throws Exception;
	public void saveInfoRecord(InfoRecord infoRecord,User user) throws Exception;
	public void updateInfoRecordForLeave(InfoRecord infoRecord) throws Exception;
	public InfoRecord getInfoRecordById(InfoRecord infoRecord) throws Exception;
	public List getRecordList(InfoRecord infoRecord,Page page) throws Exception;
	
	public void saveSearch(InfoSearch infoSearch,User user) throws Exception;
	public InfoSearch getSearchByObject(InfoSearch infoSearch) throws Exception;
	public InfoSearch getSearch(InfoSearch infoSearch) throws Exception;
	public List getMostSearchList(InfoSearch infoSearch) throws Exception;
	public List getSearchList(InfoSearch infoSearch,Page page) throws Exception;
	
	public InfoFavorite getFavoriteByObject(InfoFavorite infoFavorite) throws Exception;
	public void saveFavorite(InfoFavorite infoFavorite,User user) throws Exception;
	public List getFavoriteForIndex(InfoFavorite infoFavorite) throws Exception;
	public void deleteFavorite(InfoFavorite infoFavorite) throws Exception;
	
	public List getAskList(InfoAsk infoAsk,Page page) throws Exception;
	public List getDirInfoAskList(InfoAsk infoAsk,Page page) throws Exception;
	public void saveAsk(InfoAsk infoAsk,User user) throws Exception;
	public InfoAsk getInfoAsk(InfoAsk infoAsk) throws Exception;
	public void updateAskForView(InfoAsk infoAsk) throws Exception;
	public List getNewsAskList(InfoAsk infoAsk) throws Exception;
	public void deleteAsk(InfoAsk infoAsk) throws Exception;
	
	public List getNoteList(InfoNote infoNote,Page page) throws Exception;
	public List getNoteForIndex(InfoNote infoNote) throws Exception;
	public InfoNote getNoteByObject(InfoNote infoNote) throws Exception;
	public void saveNote(InfoNote infoNote,User user) throws Exception;
	public void deleteNote(InfoNote infoNote) throws Exception;
	
	public void saveSearchClick(InfoSearchClick infoSearchClick,User user) throws Exception;
}
