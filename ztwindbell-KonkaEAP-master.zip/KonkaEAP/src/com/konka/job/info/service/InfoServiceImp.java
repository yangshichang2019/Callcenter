package com.konka.job.info.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.solr.SearchTool;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.info.dao.InfoAskDAO;
import com.konka.job.info.dao.InfoDirectoryDAO;
import com.konka.job.info.dao.InfoFavoriteDAO;
import com.konka.job.info.dao.InfoKnowDAO;
import com.konka.job.info.dao.InfoNoteDAO;
import com.konka.job.info.dao.InfoRecordDAO;
import com.konka.job.info.dao.InfoSearchClickDAO;
import com.konka.job.info.dao.InfoSearchDAO;
import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoFavorite;
import com.konka.job.info.model.InfoKnow;
import com.konka.job.info.model.InfoNote;
import com.konka.job.info.model.InfoRecord;
import com.konka.job.info.model.InfoSearch;
import com.konka.job.info.model.InfoSearchClick;
import com.konka.useradmin.model.User;

@Service("infoService")
@Transactional  
public class InfoServiceImp implements InfoService {
	@Autowired
	private InfoDirectoryDAO infoDirectoryDAO;
	@Autowired
	private InfoKnowDAO infoKnowDAO;
	@Autowired
	private InfoRecordDAO infoRecordDAO;
	@Autowired
	private InfoSearchDAO infoSearchDAO; 
	@Autowired
	private InfoFavoriteDAO infoFavoriteDAO;
	@Autowired
	private InfoNoteDAO infoNoteDAO;
	@Autowired
	private InfoAskDAO infoAskDAO;
	@Autowired
	private InfoSearchClickDAO infoSearchClickDAO;
	public List getDirectoryList(InfoDirectory infoDirectory) throws Exception{
		return infoDirectoryDAO.getAllList(infoDirectory);
	}
	public InfoDirectory getInfoDir(InfoDirectory infoDirectory) throws Exception{
		return (InfoDirectory)infoDirectoryDAO.getById(infoDirectory.getId());
	}
	public void saveInfoDir(InfoDirectory infoDirectory,User user) throws Exception{
		if(infoDirectory.getId()!=null&&infoDirectory.getId()>0) {
			Util.setUpdateToVO(infoDirectory, user);
			infoDirectoryDAO.update(infoDirectory);
		}else {
			InfoDirectory vo = (InfoDirectory)infoDirectoryDAO.getNewObject(infoDirectory);
			if(infoDirectory.getParent_id()==0) {
				if(vo==null) {
					infoDirectory.setNum("001");
				}else {
					infoDirectory.setNum(Util.getNextNum(vo.getNum(), 3));
				}
			}else {
				if(vo==null) {
					InfoDirectory tempVO = new InfoDirectory();
					tempVO.setId(infoDirectory.getParent_id());
					tempVO = getInfoDir(tempVO);
					infoDirectory.setNum(tempVO.getNum() + "001");
				}else {
					infoDirectory.setNum(Util.getNextNum(vo.getNum(), vo.getNum().length()));
				}
			}
			Util.setCreateToVO(infoDirectory, user);
			infoDirectoryDAO.insert(infoDirectory);
		}
	}
	public void deleteInfoDir(InfoDirectory infoDirectory) throws Exception{
		infoDirectoryDAO.delete(infoDirectory.getId());
	}
	public List getDirKnowInfoList(InfoKnow infoKnow,Page page) throws Exception{
		return infoKnowDAO.getDirKnowInfoList(infoKnow, page);
	}
	public List getInfoKnowList(InfoKnow infoKnow,Page page) throws Exception{
		return infoKnowDAO.getObjectList(infoKnow, page);
	}
	public InfoKnow getInfoKnow(InfoKnow infoKnow) throws Exception{
		return (InfoKnow)infoKnowDAO.getById(infoKnow.getId());
	}
	public void saveInfoKnow(InfoKnow infoKnow,User user) throws Exception{
		if(infoKnow.getId()!=null&&infoKnow.getId()>0) {
			Util.setUpdateToVO(infoKnow, user);
			infoKnowDAO.update(infoKnow);
			isIndex(infoKnow,"update");
		}else {
			Util.setCreateToVO(infoKnow, user);
			infoKnowDAO.insert(infoKnow);
			isIndex(infoKnow,"insert");
		}
		
	}
	//ֻ���������������
	public void insertInfoKnow(InfoKnow infoKnow,User user) throws Exception{
		Util.setCreateToVO(infoKnow, user);
		infoKnowDAO.insert(infoKnow);
	}
	public List getAllKnowInfo(InfoKnow infoKnow) throws Exception{
		return infoKnowDAO.getAllList(infoKnow);
	}
	public void deleteKnow(InfoKnow infoKnow) throws Exception{
		infoKnowDAO.delete(infoKnow.getId());
		SearchTool.deleteKnowInfo(infoKnow);
	}
	public InfoKnow getPreKnow(InfoKnow infoKnow) throws Exception{
		return infoKnowDAO.getPreKnow(infoKnow);
	}
	public InfoKnow getNextKnow(InfoKnow infoKnow) throws Exception{
		return infoKnowDAO.getNextKnow(infoKnow);
	}
	public void updateKnowClick(InfoKnow infoKnow) throws Exception{
		infoKnowDAO.updateKnowClick(infoKnow);
	}
	public List getBangList(InfoKnow infoKnow) throws Exception{
		return infoKnowDAO.getBangList(infoKnow);
	}
	public List getBestKnowList(InfoKnow infoKnow) throws Exception{
		return infoKnowDAO.getBestKnowList(infoKnow);
	}
	
	public void updateKnowPingjia(InfoKnow infoKnow) throws Exception{
		infoKnowDAO.updateKnowPingjia(infoKnow);
	}
	public Integer getKnowCount(InfoKnow infoKnow) throws Exception{
		return infoKnowDAO.getKnowCount(infoKnow);
	}
	
	public InfoRecord getInfoRecord(InfoRecord infoRecord) throws Exception {
		return (InfoRecord)infoRecordDAO.getByObject(infoRecord);
	}
	public InfoRecord getInfoRecordById(InfoRecord infoRecord) throws Exception{
		return (InfoRecord)infoRecordDAO.getById(infoRecord.getId());
	}
	public void saveInfoRecord(InfoRecord infoRecord,User user) throws Exception{
		if(infoRecord.getId()!=null&&infoRecord.getId()>0) {
			Util.setUpdateToVO(infoRecord, user);
			infoRecordDAO.update(infoRecord);
		}else {
			Util.setCreateToVO(infoRecord, user);
			infoRecordDAO.insert(infoRecord);
		}
	}
	public void updateInfoRecordForLeave(InfoRecord infoRecord) throws Exception {
		infoRecordDAO.updateInfoRecordForLeave(infoRecord);
	}
	public List getRecordList(InfoRecord infoRecord,Page page) throws Exception{
		return infoRecordDAO.getObjectList(infoRecord, page);
	}
	
	public void isIndex(InfoKnow knowInfo,String type){
		try {
			knowInfo = getInfoKnow(knowInfo);
			InfoDirectory infoDirectory = new InfoDirectory();
			infoDirectory.setId(knowInfo.getDir_id());
			infoDirectory = getInfoDir(infoDirectory);
			if(knowInfo.getEnable_flag().equals("T")){
				if(knowInfo.getIs_review().equals("T")) {
					SearchTool.saveKnowInfo(knowInfo,infoDirectory,type);
				}else {
					SearchTool.deleteKnowInfo(knowInfo);
				}
			}else {
				SearchTool.deleteKnowInfo(knowInfo);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public List getFavoriteKnowList(InfoFavorite infoFavorite,Page page) throws Exception{
		return infoFavoriteDAO.getFavoriteKnowList(infoFavorite,page);
	}
	
	public void saveSearch(InfoSearch infoSearch,User user) throws Exception{
		if(infoSearch.getId()!=null&&infoSearch.getId()>0) {
			Util.setUpdateToVO(infoSearch, user);
			infoSearchDAO.update(infoSearch);
		}else {
			Util.setCreateToVO(infoSearch, user);
			infoSearchDAO.insert(infoSearch);
		}
	}
	public InfoSearch getSearchByObject(InfoSearch infoSearch) throws Exception{
		return (InfoSearch)infoSearchDAO.getByObject(infoSearch);
	}
	public InfoSearch getSearch(InfoSearch infoSearch) throws Exception{
		return (InfoSearch)infoSearchDAO.getById(infoSearch.getId());
	}
	public List getMostSearchList(InfoSearch infoSearch) throws Exception{
		return infoSearchDAO.getMostList(infoSearch);
	}
	public List getSearchList(InfoSearch infoSearch,Page page) throws Exception{
		return infoSearchDAO.getObjectList(infoSearch, page);
	}
	
	public InfoFavorite getFavoriteByObject(InfoFavorite infoFavorite) throws Exception{
		return (InfoFavorite)infoFavoriteDAO.getByObject(infoFavorite);
	}
	public void saveFavorite(InfoFavorite infoFavorite,User user) throws Exception{
		if(infoFavorite.getId()!=null&&infoFavorite.getId()>0) {
			Util.setUpdateToVO(infoFavorite, user);
			infoFavoriteDAO.update(infoFavorite);
		}else {
			Util.setCreateToVO(infoFavorite, user);
			infoFavoriteDAO.insert(infoFavorite);
		}
	}
	public List getFavoriteForIndex(InfoFavorite infoFavorite) throws Exception{
		return infoFavoriteDAO.getFavoriteForIndex(infoFavorite);
	}
	public void deleteFavorite(InfoFavorite infoFavorite) throws Exception{
		infoFavoriteDAO.delete(infoFavorite.getId());
	}
	
	public List getAskList(InfoAsk infoAsk,Page page) throws Exception{
		return infoAskDAO.getObjectList(infoAsk, page);
	}
	public List getDirInfoAskList(InfoAsk infoAsk,Page page) throws Exception{
		return infoAskDAO.getDirInfoAskList(infoAsk,page);
	}
	public void saveAsk(InfoAsk infoAsk,User user) throws Exception{
		if(infoAsk.getId()!=null&&infoAsk.getId()>0) {
			if(infoAsk.getAnswer_person()==null||infoAsk.getAnswer_person().equals("")) {
				infoAsk.setAnswer_person(user.getUsername());
				infoAsk.setAnswer_time(Util.getTimestamp());
			}	
			Util.setUpdateToVO(infoAsk, user);
			infoAskDAO.update(infoAsk);
			askIsIndex(infoAsk,"update");
		}else {		
			Util.setCreateToVO(infoAsk, user);
			infoAskDAO.insert(infoAsk);
			askIsIndex(infoAsk,"insert");
		}
		
	}
	public void askIsIndex(InfoAsk infoAsk,String type){
		try {
			infoAsk = getInfoAsk(infoAsk);
			InfoDirectory infoDirectory = new InfoDirectory();
			infoDirectory.setId(infoAsk.getDir_id());
			infoDirectory = getInfoDir(infoDirectory);
			if(infoAsk.getEnable_flag().equals("T")){
				SearchTool.saveInfoAsk(infoAsk,infoDirectory,type);
			}else {
				SearchTool.deleteInfoAsk(infoAsk);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public InfoAsk getInfoAsk(InfoAsk infoAsk) throws Exception{
		return (InfoAsk)infoAskDAO.getById(infoAsk.getId());
	}
	public void deleteAsk(InfoAsk infoAsk) throws Exception {
		infoAskDAO.delete(infoAsk.getId());
	}
	public void updateAskForView(InfoAsk infoAsk) throws Exception{
		infoAskDAO.updateAskForView(infoAsk);
	}
	public List getNewsAskList(InfoAsk infoAsk) throws Exception{
		return infoAskDAO.getNewsAskList(infoAsk);
	}
	
	public List getNoteList(InfoNote infoNote,Page page) throws Exception{
		return infoNoteDAO.getObjectList(infoNote, page);
	}
	public List getNoteForIndex(InfoNote infoNote) throws Exception{
		return infoNoteDAO.getNoteForIndex(infoNote);
	}
	public InfoNote getNoteByObject(InfoNote infoNote) throws Exception{
		return (InfoNote)infoNoteDAO.getByObject(infoNote);
	}
	public void saveNote(InfoNote infoNote,User user) throws Exception{
		
		if(infoNote.getId()!=null&&infoNote.getId()>0) {
			Util.setUpdateToVO(infoNote, user);
			infoNoteDAO.update(infoNote);
		}else {
			Util.setCreateToVO(infoNote, user);
			infoNoteDAO.insert(infoNote);
		}
	}
	public void deleteNote(InfoNote infoNote) throws Exception {
		infoNoteDAO.delete(infoNote.getId());
	}
	
	public void saveSearchClick(InfoSearchClick infoSearchClick,User user) throws Exception {
		if(infoSearchClick.getId()==null||infoSearchClick.getId()==0) {
			Util.setCreateToVO(infoSearchClick, user);
			infoSearchClickDAO.insert(infoSearchClick);
		}
	}
}
