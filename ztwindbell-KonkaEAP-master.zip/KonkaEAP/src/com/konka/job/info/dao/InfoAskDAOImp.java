package com.konka.job.info.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoKnow;
@Repository("infoAskDAO")
public class InfoAskDAOImp extends BaseDAOImp implements InfoAskDAO {
	public InfoAskDAOImp(){
		super.setMapper("com.konka.job.info.model.InfoAsk");
	}
	public List getDirInfoAskList(InfoAsk infoAsk,Page page) throws Exception{
		Util.setPageNum(infoAsk, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getDirInfoAskList", infoAsk);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
	public void updateAskForView(InfoAsk infoAsk) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateAskForView", infoAsk);
	}
	public List getNewsAskList(InfoAsk infoAsk) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getNewsAskList", infoAsk);
	}
}
