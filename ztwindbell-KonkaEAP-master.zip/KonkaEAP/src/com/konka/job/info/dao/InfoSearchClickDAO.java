package com.konka.job.info.dao;

import com.konka.common.base.BaseDAO;

public interface InfoSearchClickDAO extends BaseDAO {

}
