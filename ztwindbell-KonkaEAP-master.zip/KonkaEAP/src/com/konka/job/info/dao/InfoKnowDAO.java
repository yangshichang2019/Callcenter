package com.konka.job.info.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoFavorite;
import com.konka.job.info.model.InfoKnow;

public interface InfoKnowDAO extends BaseDAO {
	public List getDirKnowInfoList(InfoKnow infoKnow,Page page) throws Exception;
	public InfoKnow getPreKnow(InfoKnow infoKnow) throws Exception;
	public InfoKnow getNextKnow(InfoKnow infoKnow) throws Exception;
	public void updateKnowClick(InfoKnow infoKnow) throws Exception;
	public void updateKnowPingjia(InfoKnow infoKnow) throws Exception;
	public List getBangList(InfoKnow infoKnow) throws Exception;
	public List getBestKnowList(InfoKnow infoKnow) throws Exception;
	public Integer getKnowCount(InfoKnow infoKnow) throws Exception;
}
