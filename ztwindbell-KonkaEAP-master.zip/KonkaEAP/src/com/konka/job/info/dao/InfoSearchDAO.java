package com.konka.job.info.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.job.info.model.InfoSearch;

public interface InfoSearchDAO extends BaseDAO{
	public List getMostList(InfoSearch infoSearch) throws Exception;
}
