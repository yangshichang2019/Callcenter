package com.konka.job.info.dao;

import org.springframework.stereotype.Component;

import com.konka.common.base.BaseDAOImp;
@Component("infoSearchClickDAO")
public class InfoSearchClickDAOImp extends BaseDAOImp implements InfoSearchClickDAO {
	public InfoSearchClickDAOImp(){
		super.setMapper("infoSearchClick");
	}
	
}
