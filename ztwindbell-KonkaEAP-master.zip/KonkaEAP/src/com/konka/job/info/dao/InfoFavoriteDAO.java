package com.konka.job.info.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.info.model.InfoFavorite;

public interface InfoFavoriteDAO extends BaseDAO {
	public List getFavoriteForIndex(InfoFavorite infoFavorite) throws Exception;
	public List getFavoriteKnowList(InfoFavorite infoFavorite,Page page) throws Exception;
}
