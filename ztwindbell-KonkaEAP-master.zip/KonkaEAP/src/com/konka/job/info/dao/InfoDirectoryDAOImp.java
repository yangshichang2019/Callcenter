package com.konka.job.info.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("infoDirectoryDAO")
public class InfoDirectoryDAOImp extends BaseDAOImp implements InfoDirectoryDAO {
	public InfoDirectoryDAOImp() {
		super.setMapper("com.konka.job.info.model.InfoDirectory");
	}
}
