package com.konka.job.info.dao;

import com.konka.common.base.BaseDAO;
import com.konka.job.info.model.InfoRecord;

public interface InfoRecordDAO extends BaseDAO {
	public void updateInfoRecordForLeave(InfoRecord infoRecord) throws Exception;
}
