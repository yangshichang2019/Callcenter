package com.konka.job.info.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.info.model.InfoFavorite;
@Repository("infoFavoriteDAO")
public class InfoFavoriteDAOImp extends BaseDAOImp implements InfoFavoriteDAO {
	public InfoFavoriteDAOImp(){
		super.setMapper("com.konka.job.info.model.InfoFavorite");
	}
	public List getFavoriteForIndex(InfoFavorite infoFavorite) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getFavoriteForIndex",infoFavorite);
	}

	public List getFavoriteKnowList(InfoFavorite infoFavorite,Page page) throws Exception {
		Util.setPageNum(infoFavorite, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getFavoriteKnowList", infoFavorite);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
}
