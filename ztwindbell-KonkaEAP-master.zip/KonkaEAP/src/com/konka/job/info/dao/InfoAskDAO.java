package com.konka.job.info.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.info.model.InfoAsk;
import com.konka.job.info.model.InfoKnow;

public interface InfoAskDAO extends BaseDAO {
	public List getDirInfoAskList(InfoAsk infoAsk,Page page) throws Exception;
	public void updateAskForView(InfoAsk infoAsk) throws Exception;
	public List getNewsAskList(InfoAsk infoAsk) throws Exception;
}
