package com.konka.job.info.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.info.model.InfoSearch;
@Repository("infoSearchDAO")
public class InfoSearchDAOImp extends BaseDAOImp implements InfoSearchDAO {
	public InfoSearchDAOImp() {
		super.setMapper("com.konka.job.info.model.InfoSearch");
	}
	public List getMostList(InfoSearch infoSearch) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getMostList", infoSearch);
	}
}
