package com.konka.job.info.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.job.info.model.InfoNote;

public interface InfoNoteDAO extends BaseDAO {
	public List getNoteForIndex(InfoNote infoNote) throws Exception;
}
