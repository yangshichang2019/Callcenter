package com.konka.job.info.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.info.model.InfoRecord;
@Repository("infoRecordDAO")
public class InfoRecordDAOImp extends BaseDAOImp implements InfoRecordDAO {
	public InfoRecordDAOImp(){
		super.setMapper("com.konka.job.info.model.InfoRecord");
	}
	public void updateInfoRecordForLeave(InfoRecord infoRecord) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateInfoRecordForLeave", infoRecord);
	}
}
