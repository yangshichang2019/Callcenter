package com.konka.job.info.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.info.model.InfoNote;
@Repository("infoNoteDAO")
public class InfoNoteDAOImp extends BaseDAOImp implements InfoNoteDAO {
	public InfoNoteDAOImp(){
		super.setMapper("com.konka.job.info.model.InfoNote");
	}
	public List getNoteForIndex(InfoNote infoNote) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getNoteForIndex", infoNote);
	}
}
