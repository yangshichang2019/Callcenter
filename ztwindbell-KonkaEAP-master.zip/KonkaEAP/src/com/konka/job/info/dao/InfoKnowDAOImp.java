package com.konka.job.info.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.info.model.InfoDirectory;
import com.konka.job.info.model.InfoFavorite;
import com.konka.job.info.model.InfoKnow;
@Repository("infoKnowDAO")
public class InfoKnowDAOImp extends BaseDAOImp implements InfoKnowDAO {
	public InfoKnowDAOImp() {
		super.setMapper("com.konka.job.info.model.InfoKnow");
	}
	public List getDirKnowInfoList(InfoKnow infoKnow,Page page) throws Exception{
		Util.setPageNum(infoKnow, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getDirKnowInfoList", infoKnow);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
	public InfoKnow getPreKnow(InfoKnow infoKnow) throws Exception{
		return (InfoKnow)super.getSqlSessionTemplate().selectOne(super.getMapper()+".getPreKnow", infoKnow);
	}
	public InfoKnow getNextKnow(InfoKnow infoKnow) throws Exception{
		return (InfoKnow)super.getSqlSessionTemplate().selectOne(super.getMapper()+".getNextKnow", infoKnow);
	}
	public void updateKnowClick(InfoKnow infoKnow) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateKnowClick", infoKnow);
	}
	public void updateKnowPingjia(InfoKnow infoKnow) throws Exception{
		super.getSqlSessionTemplate().update(super.getMapper()+".updateKnowPingjia", infoKnow);
	}
	public List getBangList(InfoKnow infoKnow) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getBangList", infoKnow);
	}
	public List getBestKnowList(InfoKnow infoKnow) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getBestKnowList", infoKnow);
	}

	public Integer getKnowCount(InfoKnow infoKnow) throws Exception{
		return super.getSqlSessionTemplate().selectOne(super.getMapper()+".getKnowCount", infoKnow);
	}
}
