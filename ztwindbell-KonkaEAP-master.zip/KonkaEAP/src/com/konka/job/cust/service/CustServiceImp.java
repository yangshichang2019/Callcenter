package com.konka.job.cust.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.job.cust.dao.CustInfoDAO;
import com.konka.job.cust.dao.FixInfoDAO;
import com.konka.job.cust.model.CustInfo;
import com.konka.job.cust.model.FixInfo;

@Service("custService")
@Transactional  
public class CustServiceImp implements CustService {
	@Autowired
	private CustInfoDAO custInfoDAO;
	@Autowired
	private FixInfoDAO fixInfoDAO;
	public CustInfo getCusterInfo(String num) throws Exception {
		return custInfoDAO.getCusterInfo(num);
	}
	public FixInfo getFixInfo(FixInfo fixInfo) throws Exception{
		return (FixInfo)fixInfoDAO.getByObject(fixInfo);
	}
}
