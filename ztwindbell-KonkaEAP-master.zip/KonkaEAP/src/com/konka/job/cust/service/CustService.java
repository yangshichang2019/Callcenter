package com.konka.job.cust.service;

import com.konka.job.cust.model.CustInfo;
import com.konka.job.cust.model.FixInfo;

public interface CustService {
	public CustInfo getCusterInfo(String num) throws Exception;
	
	public FixInfo getFixInfo(FixInfo fixInfo) throws Exception;
}
