package com.konka.job.cust.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("fixInfoDAO")
public class FixInfoDAOImp extends BaseDAOImp implements FixInfoDAO {
	public FixInfoDAOImp() {
		super.setMapper("com.konka.job.cust.model.FixInfo");
	}
}
