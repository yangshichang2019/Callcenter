package com.konka.job.cust.dao;

import com.konka.common.base.BaseDAO;
import com.konka.job.cust.model.CustInfo;

public interface CustInfoDAO extends BaseDAO {
	public CustInfo getCusterInfo(String num) throws Exception;
}
