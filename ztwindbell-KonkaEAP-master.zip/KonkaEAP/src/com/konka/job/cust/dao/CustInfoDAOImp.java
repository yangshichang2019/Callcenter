package com.konka.job.cust.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.cust.model.CustInfo;
@Repository("custInfoDAO")
public class CustInfoDAOImp extends BaseDAOImp implements CustInfoDAO {
	public CustInfoDAOImp() {
		super.setMapper("com.konka.job.cust.model.CustInfo");
	}
	public CustInfo getCusterInfo(String num) throws Exception {
		return (CustInfo)super.getSqlSessionTemplate().selectOne(super.getMapper()+".getCusterInfo", num);
	}
}
