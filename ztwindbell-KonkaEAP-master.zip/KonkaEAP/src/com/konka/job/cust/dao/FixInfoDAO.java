package com.konka.job.cust.dao;

import com.konka.common.base.BaseDAO;

public interface FixInfoDAO extends BaseDAO {

}
