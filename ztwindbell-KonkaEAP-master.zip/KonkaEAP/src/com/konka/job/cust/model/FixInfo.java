package com.konka.job.cust.model;

import com.konka.common.base.BaseVO;

public class FixInfo extends BaseVO {
	private Integer id;
	private String fix_num;
	private String product_series;
	private String product_num;
	private String buy_date;
	private String company;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFix_num() {
		return fix_num;
	}
	public void setFix_num(String fix_num) {
		this.fix_num = fix_num;
	}
	public String getProduct_series() {
		return product_series;
	}
	public void setProduct_series(String product_series) {
		this.product_series = product_series;
	}
	public String getProduct_num() {
		return product_num;
	}
	public void setProduct_num(String product_num) {
		this.product_num = product_num;
	}
	public String getBuy_date() {
		return buy_date;
	}
	public void setBuy_date(String buy_date) {
		this.buy_date = buy_date;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
}
