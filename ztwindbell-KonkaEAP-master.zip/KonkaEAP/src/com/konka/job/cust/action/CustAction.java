package com.konka.job.cust.action;

import java.io.PrintWriter;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.tool.Util;
import com.konka.job.cust.model.CustInfo;
import com.konka.job.cust.model.FixInfo;
import com.konka.job.cust.service.CustService;
@Controller
@Scope("prototype")
public class CustAction extends BaseAction {
	@Autowired
	private CustService custService;
	private CustInfo custInfo = new CustInfo();
	private FixInfo fixInfo = new FixInfo();
	public String getCustomer() throws Exception {
		String cellNumber = "";
		if(custInfo.getMobile_phone()==null||custInfo.getMobile_phone().equals("")) {
			cellNumber = Util.getCookiesByName(super.getRequest(), "openeap.Caller");
		} else {
			cellNumber = custInfo.getMobile_phone();
			
		}
		 super.getResponse().setContentType("text/xml;charset=utf-8");
		 super.getResponse().setCharacterEncoding("UTF-8");
		 if(cellNumber=="" || cellNumber.length() == 0) {   
			 PrintWriter out=super.getResponse().getWriter();
			 JSONObject obj=new JSONObject();
			 obj.put("retFlag", "F");
			 obj.put("retMsg", "无法找到主叫号码");
			 out.println(obj.toString());
			 out.close();
			 return null;
		 }
		 //如果电话号码长度大于0
		 if (cellNumber.length() > 0 ) {
			 //根据客户来电查询客户信息资料
			 custInfo = custService.getCusterInfo(cellNumber);
			 
			 //当找不能精确找到客户信息时
			 if(custInfo==null) {
				 PrintWriter out= super.getResponse().getWriter();
				 JSONObject obj=new JSONObject();
				 obj.put("retFlag", "K");
				 obj.put("phone", cellNumber);//用户来电
				 obj.put("retMsg", "无法找到客户资料");
				 out.println(obj.toString());
				 out.close();
			 } else {
				 PrintWriter out= super.getResponse().getWriter();
				 JSONObject obj=new JSONObject();
				 obj.put("retFlag", "T");
				 obj.put("custId",custInfo.getCustId());
				 obj.put("name",custInfo.getName());
				 obj.put("cellphone",custInfo.getContact_tel());
				 obj.put("phone", cellNumber);//用户来电
				 obj.put("address", custInfo.getAddress());
				 out.println(obj.toString());
				 out.close();
			 }

		 }
		return null;
	}
	public String getFix() throws Exception {
		Util.echo(fixInfo.getFix_num());
		fixInfo = custService.getFixInfo(fixInfo);
		super.getResponse().setContentType("text/xml;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		if(fixInfo==null) {
			 PrintWriter out= super.getResponse().getWriter();
			 JSONObject obj=new JSONObject();
			 obj.put("retFlag", "F");
			 obj.put("retMsg", "无法找到此工单");
			 out.println(obj.toString());
			 out.close();
		}else {
			 PrintWriter out= super.getResponse().getWriter();
			 JSONObject obj=new JSONObject();
			 obj.put("retFlag", "T");
			 obj.put("id", fixInfo.getId());
			 obj.put("fix_num", fixInfo.getFix_num());
			 obj.put("product_series", fixInfo.getProduct_series());
			 obj.put("product_num", fixInfo.getProduct_num());
			 obj.put("buy_date", fixInfo.getBuy_date());
			 obj.put("company", fixInfo.getCompany());
			 out.println(obj.toString());
			 out.close();
		}
		return null;
	}
	public CustInfo getCustInfo() {
		return custInfo;
	}
	public void setCustInfo(CustInfo custInfo) {
		this.custInfo = custInfo;
	}
	public void setFixInfo(FixInfo fixInfo) {
		this.fixInfo = fixInfo;
	}
}
