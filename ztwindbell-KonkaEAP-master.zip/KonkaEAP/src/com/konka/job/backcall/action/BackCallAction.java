package com.konka.job.backcall.action;

import com.konka.common.base.BaseAction;

public class BackCallAction extends BaseAction {
	
}
