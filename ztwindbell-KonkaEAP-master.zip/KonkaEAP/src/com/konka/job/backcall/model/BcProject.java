package com.konka.job.backcall.model;

import com.konka.common.base.BaseVO;

public class BcProject extends BaseVO {
	private Integer id;
	private String bill_type;
	private String bill_start_time;
	private String bill_end_time;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBill_type() {
		return bill_type;
	}
	public void setBill_type(String bill_type) {
		this.bill_type = bill_type;
	}
	public String getBill_start_time() {
		return bill_start_time;
	}
	public void setBill_start_time(String bill_start_time) {
		this.bill_start_time = bill_start_time;
	}
	public String getBill_end_time() {
		return bill_end_time;
	}
	public void setBill_end_time(String bill_end_time) {
		this.bill_end_time = bill_end_time;
	}
}
