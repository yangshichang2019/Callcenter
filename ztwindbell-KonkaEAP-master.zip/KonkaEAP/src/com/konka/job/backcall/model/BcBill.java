package com.konka.job.backcall.model;

import com.konka.common.base.BaseVO;

public class BcBill extends BaseVO {
	private Integer id;
	private Integer bill_id;
	private String contact_call;
	private Integer is_called;
	private Integer is_re_call;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getBill_id() {
		return bill_id;
	}
	public void setBill_id(Integer bill_id) {
		this.bill_id = bill_id;
	}
	public Integer getIs_called() {
		return is_called;
	}
	public void setIs_called(Integer is_called) {
		this.is_called = is_called;
	}
	public Integer getIs_re_call() {
		return is_re_call;
	}
	public void setIs_re_call(Integer is_re_call) {
		this.is_re_call = is_re_call;
	}
	public String getContact_call() {
		return contact_call;
	}
	public void setContact_call(String contact_call) {
		this.contact_call = contact_call;
	}
}
