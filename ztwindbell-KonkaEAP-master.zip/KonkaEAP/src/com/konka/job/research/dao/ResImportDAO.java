package com.konka.job.research.dao;


import java.util.List;
import java.util.Map;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResImport;
import com.konka.job.research.model.ResPaper;

public interface ResImportDAO extends BaseDAO{
	
	public void insertBatchCustomer(Map map)throws Exception;
	
	public void insertBatchCustomer1(List list)throws Exception;
	
	public List getImportList(ResImport resImport,Page page)throws Exception;
	
	public List getImportList2(ResImport resImport,Page page)throws Exception;
	
}
