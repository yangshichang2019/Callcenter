package com.konka.job.research.dao;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.commons.lang.math.IntRange;
import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResPaper;
import com.konka.job.research.model.ResQuestion;
import com.konka.job.research.model.ResTask;


@Repository("ResTaskDAO")
public class ResTaskDAOImp extends BaseDAOImp implements ResTaskDAO {
	public ResTaskDAOImp() {
		super.setMapper("com.konka.job.research.model.ResTask");
	}

	@Override
	public Integer getTaskAmountByProject(ResTask resTask) throws Exception{
		resTask.setValues2(resTask.getValues()+"_TASK");
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getTaskAmountByProject", resTask);	
	}

	@Override
	public Integer togetSendTaskNum(ResTask resTask) throws Exception{
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getSendTaskNum", resTask);	
	}

	@Override
	public List togetSendTaskCustomerId(ResTask resTask) throws Exception{
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getSendListCustomerId", resTask);
	}

	@Override
	public void deleteTask(ResTask resTask)throws Exception {
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deleteTask", resTask);
		
	}

	@Override
	public List getMyTaskList(ResTask resTask, Page page)throws Exception {
		Util.setPageNum(resTask, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getMyTaskList", resTask);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	@Override
	public void insertBatchMap(Map map) throws Exception{
		List list = (List) map.get("list");
		if(list.size()>300) {
			List tempList = new ArrayList();
			Map tempMap = new HashMap();
			for(int i=0;i<list.size();i++) {
				tempList.add(list.get(i));
				Integer j = (i+1)%300;
				if(j==0) {
					tempMap.put("table1", map.get("table1").toString());
					tempMap.put("list", tempList);
					this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchmap", tempMap);
					tempList = new ArrayList();
					tempMap = new HashMap();
				}
			}
			if(tempList.size()>0) {
				tempMap.put("table1", map.get("table1").toString());
				tempMap.put("list", tempList);
				this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchmap", tempMap);
			}
		} else {
			this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchmap", map);
		}
		
	}

	@Override
	public List togetProUser(ResTask resTask) throws Exception{
		
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getProUser", resTask);
	}

	@Override
	public void insertBatchUser(List list) throws Exception{
		this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchlist", list);
		
	}

	@Override
	public Integer isExistTask(ResTask resTask) {
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".isExistTask", resTask);	
	}

	@Override
	public void deleteProUser(ResTask resTask) throws Exception {
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deleteProUser", resTask);
		
	}

	@Override
	public List getAllTaskList(ResTask resTask, Page page) throws Exception {
		Util.setPageNum(resTask, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getAllTaskList", resTask);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	@Override
	public void updateTaskgroup(ResTask resTask) throws Exception {
		this.getSqlSessionTemplate().update(this.getMapper() + ".update1", resTask);
	}

	@Override
	public Integer getTaskid(ResTask resTask) throws Exception {
		System.out.println("111");
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getTaskid", resTask);	
		list.remove(resTask.getId());
		if(list.size()==0){
			return null;
		}else{
			Random random = new Random();
			return (Integer) list.get(random.nextInt(list.size())) ;	
		}
	}


	@Override
	public ResTask getTaskbyid(ResTask resTask) throws Exception {
		// TODO Auto-generated method stub
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getById", resTask);	
	}

	@Override
	public void pauseTask(ResTask resTask) throws Exception {
		this.getSqlSessionTemplate().update(this.getMapper() + ".pauseTask", resTask);
		
	}

	@Override
	public void recoverTask(ResTask resTask) throws Exception {
		this.getSqlSessionTemplate().update(this.getMapper() + ".recoverTask", resTask);
	}

	@Override
	public List getRecoverUser(ResTask resTask) throws Exception {
		try {
			return 	this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecoverUser", resTask);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer ifExitsUser(ResTask resTask) throws Exception {
		
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".ifExitsUser", resTask);
	}

	@Override
	public void InsertProUser(ResTask resTask) throws Exception {
		this.getSqlSessionTemplate().insert(this.getMapper() + ".insertProUser", resTask);
	}



	
	
	
}
