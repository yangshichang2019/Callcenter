package com.konka.job.research.dao;



import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResPaper;
import com.konka.job.research.model.ResProject;

public interface ResFieldDAO extends BaseDAO{
	
	public List<ResField> getProFieldList(ResProject resProject) throws Exception;
	
	public void deleteField(ResField resField) throws Exception;

	public List getProFieldList2(ResProject resProject);
}
