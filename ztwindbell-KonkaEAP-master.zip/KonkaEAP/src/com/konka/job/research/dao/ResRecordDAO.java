package com.konka.job.research.dao;





import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResProject;
import com.konka.job.research.model.ResRecord;

public interface ResRecordDAO extends BaseDAO{
	
	
	public List getRecordList(ResRecord resRecord,Page page)throws Exception;
	
}
