package com.konka.job.research.dao;





import java.util.List;
import java.util.Map;

import com.konka.common.base.BaseDAO;
import com.konka.job.research.model.ResCustomer;
import com.konka.job.research.model.ResSendrecord;
import com.konka.job.research.model.ResTask;

public interface ResCustomerDAO extends BaseDAO{
	
	public ResCustomer  getCustomerByid(Map map) throws Exception;
	
	public List  getCustomerByid2(Map map) throws Exception;
	public List togetSendTaskCustomerId(ResSendrecord resSendrecord) throws Exception;

}
