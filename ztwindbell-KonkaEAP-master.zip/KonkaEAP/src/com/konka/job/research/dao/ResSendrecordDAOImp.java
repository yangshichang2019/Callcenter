package com.konka.job.research.dao;



import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResProject;
import com.konka.job.research.model.ResSendrecord;


@Repository("ResSendrecordDAO")
public class ResSendrecordDAOImp extends BaseDAOImp implements ResSendrecordDAO {
	public ResSendrecordDAOImp() {
		super.setMapper("com.konka.job.research.model.ResSendrecord");
	}

	public List getSendCustomerRecord(ResSendrecord resSendrecord,Page page) throws Exception{
	
		Util.setPageNum(resSendrecord, page);
		List<ResProject> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getSendcustomerrecord", resSendrecord);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	public void deleteSendRecord(ResSendrecord resSendrecord) throws Exception{
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deleteSendrecord", resSendrecord);
	}

	@Override
	public void toPauseSendRecord(Integer id) {
		super.getSqlSessionTemplate().update(this.getMapper() + ".updateSendrecord", id);
	}

	@Override
	public void toRecoverSendRecord(Integer id) {
		super.getSqlSessionTemplate().update(this.getMapper() + ".updateSendrecord2", id);
	}
	
	
	
}
