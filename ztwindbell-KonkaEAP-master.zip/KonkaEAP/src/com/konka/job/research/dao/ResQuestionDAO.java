package com.konka.job.research.dao;



import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResPaper;
import com.konka.job.research.model.ResProject;
import com.konka.job.research.model.ResQuestion;

public interface ResQuestionDAO extends BaseDAO{
	
	public List<ResQuestion> getPaperQuestionList(ResQuestion resQuestion)throws Exception;
	
	public void deletePaper(ResQuestion resQuestion)throws Exception;
	
	public List<ResQuestion> getPaperquestionByid(Integer id)throws Exception;
}
