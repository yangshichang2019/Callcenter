package com.konka.job.research.dao;




import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResPaper;

public interface ResPaperDAO extends BaseDAO{
	
	public List<ResPaper> getPaperList(ResPaper resPaper,Page page)throws Exception;

	public void deletePaper(ResPaper resPaper)throws Exception;
	
}
