package com.konka.job.research.dao;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.research.model.ResQuestion;


@Repository("ResQuestionDAO")
public class ResQuestionDAOImp extends BaseDAOImp implements ResQuestionDAO {
	public ResQuestionDAOImp() {
		super.setMapper("com.konka.job.research.model.ResQuestion");
	}

	public List<ResQuestion> getPaperQuestionList(ResQuestion resQuestion) throws Exception{
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getPaperQuestionList", resQuestion.getPaper_id());	
	}

	public void deletePaper(ResQuestion resQuestion)throws Exception {
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deleteQuestion", resQuestion);
	}

	public List<ResQuestion> getPaperquestionByid(Integer id) throws Exception{
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getPaperquestionByid", id);	
	}




}
