package com.konka.job.research.dao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;


@Repository("ResResultDAO")
public class ResResultDAOImp extends BaseDAOImp implements ResResultDAO {
	public ResResultDAOImp() {
		super.setMapper("com.konka.job.research.model.ResResult");
	}

	@Override
	public void insertBatchMap(Map map) throws Exception {
		List list = (List) map.get("list");
		if(list.size()>300) {
			List tempList = new ArrayList();
			Map tempMap = new HashMap();
			for(int i=0;i<list.size();i++) {
				tempList.add(list.get(i));
				Integer j = (i+1)%300;
				if(j==0) {
					tempMap.put("table", map.get("table").toString());
					tempMap.put("list", tempList);
					insertBatchMap(tempMap);
					tempList = new ArrayList();
					tempMap = new HashMap();
				}
			}
			if(tempList.size()>0) {
				tempMap.put("sql", map.get("table").toString());
				tempMap.put("list", tempList);
				insertBatchMap(tempMap);
			}
		} else {
			this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchmap", map);
		}
		
	}

	
}
