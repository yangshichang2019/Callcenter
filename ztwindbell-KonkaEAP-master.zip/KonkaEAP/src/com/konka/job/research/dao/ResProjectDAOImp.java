package com.konka.job.research.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.affairs.survey.model.Survey;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResProject;


@Repository("ResProjectDAO")
public class ResProjectDAOImp extends BaseDAOImp implements ResProjectDAO {
	public ResProjectDAOImp() {
		super.setMapper("com.konka.job.research.model.ResProject");
	}

	public List<ResProject> getProList(ResProject resProject, Page page)throws Exception {
		Util.setPageNum(resProject, page);
		List<ResProject> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getProList", resProject);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	public void deleteProject(ResProject resProject) throws Exception{
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deleteProject", resProject);
	}

	public void updateStaff(ResProject resProject)throws Exception {
		super.getSqlSessionTemplate().update(this.getMapper() + ".updateStaff", resProject);
	}

	public List<ResProject> getMyProList(ResProject resProject, Page page) throws Exception{
		Util.setPageNum(resProject, page);
		List<ResProject> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getMyProList", resProject);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}


}
