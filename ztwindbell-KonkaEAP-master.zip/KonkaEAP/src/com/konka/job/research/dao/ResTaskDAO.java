package com.konka.job.research.dao;




import java.util.List;
import java.util.Map;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResQuestion;
import com.konka.job.research.model.ResSendrecord;
import com.konka.job.research.model.ResTask;

public interface ResTaskDAO extends BaseDAO{
	
	public Integer getTaskAmountByProject(ResTask resTask)throws Exception;
	
	public Integer togetSendTaskNum(ResTask resTask)throws Exception;
	
	public List togetSendTaskCustomerId(ResTask resTask)throws Exception;
	
	public void deleteTask(ResTask resTask)throws Exception;

	public List getMyTaskList(ResTask resTask, Page page)throws Exception;

	public void insertBatchMap(Map map)throws Exception;
	
	public List togetProUser(ResTask resTask)throws Exception;
	
	public void insertBatchUser(List list)throws Exception;
	
	public Integer isExistTask(ResTask resTask )throws Exception;
	
	public void deleteProUser(ResTask resTask)throws Exception;
	
	public List getAllTaskList(ResTask resTask, Page page)throws Exception;
	
	public void updateTaskgroup(ResTask resTask)throws Exception;
	
	public Integer getTaskid(ResTask resTask)throws Exception;
	
	public ResTask getTaskbyid(ResTask resTask)throws Exception;
	
	public void pauseTask(ResTask resTask)throws Exception;
	
	public void recoverTask(ResTask resTask)throws Exception;
	
	public List getRecoverUser(ResTask resTask)throws Exception;
	
	public Integer ifExitsUser(ResTask resTask)throws Exception;
	
	public void  InsertProUser(ResTask resTask)throws Exception;
}
