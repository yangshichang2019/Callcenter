package com.konka.job.research.dao;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResProject;
import com.konka.job.research.model.ResRecord;


@Repository("ResRecordDAO")
public class ResRecordDAOImp extends BaseDAOImp implements ResRecordDAO {
	public ResRecordDAOImp() {
		super.setMapper("com.konka.job.research.model.ResRecord");
	}

	@Override
	public List getRecordList(ResRecord resRecord, Page page)
			throws Exception {
		Util.setPageNum(resRecord, page);
		List list = new ArrayList();
		try {
			list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecordList", resRecord);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	
}
