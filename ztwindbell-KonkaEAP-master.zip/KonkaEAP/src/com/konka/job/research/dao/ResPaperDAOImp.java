package com.konka.job.research.dao;


import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResPaper;


@Repository("ResPaperDAO")
public class ResPaperDAOImp extends BaseDAOImp implements ResPaperDAO {
	public ResPaperDAOImp() {
		super.setMapper("com.konka.job.research.model.ResPaper");
	}

	public List<ResPaper> getPaperList(ResPaper resPaper, Page page)throws Exception {
		Util.setPageNum(resPaper, page);
		List<ResPaper> list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getPaperList", resPaper);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	public void deletePaper(ResPaper resPaper)throws Exception {
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deletePaper", resPaper);
	}




}
