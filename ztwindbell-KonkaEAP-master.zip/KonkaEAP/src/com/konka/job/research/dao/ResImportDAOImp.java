package com.konka.job.research.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResImport;
import com.konka.job.research.model.ResPaper;


@Repository("ResImportDAO")
public class ResImportDAOImp extends BaseDAOImp implements ResImportDAO {
	public ResImportDAOImp() {
		super.setMapper("com.konka.job.research.model.ResImport");
	}
/*
	public void insertBatchCustomer(Map map){
			this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchCustomer", map);
	}*/
	
	public void insertBatchCustomer(Map map)throws Exception{
		List list = (List) map.get("list");
		if(list.size()>300) {
			List tempList = new ArrayList();
			Map tempMap = new HashMap();
			for(int i=0;i<list.size();i++) {
				tempList.add(list.get(i));
				Integer j = (i+1)%300;
				if(j==0) {
					tempMap.put("sql", map.get("sql").toString());
					tempMap.put("list", tempList);
					insertBatchCustomer(tempMap);
					tempList = new ArrayList();
					tempMap = new HashMap();
				}
			}
			if(tempList.size()>0) {
				tempMap.put("sql", map.get("sql"));
				tempMap.put("list", tempList);
				insertBatchCustomer(tempMap);
			}
		} else {
			this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchCustomer", map);
		}
	}
	
	
	public void insertBatchCustomer1(List list)throws Exception{
		if(list.size()>300) {
			List tempList = new ArrayList();
			for(int i=0;i<list.size();i++) {
				tempList.add(list.get(i));
				Integer j = (i+1)%300;
				if(j==0) {
					insertBatchCustomer1(tempList);
					tempList = new ArrayList();
				}
			}
			if(tempList.size()>0) {
				insertBatchCustomer1(tempList);
			}
		} else {
			this.getSqlSessionTemplate().insert(this.getMapper() + ".insertBatchCustomer", list);
		}
	}

	@Override
	public List getImportList(ResImport resImport, Page page)
			throws Exception {
		Util.setPageNum(resImport, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getImportList", resImport);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
	
	
	@Override
	public List getImportList2(ResImport resImport, Page page)
			throws Exception {
		Util.setPageNum(resImport, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getImportList2", resImport);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}



}
