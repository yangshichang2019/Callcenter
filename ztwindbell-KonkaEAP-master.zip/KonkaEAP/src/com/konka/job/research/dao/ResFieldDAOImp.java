package com.konka.job.research.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResProject;


@Repository("ResFieldDAO")
public class ResFieldDAOImp extends BaseDAOImp implements ResFieldDAO {
	public ResFieldDAOImp() {
		super.setMapper("com.konka.job.research.model.ResField");
	}


	public List<ResField> getProFieldList(ResProject resProject)throws Exception {
		
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getProFieldList", resProject.getId());	
	
	}


	public void deleteField(ResField resField) throws Exception{
		super.getSqlSessionTemplate().delete(this.getMapper() + ".deleteField", resField);
	}

	
	public List<ResField> getProFieldList2(ResProject resProject) {
		
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getProFieldList2", resProject.getId());	
	
	}

	
}
