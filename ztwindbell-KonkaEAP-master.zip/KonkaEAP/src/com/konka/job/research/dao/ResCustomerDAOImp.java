package com.konka.job.research.dao;



import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.research.model.ResCustomer;
import com.konka.job.research.model.ResSendrecord;
import com.konka.job.research.model.ResTask;


@Repository("ResCustomerDAO")
public class ResCustomerDAOImp extends BaseDAOImp implements ResCustomerDAO {
	public ResCustomerDAOImp() {
		super.setMapper("com.konka.job.research.model.ResCustomer");
	}

	public ResCustomer getCustomerByid(Map map) throws Exception{
			return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getCustomerByid", map);	
	}

	@Override
	public List getCustomerByid2(Map map) throws Exception {
		
		try {
			return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getCustomerByid2", map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;	
	}

	public List togetSendTaskCustomerId(ResSendrecord resSendrecord) throws Exception{
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getSendListCustomerId", resSendrecord);
	}
	
}
