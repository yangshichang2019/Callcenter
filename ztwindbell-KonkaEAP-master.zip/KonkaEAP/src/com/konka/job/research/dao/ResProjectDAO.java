package com.konka.job.research.dao;



import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResPaper;
import com.konka.job.research.model.ResProject;

public interface ResProjectDAO extends BaseDAO{
	
	public List<ResProject> getProList(ResProject resProject,Page page)throws Exception;
	
	public void deleteProject(ResProject resProject)throws Exception;
	
	public void updateStaff(ResProject resProject) throws Exception;
	
	public List<ResProject> getMyProList(ResProject resProject,Page page)throws Exception;
}
