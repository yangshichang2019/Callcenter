package com.konka.job.research.dao;





import java.util.Map;

import com.konka.common.base.BaseDAO;

public interface ResResultDAO extends BaseDAO{
	
	public void insertBatchMap(Map map)throws Exception;
	
}
