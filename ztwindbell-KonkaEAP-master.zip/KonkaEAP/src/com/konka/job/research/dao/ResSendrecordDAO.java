package com.konka.job.research.dao;





import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.research.model.ResSendrecord;

public interface ResSendrecordDAO extends BaseDAO{
	
	public List getSendCustomerRecord (ResSendrecord resSendrecord, Page page)throws Exception;
	
	public void deleteSendRecord(ResSendrecord resSendrecord)throws Exception;
	
	public void toPauseSendRecord(Integer id);
	
	public void toRecoverSendRecord(Integer id);
}
