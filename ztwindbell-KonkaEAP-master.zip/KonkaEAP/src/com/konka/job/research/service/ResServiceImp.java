package com.konka.job.research.service;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.dao.ResCustomerDAO;
import com.konka.job.research.dao.ResFieldDAO;
import com.konka.job.research.dao.ResImportDAO;
import com.konka.job.research.dao.ResPaperDAO;
import com.konka.job.research.dao.ResProjectDAO;
import com.konka.job.research.dao.ResQuestionDAO;
import com.konka.job.research.dao.ResRecordDAO;
import com.konka.job.research.dao.ResResultDAO;
import com.konka.job.research.dao.ResSendrecordDAO;
import com.konka.job.research.dao.ResTaskDAO;
import com.konka.job.research.model.ResCustomer;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResImport;
import com.konka.job.research.model.ResPaper;
import com.konka.job.research.model.ResProject;
import com.konka.job.research.model.ResQuestion;
import com.konka.job.research.model.ResRecord;
import com.konka.job.research.model.ResResult;
import com.konka.job.research.model.ResSendrecord;
import com.konka.job.research.model.ResTask;
import com.konka.useradmin.model.User;

/**
 * @author wangchen
 *
 */

@Service("ResService")
@Transactional
public class ResServiceImp implements ResService {
	@Autowired
	private ResImportDAO resImportDAO;
	@Autowired
	private ResProjectDAO resProjectDAO;
	@Autowired
	private ResFieldDAO resFiledDAO;
	@Autowired
	private ResPaperDAO resPaperDAO;
	@Autowired
	private ResQuestionDAO resQuestionDAO;
	@Autowired
	private ResTaskDAO resTaskDAO;
	@Autowired
	private ResSendrecordDAO resSendrecordDAO;
	@Autowired
	private ResCustomerDAO resCustomerDAO;
	@Autowired
	private ResRecordDAO resRecordDAO;
	@Autowired
	private ResResultDAO resResultDAO;
	

	
	
	
	@Override
	public void insertResImport(ResImport resImport,User user)throws Exception {
		
			Util.setCreateToVO(resImport, user);
			resImportDAO.insert(resImport);
	}


	@Override
	public void savePro(ResProject resProject,User user)throws Exception{
		if(resProject.getId()!=null&&resProject.getId()>0) {
			Util.setUpdateToVO(resProject, user);
			resProjectDAO.update(resProject);
		}else {
			Util.setCreateToVO(resProject, user);
			resProjectDAO.insert(resProject);
		}
	}
	
	@Override
	public List<ResProject> getProList(ResProject resProject, Page page) {
		try {
			return resProjectDAO.getProList(resProject, page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<ResField> getProFieldList(ResProject resProject)throws Exception {
		try {
			return resFiledDAO.getProFieldList(resProject);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	

	@Override
	public ResProject getProById(Integer id) throws Exception{
		try {
			return (ResProject) resProjectDAO.getById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ResField getFieldByid(ResField resField){
		try {
			return (ResField) resFiledDAO.getById(resField.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean insertField(ResField resField)throws Exception {
		try {
			if (resFiledDAO.insert(resField) == 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return true;
		}
	}

	@Override
	public boolean updateField(ResField resField)throws Exception {
		try {
			resFiledDAO.update(resField);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean insertPaper(ResPaper resPaper) throws Exception{
		try {
			if (resPaperDAO.insert(resPaper) == 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return true;
		}
	}

	@Override
	public boolean updatePaper(ResPaper resPaper) throws Exception{
		try {
			resPaperDAO.update(resPaper);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public List<ResPaper> getPaperList(ResPaper resPaper, Page page)throws Exception {
		try {
			return resPaperDAO.getPaperList(resPaper, page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ResPaper getPaperByid(ResPaper resPaper)throws Exception {
		try {
			return (ResPaper) resPaperDAO.getById(resPaper.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean insertQuestion(ResQuestion resQuestion)throws Exception {
		try {
			if (resQuestionDAO.insert(resQuestion) == 1) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return true;
		}
	}

	@Override
	public boolean updateQuestion(ResQuestion resQuestion)throws Exception {
		try {
			resQuestionDAO.update(resQuestion);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public List<ResQuestion> getPaperQuestionList(ResQuestion resQuestion)throws Exception {
		try {
			return resQuestionDAO.getPaperQuestionList(resQuestion);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ResQuestion getQuestionByid(ResQuestion resQuestion)throws Exception {
		try {
			return (ResQuestion) resQuestionDAO.getById(resQuestion.getId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void deletePaper(ResPaper resPaper) throws Exception{
		try {
			resPaperDAO.deletePaper(resPaper);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteQuestion(ResQuestion resQuestion)throws Exception {
		try {
			resQuestionDAO.deletePaper(resQuestion);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteProject(ResProject resProject) throws Exception{
		try {
			resProjectDAO.deleteProject(resProject);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteField(ResField resField) throws Exception{
		try {
			resFiledDAO.deleteField(resField);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List toPreviewPaper(Integer id) throws Exception{
		try {
			return resQuestionDAO.getPaperquestionByid(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public Integer toGetTaskAmoutByProject(ResTask resTask)throws Exception {
		try {
			return resTaskDAO.getTaskAmountByProject(resTask);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer toGetSendTaskNum(ResTask resTask)throws Exception {
		try {
			return resTaskDAO.togetSendTaskNum(resTask);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public void insertTask(ResSendrecord resSendrecord) throws Exception {
		List custList = resCustomerDAO.togetSendTaskCustomerId(resSendrecord);
		if(custList.size()>0) {
			resSendrecordDAO.insert(resSendrecord);
			Map map = new HashMap();
			map.put("list", custList);
			map.put("record",resSendrecord);
			resTaskDAO.insertBatchMap(map);
		}
	}
	@Override
	public void toSendTask(ResTask resTask, ResProject resProject, List list,User user,ResImport resImport)throws Exception {
		ResProject respro = null;
		try {
			respro = (ResProject) resProjectDAO.getById(resProject.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		resTask.setId(resProject.getId());
		resTask.setUpdate_employee(respro.getCust_table()+"_TASK");
//获取每个人派务单数		
		String  str[] = resProject.getValues().split(",");
		Integer count = 0;
		resImport = (ResImport) resImportDAO.getById(resImport.getId());
		for(String ss:str){
//			count为此次派务总共派务单数
			count = count+ Integer.parseInt(ss);
		}
		ResImport resImport2 = new ResImport();
		resImport2.setBalance_quantity(resImport.getBalance_quantity()-count);
		resImport2.setId(resImport.getId());
		resImport2.setUpdate_time(Util.getTimestamp());
		resImportDAO.update(resImport2);
		resTask.setCreate_employee(respro.getCust_table());
		resTask.setEnd(count);
		List list1 = null;
		try {
//			获取数量为count的未分配customerid
			list1 = resTaskDAO.togetSendTaskCustomerId(resTask);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List list2 = new ArrayList();
		List list3 = new ArrayList();
		List list6 = new ArrayList();
		try {
			for(int i=0;i<list.size();i++){
				
				Integer counts = Integer.parseInt(str[i]);
				User user1 = (User) list.get(i);
				ResTask resTask4 = new ResTask();
				resTask4.setAccept_user(user1.getUsername());
				list6.add(resTask4);
//		封装派务记录,按人派务	
				ResSendrecord resSendrecord = new ResSendrecord();
				resSendrecord.setAccept_user(user1.getUsername());
				resSendrecord.setCounts(counts);
				resSendrecord.setImport_id(resTask.getImport_id());
				resSendrecord.setCreate_employee(user.getUsername());
				resSendrecord.setCreate_time(Util.getTimestamp());
				list3.add(resSendrecord);
//		封装派务任务,按人派务					
				for(int j=0;j<counts;j++){
					ResTask res = new ResTask();
					res = (ResTask) list1.get(0);
					ResTask res1 = new ResTask();
					//res1.setTable(respro.getCust_table());
					res1.setAccept_user(user1.getUsername());
					res1.setCustomer_id(res.getId());
					res1.setProject_id(resProject.getId());
					res1.setImport_id(resTask.getImport_id());
					res1.setPaper_id(resTask.getPaper_id());
					res1.setCreate_employee(user.getUsername());
					res1.setCreate_time(Util.getTimestamp());
					list2.add(res1);
					list1.remove(0);
				}
				
			}
//向XX表插入数据做准备			
			List list4 =new ArrayList();	
			ResTask resTask3 = new ResTask();
			resTask3.setListUser(list6);
			resTask3.setId(respro.getId());
//获取已存在的人名字
			try {
				list4 = resTaskDAO.togetProUser(resTask3);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(list4.size()!=list.size()){
				for(int i=0;i<list.size();i++){
					int flag = 0;
					User user1 = (User) list.get(i);
					for(int j=0;j<list4.size();j++){
						if(user1.getUsername().equals(((ResTask)list4.get(j)).getAccept_user())){
							flag=1;
						}
					}
					if(flag==1){
						list.remove(i);
					}
				}
				if(list.size()!=0){
					List list5 = new ArrayList();
					for(Object object:list ){
						User user2 = (User)object;
						ResTask task = new ResTask();
						task.setAccept_user(user2.getUsername());
						task.setProject_id(respro.getId());
						list5.add(task);
					}
//					插入未有的记录 pro_user
					resTaskDAO.insertBatchUser(list5);
				}
			}
			Map map = new HashMap();
			map.put("list", list2);
			map.put("table1",respro.getCust_table()+"_TASK");
			resTaskDAO.insertBatchMap(map);
			resSendrecordDAO.insertBatch(list3);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	@Override
	public void toSendTask2(ResTask resTask, ResProject resProject,
			List senderList, List senderGroupList, User user,
			ResImport resImport)throws Exception {
		ResProject respro = null;
		try {
			respro = (ResProject) resProjectDAO.getById(resProject.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		resTask.setId(resProject.getId());
		resTask.setUpdate_employee(respro.getCust_table()+"_TASK");
		
//获取每个人派务单数		
		String  str[] = resProject.getValues().split(",");
		String  str1[] = resTask.getValues2().split(",");
		List listsx1 = new ArrayList();
		List listsx2 = new ArrayList();
		for(int i=0;i<str1.length;i++){
			if(str1[i].indexOf("*")!=-1){
				listsx2.add(i);
			}else{
				listsx1.add(i);
			}
		}
		
		Integer count = 0;
		for(Object sx1 :listsx1){
			Integer sxs1 = (Integer)sx1;
			count = count +  Integer.parseInt(str[sxs1]);
		}
		for(int i=0;i<listsx2.size();i++){
			count = count +  Integer.parseInt(str[((Integer)listsx2.get(i))])*(((List)senderGroupList.get(i)).size());
		}
		resImport = (ResImport) resImportDAO.getById(resImport.getId());
		ResImport resImport2 = new ResImport();
		resImport2.setBalance_quantity(resImport.getBalance_quantity()-count);
		resImport2.setId(resImport.getId());
		resImport2.setUpdate_time(Util.getTimestamp());
		resImportDAO.update(resImport2);
		
		
		resTask.setCreate_employee(respro.getCust_table());
		resTask.setEnd(count);
		List list1 = null;
		try {
//			获取数量为count的未分配customerid   所有customerid
			list1 = resTaskDAO.togetSendTaskCustomerId(resTask);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List list2 = new ArrayList();//装派务的任务
		List list3 = new ArrayList();//装派务记录
		Set list6 = new HashSet();//项目与人
		try {
			for(int i=0;i<senderList.size();i++){
				
				Integer counts = Integer.parseInt(str[(Integer) listsx1.get(i)]);
				User user1 = (User) senderList.get(i);
				ResTask resTask4 = new ResTask();
				resTask4.setAccept_user(user1.getUsername());
				list6.add(resTask4);
//		封装派务记录,按人派务	
				ResSendrecord resSendrecord = new ResSendrecord();
				resSendrecord.setAccept_user(user1.getUsername());
				resSendrecord.setCounts(counts);
				resSendrecord.setImport_id(resTask.getImport_id());
				resSendrecord.setCreate_employee(user.getUsername());
				resSendrecord.setCreate_time(Util.getTimestamp());
				list3.add(resSendrecord);
//		封装派务任务,按人派务					
				for(int j=0;j<counts;j++){
					ResTask res = new ResTask();
					res = (ResTask) list1.get(0);
					ResTask res1 = new ResTask();
					//res1.setTable(respro.getCust_table());
					res1.setAccept_user(user1.getUsername());
					res1.setCustomer_id(res.getId());
					res1.setProject_id(resProject.getId());
					res1.setImport_id(resTask.getImport_id());
					res1.setPaper_id(resTask.getPaper_id());
					res1.setCreate_employee(user.getUsername());
					res1.setCreate_time(Util.getTimestamp());
					list2.add(res1);
					list1.remove(0);
				}
				
			}
			
//组用户			
			
		for(int k=0;k<senderGroupList.size();k++){
			List  groupUser = (List) senderGroupList.get(k);
			Integer counts = Integer.parseInt(str[(Integer)listsx2.get(k)]);
			for(int i=0;i<groupUser.size();i++){
				User user1 = (User) groupUser.get(i);
				ResTask resTask4 = new ResTask();
				resTask4.setAccept_user(user1.getUsername());
				list6.add(resTask4);
//		封装派务记录,按人派务	
				ResSendrecord resSendrecord = new ResSendrecord();
				resSendrecord.setAccept_user(user1.getUsername());
				resSendrecord.setCounts(counts);
				resSendrecord.setImport_id(resTask.getImport_id());
				resSendrecord.setCreate_employee(user.getUsername());
				resSendrecord.setCreate_time(Util.getTimestamp());
				list3.add(resSendrecord);
//		封装派务任务,按人派务					
				for(int j=0;j<counts;j++){
					ResTask res = new ResTask();
					res = (ResTask) list1.get(0);
					ResTask res1 = new ResTask();
					//res1.setTable(respro.getCust_table());
					res1.setAccept_user(user1.getUsername());
					res1.setCustomer_id(res.getId());
					res1.setProject_id(resProject.getId());
					res1.setImport_id(resTask.getImport_id());
					res1.setPaper_id(resTask.getPaper_id());
					res1.setCreate_employee(user.getUsername());
					res1.setCreate_time(Util.getTimestamp());
					list2.add(res1);
					list1.remove(0);
				}
				
			}
			
			
		}	
			
//向用户项目表插入数据做准备			
			List list4 =new ArrayList();	
			List list7 =new ArrayList();	
			ResTask resTask3 = new ResTask();
			for(Object ob:list6){
				list7.add(ob);
			}
			resTask3.setListUser(list7);
			resTask3.setId(respro.getId());
//获取已存在的人名字
			try {
				list4 = resTaskDAO.togetProUser(resTask3);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			if(list4.size()!=list7.size()){
				for(int i=0;i<list7.size();i++){
					int flag = 0;
					ResTask user1 = (ResTask) list7.get(i);
					for(int j=0;j<list4.size();j++){
						if(user1.getAccept_user().equals(((ResTask)list4.get(j)).getAccept_user())){
							flag=1;
						}
					}
					if(flag==1){
						list7.remove(i);
					}
				}
				if(list7.size()!=0){
					List list5 = new ArrayList();
					for(Object object:list7 ){
						ResTask user2 = (ResTask)object;
						ResTask task = new ResTask();
						task.setAccept_user(user2.getAccept_user());
						task.setProject_id(respro.getId());
						list5.add(task);
					}
//					插入未有的记录 pro_user
					resTaskDAO.insertBatchUser(list5);
				}
			}
			Map map = new HashMap();
			map.put("list", list2);
			map.put("table1",respro.getCust_table()+"_TASK");
			resTaskDAO.insertBatchMap(map);
			resSendrecordDAO.insertBatch(list3);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
	}

	@Override
	public List toGetSendCusomerRecord(ResSendrecord resSendrecord,Page page)throws Exception {
		
			return resSendrecordDAO.getSendCustomerRecord(resSendrecord,page);
	}
	@Override
	public List getCustomerByid2(ResTask resTask)throws Exception {
		ResProject resProject = (ResProject) resProjectDAO.getById(resTask.getProject_id());
		List  dataList = resQuestionDAO.getPaperquestionByid(resTask.getPaper_id());
		List list = resFiledDAO.getProFieldList2(resProject);
		ResCustomer resCustomer = new ResCustomer();
		resCustomer.setValues(resProject.getCust_table());
		resCustomer.setValues2(resProject.getCust_table()+"_task");
		resCustomer.setPaper_id(resTask.getPaper_id());
		resCustomer.setStart_time(resTask.getStart_time());
		resCustomer.setEnd_time(resTask.getEnd_time());
		resCustomer.setCall_times(resTask.getCall_times());
		resCustomer.setContactTel(resTask.getContactTel());
		resCustomer.setFromCall(resTask.getFromCall());
		resCustomer.setImport_id(resTask.getImport_id());
		resCustomer.setEnable_flag(resTask.getIs_recall());
		resCustomer.setAccept_user(resTask.getAccept_user());
		
		Map map = new HashMap();
		map.put("resCustomer", resCustomer);
		map.put("list", list);
		List list2 = resCustomerDAO.getCustomerByid2(map);
		if(list2==null){
			list2 = new ArrayList();
		}
		int z=0;
		for(int i=0;i<list2.size();i++){
			String str = ((ResCustomer)list2.get(i)).getResResult();
			if(str==null||str.equals("")){
				continue;
			}
			String s[] = str.split(",");
			for(int j=0;j< dataList.size();j++){
				ResQuestion question = (ResQuestion) dataList.get(j);
				String hql="";
				z=0;
				for(int k=0;k<s.length;k++){
					String ss[] = s[k].split(":");
					if(question.getId()==Integer.parseInt(ss[0])){
					//	hql=ss[1];
						if(question.getType().equals("answerquestion")){
							hql = ss[1];
						}else{
							hql = getStr(ss[1],question.getColumn());
						}
						
						break;
					}
					z++;
				}
				if(z==s.length){
					hql="未选择";
				}
				((ResCustomer)list2.get(i)).getList().add(hql);
			}
		}
		try {
			return list2;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	

	@Override
	public List getMyTaskList(ResTask resTask, Page page)throws Exception {
	
			return resTaskDAO.getMyTaskList(resTask, page);
	
	}
	
	@Override
	public List<ResField> getProFieldList2(ResProject resProject)throws Exception {
		try {
			return resFiledDAO.getProFieldList2(resProject);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	
	@Override
	public ResTask getTaskByid(ResTask resTask)throws Exception {
		return  resTaskDAO.getTaskbyid(resTask);
	}

	@Override
	public ResCustomer getCustomerByid(int id, String cust_table,List list)throws Exception {
		ResCustomer resCustomer = new ResCustomer();
		resCustomer.setId(id);
		resCustomer.setValues(cust_table);
		resCustomer.setValues2(cust_table+"_task");
		Map map = new HashMap();
		map.put("resCustomer", resCustomer);
		map.put("list", list);
		try {
			return resCustomerDAO.getCustomerByid(map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public List<ResProject> getMyProList(ResProject resProject, Page page)throws Exception {
		try {
			return resProjectDAO.getMyProList(resProject, page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean updateResImport(ResImport resImport,User user) throws Exception {
		Util.setUpdateToVO(resImport, user);
		resImportDAO.update(resImport);
		return true;
	}

	@Override
	public List getImportList(ResImport resImport, Page page)throws Exception {

			return resImportDAO.getImportList(resImport, page);
	}
	@Override
	public List getImportList2(ResImport resImport, Page page)throws Exception {
		try {
			return resImportDAO.getImportList2(resImport, page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void commitResearch(ResRecord  resRecord,User user)throws Exception{
//		1.把任务结果写在restask中   2.点击提交任务自动跳入下个任务 3.EXCEL导出结果
		Util.setCreateToVO(resRecord, user);
		resRecordDAO.insert(resRecord);
		
		
		 
		ResTask task = new ResTask();
		task.setId(resRecord.getTask_id());
		task.setValues(resRecord.getValues());
		task = getTaskByid(task);
		task.setValues(resRecord.getValues()+"_task");
		task.setIs_called("T");
		task.setIs_recall(resRecord.getReCall());
		task.setCall_times(task.getCall_times()+1);
		task.setRemark(resRecord.getRemark());
		task.setCall_res(resRecord.getCallResult());
		String str = resRecord.getValues2();
		if(resRecord.getCallResult().equals("A")){
			if(str!=null){
				if(str.indexOf(",")!=-1){
					task.setResResult(getStr(str));
				}else{
					task.setResResult(str);
				}
			}
		}else{
					task.setResResult("");
			
		}
		
		Util.setUpdateToVO(task, user);
		resTaskDAO.update(task);
	}

	@Override
	public List getTaskRecordList(ResRecord resRecord, Page page){
		try {
			return resRecordDAO.getRecordList(resRecord, page);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List getTaskList(ResTask resTask, Page page)throws Exception {
		ResProject resProject = (ResProject) resProjectDAO.getById(resTask.getProject_id());
		resTask.setValues(resProject.getCust_table());
		return resTaskDAO.getAllTaskList(resTask, page);
	}

	@Override
	public void updateTaskgroup(ResProject resProject, String ids) throws Exception {
		String str = resProject.getValues();
		String strs[] = str.split(":");
		String user = strs[1].substring(1,strs[1].length()-2);
		resProject = (ResProject) resProjectDAO.getById(resProject.getId());
		ResTask	resTask = new ResTask();
		resTask.setUpdate_employee(user);
		resTask.setValues(resProject.getCust_table()+"_task");
		resTask.setValues2(ids);
		resTaskDAO.updateTaskgroup(resTask);
		resTask.setProject_id(resProject.getId());
		Integer count = resTaskDAO.ifExitsUser(resTask);
		if(count==0){
			resTask.setAccept_user(user);
			resTaskDAO.InsertProUser(resTask);
		}
		
		
	}

	@Override
	public void deleteTaskgroup(ResTask resTask) throws Exception {
		ResProject resProject = new ResProject();
		resProject = (ResProject) resProjectDAO.getById(resTask.getId());
		resTask.setValues2(resProject.getCust_table()+"_task");
//取相应增加数据		
		String str[] = (resTask.getValues()).split(",");
		Integer count = str.length;
		ResTask resTask2 = new ResTask();
		resTask2.setValues(resProject.getCust_table());
		resTask2.setId(Integer.parseInt(str[0]));
		resTask2 = resTaskDAO.getTaskbyid(resTask2);
//释放任务后，导入记录相应待派务数增加		
		ResImport resImport = (ResImport) resImportDAO.getById(resTask2.getImport_id());
		ResImport resImport2 = new ResImport();
		resImport2.setBalance_quantity(resImport.getBalance_quantity()+count);
		resImport2.setId(resImport.getId());
		resImport2.setUpdate_time(Util.getTimestamp());
		resImport2.setUpdate_employee("");
		resImportDAO.update(resImport2);
//删除释放任务		
		resTaskDAO.deleteBatch(resTask);
		
	}
/*
	@Override
	public Integer getTaskid(ResTask resTask,User user) throws Exception {
		ResTask resTask2 = new ResTask();
		resTask2.setAccept_user(user.getUsername());
		resTask2.setId(resTask.getId());
		if(resTask.getTable().indexOf(",")!=-1){
			resTask2.setValues(resTask.getUpdate_employee()+"_task");
		}else{
			resTask2.setValues(resTask.getTable()+"_task");
		}
		if(resTask.getTask_flag().equals("T")){//未拨打过电话任务
			resTask2.setCall_times(0);
		}else if(resTask.getTask_flag().equals("F")){//拨打过电话任务
			resTask2.setIs_called("T");
		}else if(resTask.getTask_flag().equals("J")){//需要回叫电话任务
			resTask2.setIs_recall("T");
		}else if(resTask.getTask_flag().equals("G")){//跳过此条任务
		}else if(resTask.getTask_flag().equals("K")){//未拨打过电话任务
			resTask2.setCall_times(0);
		}
		return resTaskDAO.getTaskid(resTask2);
	}

*/
	@Override
	public void deleteProUser(User user,Integer project_id) throws Exception {
		ResTask resTask = new ResTask();
		resTask.setAccept_user(user.getUsername());
		resTask.setProject_id(project_id);
		resTaskDAO.deleteProUser(resTask);
	}

	@Override
	public ResImport getResImport(ResImport resImport) throws Exception {
		return (ResImport) resImportDAO.getById(resImport.getId());
	}

	@Override
	public void updateCommonResImport(ResImport resImport,User user) throws Exception {
		ResProject resProject = getProById(resImport.getProject_id());
		if(resImport.getEnable_flag().equals("T")){
			ResTask resTask = new ResTask();
			resTask.setImport_id(resImport.getId());
			resTask.setValues(resProject.getCust_table()+"_task");
			resTask.setProject_id(resImport.getProject_id());
			resTaskDAO.recoverTask(resTask);
			List list = resTaskDAO.getRecoverUser(resTask);
			if(list.size()> 0){
				for(int i=0;i<list.size();i++){
					((ResTask)list.get(i)).setProject_id(resImport.getProject_id());
					((ResTask)list.get(i)).setEnable_flag("F");
				}
				resTaskDAO.insertBatchUser(list);	
			}
		}else if(resImport.getEnable_flag().equals("F")){
			ResTask resTask = new ResTask();
			resTask.setImport_id(resImport.getId());
			resTask.setValues(resProject.getCust_table()+"_task");
			resTaskDAO.pauseTask(resTask);
		}
		updateResImport(resImport, user);
	}

//	把选择题答案整合，多选题答案归一
	public String getStr(String str){
		String strs[] = str.split(",");
		Set set = new HashSet();
		List list = new ArrayList();
		for(String s:strs){
			String ss[] = s.split(":");
			if(set.add(ss[0])){
				list.add(ss[0]);
			}
		}
		String h1="";
		for(Object object : list){
			String g = (String)object;
			String g1=g+":";
			for(String ss:strs){
				String s1[] = ss.split(":");
				if(s1[0].equals(g)){
					g1=g1+s1[1];
				}
			}
			h1=h1+g1+",";
		}
		return h1;
	}
	
	
//为导出问卷结果，加上每题选择结果	
	public String getStr(String str,String select ){
		String str0[] = select.split("\\|");
		String str1 = str.replaceAll("\\(", "");
		String str2[] = str1.split("\\)");
		String str3="";
		for(int i=0;i<str2.length;i++){
			int j = Integer.parseInt(str2[i])-1;
			str3=str3+"("+Integer.parseInt(str2[i])+")"+str0[j];
		}
		return str3;
	}


	@Override
	public void deleteImport(ResImport resImport) throws Exception {
		
		resImportDAO.delete(resImport.getId());
		
		
	}
	public ResSendrecord getSendRecord(ResSendrecord resSendrecord) throws Exception {
		return (ResSendrecord)resSendrecordDAO.getById(resSendrecord.getId());
	}
	public ResCustomer getCustomer(ResCustomer resCustomer) throws Exception{
		return (ResCustomer)resCustomerDAO.getByObject(resCustomer);
	}
}
