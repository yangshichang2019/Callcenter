package com.konka.job.research.model;

import com.konka.common.base.BaseVO;

public class ResSendrecord extends BaseVO {
	private Integer id;
	private Integer counts;//������
	private String accept_user;
	
	private Integer paper_id;
	private Integer import_id;
	private Integer project_id;
	private String cust_table;
	private String rname;
	 
	private Integer last;//δ�����
	private ResPaper resPaper = new ResPaper();
	public Integer getImport_id() {
		return import_id;
	}
	public void setImport_id(Integer import_id) {
		this.import_id = import_id;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getCounts() {
		return counts;
	}
	public void setCounts(Integer counts) {
		this.counts = counts;
	}
	public String getAccept_user() {
		return accept_user;
	}
	public void setAccept_user(String accept_user) {
		this.accept_user = accept_user;
	}
	
	public ResSendrecord() {
		// TODO Auto-generated constructor stub
	}
	public Integer getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(Integer paper_id) {
		this.paper_id = paper_id;
	}
	public String getCust_table() {
		return cust_table;
	}
	public void setCust_table(String cust_table) {
		this.cust_table = cust_table;
	}
	public Integer getLast() {
		return last;
	}
	public void setLast(Integer last) {
		this.last = last;
	}
	public ResPaper getResPaper() {
		return resPaper;
	}
	public void setResPaper(ResPaper resPaper) {
		this.resPaper = resPaper;
	}
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	
	
}
