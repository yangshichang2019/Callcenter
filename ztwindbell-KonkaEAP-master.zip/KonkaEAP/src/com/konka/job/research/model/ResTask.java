package com.konka.job.research.model;

import java.sql.Timestamp;
import java.util.List;

import com.konka.common.base.BaseVO;

public class ResTask extends BaseVO {
	private Integer id;
	private Integer customer_id;
	private Integer paper_id;
	private Integer project_id;
	private String table;
	private String remark;
	private String call_res;
	
	
	private Integer record_id;
	
	private Integer import_id;
	private String accept_user;
	private String is_called;
	private String is_recall;
	private Integer call_times;
	private Timestamp next_call_time;
	private Timestamp answer_time;
	private String resResult;
	
	private String task_flag;
	private List listUser;
	private String fromCall;
	private String contactTel;
	private String paper_name;
	
	
	
	private ResCustomer resCustomer = new ResCustomer();
	
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getRecord_id() {
		return record_id;
	}
	public void setRecord_id(Integer record_id) {
		this.record_id = record_id;
	}
	public String getPaper_name() {
		return paper_name;
	}
	public void setPaper_name(String paper_name) {
		this.paper_name = paper_name;
	}
	public String getFromCall() {
		return fromCall;
	}
	public void setFromCall(String fromCall) {
		this.fromCall = fromCall;
	}
	public String getContactTel() {
		return contactTel;
	}
	public void setContactTel(String contactTel) {
		this.contactTel = contactTel;
	}
	public String getTask_flag() {
		return task_flag;
	}
	public void setTask_flag(String task_flag) {
		this.task_flag = task_flag;
	}
	public String getResResult() {
		return resResult;
	}
	public void setResResult(String resResult) {
		this.resResult = resResult;
	}
	public Integer getImport_id() {
		return import_id;
	}
	public void setImport_id(Integer import_id) {
		this.import_id = import_id;
	}
	public List getListUser() {
		return listUser;
	}
	public void setListUser(List listUser) {
		this.listUser = listUser;
	}
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAccept_user() {
		return accept_user;
	}
	public void setAccept_user(String accept_user) {
		this.accept_user = accept_user;
	}
	public Integer getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}
	public String getIs_called() {
		return is_called;
	}
	public void setIs_called(String is_called) {
		this.is_called = is_called;
	}
	public String getIs_recall() {
		return is_recall;
	}
	public void setIs_recall(String is_recall) {
		this.is_recall = is_recall;
	}
	public Integer getCall_times() {
		return call_times;
	}
	public void setCall_times(Integer call_times) {
		this.call_times = call_times;
	}
	public Timestamp getNext_call_time() {
		return next_call_time;
	}
	public void setNext_call_time(Timestamp next_call_time) {
		this.next_call_time = next_call_time;
	}
	public Integer getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(Integer paper_id) {
		this.paper_id = paper_id;
	}
	public Timestamp getAnswer_time() {
		return answer_time;
	}
	public void setAnswer_time(Timestamp answer_time) {
		this.answer_time = answer_time;
	}
	public ResTask() {
		// TODO Auto-generated constructor stub
	}
	public ResCustomer getResCustomer() {
		return resCustomer;
	}
	public void setResCustomer(ResCustomer resCustomer) {
		this.resCustomer = resCustomer;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public String getCall_res() {
		return call_res;
	}
	public void setCall_res(String call_res) {
		this.call_res = call_res;
	}
	
}
