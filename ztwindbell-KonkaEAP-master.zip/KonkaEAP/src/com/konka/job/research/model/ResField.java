package com.konka.job.research.model;

import com.konka.common.base.BaseVO;

public class ResField extends BaseVO {
	private Integer id;
	private Integer project_id;
	private String name;
	private String value;//����д�����ݿ�
	private Integer sort;
	private String type;
	private Integer attributeSort;
	private String trueName;
	
	
	
	public String getTrueName() {
		return trueName;
	}
	public void setTrueName(String trueName) {
		this.trueName = trueName;
	}
	public Integer getAttributeSort() {
		return attributeSort;
	}
	public void setAttributeSort(Integer attributeSort) {
		this.attributeSort = attributeSort;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	public ResField() {
		// TODO Auto-generated constructor stub
	}
}
