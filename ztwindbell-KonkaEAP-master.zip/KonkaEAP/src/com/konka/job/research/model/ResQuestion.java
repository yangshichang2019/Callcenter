package com.konka.job.research.model;

import java.util.List;

import com.konka.common.base.BaseVO;

public class ResQuestion extends BaseVO {
	private Integer id;
	private Integer paper_id;
	private String type;
	private String column;
	private String title;
	private String value;
	private Integer sort;

	private String userSelect="";
	private List selectionList;
	
	
	public String getUserSelect() {
		return userSelect;
	}
	public void setUserSelect(String userSelect) {
		this.userSelect = userSelect;
	}
	public Integer getSort() {
		return sort;
	}
	public void setSort(Integer sort) {
		this.sort = sort;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(Integer paper_id) {
		this.paper_id = paper_id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getColumn() {
		return column;
	}
	public void setColumn(String column) {
		this.column = column;
	}
	
	public List getSelectionList() {
		return selectionList;
	}
	public void setSelectionList(List selectionList) {
		this.selectionList = selectionList;
	}
	
	
	public ResQuestion() {
		// TODO Auto-generated constructor stub
	}
	
}
