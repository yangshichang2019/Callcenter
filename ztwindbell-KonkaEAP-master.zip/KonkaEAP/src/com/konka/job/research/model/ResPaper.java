package com.konka.job.research.model;

import java.util.List;

import com.konka.common.base.BaseVO;

public class ResPaper extends BaseVO {
	private Integer id;
	private Integer project_id;
	private String name;
	
	
	private List<ResQuestion> questions;
	
	
	
	
	public List<ResQuestion> getQuestions() {
		return questions;
	}
	public void setQuestions(List<ResQuestion> questions) {
		this.questions = questions;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	
	public ResPaper() {
		// TODO Auto-generated constructor stub
	}
}
