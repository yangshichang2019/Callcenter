package com.konka.job.research.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.konka.common.base.BaseVO;

public class ResCustomer extends BaseVO {
	private Integer id;
	private String fromCall;
	private String contactTel;
	private Integer call_times;
	private String call_res;
	//ϴ��
	private String is_connect;//�Ƿ��ͨ��
	private Timestamp connect_time;//���½�ͨʱ��
	/**
	 * �����ֶ�20��
	 */
	private String a;
	private String b;
	private String c;
	private String d;
	private String e;
	private String f;
	private String g;
	private String h;
	private String i;
	private String j;
	private String k;
	private String l;
	private String m;
	private String n;
	private String o;
	private String p;
	private String q;
	private String r;
	private String s;
	private String t;
//	�����ֶν���
	private Integer import_id;
	private Integer project_id;
	private Integer paper_id;
	private String table;
	private Timestamp next_call_time;
	private String remark;
	private String resResult;
	private String accept_user;
	private List list=new ArrayList();
	private Integer send_customer_times; 
	
	private String callResult;
	private String record_result;
	
	
	public String getCallResult() {
		return callResult;
	}
	public void setCallResult(String callResult) {
		this.callResult = callResult;
	}
	public String getRecord_result() {
		return record_result;
	}
	public void setRecord_result(String record_result) {
		this.record_result = record_result;
	}
	public Integer getSend_customer_times() {
		return send_customer_times;
	}
	public void setSend_customer_times(Integer send_customer_times) {
		this.send_customer_times = send_customer_times;
	}
	public String getAccept_user() {
		return accept_user;
	}
	public void setAccept_user(String accept_user) {
		this.accept_user = accept_user;
	}
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public String getResResult() {
		return resResult;
	}
	public void setResResult(String resResult) {
		this.resResult = resResult;
	}
	public Timestamp getNext_call_time() {
		return next_call_time;
	}
	public void setNext_call_time(Timestamp next_call_time) {
		this.next_call_time = next_call_time;
	}
	public Integer getPaper_id() {
		return paper_id;
	}
	public void setPaper_id(Integer paper_id) {
		this.paper_id = paper_id;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public Integer getImport_id() {
		return import_id;
	}
	public void setImport_id(Integer import_id) {
		this.import_id = import_id;
	}
	public String getA() {
		return a;
	}
	public void setA(String a) {
		this.a = a;
	}
	public String getB() {
		return b;
	}
	public void setB(String b) {
		this.b = b;
	}
	public String getC() {
		return c;
	}
	public void setC(String c) {
		this.c = c;
	}
	public String getD() {
		return d;
	}
	public void setD(String d) {
		this.d = d;
	}
	public String getE() {
		return e;
	}
	public void setE(String e) {
		this.e = e;
	}
	public String getF() {
		return f;
	}
	public void setF(String f) {
		this.f = f;
	}
	public String getG() {
		return g;
	}
	public void setG(String g) {
		this.g = g;
	}
	public String getH() {
		return h;
	}
	public void setH(String h) {
		this.h = h;
	}
	public String getI() {
		return i;
	}
	public void setI(String i) {
		this.i = i;
	}
	public String getJ() {
		return j;
	}
	public void setJ(String j) {
		this.j = j;
	}
	public String getK() {
		return k;
	}
	public void setK(String k) {
		this.k = k;
	}
	public String getL() {
		return l;
	}
	public void setL(String l) {
		this.l = l;
	}
	public String getM() {
		return m;
	}
	public void setM(String m) {
		this.m = m;
	}
	public String getN() {
		return n;
	}
	public void setN(String n) {
		this.n = n;
	}
	public String getO() {
		return o;
	}
	public void setO(String o) {
		this.o = o;
	}
	public String getP() {
		return p;
	}
	public void setP(String p) {
		this.p = p;
	}
	public String getQ() {
		return q;
	}
	public void setQ(String q) {
		this.q = q;
	}
	public String getR() {
		return r;
	}
	public void setR(String r) {
		this.r = r;
	}
	public String getS() {
		return s;
	}
	public void setS(String s) {
		this.s = s;
	}
	public String getT() {
		return t;
	}
	public void setT(String t) {
		this.t = t;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getFromCall() {
		return fromCall;
	}
	public void setFromCall(String fromCall) {
		this.fromCall = fromCall;
	}
	public String getContactTel() {
		return contactTel;
	}
	public void setContactTel(String contactTel) {
		this.contactTel = contactTel;
	}
	public Integer getCall_times() {
		return call_times;
	}
	public void setCall_times(Integer call_times) {
		this.call_times = call_times;
	}
	public String getIs_connect() {
		return is_connect;
	}
	public void setIs_connect(String is_connect) {
		this.is_connect = is_connect;
	}
	public Timestamp getConnect_time() {
		return connect_time;
	}
	public void setConnect_time(Timestamp connect_time) {
		this.connect_time = connect_time;
	}
	public String getCall_res() {
		return call_res;
	}
	public void setCall_res(String call_res) {
		this.call_res = call_res;
	}
}
