package com.konka.job.research.model;

import com.konka.common.base.BaseVO;

public class ResResult extends BaseVO {
	private Integer id;
	private Integer task_id;
	private Integer project_id;
	private Integer import_id;
	private Integer question_id;
	
	private Integer customer_id;
	
	

	private String  answer;
/*
 * 
 * �绰����� 
 * 
 * */
	
	
	
	public Integer getId() {
		return id;
	}

	public Integer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTask_id() {
		return task_id;
	}

	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}

	public Integer getProject_id() {
		return project_id;
	}

	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}

	public Integer getImport_id() {
		return import_id;
	}

	public void setImport_id(Integer import_id) {
		this.import_id = import_id;
	}

	public Integer getQuestion_id() {
		return question_id;
	}

	public void setQuestion_id(Integer question_id) {
		this.question_id = question_id;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	
	
	
	
}
