package com.konka.job.research.model;

import com.konka.common.base.BaseVO;

public class ResProject extends BaseVO {
	private Integer id;
	private String name;
	private String cust_table;
	private Integer values3 ;
	
	public Integer getValues3() {
		return values3;
	}
	public void setValues3(Integer values3) {
		this.values3 = values3;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCust_table() {
		return cust_table;
	}
	public void setCust_table(String cust_table) {
		this.cust_table = cust_table;
	}
}
