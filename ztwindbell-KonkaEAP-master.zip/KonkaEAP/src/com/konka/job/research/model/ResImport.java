package com.konka.job.research.model;

import com.konka.system.model.ExeclImport;

public class ResImport extends ExeclImport {
	private Integer id;
	private Integer project_id;
	private String title;
	private String cust_table;
	private Integer balance_quantity;//ʣ������
	
	public Integer getBalance_quantity() {
		return balance_quantity;
	}
	public void setBalance_quantity(Integer balance_quantity) {
		this.balance_quantity = balance_quantity;
	}
	public String getCust_table() {
		return cust_table;
	}
	public void setCust_table(String cust_table) {
		this.cust_table = cust_table;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getProject_id() {
		return project_id;
	}
	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
	public ResImport() {
		// TODO Auto-generated constructor stub
	}
}
