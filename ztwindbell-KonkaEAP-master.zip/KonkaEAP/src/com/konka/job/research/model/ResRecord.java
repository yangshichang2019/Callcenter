package com.konka.job.research.model;

import com.konka.common.base.BaseVO;

public class ResRecord extends BaseVO {
	private Integer id;
	private Integer task_id;
	private String callResult;
	private String resResult;
	private String reCall;
	private String remark;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCallResult() {
		return callResult;
	}
	public void setCallResult(String callResult) {
		this.callResult = callResult;
	}
	public String getResResult() {
		return resResult;
	}
	public void setResResult(String resResult) {
		this.resResult = resResult;
	}
	public Integer getTask_id() {
		return task_id;
	}
	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}
	
	public ResRecord() {
		// TODO Auto-generated constructor stub
	}
	public String getReCall() {
		return reCall;
	}
	public void setReCall(String reCall) {
		this.reCall = reCall;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
}
