package com.konka.job.research.action;

import java.io.File;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import net.sf.json.JSONObject;

import org.apache.struts2.ServletActionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResCustomer;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResImport;
import com.konka.job.research.model.ResPaper;
import com.konka.job.research.model.ResProject;
import com.konka.job.research.model.ResQuestion;
import com.konka.job.research.model.ResRecord;
import com.konka.job.research.model.ResResult;
import com.konka.job.research.model.ResSendrecord;
import com.konka.job.research.model.ResTask;
import com.konka.job.research.service.ResService;
import com.konka.system.model.ExeclCell;
import com.konka.system.model.ExeclImport;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;

@Controller
@Scope("prototype")
public class resAction extends BaseAction {

	@Autowired
	private ResService resService;
	@Autowired
	private SystemService systemService;
	@Autowired
	private UserAdminService userAdminService;
	
	private ExeclImport execlImport = new ExeclImport();
	private ResImport resImport = new ResImport();
	private ResProject resProject = new ResProject();
	private ResField resField = new ResField();
	private ResPaper resPaper = new ResPaper();
	private ResQuestion resQuestion = new ResQuestion();
	private ResTask resTask = new ResTask();
	private ResCustomer  resCustomer = new ResCustomer();
	private ResSendrecord resSendrecord = new ResSendrecord();
	private List list = new ArrayList();
	private ResRecord resRecord = new ResRecord();
	private ResResult resResult = new ResResult();
	private File file;
	private String title="T";
	private String type;
	private Integer project_id;
	private String table;
	private Integer update_dept;
	
	
	private List countList = new ArrayList();
	private List userList = new ArrayList();
	
	
	//=================项目管理=====================================	
//跳转到创建项目页面
	public String toAddEditPro() throws Exception{
		if(resProject.getId()!=null&&resProject.getId()>0) {
			resProject = resService.getProById(resProject.getId());
		}
		return "toAddEditPro";
	}
//保存项目
	public String toSavePro() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		resService.savePro(resProject,user);
		System.out.println(Constant.ACTION_S.ajaxDone.toString());
		return Constant.ACTION_S.ajaxDone.toString();
	}	
//管理项目
	public String toManagePro() throws Exception{
		dataList = resService.getProList(resProject, page);
		return "toManagePro";
	}

//上传客户资料页面
	public String toUploadProCustomer() throws Exception{
		return "toUploadProCustomer";
	}
//向客户资料表导入数据	
	public String toInsertImport() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		List list = resService.getProFieldList(resProject);
		resProject = resService.getProById(resProject.getId());
		resImport.setTable(resProject.getCust_table());
		resImport.setProject_id(resProject.getId());
		List fieldList = new ArrayList();
		ExeclCell execlCell = null;
		for (int i = 0; i < list.size(); i++) {
			execlCell = new ExeclCell();
			execlCell.setTable_column(((ResField) list.get(i)).getName());
			execlCell.setExecl_column(((ResField) list.get(i)).getSort());
			execlCell.setType(((ResField) list.get(i)).getType());
			fieldList.add(execlCell);
		}
		resService.insertResImport(resImport,user); 
		if (fieldList.size() > 0) {
			systemService.insertBatchExeclData(file,resImport, fieldList, user);
		}
		if(resImport.getResult()!=null&&!resImport.getResult().equals("")) {
			super.toError(resImport.getResult());
			resService.deleteImport(resImport);
		}else {
			resImport.setBalance_quantity(resImport.getCount());
			resService.updateResImport(resImport,user);
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}	
//列出某项目的所有字段
	public String toProFieldList() throws Exception{
			dataList = resService.getProFieldList(resProject);
			return "toProFieldList";
	}
	
//跳转到新增或者修改项目字段页面
	public String toAddEditResField() throws Exception{
		if (resField.getId() == null) {
			return "toAddEditResField";
		} else {
			resField = resService.getFieldByid(resField);
			return "toAddEditResField";
		}
	}

//保存或修改项目字段
	public String toSaveResField() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		if (resField.getId() != null) {
			resField.setUpdate_time(Util.getTimestamp());
			resField.setUpdate_employee(user.getUsername());
			resService.updateField(resField);
		} else {
			resField.setCreate_employee(user.getUsername());
			resField.setCreate_time(Util.getTimestamp());
			resField.setValue("");
			resService.insertField(resField);
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}	
//删除字段
	public String toDeleteResField() throws Exception{
		resField.setValues(ids);
		resService.deleteField(resField);
		return Constant.ACTION_S.ajaxDone.toString();
	}	
	
	
	
//===========问卷管理	===================================

//管理问卷
	public String toManageResPaper() throws Exception{
		dataList = resService.getPaperList(resPaper, page);
		return "toManageResPaper";
	}
//删除问卷
	public String toDeleteResPaper() throws Exception{
		resPaper.setValues(ids);
		resService.deletePaper(resPaper);
		return Constant.ACTION_S.ajaxDone.toString();
	}	
//跳转到保存或修改问卷页面
	public String toAddEditResPaper() throws Exception{
		if (resPaper.getId() == null) {
			return "toAddEditResPaper";
		} else {
			resPaper = resService.getPaperByid(resPaper);
			return "toAddEditResPaper";
		}
	}
//保存问卷或修改问卷
	public String toSaveResPaper() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		if (resPaper.getId() != null) {
			resPaper.setUpdate_time(Util.getTimestamp());
			resPaper.setUpdate_employee(user.getUsername());
			resService.updatePaper(resPaper);
		} else {
			resPaper.setCreate_employee(user.getUsername());
			resPaper.setCreate_time(Util.getTimestamp());
			resService.insertPaper(resPaper);
		}
		return Constant.ACTION_S.ajaxDone.toString();
		}
//列出问卷所有问题
	public String toResPaperQuestionList() throws Exception{
		dataList = resService.getPaperQuestionList(resQuestion);
		return "toResPaperQuestionList";
	}
//跳转到新增或修改问题页面
	public String toAddEditResQuestion() throws Exception{
		if (resQuestion.getId() == null) {
			return "toAddEditResQuestion";
		} else {
			resQuestion = resService.getQuestionByid(resQuestion);
			if (!resQuestion.getType().equals("answerquestion")) {
				String str[] = resQuestion.getColumn().split("\\|");
				List list = new ArrayList();
				for (String ss : str) {
					list.add(ss);
				}
				resQuestion.setSelectionList(list);
			}
			return "toAddEditResQuestion";
		}
	}
//新增或修改问题
	public String toSaveResQuestion() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		if (resQuestion.getId() != null&&resQuestion.getId()>0) {
			resQuestion.setUpdate_time(Util.getTimestamp());
			resQuestion.setUpdate_employee(user.getUsername());
			resService.updateQuestion(resQuestion);
		} else {
			resQuestion.setCreate_employee(user.getUsername());
			resQuestion.setCreate_time(Util.getTimestamp());
			resService.insertQuestion(resQuestion);
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}

//删除问题
	public String toDeleteResQuestion() throws Exception{
		resQuestion.setValues(ids);
		resService.deleteQuestion(resQuestion);
		return Constant.ACTION_S.ajaxDone.toString();
	}
//预览问卷
	public String toPreviewResPaper() throws Exception{
		resPaper.setId(resQuestion.getPaper_id());
		resPaper = resService.getPaperByid(resPaper);
		dataList = resService.toPreviewPaper(resQuestion.getPaper_id());
		dataList = changeOutPutFormat(dataList);
		return "toPreviewResPaper";
	}	
//专项填写问卷
	public String toFillInResearch() throws Exception{
		resPaper.setId(resQuestion.getPaper_id());
		resPaper = resService.getPaperByid(resPaper);
		dataList = resService.toPreviewPaper(resQuestion.getPaper_id());
		dataList = changeOutPutFormat(dataList);
		return "toFillInResearch";
	}

//选择问卷
	public String tofindPaper() throws Exception{
		dataList = resService.getPaperList(resPaper, page);
		return "tofindPaper";
	}
	
//==========任务管理===================================================	
//任务管理页面
	public String toManageTask() throws Exception{
		if(resTask.getProject_id()!=null&&resTask.getProject_id()>0){
			if(resTask.getPaper_id()!=null&&resTask.getProject_id()>0) {
				dataList = resService.getTaskList(resTask, page);
			}else {
				toError("请选择问卷！");
			}
		}else {
			toError("请选择项目！");
		}
		return "toManageTask";
	}
	
//查看客户资料及通话记录	
		public String toViewTaskInfo2() throws Exception{
			List dataList1 = new ArrayList();
//			resProject.setId(resTask.getProject_id());
			//list = resService.getProFieldList2(resProject);
			//获取客户资料				
			//resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getTable(),list);
			//resRecord.setProject_id(resTask.getProject_id());
			resRecord.setTask_id(resTask.getId());
			dataList1 = resService.getTaskRecordList(resRecord, page);
			super.getRequest().setAttribute("dataList1", dataList1);
			
			resTask.setValues(resTask.getTable());
			resTask= resService.getTaskByid(resTask);
			if(resTask.getResResult()!=null){
				if(!resTask.getResResult().equals("")){
					resPaper.setId(resTask.getPaper_id());
					resPaper = resService.getPaperByid(resPaper);
					dataList = resService.toPreviewPaper(resTask.getPaper_id());
					dataList = changeOutPutFormat2(dataList,resTask.getResResult());
				}else{
					dataList = new ArrayList();
				}
			}
			
			return "toViewTaskInfo2";
		}	
//选择项目
		public String toLookAllproject() throws Exception{
			dataList = resService.getProList(resProject, page);
			if(dataList==null){
				dataList = new ArrayList();
			}
			return "toLookAllproject";
		}
//选择导入记录
		public String toLookAllImport() throws Exception{
			dataList = resService.getImportList2(resImport, page);
			return "toLookAllImport";
		}
		
		
//1.未先选择项目，选择导入记录进入失败页面2.未先选择导入记录选择派务次数，进入失败页面
		public String toFail() throws Exception{
				if(title.equals("T")){
					setTitle("请先选择导入记录!");
				}else if(title.equals("F")){
					setTitle("请先选择项目!");
				}
					return "toFail";
		}
		
//群改任务		
		public String toUpdateTaskgroup() throws Exception{
			return "toUpdateTaskgroup";
		}
//群释放任务		
		public String toDeleteTaskgroup() throws Exception{
			int cou = ids.split(",").length;
			resTask.setValues(ids);
			resService.deleteTaskgroup(resTask);
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
//修改群选任务人		
		public String toUpdateTaskids() throws Exception{
			resService.updateTaskgroup(resProject, ids);
			return Constant.ACTION_S.ajaxDone.toString();
		}
		
//============导入记录管理=================================================
//导入记录管理
	public String toManageImport() throws Exception{
		dataList = resService.getImportList(resImport, page);
		if(dataList==null){
			dataList = new ArrayList();
		}
		return "toManageImport";
	}	
	
//转向修改导入记录页面
	public String toEditImport() throws Exception{
		resImport = resService.getResImport(resImport);
		return "toEditImport";
	}		
//修改导入记录结果
	public String toUpdateImport() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		resService.updateCommonResImport(resImport,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}		
//	  转向派务资料页面  
	public String toSendCustomer() throws Exception{
		resImport = resService.getResImport(resImport);
		resProject = resService.getProById(resImport.getProject_id());
		return "toSendCustomer";
	}
//	 查询派务资料记录
	public String toSendCustomerRecord() throws Exception{
		dataList = resService.toGetSendCusomerRecord(resSendrecord,page);
		return "toSendCustomerRecord";
	}
	//刷新用户
	public String toGetChooseUser() throws Exception {
		System.out.println(ids);
		List tempList = userAdminService.strToUserList(super.getIds());
		User user = null;
		super.getResponse().setContentType("text/plain;charset=gbk");
		super.getResponse().setCharacterEncoding("gbk");		
		Writer out = super.getResponse().getWriter();		
		StringBuilder s = new StringBuilder("{");		
		for(int i=0;i<tempList.size();i++) {
			user = (User)tempList.get(i);
			s.append("\""+user.getUsername()+"\":\""+user.getFullname()+"\",");
		}
		String st = s.toString();
		st = st.substring(0, st.length()-1);
		st = st + "}";
		out.write(st);
		out.flush();
		out.close();
		return null;
	}
//	  派务任务
	/**
	 * 派务任务
	 * 1.仅向组派务
	 * 2.仅向用户派务
	 * 3.即有用户又有组
	 */
	public String toSendTask() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		if(userList.size()>0&&countList.size()>0) {
			Integer count = 0;
			for(int i=0;i<userList.size();i++) {
				String c = countList.get(i).toString();
				if(Util.isNumeric(c)&&!c.equals("")) {
					Integer cs = Integer.parseInt(c);
					if(cs>0){
						count = count + cs;
						resSendrecord.setAccept_user(userList.get(i)+"");
						resSendrecord.setCounts(cs);
						Util.setCreateToVO(resSendrecord, user);
						resService.insertTask(resSendrecord);
					}
				}
			}
			if(count>0) {
				resImport.setBalance_quantity(resImport.getBalance_quantity()-count);
				resService.updateResImport(resImport, user);
			}
			
		}
		/*
		List senderList = null;
//   仅向组,派务任务
		if(resTask.getValues().indexOf("group")!=-1&&resTask.getValues().indexOf("user")!=-1){
			List senderGroupList = new ArrayList();
			String str = resTask.getValues();
			str = str.replaceAll("\",\"","\"}|{\"" );
			String strs[] = str.split("\\|");
			String userStr = strs[0];
			String groupStr = strs[1];//{"group":"
			if(groupStr.indexOf(",")!=-1){
				groupStr = groupStr.replaceAll("{\"group\":\"", "");
				groupStr = groupStr.replaceAll("\"}", "");
				String groups[] = groupStr.split(",");
				for(String groupStr2:groups){
					List listgroup = userAdminService.strToUserList("{\"group\":\""+groupStr2+"\"}");
					senderGroupList.add(listgroup);
				}
			}else{
				List listgroup = userAdminService.strToUserList(groupStr);
				senderGroupList.add(listgroup);
			}
			try {
				senderList = userAdminService.strToUserList(userStr);
				resService.toSendTask2(resTask, resProject, senderList,senderGroupList,user,resImport);
			} catch (Exception e) {
				e.printStackTrace();
			}
//   仅向用户不含组,派务任务			
		}else if(resTask.getValues().indexOf("group")==-1){
			try {
				 senderList = userAdminService.strToUserList(resTask.getValues());
				 resService.toSendTask(resTask, resProject, senderList,user,resImport);
			} catch (Exception e) {
				e.printStackTrace();
			}
//   即包含组又包含成员,派务任务				
		}else if(resTask.getValues().indexOf("group")!=-1&&resTask.getValues().indexOf("user")==-1){
			List senderGroupList = new ArrayList();
			String str = resTask.getValues();
			String userStr = "";
			String groupStr = str;
			if(groupStr.indexOf(",")!=-1){
				groupStr = groupStr.replaceAll("{\"group\":\"", "");
				groupStr = groupStr.replaceAll("\"}", "");
				String groups[] = groupStr.split(",");
				for(String groupStr2:groups){
					List listgroup = userAdminService.strToUserList("{\"group\":\""+groupStr2+"\"}");
					senderGroupList.add(listgroup);
				}
			}else{
				List listgroup = userAdminService.strToUserList(groupStr);
				senderGroupList.add(listgroup);
			}
			try {
				senderList = new  ArrayList();
				resService.toSendTask2(resTask, resProject, senderList,senderGroupList,user,resImport);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		*/
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
//==========我的任务========================================================	
//	 我有任务的项目
	public String toMyTask() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		resSendrecord.setAccept_user(user.getUsername());
		resSendrecord.setLast(0);//剩余量大于0
		dataList = resService.toGetSendCusomerRecord(resSendrecord, page);
		return "toMyTask";
	}
//	项目中我的任务
	public String toLookupMytask() throws Exception{
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		
		if(resTask.getRecord_id()==null){
			dataList = new ArrayList();
		}else{
			resSendrecord.setId(resTask.getRecord_id());
			resSendrecord = resService.getSendRecord(resSendrecord);
			resTask.setValues(resSendrecord.getCust_table());
			resTask.setAccept_user(user.getUsername());
			resTask.setValues2(resSendrecord.getRname());
			dataList = resService.getMyTaskList(resTask, page);
		}
		
		
		/*
		resTask.setValues(resTask.getTable());
		resTask.setTable(resTask.getTable()+"_task");
		resTask.setAccept_user(user.getUsername());
		dataList = resService.getMyTaskList(resTask, page);
		if(dataList.size()==0){
			if(resTask.getCall_times()==null&&resTask.getContactTel()==null&&
					resTask.getFromCall()==null&&resTask.getIs_recall()==null&&
					resTask.getIs_called()==null&&resTask.getNext_call_time()==null&&
					resTask.getStart_time()==null&&resTask.getEnd_time()==null&&
					resTask.getImport_id()==null
					){
				resService.deleteProUser(user, resTask.getProject_id());
			}
		}
		*/
		return "toLookupMytask";
	}	
	
//查看客户资料及通话记录	
	public String toViewTaskInfo() throws Exception{
		resProject.setId(resTask.getProject_id());
		//list = resService.getProFieldList2(resProject);
		//获取客户资料				
		//resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getTable(),list);
		//resRecord.setProject_id(resTask.getProject_id());
		resRecord.setTask_id(resTask.getId());
		dataList = resService.getTaskRecordList(resRecord, page);
		return "toViewTaskInfo";
	}
	public void custToField(ResCustomer cust,ResField field) {
		if(field.getName().equals("fromCall")) {
			field.setValue(cust.getFromCall());
		}else if(field.getName().equals("contactTel")) {
			field.setValue(cust.getContactTel());
		}else if(field.getName().equals("a")) {
			field.setValue(cust.getA());
		}else if(field.getName().equals("b")) {
			field.setValue(cust.getB());
		}else if(field.getName().equals("c")) {
			field.setValue(cust.getC());
		}else if(field.getName().equals("d")) {
			field.setValue(cust.getD());
		}else if(field.getName().equals("e")) {
			field.setValue(cust.getE());
		}else if(field.getName().equals("f")) {
			field.setValue(cust.getF());
		}else if(field.getName().equals("g")) {
			field.setValue(cust.getG());
		}else if(field.getName().equals("h")) {
			field.setValue(cust.getH());
		}else if(field.getName().equals("i")) {
			field.setValue(cust.getI());
		}else if(field.getName().equals("j")) {
			field.setValue(cust.getJ());
		}else if(field.getName().equals("k")) {
			field.setValue(cust.getK());
		}else if(field.getName().equals("l")) {
			field.setValue(cust.getL());
		}else if(field.getName().equals("m")) {
			field.setValue(cust.getM());
		}else if(field.getName().equals("n")) {
			field.setValue(cust.getN());
		}else if(field.getName().equals("o")) {
			field.setValue(cust.getO());
		}else if(field.getName().equals("p")) {
			field.setValue(cust.getP());
		}else if(field.getName().equals("q")) {
			field.setValue(cust.getQ());
		}else if(field.getName().equals("r")) {
			field.setValue(cust.getR());
		}else if(field.getName().equals("s")) {
			field.setValue(cust.getS());
		}else if(field.getName().equals("t")) {
			field.setValue(cust.getT());
		}
	}
	public String toSaveResearch() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		resService.commitResearch(resRecord, user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
//	  开始调查
	/**
	 * 此action为开始调查任务
	 * 分为5种情况
	 * 1：直接开始调查
	 * 2：未拨打过电话的任务
	 * 3：拨打过电话的任务
	 * 4：需要回叫电话任务
	 * 5:跳过此任务
	 */
	public String toStartResearch() throws Exception{
		//获取导入批次
		resImport = resService.getResImport(resImport);
		//获取项目
		resProject = resService.getProById(resImport.getProject_id());
		//获取任务
		resTask.setValues(resProject.getCust_table());
		resTask = resService.getTaskByid(resTask);
		
		resCustomer.setId(resTask.getCustomer_id());
		resCustomer.setValues(resProject.getCust_table());
		resCustomer = resService.getCustomer(resCustomer);
		
		resField.setProject_id(resProject.getId());
		List tempList = resService.getProFieldList(resProject);
		ResField r = null;
		for(int i=0;i<tempList.size();i++) {
			r = new ResField();
			r = (ResField)tempList.get(i);
			custToField(resCustomer,r);
			dataList.add(r);
		}
		resRecord.setTask_id(resTask.getId());
		list = resService.getTaskRecordList(resRecord, page);
		/*
		System.out.println("------------------------------------------"+ServletActionContext.getRequest().getRemoteAddr());
//直接选择开始的调查		
		if(resTask.getTask_flag()==null){
// 为获取项目字段属性做准备			
				resProject.setId(resTask.getProject_id());
				list = resService.getProFieldList2(resProject);
//获取客户资料				
				resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getTable(),list);
				resRecord.setTask_id(resTask.getId());
				resRecord.setProject_id(resTask.getProject_id());
				dataList = resService.getTaskRecordList(resRecord, page);
				resTask.setCall_times(dataList.size());
				resTask.setNext_call_time(resCustomer.getNext_call_time());
		}else{
//拨打过电话任务			
			if(resTask.getTask_flag().equals("F")){
				resTask.setProject_id(project_id);
				resTask.setUpdate_dept(update_dept);
				//提交任务结果				
				resService.commitResearch(resRecord, user, resTask);
				Integer id = resService.getTaskid(resTask, user);
				if(id==null){
					setTitle("该项目拨打过电话的任务已用完，请换其他项目任务或任务");
					resService.deleteProUser(user, resTask.getProject_id());
				}else{
					 resTask.setId(id);
					 resProject.setId(resTask.getProject_id());
					 list = resService.getProFieldList2(resProject);
					 resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getUpdate_employee(),list);
				     resRecord.setTask_id(resTask.getId());
				     resRecord.setProject_id(resTask.getProject_id());
					 dataList = resService.getTaskRecordList(resRecord, page);
					 resTask.setCall_times(dataList.size());
					 resTask.setNext_call_time(resCustomer.getNext_call_time());
				}
//未拨打过电话任务				
			}else if(resTask.getTask_flag().equals("T")){
				 resTask.setProject_id(project_id);
				 resTask.setUpdate_dept(update_dept);
				//提交任务结果	
				 resService.commitResearch(resRecord, user, resTask);
				 Integer id = resService.getTaskid(resTask, user);
					if(id==null){
						setTitle("该项目均已拨打电话，请换其他项目任务或任务");
					}else{
						 resTask.setId(id);
						 resProject.setId(resTask.getProject_id());
						 list = resService.getProFieldList2(resProject);
						 resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getUpdate_employee(),list);
					     resRecord.setTask_id(resTask.getId());
					     resRecord.setProject_id(resTask.getProject_id());
						 dataList = resService.getTaskRecordList(resRecord, page);
						 resTask.setCall_times(dataList.size());
						 resTask.setNext_call_time(resCustomer.getNext_call_time());
					}
//此条记录不保存，跳到下一个任务					
			}else if(resTask.getTask_flag().equals("G")){
				resTask.setProject_id(project_id);
				resTask.setUpdate_dept(update_dept);
				Integer id = resService.getTaskid(resTask, user);
				if(id==null){
					setTitle("该项目任务已完成，请换其他项目任务");
					resService.deleteProUser(user, resTask.getProject_id());
				}else{
					 resTask.setId(id);
					 resProject.setId(resTask.getProject_id());
					 list = resService.getProFieldList2(resProject);
					 resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getUpdate_employee(),list);
				     resRecord.setTask_id(resTask.getId());
				     resRecord.setProject_id(resTask.getProject_id());
					 dataList = resService.getTaskRecordList(resRecord, page);
					 resTask.setCall_times(dataList.size());
					 resTask.setNext_call_time(resCustomer.getNext_call_time());
				}
//需要回叫电话任务				
			}else if(resTask.getTask_flag().equals("J")){
				resTask.setProject_id(project_id);
				resTask.setUpdate_dept(update_dept);
				//提交任务结果				
				resService.commitResearch(resRecord, user, resTask);
				Integer id = resService.getTaskid(resTask, user);
				if(id==null){
					setTitle("需要回叫电话任务已完结，请换其他项目任务或任务");
				}else{
					 resTask.setId(id);
					 resProject.setId(resTask.getProject_id());
					 list = resService.getProFieldList2(resProject);
					 resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getUpdate_employee(),list);
				     resRecord.setTask_id(resTask.getId());
				     resRecord.setProject_id(resTask.getProject_id());
					 dataList = resService.getTaskRecordList(resRecord, page);
					 resTask.setCall_times(dataList.size());
					 resTask.setNext_call_time(resCustomer.getNext_call_time());
				}
//拨打过电话任务				
			}else if(resTask.getTask_flag().equals("F")){
				resTask.setProject_id(project_id);
				resTask.setUpdate_dept(update_dept);
				//提交任务结果				
				resService.commitResearch(resRecord, user, resTask);
				Integer id = resService.getTaskid(resTask, user);
				if(id==null){
					setTitle("该项目拨打过电话的任务已完结，请换其他项目任务或任务");
				}else{
					 resTask.setId(id);
					 resProject.setId(resTask.getProject_id());
					 list = resService.getProFieldList2(resProject);
					 resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getUpdate_employee(),list);
				     resRecord.setTask_id(resTask.getId());
				     resRecord.setProject_id(resTask.getProject_id());
					 dataList = resService.getTaskRecordList(resRecord, page);
					 resTask.setCall_times(dataList.size());
					 resTask.setNext_call_time(resCustomer.getNext_call_time());
				}
//未拨打电话任务				
			}else if(resTask.getTask_flag().equals("K")){
				resTask.setProject_id(project_id);
				resTask.setUpdate_dept(update_dept);
				//提交任务结果				
				resService.commitResearch(resRecord, user, resTask);
				Integer id = resService.getTaskid(resTask, user);
				if(id==null){
					setTitle("该项目均已拨打电话，请换其他项目任务或任务");
				}else{
					 resTask.setId(id);
					 resProject.setId(resTask.getProject_id());
					 list = resService.getProFieldList2(resProject);
					 resCustomer = resService.getCustomerByid(resTask.getId(),resTask.getUpdate_employee(),list);
				     resRecord.setTask_id(resTask.getId());
				     resRecord.setProject_id(resTask.getProject_id());
					 dataList = resService.getTaskRecordList(resRecord, page);
					 resTask.setCall_times(dataList.size());
					 resTask.setNext_call_time(resCustomer.getNext_call_time());
				}
			}
		}
		*/
		return "toStartResearch";
	}

	public ResProject getResProject() {
		return resProject;
	}

	public void setResProject(ResProject resProject) {
		this.resProject = resProject;
	}

	public ResImport getResImport() {
		return resImport;
	}

	public void setResImport(ResImport resImport) {
		this.resImport = resImport;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ResField getResField() {
		return resField;
	}

	public void setResField(ResField resField) {
		this.resField = resField;
	}

	public ResPaper getResPaper() {
		return resPaper;
	}

	public void setResPaper(ResPaper resPaper) {
		this.resPaper = resPaper;
	}

	public ResQuestion getResQuestion() {
		return resQuestion;
	}

	public void setResQuestion(ResQuestion resQuestion) {
		this.resQuestion = resQuestion;
	}
	
	public ResTask getResTask() {
		return resTask;
	}

	public void setResTask(ResTask resTask) {
		this.resTask = resTask;
	}
	
	public Integer getProject_id() {
		return project_id;
	}

	public void setProject_id(Integer project_id) {
		this.project_id = project_id;
	}

	public ResRecord getResRecord() {
		return resRecord;
	}

	public void setResRecord(ResRecord resRecord) {
		this.resRecord = resRecord;
	}

	public ResResult getResResult() {
		return resResult;
	}

	public void setResResult(ResResult resResult) {
		this.resResult = resResult;
	}
	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}
	
	public ResCustomer getResCustomer() {
		return resCustomer;
	}

	public void setResCustomer(ResCustomer resCustomer) {
		this.resCustomer = resCustomer;
	}
	public ResSendrecord getResSendrecord() {
		return resSendrecord;
	}

	public void setResSendrecord(ResSendrecord resSendrecord) {
		this.resSendrecord = resSendrecord;
	}
	
	public ExeclImport getExeclImport() {
		return execlImport;
	}

	public void setExeclImport(ExeclImport execlImport) {
		this.execlImport = execlImport;
	}
	public String getTable() {
		return table;
	}
	public void setTable(String table) {
		this.table = table;
	}
	public Integer getUpdate_dept() {
		return update_dept;
	}
	public void setUpdate_dept(Integer update_dept) {
		this.update_dept = update_dept;
	}

//	输出格式1 展示题目时
	private List changeOutPutFormat(List dataList) throws Exception{
		List lists = new ArrayList();
		for (Object obj : dataList) {
			ResQuestion resQuestion = (ResQuestion) obj;
			if (!resQuestion.getType().equals("answerquestion")) {
				List list = new ArrayList();
				if (resQuestion.getColumn().equals("")) {
					resQuestion.setSelectionList(list);
				} else {
					String ss[] = resQuestion.getColumn().split("\\|");
					for (String s : ss) {
						list.add(s);
					}
					resQuestion.setSelectionList(list);
				}
			}
			lists.add(resQuestion);
		}

		return lists;
	}
//	输出格式2 展示题目时
	private List changeOutPutFormat2(List dataList,String str) throws Exception{
		List lists = new ArrayList();
		String strs[] = str.split(",");
		for (Object obj : dataList) {
			ResQuestion resQuestion = (ResQuestion) obj;
			if (!resQuestion.getType().equals("answerquestion")) {
				for(String s: strs){
					String s1[] = s.split(":");
					if(resQuestion.getId()==Integer.parseInt(s1[0])){
						resQuestion.setUserSelect(resQuestion.getUserSelect()+s1[1]);
					}
				}
				List list = new ArrayList();
				if (resQuestion.getColumn().equals("")) {
					resQuestion.setSelectionList(list);
				} else {
					String ss[] = resQuestion.getColumn().split("\\|");
					for (String s : ss) {
						list.add(s);
					}
					resQuestion.setSelectionList(list);
				}
			}else{
				for(String s: strs){
					String s1[] = s.split(":");
					if(resQuestion.getId()==Integer.parseInt(s1[0])){
						resQuestion.setUserSelect(s1[1]);
					}
				}
			}
			lists.add(resQuestion);
		}
		return lists;
	}
	public List getCountList() {
		return countList;
	}
	public void setCountList(List countList) {
		this.countList = countList;
	}
	public List getUserList() {
		return userList;
	}
	public void setUserList(List userList) {
		this.userList = userList;
	}	
	
}
