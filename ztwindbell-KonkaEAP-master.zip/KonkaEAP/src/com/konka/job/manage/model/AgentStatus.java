package com.konka.job.manage.model;

import java.sql.Timestamp;


public class AgentStatus {
	private Integer id;
	private String session_id;
	private String status;
	private Timestamp create_time;
	private Timestamp update_time;
	private Timestamp destory_time;
	private Integer delay_hour;
	private Integer delay_minute;
	private Integer delay_second;
	private String username;
	private String ip;
	private Integer enable_flag;
	private Integer busy_reason;
	private String caller;
	private String called;
	private String vdn;
	//��չ
	private String name;
	private String in_phone;
	private String fullname;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Timestamp getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}
	public Timestamp getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Timestamp update_time) {
		this.update_time = update_time;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public Integer getEnable_flag() {
		return enable_flag;
	}
	public void setEnable_flag(Integer enable_flag) {
		this.enable_flag = enable_flag;
	}
	public Integer getDelay_hour() {
		return delay_hour;
	}
	public void setDelay_hour(Integer delay_hour) {
		this.delay_hour = delay_hour;
	}
	public Integer getDelay_minute() {
		return delay_minute;
	}
	public void setDelay_minute(Integer delay_minute) {
		this.delay_minute = delay_minute;
	}
	public Integer getDelay_second() {
		return delay_second;
	}
	public void setDelay_second(Integer delay_second) {
		this.delay_second = delay_second;
	}
	public Integer getBusy_reason() {
		return busy_reason;
	}
	public void setBusy_reason(Integer busy_reason) {
		this.busy_reason = busy_reason;
	}
	public String getSession_id() {
		return session_id;
	}
	public void setSession_id(String session_id) {
		this.session_id = session_id;
	}
	public Timestamp getDestory_time() {
		return destory_time;
	}
	public void setDestory_time(Timestamp destory_time) {
		this.destory_time = destory_time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIn_phone() {
		return in_phone;
	}
	public void setIn_phone(String in_phone) {
		this.in_phone = in_phone;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getCaller() {
		return caller;
	}
	public void setCaller(String caller) {
		this.caller = caller;
	}
	public String getCalled() {
		return called;
	}
	public void setCalled(String called) {
		this.called = called;
	}
	public String getVdn() {
		return vdn;
	}
	public void setVdn(String vdn) {
		this.vdn = vdn;
	}
}
