package com.konka.job.manage.dao;

import com.konka.common.base.BaseDAO;

public interface AccountDAO extends BaseDAO {

}
