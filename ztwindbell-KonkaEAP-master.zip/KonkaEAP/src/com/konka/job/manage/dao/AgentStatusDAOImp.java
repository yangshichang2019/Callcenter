package com.konka.job.manage.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.manage.model.AgentStatus;
@Repository("agentStatusDAO")
public class AgentStatusDAOImp extends BaseDAOImp implements AgentStatusDAO {
	public AgentStatusDAOImp(){
		super.setMapper("com.konka.job.manage.model.AgentStatus");
	}
	public List getOnline(AgentStatus agentStatus) throws Exception{
		return super.getSqlSessionTemplate().selectList(super.getMapper()+".getOnline", agentStatus);
	}
}
