package com.konka.job.manage.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
@Repository("accountDAO")
public class AccountDAOImp extends BaseDAOImp implements AccountDAO {

}
