package com.konka.job.manage.dao;

import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.job.manage.model.AgentStatus;

public interface AgentStatusDAO extends BaseDAO {
	public List getOnline(AgentStatus agentStatus) throws Exception;
}
