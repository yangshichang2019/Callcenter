package com.konka.job.manage.action;

import java.io.Writer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.job.manage.model.Account;
import com.konka.job.manage.model.AgentStatus;
import com.konka.job.manage.service.ManageService;
import com.konka.system.model.SessionInfo;
import com.konka.useradmin.model.User;
@Controller
@Scope("prototype")
public class ManageAction extends BaseAction {
	@Autowired
	private ManageService manageService;
	private Account account = new Account();
	private AgentStatus agentStatus = new AgentStatus();
	//用户账户列表
	public String toUserAccountList() throws Exception {
		User user = (User)super.getSession().get(Constant.SESSION_USER);
		account.setUsername(user.getUsername());
		account.setEnable_flag("T");
		dataList = manageService.getAccountList(account,page);
		return "toUserAccountList";
	}
	//绑定账户
	public String toAddEditAccount() throws Exception {
		
		return "toAddEditAccount";
	}
	//保存账户
	public String toSaveAccount() throws Exception {
		
		return "toSaveAccount";
	}
	//访问系统
	public String toVisiteByAccount() throws Exception {
		return "toVisiteByAccount";
	}
	
	//查看在线坐席
	public String toViewAgent() throws Exception {
		dataList = manageService.getOnline(agentStatus);
		return "toViewAgent";
	}
	//查看在线坐席json
	public String toViewAgentJson() throws Exception {
		
		dataList = manageService.getOnline(agentStatus);
		
		super.getResponse().setContentType("text/plain;charset=gbk");
		super.getResponse().setCharacterEncoding("GBK");
		Writer out = super.getResponse().getWriter();		
		StringBuilder s = new StringBuilder("{");
		AgentStatus vo = null;
		for(int i=0;i<dataList.size();i++) {
			vo = (AgentStatus)dataList.get(i);
			if(vo.getName()==null) {
				vo.setName(vo.getUsername());
			}
			if(s.indexOf("\""+vo.getName()+"\"")<0){
				s.append("\""+vo.getName()+"\":");
				s.append("[{");
				s.append("\"a\":\""+vo.getStatus()+"\",");//status
				if(vo.getDelay_hour()>0) {
					s.append("\"b\":\""+vo.getDelay_hour()+":");//delay_hour
				}else {
					s.append("\"b\":\"");//delay_hour
				}
				if(vo.getDelay_minute()<10) {
					s.append("0"+vo.getDelay_minute()+":");//delay_minute
				}else {
					s.append(vo.getDelay_minute()+":");//delay_minute
				}
				if(vo.getDelay_second()<10) {
					s.append("0"+vo.getDelay_second()+"\",");//delay_second
				}else {
					s.append(vo.getDelay_second()+"\",");//delay_second
				}
				if(vo.getBusy_reason()==null) {
					s.append("\"c\":\"\",");//busy_reason
				}else {
					s.append("\"c\":\""+vo.getBusy_reason()+"\",");//busy_reason
				}
				s.append("\"d\":\""+vo.getIn_phone()+"\",");//in_phone
				s.append("\"e\":\""+vo.getUsername()+"\",");//create_employee
				s.append("\"f\":\""+vo.getFullname()+"\",");//fullname
				if(vo.getCaller()==null) {
					s.append("\"g\":\"\",");//caller
				}else {
					s.append("\"g\":\""+vo.getCaller()+"\",");//caller
				}
				if(vo.getCalled()==null) {
					s.append("\"h\":\"\",");//called
				}else {
					s.append("\"h\":\""+vo.getCalled()+"\",");//called
				}
				if(vo.getVdn()==null) {
					s.append("\"i\":\"\"");//vdn
				}else {
					s.append("\"i\":\""+vo.getVdn()+"\"");//vdn
				}
				s.append("}],");
			}

		}
		String st = s.toString();
		st = st.substring(0, st.length()-1);
		st = st + "}";
		out.write(st);
		out.flush();
		out.close();
		
		return null;
	}
	
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public ManageService getManageService() {
		return manageService;
	}
	public void setManageService(ManageService manageService) {
		this.manageService = manageService;
	}
	public AgentStatus getAgentStatus() {
		return agentStatus;
	}
	public void setAgentStatus(AgentStatus agentStatus) {
		this.agentStatus = agentStatus;
	}
}
