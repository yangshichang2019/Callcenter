package com.konka.job.manage.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.job.manage.model.Account;
import com.konka.job.manage.model.AgentStatus;
import com.konka.useradmin.model.User;

public interface ManageService {
	public List getAccountList(Account account,Page page) throws Exception;
	public List getOnline(AgentStatus agentStatus) throws Exception;
}
