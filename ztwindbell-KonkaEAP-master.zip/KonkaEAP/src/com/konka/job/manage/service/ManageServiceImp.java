package com.konka.job.manage.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.manage.dao.AccountDAO;
import com.konka.job.manage.dao.AgentStatusDAO;
import com.konka.job.manage.model.Account;
import com.konka.job.manage.model.AgentStatus;
import com.konka.system.model.SessionInfo;
import com.konka.useradmin.model.User;

@Service("manageService")
@Transactional  
public class ManageServiceImp implements ManageService {
	@Autowired
	private AccountDAO accountDAO;
	@Autowired
	private AgentStatusDAO agentStatusDAO;
	public List getAccountList(Account account,Page page) throws Exception{
		return accountDAO.getObjectList(account, page);
	}
	public List getOnline(AgentStatus agentStatus) throws Exception{
		return agentStatusDAO.getOnline(agentStatus);
	}
}
