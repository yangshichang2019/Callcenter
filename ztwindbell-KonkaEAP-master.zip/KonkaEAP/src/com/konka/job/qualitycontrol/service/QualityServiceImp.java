package com.konka.job.qualitycontrol.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.qualitycontrol.dao.CheckSpotDAO;
import com.konka.job.qualitycontrol.dao.ComplainResDAO;
import com.konka.job.qualitycontrol.dao.ContentItemDAO;
import com.konka.job.qualitycontrol.dao.QcComplainDAO;
import com.konka.job.qualitycontrol.dao.QcContentDAO;
import com.konka.job.qualitycontrol.dao.QcEmployeeDAO;
import com.konka.job.qualitycontrol.dao.QcPlanDAO;
import com.konka.job.qualitycontrol.dao.QcTaskDAO;
import com.konka.job.qualitycontrol.dao.SatisficationDAO;
import com.konka.job.qualitycontrol.model.CheckSpot;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.ContentItem;
import com.konka.job.qualitycontrol.model.QcComplain;
import com.konka.job.qualitycontrol.model.QcContent;
import com.konka.job.qualitycontrol.model.QcEmployee;
import com.konka.job.qualitycontrol.model.QcPlan;
import com.konka.job.qualitycontrol.model.QcTask;
import com.konka.job.qualitycontrol.model.Satisfication;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;

/**
 * @author wangchen
 * 
 */

@Service("QualityService")
@Transactional
public class QualityServiceImp implements QualityService {
	@Autowired
	private SatisficationDAO satisficationDAO;
	@Autowired
	private QcContentDAO qcContentDAO;
	@Autowired
	private ContentItemDAO contentItemDAO;
	@Autowired
	private QcPlanDAO qcPlanDAO;
	@Autowired
	private QcTaskDAO qcTaskDAO;
	@Autowired
	private CheckSpotDAO checkSpotDAO;
	@Autowired
	private QcComplainDAO qcComplainDAO;
	@Autowired
	private ComplainResDAO complainResDAO;
	@Autowired
	private QcEmployeeDAO qcEmployeeDAO;
	@Autowired
	private SystemService systemService;
	@Autowired
	private UserAdminService userAdminService;

	@Override
	public List<Satisfication> getSatisficationList(
			Satisfication satisfication, Page page) throws Exception {
		try {
			return satisficationDAO.getSatisfitionList(satisfication, page);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<QcContent> getQcContentList(QcContent qcContent, Page page)
			throws Exception {
		return qcContentDAO.getObjectList(qcContent, page);
	}

	@Override
	public QcContent getContent(QcContent qcContent) throws Exception {
		return (QcContent) qcContentDAO.getById(qcContent.getId());
	}

	@Override
	public String saveContent(QcContent qcContent, User user) throws Exception {
		if (qcContent.getId() == null) {
			QcContent Content = qcContentDAO.getContentByName(qcContent);
			if (Content == null) {
				Util.setCreateToVO(qcContent, user);
				qcContentDAO.insert(qcContent);
				return null;
			} else {
				return "T";
			}
		} else {
			Util.setUpdateToVO(qcContent, user);
			qcContentDAO.update(qcContent);
			return null;
		}
	}

	@Override
	public List getContentItemList(ContentItem contentItem) throws Exception {
		return contentItemDAO.getAllList(contentItem);
	}

	@Override
	public ContentItem getContentItem(ContentItem contentItem) throws Exception {
		return (ContentItem) contentItemDAO.getById(contentItem.getId());
	}

	@Override
	public String saveContentItem(ContentItem contentItem, User user)
			throws Exception {
		if (contentItem.getId() == null) {
			ContentItem Content = contentItemDAO
					.getContentItemByName(contentItem);
			if (Content == null) {
				Util.setCreateToVO(contentItem, user);
				contentItemDAO.insert(contentItem);
				return null;
			} else {
				return "T";
			}
		} else {
			Util.setUpdateToVO(contentItem, user);
			contentItemDAO.update(contentItem);
			return null;
		}
	}

	@Override
	public List getPlanList(QcPlan qcPlan, Page page) throws Exception {
		return qcPlanDAO.getObjectList(qcPlan, page);
	}

	@Override
	public QcPlan getPlan(QcPlan qcPlan) throws Exception {
		return (QcPlan) qcPlanDAO.getById(qcPlan.getId());
	}

	@Override
	public List getContentList(QcContent qcContent) throws Exception {
		return qcContentDAO.getAllList(qcContent);
	}

	@Override
	public String savePlan(QcPlan qcPlan, User user, List list)
			throws Exception {
		if (qcPlan.getId() == null) {
			QcPlan plan = qcPlanDAO.getPlanByName(qcPlan);
			if (plan == null) {
				Util.setCreateToVO(qcPlan, user);
				qcPlanDAO.insert(qcPlan);
				List tempList = new ArrayList();
				for (int i = 0; i < list.size(); i++) {
					User employee = (User) list.get(i);
					QcEmployee qcEmployee = new QcEmployee();
					qcEmployee.setPlan_id(qcPlan.getId());
					qcEmployee.setEmployee(employee.getUsername());
					qcEmployee.setEmployee_name(employee.getFullname());
					qcEmployee.setQuality_times(qcPlan.getQuality_times());
					qcEmployee.setReal_times(0);
					Util.setCreateToVO(qcEmployee, user);
					qcEmployee.setCreate_dept(qcPlan.getCreate_dept());
					tempList.add(qcEmployee);
				}
				if (tempList.size() > 0) {
					qcEmployeeDAO.insertBatch(tempList);
				}
				return null;
			} else {
				return "T";
			}
		} else {
			 SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			 Date d =  df.parse(qcPlan.getPlan_start());
			 Date now = new Date();
			 long time = now.getTime() - d.getTime();
			if(time>=0){
				return "F";
			}else{
				Util.setUpdateToVO(qcPlan, user);
				qcPlanDAO.update(qcPlan);
				qcTaskDAO.delete(qcPlan.getId());
				qcEmployeeDAO.delete(qcPlan.getId());
				
				List tempList = new ArrayList();
				for (int i = 0; i < list.size(); i++) {
					User employee = (User) list.get(i);
					QcEmployee qcEmployee = new QcEmployee();
					qcEmployee.setPlan_id(qcPlan.getId());
					qcEmployee.setEmployee(employee.getUsername());
					qcEmployee.setEmployee_name(employee.getFullname());
					qcEmployee.setQuality_times(qcPlan.getQuality_times());
					qcEmployee.setReal_times(0);
					Util.setCreateToVO(qcEmployee, user);
					tempList.add(qcEmployee);
				}
				if (tempList.size() > 0) {
					qcEmployeeDAO.insertBatch(tempList);
				}
				
				return null;
			}
		}
	}

	// 解析json获取派务者工号
	private String getuserName(String executor_ids) {
		return executor_ids.substring(executor_ids.indexOf(":") + 2,
				executor_ids.length() - 2);
	}

	private List getRecordList(QcPlan qcPlan, User employee) throws Exception {
		qcPlan.setValues(employee.getUsername());
		if(qcPlan.getMode().equals("F")){
			List list = qcPlanDAO.getVoiceRecordList(qcPlan);
			List recordlist = new ArrayList();
			if (list.size() == 0) {
				return null;
			} else {
				// 判断获取的录音数量是否小于等于需要的数量
				if (list.size() <= qcPlan.getQuality_times()) {
					// 小于则直接赋值
					recordlist = list;
				} else {
					// 大于则随机抽取需要的数量
					for (int i = 0; i < qcPlan.getQuality_times(); i++) {
						int count = (int) (Math.random() * (list.size() - 1));
						recordlist.add(list.get(count));
						list.remove(count);
					}
				}
				String str = "";
				for (Object object : recordlist) {
					QcPlan plan = (QcPlan) object;
					str = str + "'" + plan.getRid() + "'" + ",";
				}
				QcTask qcTask = new QcTask();
				qcTask.setValues(str.substring(0, str.length() - 1));
				return qcTaskDAO.getVoiceRecordList(qcTask);
			}
			
		}else if(qcPlan.getMode().equals("T")){
			List list2 = qcPlanDAO.getVoiceRecordList2(qcPlan);
			List list = new ArrayList();
			if(list2.size()==0){
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				Date d =  df.parse(qcPlan.getCall_end());
				Date now = new Date();
				long time = now.getTime() - d.getTime();
				if(time>0){
					list = qcPlanDAO.getVoiceRecordList(qcPlan);
				}
			}else{
				 list = list2;
			}
			List recordlist = new ArrayList();
			if (list.size() == 0) {
				return null;
			} else {
				// 判断获取的录音数量是否小于等于需要的数量
				if (list.size() <= qcPlan.getQuality_times()) {
					// 小于则直接赋值
					recordlist = list;
				} else {
					// 大于则随机抽取需要的数量
					for (int i = 0; i < qcPlan.getQuality_times(); i++) {
						int count = (int) (Math.random() * (list.size() - 1));
						recordlist.add(list.get(count));
						list.remove(count);
					}
				}
				String str = "";
				for (Object object : recordlist) {
					QcPlan plan = (QcPlan) object;
					str = str + "'" + plan.getRid() + "'" + ",";
				}
				QcTask qcTask = new QcTask();
				qcTask.setValues(str.substring(0, str.length() - 1));
				return qcTaskDAO.getVoiceRecordList(qcTask);
			}
			
		}else if(qcPlan.getMode().equals("V")){
			List list2 = qcPlanDAO.getVoiceRecordList3(qcPlan);
			List list = new ArrayList();
			if(list2.size()==0){
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				Date d =  df.parse(qcPlan.getCall_end());
				Date now = new Date();
				long time = now.getTime() - d.getTime();
				if(time>0){
					list = qcPlanDAO.getVoiceRecordList(qcPlan);
				}
			}else{
				 list = list2;
			}
			List recordlist = new ArrayList();
			if (list.size() == 0) {
				return null;
			} else {
				// 判断获取的录音数量是否小于等于需要的数量
				if (list.size() <= qcPlan.getQuality_times()) {
					// 小于则直接赋值
					recordlist = list;
				} else {
					// 大于则随机抽取需要的数量
					for (int i = 0; i < qcPlan.getQuality_times(); i++) {
						int count = (int) (Math.random() * (list.size() - 1));
						recordlist.add(list.get(count));
						list.remove(count);
					}
				}
				String str = "";
				for (Object object : recordlist) {
					QcPlan plan = (QcPlan) object;
					str = str + "'" + plan.getRid() + "'" + ",";
				}
				QcTask qcTask = new QcTask();
				qcTask.setValues(str.substring(0, str.length() - 1));
				return qcTaskDAO.getVoiceRecordList(qcTask);
			}
			
		}else{
			List list2 = qcPlanDAO.getVoiceRecordList4(qcPlan);
			List list = new ArrayList();
			if(list2.size()==0){
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
				Date d =  df.parse(qcPlan.getCall_end());
				Date now = new Date();
				long time = now.getTime() - d.getTime();
				if(time>0){
					list = qcPlanDAO.getVoiceRecordList(qcPlan);
				}
			}else{
				 list = list2;
			}
			List recordlist = new ArrayList();
			if (list.size() == 0) {
				return null;
			} else {
				// 判断获取的录音数量是否小于等于需要的数量
				if (list.size() <= qcPlan.getQuality_times()) {
					// 小于则直接赋值
					recordlist = list;
				} else {
					// 大于则随机抽取需要的数量
					for (int i = 0; i < qcPlan.getQuality_times(); i++) {
						int count = (int) (Math.random() * (list.size() - 1));
						recordlist.add(list.get(count));
						list.remove(count);
					}
				}
				String str = "";
				for (Object object : recordlist) {
					QcPlan plan = (QcPlan) object;
					str = str + "'" + plan.getRid() + "'" + ",";
				}
				QcTask qcTask = new QcTask();
				qcTask.setValues(str.substring(0, str.length() - 1));
				return qcTaskDAO.getVoiceRecordList(qcTask);
			}
		}
	}

	@Override
	public List<QcTask> getPlanTaskList(QcTask qcTask, Page page)
			throws Exception {
		return qcTaskDAO.getObjectList(qcTask, page);
	}
	
	@Override
	public List<QcTask> getPlanTaskList2(QcTask qcTask, Page page)
			throws Exception {
		return qcTaskDAO.getObjectList2(qcTask, page);
	}

	@Override
	public QcTask getTask(QcTask qcTask) throws Exception {
		return (QcTask) qcTaskDAO.getById(qcTask.getId());
	}

	@Override
	public void EvaluateTask(QcTask qcTask, User user) throws Exception {
		qcTask.setEnable_flag("T");
		if(qcTask.getCreate_dept()==null){
			 qcTask.setCreate_dept(2);
		}
		Util.setUpdateToVO(qcTask, user);
		qcTaskDAO.update(qcTask);

	}

	@Override
	public List getEvaluatedTask(QcTask qcTask) throws Exception {
		QcPlan qcPlan = (QcPlan) qcPlanDAO.getById(qcTask.getPlan_id());
		ContentItem contentItem = new ContentItem();
		contentItem.setContent_id(qcPlan.getContent_id());
		return contentItemDAO.getAllList(contentItem);
	}

	@Override
	public void updatePlan(Integer plan_id, User user) throws Exception {
		QcPlan plan = new QcPlan();
		plan.setId(plan_id);
		plan.setEnable_flag("T");
		Util.setUpdateToVO(plan, user);
		qcPlanDAO.update(plan);
	}

	public List<ContentItem> getContentItemList(String result, List list) {
		String str[] = result.split(",");
		for (int i = 0; i < list.size(); i++) {
			int id = ((ContentItem) list.get(i)).getId();
			for (int j = 0; j < str.length; j++) {
				String strs[] = str[j].split(":");
				if (id == Integer.parseInt(strs[0])) {
					((ContentItem) list.get(i)).setValues(strs[1]);
				}
			}
		}
		return list;
	}

	@Override
	public List getPlanList2(QcPlan qcPlan, Page page) {
		return qcPlanDAO.getCheckSpotList(qcPlan, page);
	}

	@Override
	public String saveCheckspot(QcPlan qcPlan, User user) throws Exception {
		if (qcPlan.getId() == null) {
			QcPlan plan = qcPlanDAO.getCheckspotByName(qcPlan);
			if (plan == null) {
				Util.setCreateToVO(qcPlan, user);
				qcPlanDAO.insertCheckspot(qcPlan);
				String str[] = qcPlan.getEmployees().split(",");
				for(String strs:str){
					qcPlan.setExecutor(strs.substring(strs.indexOf("[")+1,strs.length()-1));
					List list = qcPlanDAO.getCheckSpotList(qcPlan);
					insertCheckspotBatch(qcPlan,list, user);
				}
				
				
				return null;
			} else {
				return "T";
			}
		} else {
			Util.setUpdateToVO(qcPlan, user);
			qcPlanDAO.update(qcPlan);
			return null;
		}
	}

	private void insertCheckspotBatch(QcPlan qcPlan, List list, User user) throws Exception {
	
		if(list.size()!=0){
			List listCheckSpot = new ArrayList();
			if(list.size()>qcPlan.getQuality_times()){
				//当取得某个质检员在这段时间的考评量，若大于安排抽检量则随机抽取安排的数量				
				list = getCheckSpotList(list,qcPlan.getQuality_times());
				for(Object object:list){
					CheckSpot checkSpot = new CheckSpot();
					checkSpot.setPlan_id(qcPlan.getId());
					checkSpot.setTask_id(((QcPlan)object).getId());
					Util.setCreateToVO(checkSpot, user);
					listCheckSpot.add(checkSpot);
				}
			}else{
				for(Object object:list){
					CheckSpot checkSpot = new CheckSpot();
					checkSpot.setPlan_id(qcPlan.getId());
					checkSpot.setTask_id(((QcPlan)object).getId());
					Util.setCreateToVO(checkSpot, user);
					listCheckSpot.add(checkSpot);
				}
			}
			checkSpotDAO.insertBatch(listCheckSpot);
		}
	}

	private List getCheckSpotList(List list,int counts) {
		List listCheckSpot = new ArrayList();
		for(int i=0;i<counts;i++){
			int count = (int) (Math.random() * (list.size() - 1));
			listCheckSpot.add(list.get(count));
			list.remove(count);
		}
		return listCheckSpot;
	}

	@Override
	public List getCheckSpotList(CheckSpot checkSpot, Page page)
			throws Exception {
		return checkSpotDAO.getObjectList(checkSpot, page);
	}

	@Override
	public void saveCheckspotRes(CheckSpot checkSpot, User user) throws Exception {
		 checkSpot.setEnable_flag("T");
		 Util.setUpdateToVO(checkSpot, user);
		 checkSpotDAO.update(checkSpot);
	}

	@Override
	public void saveComplain(QcComplain qcComplain, ComplainRes complainRes, User user) throws Exception {
		QcComplain  complain = (QcComplain) qcComplainDAO.getById2(qcComplain.getTask_id());
		if (complain == null) {
			Util.setCreateToVO(qcComplain, user);
			Util.setCreateToVO(complainRes, user);
			qcComplainDAO.insert(qcComplain);
			complainRes.setRes_flag("E");
			complainRes.setComplain_id(qcComplain.getId());
			complainResDAO.insert(complainRes);
			List userList = userAdminService.strToUserList("{\"group\":\""+25+"\"}");
			systemService.insertRemind("QUALITY", complainRes.getId(),"新质检申诉等待处理", "由 "+qcComplain.getCreate_employee()+" 创建的质检申诉等待处理中。", null, null, userList, user);
			
			
		} else {
			if(complain.getComplain_flag().equals("A")){
				complain.setComplain_flag("B");
				complain.setComplain_res("F");
				complainRes.setRes_flag("B");
				Util.setUpdateToVO(complain, user);
				complain.setComplain_status("G");
				qcComplainDAO.update(complain);
				complainRes.setComplain_id(complain.getId());
				Util.setCreateToVO(complainRes, user);
				complainResDAO.insert(complainRes);
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉等待处理", "由 "+complain.getCreate_employee()+" 创建的质检二次申诉等待处理中。", null, null, "65053", user);
			}else if(complain.getComplain_flag().equals("B")){
				complain.setComplain_flag("C");
				complain.setComplain_res("F");
				complainRes.setRes_flag("C");
				Util.setUpdateToVO(complain, user);
				complain.setComplain_status("G");
				qcComplainDAO.update(complain);
				complainRes.setComplain_id(complain.getId());
				Util.setCreateToVO(complainRes, user);
				complainResDAO.insert(complainRes);
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉等待处理", "由 "+complain.getCreate_employee()+" 创建的质检三次申诉等待处理中。", null, null, "zhenyong", user);
			}else if(complain.getComplain_flag().equals("E")){
				complain.setComplain_flag("E");
				complain.setComplain_res("F");
				Util.setUpdateToVO(complain, user);
				complain.setComplain_status("G");
				qcComplainDAO.update(complain);
				complainRes.setComplain_id(complain.getId());
				Util.setCreateToVO(complainRes, user);
				complainRes.setEnable_flag("F");
				complainResDAO.updateByComplainId(complainRes);
				List userList = userAdminService.strToUserList("{\"group\":\""+25+"\"}");
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉等待处理", "由 "+complain.getCreate_employee()+" 创建的质检申诉等待处理中。", null, null, userList, user);
			}
		}
	}

	@Override
	public QcComplain getComplain(QcComplain qcComplain) throws Exception {
		QcComplain  complain = (QcComplain) qcComplainDAO.getById(qcComplain.getId());
		return complain;
	}
	
	
	@Override
	public QcComplain getComplain2(QcComplain qcComplain) throws Exception {
		QcComplain  complain = (QcComplain) qcComplainDAO.getById2(qcComplain.getTask_id());
		return complain;
	}

	@Override
	public List getComplaintCheckList(ComplainRes complainRes,
			Page page) throws Exception {
		List list1 = complainResDAO.getObjectList(complainRes, page);
		if(complainRes.getCreate_time()!=null){
			complainRes.setUpdate_time(complainRes.getCreate_time());
			complainRes.setCreate_time(null);
			List list2 = complainResDAO.getObjectList(complainRes, page);
			if(list2.size()>0){
				for(int i=0;i<list2.size();i++){
					ComplainRes cres = (ComplainRes)list2.get(i);
					complainRes.setUpdate_time(Util.getTimestamp());
					complainRes.setValues(""+cres.getId());
					complainRes.setValues2(""+cres.getComplain_id());
					complainResDAO.updateRes(complainRes);
					complainResDAO.updateComRes(complainRes);
				}
			}
		}
		return list1;
	}

	@Override
	public ComplainRes getComplainRes(ComplainRes complainRes) throws Exception {
		return (ComplainRes) complainResDAO.getById(complainRes.getId());
	}

	@Override
	public void saveCheckRes(ComplainRes complainRes, User user) throws Exception {
		
		QcComplain complain = new QcComplain();
		complain.setId(complainRes.getComplain_id());
		QcComplain vo= (QcComplain) qcComplainDAO.getById(complainRes.getComplain_id());
		if(complainRes.getRes_flag().equals("E")){
			if(complainRes.getResult().equals("T")){
				complain.setComplain_flag("A");
				complainRes.setRes_flag("A");
				complainRes.setRemark("");
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉状态改变", "您的质检申诉由初阅状态进入一次审核。", null, null, vo.getCreate_employee(), user);
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉等待处理", "由 "+vo.getCreate_employee()+" 创建的质检一次申诉等待处理中。", null, null, "60052", user);
			}else{
				complain.setComplain_res("T");
				complain.setComplain_status(complainRes.getResult());
				complainRes.setEnable_flag("T");
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉状态改变", "您的申诉被驳回。", null, null,  vo.getCreate_employee(), user);
			}
		}else{
			complain.setId(complainRes.getComplain_id());
			complain.setComplain_res("T");
			complain.setComplain_status(complainRes.getResult());
			complainRes.setEnable_flag("T");
			if(complainRes.getResult().equals("T")){
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉状态改变", "您的申诉已通过。", null, null,  vo.getCreate_employee(), user);
			}else{
				systemService.insertRemind("QUALITY", complainRes.getId(),"质检申诉状态改变", "您的申诉被驳回。", null, null,  vo.getCreate_employee(), user);
			}
		}
		Util.setUpdateToVO(complainRes, user);
		Util.setUpdateToVO(complain, user);
		qcComplainDAO.update(complain);
		complainResDAO.update(complainRes);
	}

	@Override
	public List getComplainResList(ComplainRes complainRes) throws Exception {
		return complainResDAO.getAllList(complainRes);
	}

	@Override
	public List getComplainResLast(QcComplain qcComplain)
			throws Exception {
		return qcComplainDAO.ComplainResLast(qcComplain);
	}

	@Override
	public List getComplainList(QcComplain qcComplain, Page page) throws Exception {
		return qcComplainDAO.getObjectList(qcComplain, page);
	}

	@Override
	public List getComplainAll(ComplainRes complainRes) throws Exception {
		return complainResDAO.getAllList(complainRes);
	}

	@Override
	public List getAllRecordList(QcTask qcTask, Page page) throws Exception {
		return qcTaskDAO.getAllRecordList(qcTask, page);
	}
	
	@Override
	public List getAllRecordList2(QcTask qcTask, Page page) throws Exception {
		return qcTaskDAO.getAllRecordList2(qcTask, page);
	}

	@Override
	public List getAllComplainResList(ComplainRes complainRes) throws Exception {
		return complainResDAO.getAllListComRes(complainRes);
	}

	@Override
	public List getallTaskByT(QcTask qcTask) throws Exception {
		return qcTaskDAO.getAllList(qcTask);
	}

	@Override
	public QcTask getTaskRecord(QcTask qcTask) {
		return qcTaskDAO.getTaskRecord(qcTask);
	}
	@Override
	public QcTask getTaskRecord2(QcTask qcTask) {
		return qcTaskDAO.getTaskRecord2(qcTask);
	}

	@Override
	public void insertTaskRecord(QcTask qcTask,User user) throws Exception {
		 Timestamp now = Util.getTimestamp();
		 qcTask.setCreate_employee(user.getUsername());
		 qcTask.setCreate_time(now);
		 if(qcTask.getCreate_dept()==null){
			 qcTask.setCreate_dept(2);
		 }
		 Util.setUpdateToVO(qcTask, user);
		 qcTaskDAO.insert(qcTask);
	}

	@Override
	public List toPlanEmployeeList(QcEmployee qcEmployee) throws Exception {
		return qcEmployeeDAO.getAllList(qcEmployee);
	}

	@Override
	public void checkEmployeeTask(QcEmployee qcEmployee,User user) throws Exception {
		qcEmployee = (QcEmployee) qcEmployeeDAO.getById(qcEmployee.getId());
		if(qcEmployee.getEnable_flag().equals("F")){
			int zhi =  qcEmployee.getQuality_times()-qcEmployee.getReal_times();
			List tempList = new ArrayList();
		    QcPlan 	qcPlan = (QcPlan) qcPlanDAO.getById(qcEmployee.getPlan_id());
		    qcPlan.setQuality_times(zhi);
		    User employee = new User();
		    employee.setUsername(qcEmployee.getEmployee());
			List recordList = getRecordList(qcPlan, employee);
			if (recordList != null) {
				for (Object object : recordList) {
					QcTask qcTask = (QcTask) object;
					qcTask.setPlan_id(qcPlan.getId());
					qcTask.setExecutor(qcPlan.getExecutor().substring(qcPlan.getExecutor().indexOf("[")+1,qcPlan.getExecutor().length()-1));
					qcTask.setContent_id(qcPlan.getContent_id());
					qcTask.setTask_start(qcPlan.getPlan_start());
					qcTask.setTask_end(qcPlan.getPlan_end());
					Util.setCreateToVO(qcTask, user);
					tempList.add(qcTask);
				}
			}
			if (tempList.size() > 0) {
				qcTaskDAO.insertBatch(tempList);
				qcEmployee.setReal_times(tempList.size());
				if(tempList.size()==zhi){
					qcEmployee.setEnable_flag("T");
				}
				Util.setUpdateToVO(qcEmployee, user);
				qcEmployeeDAO.update(qcEmployee);
			}
		}
	}

	@Override
	public void updatePlanEmployee(QcTask task,User user) throws Exception {
		QcEmployee qc = new QcEmployee();
		qc.setPlan_id(task.getPlan_id());
		qc.setEmployee(task.getEmployee());
		qc.setT_flag("T");
		Util.setUpdateToVO(qc, user);
		qcEmployeeDAO.updateEmployee(qc);
	}

	@Override
	public List getAvgRecordList(QcTask qcTask, Page page) throws Exception {
		return qcTaskDAO.getAvgRecordList(qcTask, page);
	}

	@Override
	public void deleteRecord(QcTask qcTask) {
		 qcTaskDAO.deleteRecord(qcTask);
		 qcTaskDAO.deleteRecordComplain(qcTask);
		 qcTaskDAO.deleteRecordCheckspot(qcTask);
	}

	@Override
	public CheckSpot getCheckSpot(CheckSpot checkSpot) throws Exception {
		return (CheckSpot) checkSpotDAO.getById(checkSpot.getId());
	}

	@Override
	public String getServiceType(String ueid) throws Exception {
		return qcTaskDAO.getTelServiceType(ueid);
	}

	@Override
	public String getServiceType2(Integer id) {
		return qcTaskDAO.getTelServiceType2(id);
	}
	
	
}
