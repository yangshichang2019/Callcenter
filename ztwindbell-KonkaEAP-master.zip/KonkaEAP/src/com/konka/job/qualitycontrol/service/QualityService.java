package com.konka.job.qualitycontrol.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.job.qualitycontrol.model.CheckSpot;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.ContentItem;
import com.konka.job.qualitycontrol.model.QcComplain;
import com.konka.job.qualitycontrol.model.QcContent;
import com.konka.job.qualitycontrol.model.QcEmployee;
import com.konka.job.qualitycontrol.model.QcPlan;
import com.konka.job.qualitycontrol.model.QcTask;
import com.konka.job.qualitycontrol.model.Satisfication;
import com.konka.useradmin.model.User;

public interface QualityService {

	// 获取满意度报表
	public List<Satisfication> getSatisficationList(
			Satisfication satisfication, Page page) throws Exception;

//---------------------------------------------------------------------------------
	// 获取考评内容列表
	public List<QcContent> getQcContentList(QcContent qcContent, Page page)
			throws Exception;

	// 获取考评内容
	public QcContent getContent(QcContent qcContent) throws Exception;

	// 修改或新建考评内容
	public String saveContent(QcContent qcContent, User user) throws Exception;
	
	//获取考评内容项目列表
	public List getContentItemList(ContentItem contentItem)throws Exception;
	//获取考评内容项目
	public ContentItem getContentItem(ContentItem contentItem)throws Exception;
	//保存或修改考评内容项目
	public String saveContentItem(ContentItem contentItem, User user)throws Exception;
	//获取考评计划列表
	public List getPlanList(QcPlan qcPlan, Page page)throws Exception;
	
	public QcPlan getPlan(QcPlan qcPlan)throws Exception;
	//得到所有考评内容	
	public List getContentList(QcContent qcContent)throws Exception;
	//保存或修改考评计划
	public String savePlan(QcPlan qcPlan, User user,List list)throws Exception;
	// 获取考评计划执行情况
		public List<QcTask> getPlanTaskList2(QcTask qcTask, Page page)throws Exception;
	// 获取考评计划执行情况
	public List<QcTask> getPlanTaskList(QcTask qcTask, Page page)throws Exception;
	//	获取质检任务
	public QcTask getTask(QcTask qcTask)throws Exception;
	//修改质检任务
	public void EvaluateTask(QcTask qcTask, User user) throws Exception;

	public List getEvaluatedTask(QcTask qcTask) throws Exception;
	//修改质检计划变成完成状态	
	public void updatePlan(Integer plan_id, User user) throws Exception;
	
	public List getContentItemList(String result, List list) throws Exception;
	//二次抽检计划	
	public List getPlanList2(QcPlan qcPlan, Page page);
	//保存或修改抽检计划	
	public String saveCheckspot(QcPlan qcPlan, User user)throws Exception;

	public List getCheckSpotList(CheckSpot checkSpot, Page page)throws Exception;

	public void saveCheckspotRes(CheckSpot checkSpot, User user)throws Exception;
	//创建申诉
	public void saveComplain(QcComplain qcComplain, ComplainRes complainRes, User user)throws Exception;

	public QcComplain getComplain(QcComplain qcComplain)throws Exception;
	
	
	public QcComplain getComplain2(QcComplain qcComplain)throws Exception;

	public List getComplaintCheckList(ComplainRes complainRes, Page page)throws Exception;

	public ComplainRes getComplainRes(ComplainRes complainRes)throws Exception;

	public void saveCheckRes(ComplainRes complainRes, User user) throws Exception;

	public List getComplainResList(ComplainRes complainRes) throws Exception;
	//获取是否已经审批通过
	public List getComplainResLast(QcComplain qcComplain) throws Exception;
	//综合查询 申诉
	public List getComplainList(QcComplain qcComplain, Page page) throws Exception;
	//获取所有申诉包括还未审核的
	public List getComplainAll(ComplainRes complainRes) throws Exception;
	//获取所有电话记录
	public List getAllRecordList(QcTask qcTask, Page page) throws Exception;
	//获取所有电话记录
	public List getAllRecordList2(QcTask qcTask, Page page) throws Exception;
	//获取某些complian_id	下所有的具体申诉
	public List getAllComplainResList(ComplainRes complainRes) throws Exception;
	//获取所有任务
	public List getallTaskByT(QcTask qcTask)throws Exception;
	//从录音中读取此次任务
	public QcTask getTaskRecord(QcTask qcTask);
	public QcTask getTaskRecord2(QcTask qcTask);
	//单次插入
	public void insertTaskRecord(QcTask qcTask, User user) throws Exception;
	//获取该计划所有的被调查员工	
	public List toPlanEmployeeList(QcEmployee qcEmployee) throws Exception;
	//验证质检员任务是否完成	
	public void checkEmployeeTask(QcEmployee qcEmployee, User user) throws Exception;
	//修改状态EMPLOYEE	
	public void updatePlanEmployee(QcTask task, User user) throws Exception;
	//计算客服平均分
	public List getAvgRecordList(QcTask qcTask, Page page)throws Exception;
	//删除此次评分
	public void deleteRecord(QcTask qcTask);
	//获取抽检
	public CheckSpot getCheckSpot(CheckSpot checkSpot) throws Exception;
	
	
	
	//获取电话服务类型
	public String getServiceType(String  ueid) throws Exception;
	//获取电话服务类型2
	public String getServiceType2(Integer id);
	
	
}
