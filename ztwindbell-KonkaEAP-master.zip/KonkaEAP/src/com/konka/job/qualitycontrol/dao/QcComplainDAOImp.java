package com.konka.job.qualitycontrol.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.QcComplain;
import com.konka.job.qualitycontrol.model.QcContent;


@Repository("QcComplainDAO")
public class QcComplainDAOImp extends BaseDAOImp implements QcComplainDAO {
	public QcComplainDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.QcComplain");
	}

	@Override
	public Object getById2(Integer id) throws Exception {
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getById2", id);
	}

	@Override
	public List ComplainResLast(QcComplain qcComplain) throws Exception {
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getNewAllList", qcComplain);
	}




	
}
