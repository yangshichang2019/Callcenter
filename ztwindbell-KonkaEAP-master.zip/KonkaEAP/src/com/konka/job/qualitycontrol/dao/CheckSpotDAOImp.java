package com.konka.job.qualitycontrol.dao;


import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;


@Repository("CheckSpotDAO")
public class CheckSpotDAOImp extends BaseDAOImp implements CheckSpotDAO {
	public CheckSpotDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.CheckSpot");
	}

}
