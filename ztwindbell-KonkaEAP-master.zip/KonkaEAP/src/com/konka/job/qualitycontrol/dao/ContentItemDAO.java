package com.konka.job.qualitycontrol.dao;





import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.job.qualitycontrol.model.ContentItem;
import com.konka.job.qualitycontrol.model.QcContent;

public interface ContentItemDAO extends BaseDAO{
	
	
	public ContentItem getContentItemByName(ContentItem contentItem);
	
}
