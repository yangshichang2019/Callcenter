package com.konka.job.qualitycontrol.dao;





import com.konka.common.base.BaseDAO;
import com.konka.job.qualitycontrol.model.QcContent;

public interface QcContentDAO extends BaseDAO{
	
	public QcContent getContentByName(QcContent qcContent);
	
}
