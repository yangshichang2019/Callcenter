package com.konka.job.qualitycontrol.dao;





import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.job.qualitycontrol.model.QcPlan;
import com.konka.job.qualitycontrol.model.QcTask;

public interface QcTaskDAO extends BaseDAO{
	
		//根据录音id获取录音记录
		public List getVoiceRecordList(QcTask qcTask);
		//获取所有通讯记录
		public List getAllRecordList(BaseVO baseVO,Page page) throws Exception;
		//获取所有通讯记录
		public List getAllRecordList2(BaseVO baseVO,Page page) throws Exception;
		//从录音表中读取数据
		public QcTask getTaskRecord(QcTask qcTask);
		public QcTask getTaskRecord2(QcTask qcTask);
		//计算客服平均分
		public List getAvgRecordList(BaseVO baseVO, Page page);
		//批量删除评分
		public Object deleteRecord(QcTask qcTask);
		//批量删除评分申诉
		public Object deleteRecordComplain(QcTask qcTask);
		//批量删除评分抽检
		public Object deleteRecordCheckspot(QcTask qcTask);
		//获取服务类型
		public String getTelServiceType(String ueid);
		//获取服务类型2
		public String getTelServiceType2(Integer id);
		//获取带满意度的
		public List<QcTask> getObjectList2(BaseVO baseVO,Page page);
	
	
}
