package com.konka.job.qualitycontrol.dao;





import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.QcContent;

public interface ComplainResDAO extends BaseDAO{
	
	public List getAllListComRes(ComplainRes complainRes) throws Exception ;
	
	public void updateByComplainId(ComplainRes complainRes) throws Exception ;

	public void updateRes(ComplainRes complainRes);

	public void updateComRes(ComplainRes complainRes);

}
