package com.konka.job.qualitycontrol.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.qualitycontrol.model.QcContent;
import com.konka.job.qualitycontrol.model.QcPlan;


@Repository("QcPlanDAO")
public class QcPlanDAOImp extends BaseDAOImp implements QcPlanDAO {
	public QcPlanDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.QcPlan");
	}

	@Override
	public QcPlan getPlanByName(QcPlan qcPlan) {
		return (QcPlan) this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getPlanByName", qcPlan);	
	}

	@Override
	public List getVoiceRecordList(QcPlan qcPlan) {
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecordVoiceList", qcPlan);
	}

	@Override
	public List getCheckSpotList(QcPlan qcPlan, Page page) {
		Util.setPageNum(qcPlan, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getCheckspotList", qcPlan);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	@Override
	public QcPlan getCheckspotByName(QcPlan qcPlan) {
		return (QcPlan) this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getCheckspotByName", qcPlan);
	}

	@Override
	public int insertCheckspot(QcPlan qcPlan) {
		return this.getSqlSessionTemplate().insert(this.getMapper() + ".insertCheckspot", qcPlan);
	}

	@Override
	public List getCheckSpotList(QcPlan qcPlan) {
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getCheckSpotListId", qcPlan);
	}

	@Override
	public List getVoiceRecordList2(QcPlan qcPlan) {
		// TODO Auto-generated method stub
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecordVoiceList2", qcPlan);
	}

	@Override
	public List getVoiceRecordList3(QcPlan qcPlan) {
		// TODO Auto-generated method stub
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecordVoiceList3", qcPlan);
	}

	@Override
	public List getVoiceRecordList4(QcPlan qcPlan) {
		// TODO Auto-generated method stub
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecordVoiceList4", qcPlan);
	}




	
}
