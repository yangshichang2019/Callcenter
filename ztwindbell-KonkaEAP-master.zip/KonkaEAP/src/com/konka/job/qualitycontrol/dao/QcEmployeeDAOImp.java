package com.konka.job.qualitycontrol.dao;


import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.job.qualitycontrol.model.QcEmployee;


@Repository("QcEmployee")
public class QcEmployeeDAOImp extends BaseDAOImp implements QcEmployeeDAO {
	public QcEmployeeDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.QcEmployee");
	}

	@Override
	public void updateEmployee(QcEmployee qc) {
		this.getSqlSessionTemplate().update(this.getMapper() + ".updateEmployee", qc);
		
	}
	
	
}
