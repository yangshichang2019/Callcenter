package com.konka.job.qualitycontrol.dao;





import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.QcComplain;
import com.konka.job.qualitycontrol.model.QcContent;

public interface QcComplainDAO extends BaseDAO{
	
	public Object getById2(Integer id) throws Exception;

	public List ComplainResLast(QcComplain qcComplain)throws Exception;
}
