package com.konka.job.qualitycontrol.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.qualitycontrol.model.QcContent;
import com.konka.job.qualitycontrol.model.QcPlan;
import com.konka.job.qualitycontrol.model.QcTask;


@Repository("QcTaskDAO")
public class QcTaskDAOImp extends BaseDAOImp implements QcTaskDAO {
	public QcTaskDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.QcTask");
	}

	@Override
	public List getVoiceRecordList(QcTask qcTask) {
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getRecordVoiceListByRid", qcTask);
	}

	@Override
	public List getAllRecordList(BaseVO baseVO, Page page) throws Exception {
		Util.setPageNum(baseVO, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getAllRecordList", baseVO);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}
	
	@Override
	public List getAllRecordList2(BaseVO baseVO, Page page) throws Exception {
		Util.setPageNum(baseVO, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getAllRecordListzhuanjie", baseVO);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	@Override
	public QcTask getTaskRecord(QcTask qcTask) {
		String id = qcTask.getCallrecord_id();
		return  this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getTaskRecord",id );
	}
	@Override
	public QcTask getTaskRecord2(QcTask qcTask) {
		String id = qcTask.getRecordid();
		return  this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getTaskRecord2",id );
	}

	@Override
	public List getAvgRecordList(BaseVO baseVO, Page page) {
		Util.setPageNum(baseVO, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getAvgRecordList", baseVO);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	@Override
	public Object deleteRecord(QcTask qcTask) {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteRecord", qcTask);
		return null;
	}

	@Override
	public Object deleteRecordComplain(QcTask qcTask) {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteRecord1", qcTask);
		return null;
	}

	@Override
	public Object deleteRecordCheckspot(QcTask qcTask) {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteRecord2", qcTask);
		return null;
	}

	@Override
	public String getTelServiceType(String id) {
		return  this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getueid",id );
	}

	@Override
	public String getTelServiceType2(Integer id) {
		return  this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getueid2",id );
	}

	@Override
	public List<QcTask> getObjectList2(BaseVO baseVO,Page page) {
		Util.setPageNum(baseVO, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getObjectList2", baseVO);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

}
