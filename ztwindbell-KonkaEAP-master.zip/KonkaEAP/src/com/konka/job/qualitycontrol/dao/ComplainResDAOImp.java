package com.konka.job.qualitycontrol.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.QcContent;


@Repository("ComplainResDAO")
public class ComplainResDAOImp extends BaseDAOImp implements ComplainResDAO {
	public ComplainResDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.ComplainRes");
	}

	@Override
	public List getAllListComRes(ComplainRes complainRes) throws Exception {
		return this.getSqlSessionTemplate().selectList(this.getMapper() + ".getComResAllList", complainRes);
	}

	@Override
	public void updateByComplainId(ComplainRes complainRes) throws Exception {
		this.getSqlSessionTemplate().update(this.getMapper() + ".update2", complainRes);
	}

	@Override
	public void updateRes(ComplainRes complainRes) {
		this.getSqlSessionTemplate().update(this.getMapper() + ".update3", complainRes);
	}

	@Override
	public void updateComRes(ComplainRes complainRes) {
		this.getSqlSessionTemplate().update(this.getMapper() + ".update4", complainRes);
	}

	


	
}
