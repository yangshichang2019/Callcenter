package com.konka.job.qualitycontrol.dao;


import java.util.List;

import com.konka.common.base.BaseDAO;
import com.konka.common.tool.Page;
import com.konka.job.qualitycontrol.model.Satisfication;

public interface SatisficationDAO extends BaseDAO{
	public List getSatisfitionList(Satisfication satisfication , Page page)throws Exception;
	
}
