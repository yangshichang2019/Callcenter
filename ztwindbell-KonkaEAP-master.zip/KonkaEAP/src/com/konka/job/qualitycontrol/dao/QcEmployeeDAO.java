package com.konka.job.qualitycontrol.dao;


import com.konka.common.base.BaseDAO;
import com.konka.job.qualitycontrol.model.QcEmployee;

public interface QcEmployeeDAO extends BaseDAO{

	public void updateEmployee(QcEmployee qc);
	
}
