package com.konka.job.qualitycontrol.dao;


import java.util.List;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.qualitycontrol.model.Satisfication;


@Repository("SatisficationDAO")
public class SatisficationDAOImp extends BaseDAOImp implements SatisficationDAO {
	public SatisficationDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.Satisfication");
	}

	@Override
	public List getSatisfitionList(Satisfication satisfication, Page page){
		Util.setPageNum(satisfication, page);
		List list = this.getSqlSessionTemplate().selectList(this.getMapper() + ".getSatisficationList", satisfication);
		if(list!=null&&list.size()>0) {
			page.setResult_count(((BaseVO)list.get(0)).getResult_count());
		}
		return list;
	}

	
	
}
