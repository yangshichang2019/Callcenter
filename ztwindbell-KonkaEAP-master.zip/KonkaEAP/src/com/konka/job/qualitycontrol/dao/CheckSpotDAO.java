package com.konka.job.qualitycontrol.dao;






import com.konka.common.base.BaseDAO;

public interface CheckSpotDAO extends BaseDAO{
	
}
