package com.konka.job.qualitycontrol.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.job.qualitycontrol.model.ContentItem;
import com.konka.job.qualitycontrol.model.QcContent;


@Repository("ContentItemDAO")
public class ContentItemDAOImp extends BaseDAOImp implements ContentItemDAO {
	public ContentItemDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.ContentItem");
	}

	@Override
	public ContentItem getContentItemByName(ContentItem contentItem) {
		return (ContentItem) this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getContentItemByName", contentItem);
	}



	
}
