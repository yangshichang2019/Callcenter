package com.konka.job.qualitycontrol.dao;

import org.springframework.stereotype.Repository;
import com.konka.common.base.BaseDAOImp;
import com.konka.job.qualitycontrol.model.QcContent;


@Repository("QcContentDAO")
public class QcContentDAOImp extends BaseDAOImp implements QcContentDAO {
	public QcContentDAOImp() {
		super.setMapper("com.konka.job.qualitycontrol.model.QcContent");
	}


	@Override
	public QcContent getContentByName(QcContent qcContent) {
		return (QcContent) this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getContentByName", qcContent);	
	}


	
}
