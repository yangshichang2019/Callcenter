package com.konka.job.qualitycontrol.model;




import java.util.List;

import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * ����������
 *
 */
public class CheckSpot extends BaseVO {
	
	private Integer id;
	
	private Integer plan_id;
	private Integer task_id;
	private String evaluate;
	private String remark;
	
	private String callrecord_id;
	private Integer content_id;
	private String call_evaluate;//�˴�ͨ����������
	private String executor;//������
	private String employee;//��������
	private String employees;//��������
	private String task_start;//����ʼʱ��
	private String task_end;//�������ʱ��
	private String result;//�������ݵ÷�
	private String voice_start;//¼����ʼʱ��
	private String voice_end;//¼������ʱ��
	private	String orgCaller;//���к���
	private String orgCalled;//���к���
	private Integer time_long;//ͨ��ʱ��
	private String advice;//��������
	private String grade;//�����ȼ�
	private Integer score;
	
	private String content_name;
	private String plan_name;
	
	private List<ContentItem> list;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCallrecord_id() {
		return callrecord_id;
	}
	public void setCallrecord_id(String callrecord_id) {
		this.callrecord_id = callrecord_id;
	}
	public String getExecutor() {
		return executor;
	}
	public void setExecutor(String executor) {
		this.executor = executor;
	}
	public String getCall_evaluate() {
		return call_evaluate;
	}
	public void setCall_evaluate(String call_evaluate) {
		this.call_evaluate = call_evaluate;
	}
	
	public String getEmployee() {
		return employee;
	}
	public void setEmployee(String employee) {
		this.employee = employee;
	}
	public String getTask_start() {
		return task_start;
	}
	public void setTask_start(String task_start) {
		this.task_start = task_start;
	}
	public String getTask_end() {
		return task_end;
	}
	public void setTask_end(String task_end) {
		this.task_end = task_end;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	public String getVoice_start() {
		return voice_start;
	}
	public void setVoice_start(String voice_start) {
		this.voice_start = voice_start;
	}
	public String getVoice_end() {
		return voice_end;
	}
	public void setVoice_end(String voice_end) {
		this.voice_end = voice_end;
	}
	public String getOrgCaller() {
		return orgCaller;
	}
	public void setOrgCaller(String orgCaller) {
		this.orgCaller = orgCaller;
	}
	public String getOrgCalled() {
		return orgCalled;
	}
	public void setOrgCalled(String orgCalled) {
		this.orgCalled = orgCalled;
	}
	public Integer getTime_long() {
		return time_long;
	}
	public void setTime_long(Integer time_long) {
		this.time_long = time_long;
	}
	
	public Integer getContent_id() {
		return content_id;
	}
	public void setContent_id(Integer content_id) {
		this.content_id = content_id;
	}
	public String getAdvice() {
		return advice;
	}
	public void setAdvice(String advice) {
		this.advice = advice;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public CheckSpot() {
		// TODO Auto-generated constructor stub
	}
	public List<ContentItem> getList() {
		return list;
	}
	public void setList(List<ContentItem> list) {
		this.list = list;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getContent_name() {
		return content_name;
	}
	public void setContent_name(String content_name) {
		this.content_name = content_name;
	}
	public String getPlan_name() {
		return plan_name;
	}
	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}
	public Integer getTask_id() {
		return task_id;
	}
	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}
	public String getEvaluate() {
		return evaluate;
	}
	public void setEvaluate(String evaluate) {
		this.evaluate = evaluate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Integer getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(Integer plan_id) {
		this.plan_id = plan_id;
	}
	public String getEmployees() {
		return employees;
	}
	public void setEmployees(String employees) {
		this.employees = employees;
	}
	
	
	
}
