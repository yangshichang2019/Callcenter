package com.konka.job.qualitycontrol.model;




import java.sql.Timestamp;
import java.util.List;

import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * ����������
 *
 */
public class QcTask extends BaseVO {
	
	private Integer id;
	private Integer plan_id;		
	private String callrecord_id;
	private Integer content_id;
	private String call_evaluate;//�˴�ͨ����������
	private String executor;//������
	private String employee;//��������
	private String employee_name;//��������
	private String task_start;//����ʼʱ��
	private String task_end;//�������ʱ��
	private String result;//�������ݵ÷�
	private String voice_start;//¼����ʼʱ��
	private String voice_end;//¼������ʱ��
	private	String orgCaller;//���к���
	private String orgCalled;//���к���
	private Integer time_long;//ͨ��ʱ��
	private String advice;//��������
	private String grade;//�����ȼ�
	private Integer score;
	
	private String content_name;
	private String plan_name;
	private String update_start;//¼����ʼʱ��
	private String update_end;//¼������ʱ��
	
	private List<ContentItem> list;
	
	private  Integer time_start;//ʱ��
	private  Integer time_end;//ʱ��
	private String  type;
	
	private String  is_flag;
	private String  qc_status;
	
	private Timestamp shenhe_time;
	private String recordid;
	private String service_type;//��������
	
	private String is_zhuanjie;
	private String satisfaction;
	
	
	
	
	public String getService_type() {
		return service_type;
	}
	public void setService_type(String service_type) {
		this.service_type = service_type;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(Integer plan_id) {
		this.plan_id = plan_id;
	}
	public String getCallrecord_id() {
		return callrecord_id;
	}
	public void setCallrecord_id(String callrecord_id) {
		this.callrecord_id = callrecord_id;
	}
	public String getExecutor() {
		return executor;
	}
	public void setExecutor(String executor) {
		this.executor = executor;
	}
	public String getCall_evaluate() {
		return call_evaluate;
	}
	public void setCall_evaluate(String call_evaluate) {
		this.call_evaluate = call_evaluate;
	}
	
	public String getEmployee() {
		return employee;
	}
	public void setEmployee(String employee) {
		this.employee = employee;
	}
	public String getTask_start() {
		return task_start;
	}
	public void setTask_start(String task_start) {
		this.task_start = task_start;
	}
	public String getTask_end() {
		return task_end;
	}
	public void setTask_end(String task_end) {
		this.task_end = task_end;
	}
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
	public String getVoice_start() {
		return voice_start;
	}
	public void setVoice_start(String voice_start) {
		this.voice_start = voice_start;
	}
	public String getVoice_end() {
		return voice_end;
	}
	public void setVoice_end(String voice_end) {
		this.voice_end = voice_end;
	}
	public String getOrgCaller() {
		return orgCaller;
	}
	public void setOrgCaller(String orgCaller) {
		this.orgCaller = orgCaller;
	}
	public String getOrgCalled() {
		return orgCalled;
	}
	public void setOrgCalled(String orgCalled) {
		this.orgCalled = orgCalled;
	}
	public Integer getTime_long() {
		return time_long;
	}
	public void setTime_long(Integer time_long) {
		this.time_long = time_long;
	}
	
	public Integer getContent_id() {
		return content_id;
	}
	public void setContent_id(Integer content_id) {
		this.content_id = content_id;
	}
	public String getAdvice() {
		return advice;
	}
	public void setAdvice(String advice) {
		this.advice = advice;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public QcTask() {
		// TODO Auto-generated constructor stub
	}
	public List<ContentItem> getList() {
		return list;
	}
	public void setList(List<ContentItem> list) {
		this.list = list;
	}
	public Integer getScore() {
		return score;
	}
	public void setScore(Integer score) {
		this.score = score;
	}
	public String getContent_name() {
		return content_name;
	}
	public void setContent_name(String content_name) {
		this.content_name = content_name;
	}
	public String getPlan_name() {
		return plan_name;
	}
	public void setPlan_name(String plan_name) {
		this.plan_name = plan_name;
	}
	public Integer getTime_start() {
		return time_start;
	}
	public void setTime_start(Integer time_start) {
		this.time_start = time_start;
	}
	public Integer getTime_end() {
		return time_end;
	}
	public void setTime_end(Integer time_end) {
		this.time_end = time_end;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getIs_flag() {
		return is_flag;
	}
	public void setIs_flag(String is_flag) {
		this.is_flag = is_flag;
	}
	public String getQc_status() {
		return qc_status;
	}
	public void setQc_status(String qc_status) {
		this.qc_status = qc_status;
	}
	public Timestamp getShenhe_time() {
		return shenhe_time;
	}
	public void setShenhe_time(Timestamp shenhe_time) {
		this.shenhe_time = shenhe_time;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getUpdate_start() {
		return update_start;
	}
	public void setUpdate_start(String update_start) {
		this.update_start = update_start;
	}
	public String getUpdate_end() {
		return update_end;
	}
	public void setUpdate_end(String update_end) {
		this.update_end = update_end;
	}
	public String getRecordid() {
		return recordid;
	}
	public void setRecordid(String recordid) {
		this.recordid = recordid;
	}
	public String getIs_zhuanjie() {
		return is_zhuanjie;
	}
	public void setIs_zhuanjie(String is_zhuanjie) {
		this.is_zhuanjie = is_zhuanjie;
	}
	public String getSatisfaction() {
		return satisfaction;
	}
	public void setSatisfaction(String satisfaction) {
		this.satisfaction = satisfaction;
	}
	
	
	
}
