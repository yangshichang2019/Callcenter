package com.konka.job.qualitycontrol.model;




import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * �ƻ�Ա����
 *
 */
public class QcEmployee extends BaseVO {
	
	private Integer id;
	private Integer plan_id;	//�����ƻ�
	private Integer quality_times;//�ʼ����
	private Integer real_times;//�����������
	private String employee;//�ʼ�Ķ��� ����
	private String employee_name;//�ʼ�Ķ�������
	private String t_flag;//ͨ��ʱ�俪ʼ
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getPlan_id() {
		return plan_id;
	}
	public void setPlan_id(Integer plan_id) {
		this.plan_id = plan_id;
	}
	public Integer getQuality_times() {
		return quality_times;
	}
	public void setQuality_times(Integer quality_times) {
		this.quality_times = quality_times;
	}
	public Integer getReal_times() {
		return real_times;
	}
	public void setReal_times(Integer real_times) {
		this.real_times = real_times;
	}
	public String getEmployee() {
		return employee;
	}
	public void setEmployee(String employee) {
		this.employee = employee;
	}
	public String getEmployee_name() {
		return employee_name;
	}
	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}
	public String getT_flag() {
		return t_flag;
	}
	public void setT_flag(String t_flag) {
		this.t_flag = t_flag;
	}
	
	public QcEmployee() {
		// TODO Auto-generated constructor stub
	}
	
}
