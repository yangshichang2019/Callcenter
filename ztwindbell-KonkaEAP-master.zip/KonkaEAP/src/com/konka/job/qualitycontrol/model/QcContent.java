package com.konka.job.qualitycontrol.model;


import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * ����������
 *
 */
public class QcContent extends BaseVO {
	
	private Integer id;
	private String  name;
	private String  score;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public QcContent() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
