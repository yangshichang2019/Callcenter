package com.konka.job.qualitycontrol.model;




import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * �����ƻ���
 *
 */
public class QcPlan extends BaseVO {
	
	private Integer id;
	private Integer content_id;	//��������
	private String content_name;	//��������
	private Integer quality_times;//�ʼ����
	private String name;	//�ƻ�����
	private String type;	//����  ����
	private String mode;	//��Ա�� ����Ա��
	private String executor;//�ʼ�Ա
	private String executor_ids;//�ʼ�Ա
	private String employees;//�ʼ�Ķ���
	private String employees_ids;//�ʼ�Ķ���
	private String call_start;//ͨ��ʱ�俪ʼ
	private String call_end;//ͨ��ʱ�����
	private String plan_start;//�ƻ���ʼʱ��
	private String plan_end;//�ƻ�����ʱ��
	
	private String rid;//�����ֶ�
	
	public String getMode() {
		return mode;
	}
	public void setMode(String mode) {
		this.mode = mode;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getContent_id() {
		return content_id;
	}
	public void setContent_id(Integer content_id) {
		this.content_id = content_id;
	}
	public Integer getQuality_times() {
		return quality_times;
	}
	public void setQuality_times(Integer quality_times) {
		this.quality_times = quality_times;
	}
	public String getExecutor() {
		return executor;
	}
	public void setExecutor(String executor) {
		this.executor = executor;
	}
	public String getEmployees() {
		return employees;
	}
	public void setEmployees(String employees) {
		this.employees = employees;
	}
	public String getCall_start() {
		return call_start;
	}
	public void setCall_start(String call_start) {
		this.call_start = call_start;
	}
	public String getCall_end() {
		return call_end;
	}
	public void setCall_end(String call_end) {
		this.call_end = call_end;
	}
	public String getPlan_start() {
		return plan_start;
	}
	public void setPlan_start(String plan_start) {
		this.plan_start = plan_start;
	}
	public String getPlan_end() {
		return plan_end;
	}
	public void setPlan_end(String plan_end) {
		this.plan_end = plan_end;
	}
	
	public String getExecutor_ids() {
		return executor_ids;
	}
	public void setExecutor_ids(String executor_ids) {
		this.executor_ids = executor_ids;
	}
	public String getEmployees_ids() {
		return employees_ids;
	}
	public void setEmployees_ids(String employees_ids) {
		this.employees_ids = employees_ids;
	}
	public String getContent_name() {
		return content_name;
	}
	public void setContent_name(String content_name) {
		this.content_name = content_name;
	}
	
	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public QcPlan() {
		// TODO Auto-generated constructor stub
	}
	
	
	
}
