package com.konka.job.qualitycontrol.model;

import com.konka.common.base.BaseVO;

/**
 * @author ���� ������Ŀ��
 * 
 */
public class ContentItem extends BaseVO {

	private Integer id;
	private String name;
	private Integer content_id;
	private Integer sort;
	private float score;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getContent_id() {
		return content_id;
	}

	public void setContent_id(Integer content_id) {
		this.content_id = content_id;
	}
	

	public float getScore() {
		return score;
	}

	public void setScore(float score) {
		this.score = score;
	}

	public ContentItem() {
		// TODO Auto-generated constructor stub
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}
	
}
