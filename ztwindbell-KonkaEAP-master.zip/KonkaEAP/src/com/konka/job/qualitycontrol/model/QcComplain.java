package com.konka.job.qualitycontrol.model;




import java.util.ArrayList;
import java.util.List;

import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * ������
 *
 */
public class QcComplain extends BaseVO {
	
	private Integer id;
	private Integer task_id;	
	private String complain_flag;//����״̬�����ĸ��ڵ�  ����  ֣�� ������ 
	private String complain_res;//����״̬���ڸýڵ� δ����/�Ѵ��� ״̬
	private String orgCaller;
	private String orgCalled;
	private Integer content_id;
	
	private String complain_status;
	private String employee_name;
	private String gleader;
	
	private List list = new ArrayList();
	
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getTask_id() {
		return task_id;
	}

	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}

	public String getComplain_flag() {
		return complain_flag;
	}

	public void setComplain_flag(String complain_flag) {
		this.complain_flag = complain_flag;
	}

	public String getComplain_res() {
		return complain_res;
	}

	public void setComplain_res(String complain_res) {
		this.complain_res = complain_res;
	}

	public QcComplain() {
		// TODO Auto-generated constructor stub
	}

	public String getOrgCaller() {
		return orgCaller;
	}

	public void setOrgCaller(String orgCaller) {
		this.orgCaller = orgCaller;
	}

	public String getOrgCalled() {
		return orgCalled;
	}

	public void setOrgCalled(String orgCalled) {
		this.orgCalled = orgCalled;
	}

	public Integer getContent_id() {
		return content_id;
	}

	public void setContent_id(Integer content_id) {
		this.content_id = content_id;
	}

	public List getList() {
		return list;
	}

	public void setList(List list) {
		this.list = list;
	}

	public String getComplain_status() {
		return complain_status;
	}

	public void setComplain_status(String complain_status) {
		this.complain_status = complain_status;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getGleader() {
		return gleader;
	}

	public void setGleader(String gleader) {
		this.gleader = gleader;
	}
	
	
}
