package com.konka.job.qualitycontrol.model;


import com.konka.common.base.BaseVO;

/**
 * @author ����   
 * ���߽����
 *
 */
public class ComplainRes extends BaseVO {
	
	private Integer id;
	private Integer complain_id;
	private String  cause;
	private String  result;
	private String  remark;
	private String  res_flag;
	
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public Integer getComplain_id() {
		return complain_id;
	}
	public void setComplain_id(Integer complain_id) {
		this.complain_id = complain_id;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public ComplainRes() {
		// TODO Auto-generated constructor stub
	}
	public String getCause() {
		return cause;
	}
	public void setCause(String cause) {
		this.cause = cause;
	}
	public String getRes_flag() {
		return res_flag;
	}
	public void setRes_flag(String res_flag) {
		this.res_flag = res_flag;
	}
	
	
	
}
