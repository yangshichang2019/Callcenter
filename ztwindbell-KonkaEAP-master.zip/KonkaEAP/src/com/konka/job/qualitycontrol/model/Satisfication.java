package com.konka.job.qualitycontrol.model;


import java.sql.Timestamp;

import com.konka.common.base.BaseVO;

public class Satisfication extends BaseVO {
	
	private String  number;
	private String  agent_name;//������Ա����
	private String  caller;//����
	private String  called;//������
	private String satisfied;//�����
	private Integer time_long;//ʱ��
	private Integer time_long1;//ʱ�����ڲ�ѯС��
	private String agent_no;//����
	private String  rid; //¼��id
	private String  time; //�ύ����ʱ��
	private String endtime;
	private String call_time;
	
	
	public String getRid() {
		return rid;
	}
	public void setRid(String rid) {
		this.rid = rid;
	}
	public Integer getTime_long1() {
		return time_long1;
	}
	public void setTime_long1(Integer time_long1) {
		this.time_long1 = time_long1;
	}
	public String getEndtime() {
		return endtime;
	}
	public void setEndtime(String endtime) {
		this.endtime = endtime;
	}
	public String getCall_time() {
		return call_time;
	}
	public void setCall_time(String call_time) {
		this.call_time = call_time;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getCaller() {
		return caller;
	}
	public void setCaller(String caller) {
		this.caller = caller;
	}
	public String getCalled() {
		return called;
	}
	public void setCalled(String called) {
		this.called = called;
	}
	public String getSatisfied() {
		return satisfied;
	}
	public void setSatisfied(String satisfied) {
		this.satisfied = satisfied;
	}
	public Integer getTime_long() {
		return time_long;
	}
	public void setTime_long(Integer time_long) {
		this.time_long = time_long;
	}
	public String getAgent_name() {
		return agent_name;
	}
	public void setAgent_name(String agent_name) {
		this.agent_name = agent_name;
	}
	public String getAgent_no() {
		return agent_no;
	}
	public void setAgent_no(String agent_no) {
		this.agent_no = agent_no;
	}
	
	
	
	
}
