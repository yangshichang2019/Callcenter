package com.konka.job.qualitycontrol.action;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Util;
import com.konka.job.qualitycontrol.model.CheckSpot;
import com.konka.job.qualitycontrol.model.ComplainRes;
import com.konka.job.qualitycontrol.model.ContentItem;
import com.konka.job.qualitycontrol.model.QcComplain;
import com.konka.job.qualitycontrol.model.QcContent;
import com.konka.job.qualitycontrol.model.QcEmployee;
import com.konka.job.qualitycontrol.model.QcPlan;
import com.konka.job.qualitycontrol.model.QcTask;
import com.konka.job.qualitycontrol.model.Satisfication;
import com.konka.job.qualitycontrol.service.QualityService;
import com.konka.job.summary.model.Summary;
import com.konka.job.summary.service.SummaryService;
import com.konka.system.service.SystemService;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;
import com.konka.util.DateUtil;

@Controller
@Scope("prototype")
public class QualityAction extends BaseAction {

	@Autowired
	private QualityService qualityService;
	@Autowired
	private SummaryService summaryService;
	@Autowired
	private SystemService systemService;
	@Autowired
	private UserAdminService userAdminService;
	
	

	private Satisfication satisfication = new Satisfication();
	private QcContent qcContent = new QcContent();
	private ContentItem contentItem = new ContentItem();
	private QcPlan qcPlan = new QcPlan();
	private QcTask qcTask = new QcTask();
	private CheckSpot checkSpot = new CheckSpot();
	private QcComplain qcComplain = new QcComplain();
	private ComplainRes complainRes = new ComplainRes();
	private QcEmployee qcEmployee = new QcEmployee();
	private Summary summary = new Summary() ;
	
	
	
	
	//删除评分
	public String toDeleteRecord() throws Exception {
		qcTask.setValues(ids);
		qualityService.deleteRecord(qcTask);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	// 质检考评（质检员查询）
	public String toManageQuality() throws Exception {
		if(qcTask.getUpdate_start()==null){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar now = Calendar.getInstance();
			Calendar now2 = Calendar.getInstance();
			now.setTime(new Date());
			now2.setTime(new Date());
			now.set(Calendar.DATE, now.get(Calendar.DATE) - 2);
			now2.set(Calendar.DATE, now2.get(Calendar.DATE));
			
			qcTask.setUpdate_start(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
			qcTask.setUpdate_end(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");			
		}
		qcTask.setEnable_flag("T");
		dataList = qualityService.getPlanTaskList(qcTask, page);
			
			
		return "toManageQuality";
	}
	
	
	
	// 质检考评（质检员查询）
		public String toManageQualityByLook() throws Exception {
			if(qcTask.getUpdate_start()==null){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Calendar now = Calendar.getInstance();
				Calendar now2 = Calendar.getInstance();
				now.setTime(new Date());
				now2.setTime(new Date());
				now.set(Calendar.DATE, now.get(Calendar.DATE) - 2);
				now2.set(Calendar.DATE, now2.get(Calendar.DATE));
				
				qcTask.setUpdate_start(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
				qcTask.setUpdate_end(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");
			}
			qcTask.setEnable_flag("T");
			dataList = qualityService.getPlanTaskList(qcTask, page);
				
				
			return "toManageQualityByLook";
		}
	
	
	
	
	
	// 通用呼叫记录查询(坐席员自己查询自己)
	public String toManageAllRecordbyEmployee() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qcTask.setEmployee(user.getUsername());
		if(qcTask.getVoice_start()==null){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar now = Calendar.getInstance();
			Calendar now2 = Calendar.getInstance();
			now.setTime(new Date());
			now2.setTime(new Date());
			now.set(Calendar.DATE, now.get(Calendar.DATE) - 1);
			now2.set(Calendar.DATE, now2.get(Calendar.DATE));
			qcTask.setVoice_start(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
			qcTask.setVoice_end(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");
		}
		dataList = qualityService.getAllRecordList(qcTask, page);
		return "toManageAllRecordbyEmployee";
	}
	
	
	// 通用呼叫记录查询（管理员查询）
	public String toManageAllRecord() throws Exception {
		
		if(qcTask.getVoice_start()==null){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar now = Calendar.getInstance();
			Calendar now2 = Calendar.getInstance();
			now.setTime(new Date());
			now2.setTime(new Date());
			now.set(Calendar.DATE, now.get(Calendar.DATE) - 1);
			now2.set(Calendar.DATE, now2.get(Calendar.DATE));
			qcTask.setVoice_start(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
			qcTask.setVoice_end(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");
		}
		if(qcTask.getIs_zhuanjie()==null||qcTask.getIs_zhuanjie().equals("")){
			if(qcTask.getVoice_start()!=null){
				dataList = qualityService.getAllRecordList(qcTask, page);
			}
		}else {
			if(qcTask.getVoice_start()!=null){
				dataList = qualityService.getAllRecordList2(qcTask, page);
			}
		}
		
		
		return "toManageAllRecord";
	}
	
	
	
	// 通用呼叫记录查询（管理员可删除评分）
		public String toManageAllRecordByDel() throws Exception {
			if(qcTask.getVoice_start()==null){
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Calendar now = Calendar.getInstance();
				Calendar now2 = Calendar.getInstance();
				now.setTime(new Date());
				now2.setTime(new Date());
				now.set(Calendar.DATE, now.get(Calendar.DATE) - 1);
				now2.set(Calendar.DATE, now2.get(Calendar.DATE));
				qcTask.setVoice_start(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
				qcTask.setVoice_end(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");
			}
			if(qcTask.getVoice_start()!=null){
				dataList = qualityService.getAllRecordList(qcTask, page);
			}
			return "toManageAllRecordByDel";
		}
	
	
	// 通用呼叫记录查询（坐席组长查询）
		public String toManageAllRecordbyGroup() throws Exception {
			if(qcTask.getVoice_start()==null){
				qcTask.setVoice_start(DateUtil.formatDateToStr("yyyy-MM-dd 00:00:00", new Date()));
				qcTask.setVoice_end(DateUtil.formatDateToStr("yyyy-MM-dd 23:59:59", new Date()));
			}
			if(qcTask.getVoice_start()!=null){
				dataList = qualityService.getAllRecordList(qcTask, page);
			}
			return "toManageAllRecordbyGroup";
		}

	// ---------------------申诉模块------------------------------- 
	// 查看评分 并给出结果 且申诉情况
	public String toLookEvaluateTask2() throws Exception {

		List resList = qualityService.getComplainResList(complainRes);
		super.getRequest().setAttribute("resList", resList);
		qcTask = qualityService.getTask(qcTask);
		summary.setRecord_id(qcTask.getRecordid());
		summary = summaryService.getSummaryByRecordId(summary);
		qcContent = qualityService.getContent(qcContent);
		dataList = qualityService.getContentItemList(contentItem);
		// 让选项添加上答案
		dataList = getContentItemList(qcTask.getResult(), dataList);
		return "toLookEvaluateTask2";
	}

	// 申诉结果查询
	public String toSearchComplain() throws Exception {
		dataList = qualityService.getComplainList(qcComplain, page);
		return "toSearchComplain";
	}
	
	
	
	// 申诉结果查询(组长)
	public String toSearchComplainByGroup() throws Exception {
		if(qcComplain.getGleader()==null){
			dataList = new ArrayList();
		}else{
			dataList = qualityService.getComplainList(qcComplain, page);
		}
		return "toSearchComplainByGroup";
	}

	//--- 保存申诉结果
	public String toSaveCheckRes() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qualityService.saveCheckRes(complainRes, user);
		if(complainRes.getResult().equals("T")){
			qualityService.EvaluateTask(qcTask, user);
		}
		
		return Constant.ACTION_S.ajaxDone.toString();
	}
	// 保存评价
	public String toSaveEvaluate() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qualityService.EvaluateTask(qcTask, user);
		systemService.insertRemind("QUALITY", qcTask.getId(),"新录音已被考评", "您有一通录音于"+Util.getTimestamp()+"被考评，核得分为"+qcTask.getScore()+"分", null, null, qcTask.getEmployee(), user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	// 修改评价
	public String toModifyEvaluate() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qualityService.EvaluateTask(qcTask, user);
		systemService.insertRemind("QUALITY", qcTask.getId(),"质检考评变动", "考评分数于"+Util.getTimestamp()+"被修改，考评得分为"+qcTask.getScore()+"分", null, null, qcTask.getEmployee(), user);
		return Constant.ACTION_S.ajaxDone.toString();
	}	
	
	
	// 修改计划评分
	public String toModifyEvaluateTask() throws Exception {
		
		String sType = qualityService.getServiceType2(qcTask.getId());
		qcTask = qualityService.getTask(qcTask);
		summary.setRecord_id(qcTask.getRecordid());
		summary = summaryService.getSummaryByRecordId(summary);
		qcContent = qualityService.getContent(qcContent);
		dataList = qualityService.getContentItemList(contentItem);
		// 让选项添加上答案
		dataList = getContentItemList(qcTask.getResult(), dataList);
		qcTask.setService_type(sType);
		
		return "toModifyEvaluateTask";
	}	
	
	// 查看评分 并给出申诉审核结果
	public String toCheckEvaluateTask() throws Exception {
		complainRes = qualityService.getComplainRes(complainRes);
		qcComplain.setId(complainRes.getComplain_id());
		qcComplain = qualityService.getComplain(qcComplain);
		qcTask.setId(qcComplain.getTask_id());
		qcTask = qualityService.getTask(qcTask);
		
		summary.setRecord_id(qcTask.getRecordid());
		summary = summaryService.getSummaryByRecordId(summary);
		qcContent.setId(qcTask.getContent_id());
		qcContent = qualityService.getContent(qcContent);
		contentItem.setContent_id(qcTask.getContent_id());
		dataList = qualityService.getContentItemList(contentItem);
		// 让选项添加上答案
		dataList = getContentItemList(qcTask.getResult(), dataList);
		return "toCheckEvaluateTask";
	}
	
	
	// 查看评分 并给出申诉审核结果
		public String toCheckEvaluateTask1() throws Exception {
			complainRes = qualityService.getComplainRes(complainRes);
			qcComplain.setId(complainRes.getComplain_id());
			qcComplain = qualityService.getComplain(qcComplain);
			qcTask.setId(qcComplain.getTask_id());
			qcTask = qualityService.getTask(qcTask);
			
			summary.setRecord_id(qcTask.getRecordid());
			summary = summaryService.getSummaryByRecordId(summary);
			qcContent.setId(qcTask.getContent_id());
			qcContent = qualityService.getContent(qcContent);
			contentItem.setContent_id(qcTask.getContent_id());
			dataList = qualityService.getContentItemList(contentItem);
			// 让选项添加上答案
			dataList = getContentItemList(qcTask.getResult(), dataList);
			return "toCheckEvaluateTask1";
		}
	
	

	// 申诉审核
	public String toCheckComplain() throws Exception {
		if(complainRes.getRes_flag()==null){
			dataList = new ArrayList();
		}else{
			dataList = qualityService.getComplaintCheckList(complainRes, page);
		}
		return "toCheckComplain";
	}
	// 申诉初阅
	public String toMgrCheck() throws Exception {
		complainRes.setRes_flag("E");
		complainRes.setEnable_flag("F");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar now = Calendar.getInstance();
		now.setTime(new Date());
		now.set(Calendar.DATE, now.get(Calendar.DATE) - 1);
		String tsStr = sdf.format(now.getTime());
		Timestamp ts = new Timestamp(System.currentTimeMillis());   
        ts = Timestamp.valueOf(tsStr);   
		complainRes.setCreate_time(ts);
		dataList = qualityService.getComplaintCheckList(complainRes, page);
		return "toMgrCheck";
	}	
	
	
	

	// 客服发起申诉
	public String toStartComplain() throws Exception {
		int id = qcComplain.getTask_id();
		qcComplain = qualityService.getComplain2(qcComplain);
		if (qcComplain == null) {
			qcTask.setId(id);
			qcTask = qualityService.getTask(qcTask);
			int flag = getTimeMax(qcTask.getUpdate_time().toString(),5);
			//判断是否超过5天
			if(flag>=0){
				qcComplain = new QcComplain();
				qcComplain.setComplain_flag("E");
				qcComplain.setValues2("M");
				qcComplain.setTask_id(id);
			}else{
				qcComplain = new QcComplain();
				qcComplain.setValues2("K");
			}
		} else {
			List res = qualityService.getComplainResLast(qcComplain);
			complainRes.setComplain_id(qcComplain.getId());
			complainRes.setEnable_flag("");
			dataList = qualityService.getComplainResList(complainRes);
			if (res == null || res.size() == 0) {
				if (qcComplain.getComplain_res().equals("F")) {
					qcComplain.setValues2("F");// 此次审核还未结束
				} else if (qcComplain.getComplain_res().equals("T")
						&& qcComplain.getComplain_flag().equals("C")) {
					qcComplain.setValues2("G");// 三次申诉结束
				} else if (qcComplain.getComplain_res().equals("T")
						&& !qcComplain.getComplain_flag().equals("C")) {
					qcComplain.setValues2("T");// 继续申诉
					complainRes = (ComplainRes)dataList.get(0);
					int flag = getTimeMax(complainRes.getUpdate_time().toString(),2);
					if(flag>=0){
						if (qcComplain.getComplain_flag().equals("A")) {
							qcComplain.setComplain_flag("B");
						} else if(qcComplain.getComplain_flag().equals("B")) {
							qcComplain.setComplain_flag("C");
						} else if(qcComplain.getComplain_flag().equals("E")) {
							qcComplain.setComplain_flag("E");
						}
						complainRes = new ComplainRes();
					}else{
						qcComplain.setValues2("K");
					}
				}
			} else {
				qcComplain.setValues2("H");// 申诉成功
			}
		}
		return "toStartComplain";
	}

	public int getTimeMax(String  str,int days) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar now = Calendar.getInstance();
		now.setTime(new Date());
		now.set(Calendar.DATE, now.get(Calendar.DATE) - days);
		String str1 = sdf.format(now.getTime());
		return compare_date(str,str1);
	}
	
	 public  int compare_date(String DATE1, String DATE2) {
	        DateFormat df = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	        try {
	            Date dt1 = df.parse(DATE1);
	            Date dt2 = df.parse(DATE2);
	            if (dt1.getTime() > dt2.getTime()) {
	                return 1;
	            } else if (dt1.getTime() < dt2.getTime()) {
	                return -1;
	            } else {
	                return 0;
	            }
	        } catch (Exception exception) {
	            exception.printStackTrace();
	        }
	        return 0;
	    }
	

	// 保存申诉内容
	public String toSaveComplain() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qualityService.saveComplain(qcComplain, complainRes, user);
		return Constant.ACTION_S.ajaxDone.toString();
	}

	// ---------------------抽检考评-------------------------------
	// 质检员查看自己被抽检的结果
	public String toPlanCheckSpotListStatus1() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		checkSpot.setEnable_flag("T");
		checkSpot.setExecutor(user.getUsername());
		dataList = qualityService.getCheckSpotList(checkSpot, page);
		return "toPlanCheckSpotListStatus1";
	}

	// 查看我自己被抽检的计划
	public String toMyCheckSpot() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qcPlan.setEmployees(user.getUsername());
		dataList = qualityService.getPlanList2(qcPlan, page);
		return "toMyCheckSpot";
	}

	// 查看抽检计划情况
	public String toPlanCheckSpotListStatus() throws Exception {
		checkSpot.setEnable_flag("T");
		dataList = qualityService.getCheckSpotList(checkSpot, page);
		return "toPlanCheckSpotListStatus";
	}

	// 保存审核结果
	public String toSaveCheckSpotRes() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qualityService.EvaluateTask(qcTask, user);
		qualityService.saveCheckspotRes(checkSpot, user);
		return Constant.ACTION_S.ajaxDone.toString();
	}

	// 查看评分 并给出结果
	public String toLookEvaluateTask() throws Exception {
		qcTask = qualityService.getTask(qcTask);
		qcContent = qualityService.getContent(qcContent);
		summary.setRecord_id(qcTask.getRecordid());
		summary = summaryService.getSummaryByRecordId(summary);
		dataList = qualityService.getContentItemList(contentItem);
		// 让选项添加上答案
		dataList = getContentItemList(qcTask.getResult(), dataList);
		return "toLookEvaluateTask";
	}
	// 查看评分 并给出结果
	public String toModifyLookEvaluateTask() throws Exception {
		checkSpot = qualityService.getCheckSpot(checkSpot);
		qcTask.setId(checkSpot.getTask_id());
		qcTask = qualityService.getTask(qcTask);
		qcContent.setId(qcTask.getContent_id());
		qcContent = qualityService.getContent(qcContent);
		contentItem.setContent_id(qcTask.getContent_id());
		dataList = qualityService.getContentItemList(contentItem);
		// 让选项添加上答案
		dataList = getContentItemList(qcTask.getResult(), dataList);
		return "toModifyLookEvaluateTask";
	}
	
	

	// 查看抽检计划情况
	public String toPlanCheckSpotList() throws Exception {
		checkSpot.setEnable_flag("F");
		dataList = qualityService.getCheckSpotList(checkSpot, page);
		return "toPlanCheckSpotList";
	}

	// 抽检计划维护toManageCheckSpot
	public String toManageCheckSpot() throws Exception {
		dataList = qualityService.getPlanList2(qcPlan, page);
		return "toManageCheckSpot";
	}

	// 新增抽检或修改抽检计划
	public String toAddEditCheckspot() throws Exception {
		if (qcPlan.getId() != null) {
			qcPlan = qualityService.getPlan(qcPlan);
		}
		return "toAddEditCheckspot";
	}

	// 修改或新建 考评内容维护
	public String toSaveCheckspot() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		String flag = qualityService.saveCheckspot(qcPlan, user);
		if (flag != null) {
			super.toError("该考评计划名称已存在");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}

	// -----------------------------------------------------------

	// ----------------------考评内容----------------------
	// 查看评分 并给出结果
	public String toLookEvaluateTask1() throws Exception {
		
		String sType = qualityService.getServiceType2(qcTask.getId());
		qcTask = qualityService.getTask(qcTask);
		summary.setRecord_id(qcTask.getRecordid());
		summary = summaryService.getSummaryByRecordId(summary);
		qcContent = qualityService.getContent(qcContent);
		dataList = qualityService.getContentItemList(contentItem);
		// 让选项添加上答案
		dataList = getContentItemList(qcTask.getResult(), dataList);
		qcTask.setService_type(sType);
		return "toLookEvaluateTask1";
	}

	// 我的质检考评
	public String toMyQuality() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qcTask.setEnable_flag("T");
		qcTask.setEmployee(user.getUsername());
		dataList = qualityService.getPlanTaskList(qcTask, page);
		return "toMyQuality";
	}

	// 考评内容维护
	public String toManageContent() throws Exception {
		dataList = qualityService.getQcContentList(qcContent, page);
		return "toManageContent";
	}

	// 跳转---修改或创建 考评内容维护
	public String toAddEditContent() throws Exception {
		if (qcContent.getId() != null) {
			qcContent = qualityService.getContent(qcContent);
		}
		return "toAddEditContent";
	}

	// 修改或新建 考评内容维护
	public String toSaveContent() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		String flag = qualityService.saveContent(qcContent, user);
		if (flag != null) {
			super.toError("该考评内容已存在");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}

	// ----------------------考评内容项目----------------------
	// 考评内容项目维护
	public String toContentItemList() throws Exception {
		dataList = qualityService.getContentItemList(contentItem);
		return "toContentItemList";
	}

	// 跳转---修改或创建 考评内容维护
	public String toAddEditContentItem() throws Exception {
		if (contentItem.getId() != null) {
			contentItem = qualityService.getContentItem(contentItem);
		}
		return "toAddEditContentItem";
	}

	// 修改或新建 考评内容维护
	public String toSaveContentItem() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		String flag = qualityService.saveContentItem(contentItem, user);
		if (flag != null) {
			super.toError("该考评内容已存在");
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}

	// ----------------------考评计划----------------------
	// 考评计划维护
	public String toManagePlan() throws Exception {
		dataList = qualityService.getPlanList(qcPlan, page);
		return "toManagePlan";
	}

	// 跳转---修改或创建 考评内容维护
	public String toAddEditPlan() throws Exception {
		if (qcPlan.getId() != null) {
			qcPlan = qualityService.getPlan(qcPlan);
		}
		return "toAddEditPlan";
	}

	// 查找考评内容
	public String tofindContent() throws Exception {
		dataList = qualityService.getContentList(qcContent);
		return "tofindContent";
	}

	// 查找考评内容
	public String tofindPlan() throws Exception {
		dataList = qualityService.getPlanList(qcPlan, page);
		return "tofindPlan";
	}

	// 修改或新建 考评内容维护
	public String toSavePlan() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		List employees = userAdminService.strToUserList(qcPlan
				.getEmployees_ids());
		String flag = qualityService.savePlan(qcPlan, user, employees);
		if (flag != null) {
			if(flag.equals("F")){
				super.toError("该考评计划已开始");
			}else if(flag.equals("T")){
				super.toError("该考评计划名称已存在");
			}
		}
		return Constant.ACTION_S.ajaxDone.toString();
	}

	// 查看考评计划执行情况
	public String toPlanTaskList() throws Exception {
		qcTask.setEnable_flag("T");
		dataList = qualityService.getPlanTaskList(qcTask, page);
		List list = qualityService.getEvaluatedTask(qcTask);
		dataList = getEvaluateTaskList(dataList, list);
		super.getRequest().setAttribute("contentitemlist", list);

		return "toPlanTaskList";
	}
	
	// 查看考评计划人员
	public String toPlanEmployeeList() throws Exception {
		dataList = qualityService.toPlanEmployeeList(qcEmployee);
		return "toPlanEmployeeList";
	}
	
	// 查看考评计划人员
	public String toPlanEmployeeTaskList() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qualityService.checkEmployeeTask(qcEmployee,user);
		dataList = qualityService.getPlanTaskList(qcTask, page);
		int tflag = 0;
		QcTask task = new QcTask();
		for(Object object:dataList){
			 task = (QcTask)object;
			if(task.getEnable_flag().equals("F")){
				tflag=1;
			}
		}
		if(tflag==0&&dataList.size()!=0){
			qualityService.updatePlanEmployee(task,user);	
		}
		
		return "toPlanEmployeeTaskList";
	}

	// 质检计划执行
	public String toExePlan() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qcPlan.setExecutor(user.getFullname() + "[" + user.getUsername() + "]");
		qcPlan.setPlan_start(GetNowDate());
		qcPlan.setEnable_flag("F");
		dataList = qualityService.getPlanList(qcPlan, page);
		return "toExePlan";
	}

	// 查看考评计划执行情况
	public String toPlanTaskListCheck() throws Exception {
		dataList = qualityService.getPlanTaskList(qcTask, page);
		return "toPlanTaskListCheck";
	}

	// 查看考评计划执行情况
	public String toEvaluateTask() throws Exception {
		String sType = qualityService.getServiceType2(qcTask.getId());
		qcTask = qualityService.getTask(qcTask);
		QcTask qc = qualityService.getTaskRecord(qcTask);
		qcTask.setSatisfaction(qc.getSatisfaction());
		qcContent = qualityService.getContent(qcContent);
		summary.setRecord_id(qcTask.getRecordid());
		summary = summaryService.getSummaryByRecordId(summary);
		dataList = qualityService.getContentItemList(contentItem);
		qcTask.setService_type(sType);
		return "toEvaluateTask";
	}

	
	// 修改计划评分
	public String toAddNewRecord() throws Exception {
		if(qcTask.getCallrecord_id()!=null&&qcTask.getCallrecord_id().equals("F")){
			qcTask.setValues("F");
		}else{
			contentItem.setContent_id(qcContent.getId());
			if(qcTask.getCallrecord_id()!=null){
				qcTask = qualityService.getTaskRecord(qcTask);
			}else if(qcTask.getRecordid()!=null){
				qcTask = qualityService.getTaskRecord2(qcTask);
			}
			String sType = qualityService.getServiceType(qcTask.getCallrecord_id());
			summary.setRecord_id(qcTask.getRecordid());
			summary = summaryService.getSummaryByRecordId(summary);
			qcContent = qualityService.getContent(qcContent);
			dataList = qualityService.getContentItemList(contentItem);
			qcTask.setValues("T");
			qcTask.setService_type(sType);
		}
		return "toAddNewRecord";
	}	

	
	
	// 保存评价(针对投诉的直接考评)
	public String toSaveEvaluateRecord() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		qcTask.setExecutor(user.getUsername());
		qcTask.setContent_id(qcContent.getId());
		qcTask.setPlan_id(-1);
		qualityService.insertTaskRecord(qcTask,user);
		systemService.insertRemind("QUALITY", qcTask.getId(),"新录音已被考评", "新录音考于"+Util.getTimestamp()+"被考评，考评得分为"+qcTask.getScore()+"分", null, null, qcTask.getEmployee(), user);
		return Constant.ACTION_S.ajaxDone.toString();
	}	

	// 把考评结果和任务封装在一起 (CheckSpot)
	private List getSpotCheckList(List dataList, List list) {
		List list1 = new ArrayList();
		for (Object object : dataList) {
			CheckSpot task = (CheckSpot) object;
			task.setList(getContentItemList(task.getResult(), list));
			list1.add(task);
		}
		return list1;
	}

	// 把考评结果和任务封装在一起(TASK)
	private List getEvaluateTaskList(List dataList, List list) {
		List list1 = new ArrayList();
		for (Object object : dataList) {
			QcTask task = (QcTask) object;
			task.setList(getContentItemList(task.getResult(), list));
			list1.add(task);
		}
		return list1;
	}

	// 二次封装考评结果和任务
	public List<ContentItem> getContentItemList(String result, List list) {
		String str[] = result.split(",");
		for (int i = 0; i < list.size(); i++) {
			int id = ((ContentItem) list.get(i)).getId();
			for (int j = 0; j < str.length; j++) {
				String strs[] = str[j].split(":");
				if (id == Integer.parseInt(strs[0])) {
					((ContentItem) list.get(i)).setValues(strs[1]);
				}
			}
		}
		return list;
	}

	// 获取当前时间
	public String GetNowDate() {
		String temp_str = "";
		Date dt = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		temp_str = sdf.format(dt);
		return temp_str;
	}

	// ------------------------ 满意度 ---------------------
	public String toManageSatisfication() throws Exception {
		if (satisfication.getCall_time() != null
				&& satisfication.getCall_time().equals("")) {
			satisfication.setCall_time(null);
		}
		if (satisfication.getEndtime() != null
				&& satisfication.getEndtime().equals("")) {
			satisfication.setEndtime(null);
		}
		if (satisfication.getAgent_name() != null
				&& satisfication.getAgent_name().equals("")) {
			satisfication.setAgent_name(null);
		}
		if (satisfication.getAgent_no() != null
				&& satisfication.getAgent_no().equals("")) {
			satisfication.setAgent_no(null);
		}
		if (satisfication.getCalled() != null
				&& satisfication.getCalled().equals("")) {
			satisfication.setCalled(null);
		}
		if (satisfication.getCaller() != null
				&& satisfication.getCaller().equals("")) {
			satisfication.setCaller(null);
		}
		if (satisfication.getSatisfied() != null
				&& satisfication.getSatisfied().equals("")) {
			satisfication.setSatisfied(null);
		}
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (satisfication.getEndtime() == null
				&& satisfication.getCall_time() == null
				&& satisfication.getAgent_name() == null
				&& satisfication.getAgent_no() == null
				&& satisfication.getCalled() == null
				&& satisfication.getCaller() == null
				&& satisfication.getSatisfied() == null
				&& satisfication.getTime_long() == null
				&& satisfication.getTime_long1() == null) {
			Calendar now = Calendar.getInstance();
			now.setTime(new Date());
			now.set(Calendar.DATE, now.get(Calendar.DATE) - 3);
			satisfication.setCall_time(df.format(now.getTime()));
		} else {
			if (satisfication.getCall_time() != null
					&& satisfication.getEndtime() != null) {

				Date date = sdf.parse(satisfication.getCall_time());
				Date date1 = sdf.parse(satisfication.getEndtime());
				satisfication.setCall_time(df.format(date.getTime()));
				satisfication.setEndtime(df.format(date1.getTime()));
			} else if (satisfication.getCall_time() == null
					&& satisfication.getEndtime() != null) {
				Date date1 = sdf.parse(satisfication.getEndtime());
				satisfication.setEndtime(df.format(date1.getTime()));
			} else if (satisfication.getCall_time() != null
					&& satisfication.getEndtime() == null) {
				Date date = sdf.parse(satisfication.getCall_time());
				satisfication.setCall_time(df.format(date.getTime()));
			}
		}
		dataList = qualityService.getSatisficationList(satisfication, page);

		if (satisfication.getCall_time() != null
				&& !satisfication.getCall_time().equals("")) {
			Date date = df.parse(satisfication.getCall_time());
			satisfication.setCall_time(sdf.format(date.getTime()));
		}
		if (satisfication.getEndtime() != null
				&& !satisfication.getEndtime().equals("")) {
			Date date = df.parse(satisfication.getEndtime());
			satisfication.setEndtime(sdf.format(date.getTime()));
		}
		return "toManageSatisfication";
	}
	// 电话小结管理
	public String toScoreSummary() throws Exception {
		if(summary.getStart_time()==null||summary.getStart_time().equals("")){
			summary.setStart_time(DateUtil.formatDateToStr("yyyy-MM-dd 00:00:00", new Date()));
		}
		if(summary.getEnd_time()==null||summary.getEnd_time().equals("")){
			summary.setEnd_time(DateUtil.formatDateToStr("yyyy-MM-dd 23:59:59", new Date()));
		}
        dataList = summaryService.getSummaryList(summary, page);
		return "toScoreSummary";
	}
	public Satisfication getSatisfication() {
		return satisfication;
	}

	public void setSatisfication(Satisfication satisfication) {
		this.satisfication = satisfication;
	}

	public QcContent getQcContent() {
		return qcContent;
	}

	public void setQcContent(QcContent qcContent) {
		this.qcContent = qcContent;
	}

	public ContentItem getContentItem() {
		return contentItem;
	}

	public void setContentItem(ContentItem contentItem) {
		this.contentItem = contentItem;
	}

	public QcPlan getQcPlan() {
		return qcPlan;
	}

	public void setQcPlan(QcPlan qcPlan) {
		this.qcPlan = qcPlan;
	}

	public QcTask getQcTask() {
		return qcTask;
	}

	public void setQcTask(QcTask qcTask) {
		this.qcTask = qcTask;
	}

	public CheckSpot getCheckSpot() {
		return checkSpot;
	}

	public void setCheckSpot(CheckSpot checkSpot) {
		this.checkSpot = checkSpot;
	}

	public QcComplain getQcComplain() {
		return qcComplain;
	}

	public void setQcComplain(QcComplain qcComplain) {
		this.qcComplain = qcComplain;
	}

	public ComplainRes getComplainRes() {
		return complainRes;
	}

	public void setComplainRes(ComplainRes complainRes) {
		this.complainRes = complainRes;
	}

	public QcEmployee getQcEmployee() {
		return qcEmployee;
	}

	public void setQcEmployee(QcEmployee qcEmployee) {
		this.qcEmployee = qcEmployee;
	}

	public Summary getSummary() {
		return summary;
	}

	public void setSummary(Summary summary) {
		this.summary = summary;
	}
	
	
}
