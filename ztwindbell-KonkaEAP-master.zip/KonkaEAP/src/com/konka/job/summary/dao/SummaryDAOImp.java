package com.konka.job.summary.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.common.base.BaseVO;
import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.research.model.ResField;
import com.konka.job.research.model.ResProject;
import com.konka.job.summary.model.Summary;


@Repository("SummaryDAO")
public class SummaryDAOImp extends BaseDAOImp implements SummaryDAO {
	public SummaryDAOImp() {
		super.setMapper("com.konka.job.summary.model.Summary");
	}

	@Override
	public void deleteSummary(Summary summary) {
		this.getSqlSessionTemplate().delete(this.getMapper() + ".deleteSummary", summary);
	}

	@Override
	public Summary getById2(String id) {
		return this.getSqlSessionTemplate().selectOne(this.getMapper() + ".getById2", id);
	}
	
}
