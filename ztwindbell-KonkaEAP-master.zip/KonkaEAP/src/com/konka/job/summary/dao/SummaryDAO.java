package com.konka.job.summary.dao;




import com.konka.common.base.BaseDAO;
import com.konka.job.summary.model.Summary;

public interface SummaryDAO extends BaseDAO{

	public void deleteSummary(Summary summary);

	public Summary getById2(String recordid);
	
	
}
