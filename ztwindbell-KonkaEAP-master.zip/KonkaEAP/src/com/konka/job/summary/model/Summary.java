package com.konka.job.summary.model;


import com.konka.common.base.BaseVO;

public class Summary extends BaseVO {
	private Integer id;
	private String call_result;
	private String record_id;
	private String type;
	private String custcall;
	private String agentcall;
	private Integer product_id;
	private Integer service_id;
	private Integer area_id;
	private String remark;
	
	private String call_result_cn;
	private String product_id_cn;
	private String service_id_cn;
	
	private Integer is_complete;
	
	private Integer satisfaction;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCall_result() {
		return call_result;
	}
	public void setCall_result(String call_result) {
		this.call_result = call_result;
	}
	public String getRecord_id() {
		return record_id;
	}
	public void setRecord_id(String record_id) {
		this.record_id = record_id;
	}
	public String getCustcall() {
		return custcall;
	}
	public void setCustcall(String custcall) {
		this.custcall = custcall;
	}
	public String getAgentcall() {
		return agentcall;
	}
	public void setAgentcall(String agentcall) {
		this.agentcall = agentcall;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	
	public Summary() {
		// TODO Auto-generated constructor stub
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getProduct_id() {
		return product_id;
	}
	public void setProduct_id(Integer product_id) {
		this.product_id = product_id;
	}
	public Integer getService_id() {
		return service_id;
	}
	public void setService_id(Integer service_id) {
		this.service_id = service_id;
	}
	public Integer getArea_id() {
		return area_id;
	}
	public void setArea_id(Integer area_id) {
		this.area_id = area_id;
	}
	public String getCall_result_cn() {
		return call_result_cn;
	}
	public void setCall_result_cn(String call_result_cn) {
		this.call_result_cn = call_result_cn;
	}
	public String getProduct_id_cn() {
		return product_id_cn;
	}
	public void setProduct_id_cn(String product_id_cn) {
		this.product_id_cn = product_id_cn;
	}
	public String getService_id_cn() {
		return service_id_cn;
	}
	public void setService_id_cn(String service_id_cn) {
		this.service_id_cn = service_id_cn;
	}
	public Integer getIs_complete() {
		return is_complete;
	}
	public void setIs_complete(Integer is_complete) {
		this.is_complete = is_complete;
	}
	public Integer getSatisfaction() {
		return satisfaction;
	}
	public void setSatisfaction(Integer satisfaction) {
		this.satisfaction = satisfaction;
	}
	
	
}
