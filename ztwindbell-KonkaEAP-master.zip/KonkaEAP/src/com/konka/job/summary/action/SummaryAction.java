package com.konka.job.summary.action;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.DateTool;
import com.konka.common.tool.Util;
import com.konka.job.summary.model.Summary;
import com.konka.job.summary.service.SummaryService;
import com.konka.useradmin.model.User;
import com.konka.useradmin.service.UserAdminService;
import com.konka.util.DateUtil;

@Controller
@Scope("prototype")
public class SummaryAction extends BaseAction {

	@Autowired
	private SummaryService summaryService;
	@Autowired
	private UserAdminService userAdminService;

	private Summary summary = new Summary() ;
	
	
	// 电话小结管理
	public String toManageSummary() throws Exception {
		if(summary.getStart_time()==null||summary.getStart_time().equals("")){
			summary.setStart_time(DateUtil.formatDateToStr("yyyy-MM-dd 00:00:00", new Date()));
		}
		if(summary.getEnd_time()==null||summary.getEnd_time().equals("")){
			summary.setEnd_time(DateUtil.formatDateToStr("yyyy-MM-dd 23:59:59", new Date()));
		}
        dataList = summaryService.getSummaryList(summary, page);
		return "toManageSummary";
	}
	
	// 查询个人电话小结
	public String toManageSummaryPer() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		if(summary.getStart_time()==null||summary.getStart_time().equals("")) {
			summary.setStart_time(DateTool.formatDate("yyyy-MM-dd", null)+" 00:00:00");
		}
		if(summary.getEnd_time()==null||summary.getEnd_time().equals("")) {
			summary.setEnd_time(DateTool.formatDate("yyyy-MM-dd", null)+" 23:59:59");
		}
		summary.setCreate_employee(user.getUsername());
	    dataList = summaryService.getSummaryList(summary, page);
		return "toManageSummaryPer";
	}	
	
	// 删除电话小结管理
	public String toDelSummary() throws Exception {
		summary.setValues(ids);
		summaryService.delSummary(summary);
		return Constant.ACTION_S.ajaxDone.toString();
	}	
	// 修改电话小结管理
	public String toSaveSummary() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		Util.setUpdateToVO(summary, user);
		summary.setCall_result_cn(Constant.codeNameMap.get("SUMMARY_CONVERSE_RESULT").get(summary.getCall_result()));
		summary.setProduct_id_cn(Constant.codeNameMap.get("SUMMARY_PRODUCT_ID").get(summary.getProduct_id()+""));
		summary.setService_id_cn(Constant.codeNameMap.get("SUMMARY_SERVICE_ID").get(summary.getService_id()+""));
		summaryService.SaveSummary(summary);
		return Constant.ACTION_S.ajaxDone.toString();
	}		
	//打开修改电话小结页面
	public String toAddEditSummary() throws Exception {
		if (summary.getId() != null) {
			summary = summaryService.getSummary(summary);
		}
		return "toAddEditSummary";
	}
	
	//打开修改电话小结页面
		public String toModifySummary() throws Exception {
			if (summary.getId() != null) {
				summary = summaryService.getSummary(summary);
			}
			return "toModifySummary";
		}
	//查看电话小结页面
	public String toLookSummary() throws Exception {
		if (summary.getId() != null) {
			summary = summaryService.getSummary(summary);
		}
		return "toLookSummary";
	}	
	
	
	public Summary getSummary() {
		return summary;
	}
	public void setSummary(Summary summary) {
		this.summary = summary;
	}

}
