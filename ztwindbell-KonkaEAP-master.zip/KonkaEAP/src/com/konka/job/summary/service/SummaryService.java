package com.konka.job.summary.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.job.summary.model.Summary;




public interface SummaryService {
	/**
	 * 获取所有电话小结
	 */
	public List<Summary> getSummaryList(Summary summary, Page page)throws Exception;
	/**
	 * 删除电话小结
	 */
	public void delSummary(Summary summary);
	/**
	 * 获取某电话小结
	 * @throws Exception 
	 */
	public Summary getSummary(Summary summary) throws Exception;
	
	/**
	 * 修改电话小结
	 * @throws Exception 
	 */
	public void SaveSummary(Summary summary) throws Exception;
	
	/**
	 * 通过录音号码获取电话小结
	 * @throws Exception 
	 */
	public Summary getSummaryByRecordId(Summary summary) throws Exception;
	
}
