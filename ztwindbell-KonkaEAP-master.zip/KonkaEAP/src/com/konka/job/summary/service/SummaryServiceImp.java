package com.konka.job.summary.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.job.summary.dao.SummaryDAO;
import com.konka.job.summary.model.Summary;



@Service("SummaryService")
@Transactional
public class SummaryServiceImp implements SummaryService {
	@Autowired
	private SummaryDAO summaryDAO;

	@Override
	public List<Summary> getSummaryList(Summary summary, Page page)
			throws Exception {
		return summaryDAO.getObjectList(summary, page);
	}

	@Override
	public void delSummary(Summary summary) {
		 summaryDAO.deleteSummary(summary);
	}

	@Override
	public Summary getSummary(Summary summary) throws Exception {
		return (Summary) summaryDAO.getById(summary.getId());
	}

	@Override
	public void SaveSummary(Summary summary) throws Exception {
		summaryDAO.update(summary);
	}

	@Override
	public Summary getSummaryByRecordId(Summary summary) throws Exception {
		return (Summary) summaryDAO.getById2(summary.getRecord_id());
	}
	
	

	
	
	
	
}
