package com.konka.job.consult.action;


import java.io.PrintWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.metamodel.SetAttribute;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.konka.common.base.BaseAction;
import com.konka.common.constant.Constant;
import com.konka.common.tool.Tree;
import com.konka.common.tool.Util;
import com.konka.database.model.Series;
import com.konka.job.consult.model.Consult;
import com.konka.job.consult.service.ConsultService;
import com.konka.useradmin.model.User;

@Controller
@Scope("prototype")
public class ConsultAction extends BaseAction {
	@Autowired
	private ConsultService consultService;
	private Consult consult = new Consult() ;
	private String param;
	private String param2;
	
	public String toAddEditConsult() throws Exception {
		return "toAddEditConsult";
	}
	public String toSaveConsult() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		consultService.saveConsult(consult,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toUpdateConsult() throws Exception {
		User user = (User) super.getSession().get(Constant.SESSION_USER);
		consultService.updateConsult(consult,user);
		return Constant.ACTION_S.ajaxDone.toString();
	}
	
	public String toSearchConsult() throws Exception {
		if(param.equals("")){
			setParam(null);
		}
		return "toSearchConsult";
	}
	
	public String toSearchConsultH() throws Exception {
		if(param.equals("")){
			setParam(null);
		}
		return "toSearchConsultH";
	}
	
	public String toSearchConsult2() throws Exception {
		if(!param.equals("")){
			setParam(new String(param.getBytes("iso-8859-1"),"UTF-8") );
		}
		return "toSearchConsult2";
	}
	
	public String toSearchConsult2H() throws Exception {
		if(!param.equals("")){
			setParam(new String(param.getBytes("iso-8859-1"),"UTF-8") );
		}
		return "toSearchConsult2H";
	}
	
	public String toLookConsult() throws Exception {
		consult = consultService.getAllConsultById(consult);
		return "toLookConsult";
	}
	
	public String toModifyConsult() throws Exception {
		consult = consultService.getAllConsultById(consult);
		return "toModifyConsult";
	}
	
	public String toSearchConsultInfo() throws Exception {
		if(consult.getStart_time()==null){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar now = Calendar.getInstance();
			Calendar now2 = Calendar.getInstance();
			now.setTime(new Date());
			now2.setTime(new Date());
			now.set(Calendar.DATE, now.get(Calendar.DATE) - 7);
			now2.set(Calendar.DATE, now2.get(Calendar.DATE));
			consult.setStart_time(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
			consult.setEnd_time(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");
		}
		dataList = consultService.getAllConsultList(consult, page);
		return "toSearchConsultInfo";
	}
	
	public String toSearchConsultInfo2() throws Exception {
		if(consult.getStart_time()==null){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar now = Calendar.getInstance();
			Calendar now2 = Calendar.getInstance();
			now.setTime(new Date());
			now2.setTime(new Date());
			now.set(Calendar.DATE, now.get(Calendar.DATE) - 7);
			now2.set(Calendar.DATE, now2.get(Calendar.DATE));
			consult.setStart_time(sdf.format(now.getTime()).substring(0,11)+"00:00:00");
			consult.setEnd_time(sdf.format(now2.getTime()).substring(0,11)+"23:59:59");
		}
		dataList = consultService.getAllConsultList(consult, page);
		return "toSearchConsultInfo2";
	}
	
	public String getConsultInfo() throws Exception {
		super.getResponse().setContentType("text/xml;charset=utf-8");
		super.getResponse().setCharacterEncoding("UTF-8");
		if(consult.getContactCall()!=null||!consult.getContactCall().equals("")) {
			consult = consultService.getAllConsultByFromCall(consult);
			if(consult==null) {
				 PrintWriter out= super.getResponse().getWriter();
				 JSONObject obj=new JSONObject();
				 obj.put("retFlag", "K");
				 obj.put("retMsg", "无法找到客户资料");
				 out.println(obj.toString());
				 out.close();
			 } else {
				 PrintWriter out= super.getResponse().getWriter();
				 JSONObject obj=new JSONObject();
				 obj.put("retFlag", "T");
				 obj.put("name",consult.getName());
				 obj.put("city",consult.getCity());
				 obj.put("product_num",consult.getProduct_num());
				 obj.put("address", consult.getAddress());
				 out.println(obj.toString());
				 out.close();
			 }
		}else{
			PrintWriter out=super.getResponse().getWriter();
			JSONObject obj=new JSONObject();
			obj.put("retFlag", "F");
			obj.put("retMsg", "未填写联系号码");
			out.println(obj.toString());
			out.close();
			return null;
		}
		return null;
	}
	
	public Consult getConsult() {
		return consult;
	}
	public void setConsult(Consult consult) {
		this.consult = consult;
	}
	public String getParam() {
		return param;
	}
	public void setParam(String param) {
		this.param = param;
	}
	public String getParam2() {
		return param2;
	}
	public void setParam2(String param2) {
		this.param2 = param2;
	}
	
	
}
