package com.konka.job.consult.model;

import com.konka.common.base.BaseVO;

public class Consult extends BaseVO {
	
	private Integer id;
	private String custId;
	private String name;
	private String city;
	private String fromCall;
	private String contactCall;
	private String address;
	private String consult_desc;
	private String product_series;
	private String product_num;
	
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getFromCall() {
		return fromCall;
	}
	public void setFromCall(String fromCall) {
		this.fromCall = fromCall;
	}
	
	public String getContactCall() {
		return contactCall;
	}
	public void setContactCall(String contactCall) {
		this.contactCall = contactCall;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getConsult_desc() {
		return consult_desc;
	}
	public void setConsult_desc(String consult_desc) {
		this.consult_desc = consult_desc;
	}
	public String getProduct_num() {
		return product_num;
	}
	public void setProduct_num(String product_num) {
		this.product_num = product_num;
	}
	public String getProduct_series() {
		return product_series;
	}
	public void setProduct_series(String product_series) {
		this.product_series = product_series;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
}
