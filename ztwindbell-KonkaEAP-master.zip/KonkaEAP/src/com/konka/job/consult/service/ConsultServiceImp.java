package com.konka.job.consult.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.konka.common.tool.Page;
import com.konka.common.tool.Util;
import com.konka.job.consult.dao.ConsultDAO;
import com.konka.job.consult.model.Consult;
import com.konka.job.cust.dao.CustInfoDAO;
import com.konka.job.cust.dao.FixInfoDAO;
import com.konka.job.cust.model.CustInfo;
import com.konka.job.cust.model.FixInfo;
import com.konka.useradmin.model.User;

@Service("ConsultService")
@Transactional  
public class ConsultServiceImp implements ConsultService {
	@Autowired
	private ConsultDAO consultDAO;
	
	
	public void saveConsult(Consult consult, User user) throws Exception {
		Util.setCreateToVO(consult, user);
		try{
			consultDAO.insert(consult);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}


	@Override
	public List getAllConsultList(Consult consult, Page page)throws Exception {
		return consultDAO.getObjectList(consult, page);
	}


	@Override
	public Consult getAllConsultById(Consult consult) throws Exception {
		return (Consult) consultDAO.getById(consult.getId());
	}


	@Override
	public void updateConsult(Consult consult, User user) throws Exception {
		Util.setUpdateToVO(consult, user);
		try{
			consultDAO.update(consult);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}


	@Override
	public Consult getAllConsultByFromCall(Consult consult) throws Exception {
		// TODO Auto-generated method stub
		return (Consult) consultDAO.getByObject(consult);
	}
}
