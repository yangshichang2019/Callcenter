package com.konka.job.consult.service;

import java.util.List;

import com.konka.common.tool.Page;
import com.konka.job.consult.model.Consult;
import com.konka.useradmin.model.User;


public interface ConsultService {
	
	public void saveConsult(Consult consult, User user) throws Exception;
	
	public List getAllConsultList(Consult consult,Page page) throws Exception;
	
	public Consult getAllConsultById(Consult consult) throws Exception;

	public void updateConsult(Consult consult, User user)throws Exception;

	public Consult getAllConsultByFromCall(Consult consult) throws Exception;
}
