package com.konka.job.consult.dao;

import org.springframework.stereotype.Repository;

import com.konka.common.base.BaseDAOImp;
import com.konka.job.cust.model.CustInfo;
@Repository("ConsultDAO")
public class ConsultDAOImp extends BaseDAOImp implements ConsultDAO {
	public ConsultDAOImp() {
		super.setMapper("com.konka.job.consult.model.Consult");
	}
}
