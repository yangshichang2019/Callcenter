package com.konka.job.consult.dao;

import com.konka.common.base.BaseDAO;
import com.konka.job.cust.model.CustInfo;

public interface ConsultDAO extends BaseDAO {
}