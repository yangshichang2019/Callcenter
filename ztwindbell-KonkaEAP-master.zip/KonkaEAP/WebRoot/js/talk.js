var talk_error_001 = "服务器断开！";
var talk_error_002 = "登录信息已失效！";
//发送信息
var font_family="SimSun";
var font_size="12px";
var font_weight="normal";
var font_style="normal";
var font_color="#000000";
function talk_send_msg(content,type,receive,is_public){
	if(content!='') {
		var msgStr = jQuery.parseJSON("{\"content\":\""+content+"\",\"type\":\""+type+"\",\"receive\":\""+receive+"\",\"is_public\":\""+is_public+"\"}");
		content = escape(content);
		var d = {"talkMsg.content":content,"talkMsg.type":type,"talkMsg.receive":receive,"talkMsg.format":"font-family:"+font_family+";font-size:"+font_size+";font-weight:"+font_weight+";font-style:"+font_style+";color:"+font_color+";","talkMsg.is_public":is_public};
		$.ajax({
			type: "post",
			url: 'talk_sendUserTalkMsg',
			data: d,
			dataType:'json',
			timeout:3000,
			error: function(){
				talk_send_msg_error(talk_error_001,msgStr);
			},
			success: function(result){
				if(result!=null){
					if(result.statusCode) {
						talk_send_msg_error(talk_error_002,msgStr);
						return;
					}
					if(result.result=="success") {
						talk_send_msg_success(result,msgStr);
					} else {
						talk_send_msg_error(result.info,msgStr);
					}
				}else {

					talk_send_msg_error(talk_error_001,msgStr);
				}
			}
		});
	}
}
var talk_time = "";
var online_status = "ONLINE";
//循环获取最新信息
function talk_get_msg(){
	var d = "talkMsg.start_time="+talk_time+"&talkOnline.status="+online_status;
	$.ajax({
		type: "post",
		url: 'talk_getUserTalkMsg',
		data:d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_get_msg_error(talk_error_001);
		},
		success: function(data){
			if(data!=null){
				if(data.statusCode) {
					talk_get_msg_error(talk_error_002);
					return;
				}
				if(data.result=="success") {
					talk_time = data.time;
					talk_get_msg_success(data);
				} else {
					talk_get_msg_error(data.info);
				}
			}else {

				talk_get_msg_error(talk_error_001);
			}
		}
	});
}
//获取离线消息列表
function talk_get_user_history_msg(){
	$.ajax({
		type: "post",
		url: 'talk_getTalkHistoryUserList',
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_get_user_history_msg_error(talk_error_001);
		},
		success: function(data){
			if(data!=null){
				if(data.statusCode) {
					talk_get_user_history_msg_error(talk_error_002);
					return;
				}
				if(data.result=="success") {
					talk_get_user_history_msg_success(data);
				} else {
					talk_get_user_history_msg_error(data.info);
				}
			}else {

				talk_get_user_history_msg_error(talk_error_001);
			}
		}
	});
}
//获取组列表
function talk_get_group(type){
	var d = "type=" + type;
	$.ajax({
		type: "post",
		url: 'talk_getTalkGroupList',
		data: d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_get_group_error(talk_error_001,type);
		},
		success: function(result){
			if(result!=null) {
				if(result.statusCode) {
					talk_get_group_error(talk_error_002,type);
					return;
				}
				if(result.result=="success") {
					talk_get_group_success(result,type);
				} else {
					talk_get_group_error(result.info,type);
				}
			}else {

				talk_get_group_error(talk_error_001,type);
			}
		}
	});
}
//获取组成员
function talk_get_group_user(id,page){
	if(page==null||page=='') {
		page = 1;
	}
	var d = "talkGroup.id=" + id+"&page.num="+page+"&page.numPerPage=100";
	$.ajax({
		type: "post",
		url: 'talk_toGetGroupUserList',
		data: d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_get_group_user_error(talk_error_001,id);
		},
		success: function(result){
			if(result!=null) {
				if(result.statusCode) {
					talk_get_group_user_error(talk_error_002,id);
					return;
				}
				if(result.result=="success") {
					talk_get_group_user_success(result,id);
				} else {
					talk_get_group_user_error(result.info,id);
				}
			}else {

				talk_get_group_user_error(talk_error_001,id);
			}
		}
	});
}
//获取个人信息
function talk_get_user_info(username){
	var d = "talkOnline.username=" + username;
	$.ajax({
		type: "post",
		url: 'talk_toLoadUserMsg',
		data: d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_get_user_info_error(talk_error_001,username);
		},
		success: function(result){
			if(result!=null) {
				if(result.statusCode) {
					talk_get_user_info_error(talk_error_002,username);
					return;
				}
				if(result.result=="success") {
					talk_get_user_info_success(result,username);
				} else {
					talk_get_user_info_error(result.info,username);
				}
			}else {

				talk_get_user_info_error(talk_error_001,username);
			}
		}
	});
}


//打开单个对象消息,读取部分历史消息
function talk_get_user_msg(type,id){
	var d = "talkMsg.type="+type+"&talkMsg.create_employee="+id;
	var msgStr = jQuery.parseJSON("{\"type\":\""+type+"\",\"id\":\""+id+"\"}");
	$.ajax({
		type: "post",
		url: 'talk_toUserTalkMsgForRead',
		data:d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_get_user_msg_error(talk_error_001,msgStr);
		},
		success: function(data){
			if(data!=null) {
				if(data.statusCode) {
					talk_get_user_msg_error(talk_error_002,msgStr);
					return;
				}
				if(data.result=="success") {
					talk_get_user_msg_success(data,msgStr);
				} else {
					talk_get_user_msg_error(data.info,msgStr);
				}
			}else {

				talk_get_user_msg_error(talk_error_001,msgStr);
			}
		}
	});
}
function talk_toSearchUser(key){
	var d = "keyword="+key;
	$.ajax({
		type: "post",
		url: 'talk_toSearchUser',
		data:d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_toSearchUser_error(talk_error_001,key);
		},
		success: function(data){
			if(data!=null) {
				if(data.statusCode) {
					talk_toSearchUser_error(talk_error_002,key);
					return;
				}
				if(data.result=="success") {
					talk_toSearchUser_success(data,key);
				} else {
					talk_toSearchUser_error(data.info,key);
				}
			}else {

				talk_toSearchUser_error(talk_error_001,key);
			}
		}
	});
}
function talk_toAddTalkGroupUser(username,groupId){
	var d = "username="+username;
	var d = {"talkOnline.username":username,"talkGroup.id":groupId};
	$.ajax({
		type: "post",
		url: 'talk_toAddTalkGroupUser',
		data:d,
		dataType:'json',
		timeout:3000,
		error: function(){
			talk_toAddTalkGroupUser_error(talk_error_001,username);
		},
		success: function(data){
			if(data!=null) {
				
				
				if(data.statusCode) {
					
					
					talk_toAddTalkGroupUser_success(data,username);
					talk_get_group_user(groupId);
					return;
				}
				if(data.result=="success") {
					
					
					talk_toAddTalkGroupUser_success(data,username);
				} else {
					talk_toAddTalkGroupUser_error(data.info,username);
				}
			}else {

				talk_toAddTalkGroupUser_error(talk_error_001,username);
			}
		}
	});
}