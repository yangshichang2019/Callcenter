
$(function (){			
   window['dandan']={}


	//ctrl+回车
	// $("#textarea").bind('keyup',function(event) {   
	// 	if(fasong_key=='ctrl') {
	//     	if(event.ctrlKey&&event.keyCode==13){   
	//     		saysay();
	//        }
	//	}else {
	//		if(!event.ctrlKey&&event.keyCode==13){
	//			saysay();
	//		}
	//	}
	// }); 
	$("#textarea").keypress(function(event) {  
		event = event || window.event;
		var asc = document.all ? event.keyCode : event.which;
		var shift = event.shiftKey;
		if(fasong_key=='ctrl') {
			if(event.ctrlKey) { 
				saysay();
	        	return false;
	        }
		}else{
			if(asc == 13 && !shift) {
				saysay();
				return false;
			}
		}
		return true;
	}); 
	
	
    $("#keyword").bind('keyup',function(event) {   
		if(event.keyCode==13){
			searchUser();
		}
    });
    
});

//浏览器
function liulanqi(){
	  var h=$(window).height();
	  var w=$(window).width();
	  //宽
	  if(w<=800){
		  $("#top").width(800);
		  $("#top #top_msg").width(445);
		  $("#body").width(800);
		  $("#mid_say #textarea").width(320)
	  }else{
		  $("#top").css("width","100%");  
		  $("#top #top_msg").width(w-355);
		  $("#body").css("width","100%"); 
		  $("#mid #mid_say #textarea").width(w-480);
	  }	  
	  //高
	  if(h<500){
		  $("#left .box_in").height(394);
		  $("#mid .my_show").height(262);
		  $("#right .showInfo").height(394);
	  }else {
		  $("#left .box_in").height(h-103);
		  $("#mid .my_show").height(h-235);
		  $("#right .showInfo").height(h-102);
	  }
	  //显示的内容的高度出现滚动条
}


  //搜索
function searchUser(){
  	if($("#keyword").val()!='') {
  		talk_toSearchUser($("#keyword").val());
  	}
}
//加人
function addGroupUser(){
  	if($("#username").val()!='') {
  		talk_toAddTalkGroupUser($("#username").val(),$("#groupId").val());
  	}
}
//改变聊天状态
function changeStatus(o){
	if(online_status=='ONLINE') {
		online_status = 'BUSY';
		$(o).html('<span>状态</span>：忙碌');
	}else if(online_status=='BUSY'){
		online_status = 'LEAVE';
		$(o).html('<span>状态</span>：离开');
	}else if(online_status=='LEAVE') {
		online_status = 'ONLINE';
		$(o).html('<span>状态</span>：在线');
	}
}
//光标移动到最后
function moveEnd() {
	var value = $("#textarea").html();
	$("#textarea").html("");
	$("#textarea").focus();
	$("#textarea").html(value);
}
//工具条操作
function format(o,t,v) {
	if(t=='family'||t=='size'||t=='color') {
		$(o).parent().parent().hide();
	}
	if(t=='family') {
		font_family = v;
		$("#textarea").css("font-family",font_family);
	}else if(t=='size') {
		font_size = v;
		$("#textarea").css("font-size",font_size);
	}else if(t=='weight') {
		if(font_weight==""||font_weight=="normal"){
			font_weight=v;
		}else {
			font_weight = "normal";
		}
		$("#textarea").css("font-weight",font_weight);
	}else if(t=='style') {
		if(font_style==""||font_style=="normal"){
			font_style=v;
		}else {
			font_style = "normal";
		}
		$("#textarea").css("font-style",font_style);
	}else if(t=='color') {
		font_color = v;
		$("#textarea").css("color",font_color);
	}else if(t=='face') {
		$("#textarea").append("<img src='"+v+"' />");
	}
	moveEnd();
}
//上传文件
function uploadFile(fileId, containerId) {  
	  $.ajaxFileUpload({  
	    fileElementId: fileId,  
	    url: '../up_doEditorUpload?uploadFile.model=IM&uploadFile.method=toSendUploadFile&uploadFile.subpath=office',  
	    dataType: 'json',  
	    beforeSend: function (XMLHttpRequest) {  
	      $("#updateContainer").html("正在上传请稍后...");
	    },  
	    success: function (data, textStatus) {  
	    	if(data.err!="") {
		    	$("#updateContainer").html(data.err);
	    	}else {
	    		$("#textarea").append("<a href='"+data.msg.url+"'>"+data.msg.localfile+"</a>");
	    		$("#updateContainer").html("发送成功！");
	    	}
	    },  
	    error: function (XMLHttpRequest, textStatus, errorThrown) {  
	      $("#" + containerId).html("上传出错！");  
	    },  
	    complete: function (XMLHttpRequest, textStatus) {  
	      //("loaded");  
	    }  
	  });  
}  


//更新页面用户状态
function updateUserStatus(user,status) {
	//中间
	$("#I_USER_"+user).attr("src","../themes/talk/"+status+".gif");
	//右侧
	$(".S_USER_"+user).attr("class","S_USER_"+user+" "+status);
	//左侧
	if($("#L_USER_"+user).hasClass("new")){
		$("#L_USER_"+user).attr("class","new "+status);
	}else {
		$("#L_USER_"+user).attr("class",status);
	}
}
function statusToCn(s) {
	if(s=="EXIT") {
		return "离线";
	}else if(s=="ONLINE"){
		return "在线";
	}else if(s=="LEAVE") {
		return "离开";
	}else if(s=="BUSY") {
		return "忙碌";
	}else {
		return "未知";
	}
}
//获取用户状态图标
function getUserIcon(type,user){
	if(type=="GROUP") {
		return "../themes/talk/GROUP.gif";
	}else if(type=="USER"){
		var s = online_user.get(user);
		if(s!=null&&s!='') {
			return "../themes/talk/"+s+".gif";
		}else {
			return "../themes/talk/EXIT.gif";
		}
	}
}
//获取用户状态样式
function getUserIconClass(type,user){
	if(type=="GROUP") {
		return "group";
	}else if(type=="USER"){
		var s = online_user.get(user);
		if(s!=null&&s!='') {
			return s;
		}else {
			return "EXIT";
		}
	}
}

//人员、群组鼠标经过事件
function hover_user($this){
  $($this).hover(
    function () {
     $(this).addClass("hover");
    },
    function () {
      $(this).removeClass("hover");
    }
  );
}

//更新下拉框个数
function user_geshu(){
     var length1=$(".ul_1 > li").length;
     var length2=$(".ul_2 > li").length;
     $(".n_geshu_1").text(length1);
     $(".n_geshu_2").text(length2);	
}


//未读消息提醒
function remindUser() {
	var title_count = 0;
	$(".ul_1 li").each(function(index,element){
		title_count = parseInt($(element).attr("num"))+title_count;
	});
	$(".ul_2 li").each(function(index,element){
		title_count = parseInt($(element).attr("num"))+title_count;
	});
	if(title_count>0) {
		document.title="("+title_count+")新消息";
	}else {
		document.title="席间消息";
	}
}
//接收消息时展示消息内容
function showMsg(type,name,receive,full,time,content,mat,timeStyle){
	var u = "";
	var c = "";
	if(timeStyle!='long') {
		time = time.substr(11,8);
	}else {
		time = time.substr(0,19);
	}
	
	if(type=="USER"){
		u = name;
		c = "<div class='say_con'><div class='my_say_t'>"+full+"("+name+")"+" "+time+"</div><div class='my_say_c' style='"+mat+"'>"+content+"</div></div>";
		
	}else if(type=="GROUP"){
		u = receive;
		if(content.indexOf("@"+login_user)>-1||content.indexOf("@"+login_full)>-1){
			var num = $("#L_GROUP_"+u).attr("num");
			$("#L_GROUP_"+u).attr("num",parseInt(num)+1);
			$("#L_GROUP_"+u).html("被@("+(parseInt(num)+1)+")");
		}
		c = "<div class='say_con'><div class='my_say_t'>"+full+"(<a href='javascript:' onclick='title_new(\""+full+"\",\""+name+"\",\"USER\");return false;'>"+name+"</a>)"+" "+time+"</div><div class='my_say_c' style='"+mat+"'>"+content+"</div></div>";
	}
	
	if($("#user_con_"+type+"_"+u).length<1){
		$(".my_show").append('<div class="user_con_div" id="user_con_'+type+'_'+u+'" style="display:none"></div>');
	}
	$("#user_con_"+type+"_"+u).append(c);
	//delete if($("#M_"+type+"_"+u).length>0){
	if(ing_user==u&&ing_type==type) {
		$(".my_show").scrollTop($("#user_con_"+type+"_"+u).height()-$(".my_show").height());//让滚动滚到最底端
	}
	//delete else {
	//delete $("#zi_"+type+"_"+u).addClass("new");
	//delete }
	//delete }else {
		if($("#L_"+type+"_"+u).length>0){
			$("#L_"+type+"_"+u).addClass("new");//<img src='../themes/talk/msg.gif'/>
			//更新消息数
			if(type=="USER") {
				var num = $("#L_"+type+"_"+u).attr("num");
				$("#L_"+type+"_"+u).attr("num",parseInt(num)+1);
				$("#L_"+type+"_"+u).html(full+"("+(parseInt(num)+1)+")");
			}
		}else {
			$(".ul_1").prepend('<li id="L_'+type+'_'+u+'" num="1" class="new '+getUserIconClass(type,u)+'" title="'+u+'">'+full+'(1)</li>');
			$('#L_'+type+'_'+u).click(function(){title_new(full,name,type);});//给按钮加事件
			hover_user('#L_'+type+'_'+u);
			user_geshu();
		}
	//delete }
	//如果聊天框内消息队列大于100，则移除前30个
	if($("#user_con_"+type+"_"+u+" div").length>200) {
		$("#user_con_"+type+"_"+u+" div:lt(30)").remove();
	}
}

//关闭打开的窗口
function delete_user(user,type){
	//delete if(ing_user==user&&ing_type==type){
		var id = 'USER_'+user;
		//delete	$("#M_"+id).remove();//栏目栏目
		$("#user_con_"+id).remove();//删除内容
		$("#L_"+id).remove();//删除内容
		$("#R_"+id).hide();
		//delete	if($(".list").length>0){
		//delete		 var eq=$(".list").length-1;
		//delete		 ing_user=$(".list:eq("+eq+")").attr("user");//给聊天框定位
		//delete		 ing_type=$(".list:eq("+eq+")").attr("type");//给聊天框定位
		//delete		 $("#user_con_"+ing_type+"_"+ing_user).show();//显示最后一个的内容
		//delete		 $("#R_"+ing_type+"_"+ing_user).show();//显示最后一个的内容
		//delete		 $(".my_show").scrollTop($(".con_box").height()-$(".my_show").height());/*让滚动滚到最底端*/
		//delete		 $("#zino_"+ing_type+"_"+ing_user).addClass("td_hide_click");//给最后一个加样式
		//delete     $("#zi_"+ing_type+"_"+ing_user).addClass("td_user_click");//给最后一个加样式
		//delete	}
		user_geshu();
		ing_user='';
		ing_type='';
		ing_name='';
		//delete}
	//deleteelse {
	//delete	title_new(name,user,type);
	//delete}
}

//发送后调用此方法
function saysay(){
	if(ing_user!=''){
		var c = $("#textarea").html();
		c = trim2(c);
		if(c.length<1){
			$(".tixing").html('o(︶︿︶)o 内容不能为空！');
			return;
		}
		if(strLength(c)>1000) {
			$(".tixing").html('(＞﹏＜) 内容太长了！');
		}else {
			if($("#is_public:checked").val()=='T'){
				talk_send_msg(c,ing_type,ing_user,'T');
			}else {
				talk_send_msg(c,ing_type,ing_user,'F');
			}
			$("#textarea").html("");
			$(".tixing").html("");
		}
		moveEnd();//光标焦点
	} else {
		$(".tixing").html('(─.─||| 没有聊天对象！');
	}
}
//替换所有
function trim2(content){   
	  var string = content;   
	  try{   
		  string = string.replace(/<!--[\s\S]*?-->|<!(--)?\[[\s\S]+?\](--)?>|<style(\s+[^>]*?)?>[\s\S]*?<\/style>/ig, '');
		  string = string.replace(/<(?!(img|IMG|BR|br|Br|a|A))[\s\S]*?>/g," ");
		  if(fasong_key!='ctrl') {
		      string=string.replace(/\r\n/g,"")   
		      string=string.replace(/\n/g,"");  
		  }else {
		      string=string.replace(/\r\n/g,"<br/>")   
		      string=string.replace(/\n/g,"<br/>");  
		  } 
		  string = string.replace(/\\/g,''); 
		  string = string.replace(/"/g,'\'');
		  string = string.replace(/&nbsp;/g,' ');   
	  }catch(e) {   
	      
	  }   
	  return string;   
}
function cleanPaste(text) {
	text = text.replace(/<!--[\s\S]*?-->|<!(--)?\[[\s\S]+?\](--)?>|<style(\s+[^>]*?)?>[\s\S]*?<\/style>/ig, '');
	text = text.replace(/<\/?[^>]*>/g," ");
	return text;
}
function strLength(str) {
    ///<summary>获得字符串实际长度，中文2，英文1</summary>
    ///<param name="str">要获得长度的字符串</param>
    var realLength = 0, len = str.length, charCode = -1;
    for (var i = 0; i < len; i++) {
        charCode = str.charCodeAt(i);
        if (charCode >= 0 && charCode <= 128) realLength += 1;
        else realLength += 2;
    }
    return realLength;
};
function saysay_auto(content){
	if($(".list").length>0){
		content = content.replace(/"/g,"'")    
		talk_send_msg(content,ing_type,ing_user);
		moveEnd();//光标焦点
	}  
}

//发起新聊天
function title_new(name,user,type){
	$("#L_"+ing_type+"_"+ing_user).css("background-color","");
	$("#L_"+ing_type+"_"+ing_user).css("color","");
	
	$("#L_"+ing_type+"_"+ing_user).removeClass("new");
	//$("#L_"+ing_type+"_"+ing_user).html(ing_name);
	
	$("#L_"+ing_type+"_"+ing_user).attr("num","0");
  ing_user=user;//设置当前用户
  ing_name=name;//设置当前类型
  ing_type=type;//设置当前类型
  var id = type+'_'+user;
  //----------------顶部样式处理开始-----------------
//delete if($("#M_"+id).length<1){
//delete $("#mid_top").append('<div id="M_'+id+'" user="'+user+'" type="'+type+'" class="list"><table border="0" cellspacing="0" cellpadding="0"><tr><td id="zi_'+id+'" class="td_user td_user_click"><img id="I_'+id+'" src="'+getUserIcon(type,user)+'"/>'+name+'</td><td id="zino_'+id+'" class="td_hide td_hide_click">X</td></tr></table></div>');
//delete $("#zi_"+id).click(function(){title_new(name,user,type); });//给按钮加事件
//delete $("#zino_"+id).click(function(){delete_user(name,user,type);});//关闭打开的
//delete }else{
//delete $("#zi_"+id).removeClass("new");
//delete $("#zino_"+id).addClass("td_hide_click");//给自己加样式
//delete $("#zi_"+id).addClass("td_user_click");//给自己加样式
//delete }
//delete $("#M_"+id).siblings().children().children().children().children().removeClass("td_hide_click td_user_click");
	//----------------顶部样式处理结束-----------------
  //----------------内容框样式处理开始-----------------
	if($("#user_con_"+id).length<1){
		$(".my_show").append('<div class="user_con_div" id="user_con_'+id+'"></div>');
		if(type=="USER") {
			talk_get_user_msg(type,user);
		}
	}else {
		$("#user_con_"+id).show();
	}
	$("#user_con_"+id).siblings().hide();//隐藏其他兄弟
	$(".my_show").scrollTop($("#user_con_"+id).height()-$(".my_show").height());/*让滚动滚到最底端*/
	//----------------内容框样式处理结束-----------------
	//----------------左侧样式处理开始-----------------
	//如果是用户，需新建最近聊天
	if(type=="USER") {
		if($("#L_"+id).length<1){
			$(".ul_1").prepend('<li id="L_'+id+'" num="0" class="'+getUserIconClass(type,user)+'" title="'+user+'">'+name+'</li>');
			$('#L_'+id).click(function(){title_new(name,user,type);});//给按钮加事件
			hover_user('#L_'+id);
			user_geshu();
		}else {
			$("#L_"+id).attr("num","0");
		}
	}else {
		$("#L_"+id).attr("num","0");
	}
	$("#L_"+id).css("background-color","#ACC4DC");
	$("#L_"+id).css("color","#FFFFFF");
  //样式归位

	$("#L_"+id).removeClass("new");
//	$("#L_"+id).html(name);

	//----------------左侧样式处理结束-----------------
	//----------------右侧样式处理开始-----------------
	if($("#R_"+id).length<1){
		if(type=="GROUP"){
			$(".showInfo").append("<ul class='r_ul' id='R_"+id+"'></ul>");
			$("#R_"+id).siblings().hide();//隐藏其他兄弟
			talk_get_group_user(user);
		}else if(type=="USER"){
			$(".showInfo").append("<div id='R_"+id+"'></div>");
			$("#R_USER_"+user).siblings().hide();//隐藏其他兄弟
			talk_get_user_info(user);
		}
	}else {
		if(type=="GROUP"){
	 		$("#R_"+id).siblings().hide();//隐藏其他兄弟
	 		$("#R_"+id).show();
		}else if(type=="USER"){
			$("#R_USER_"+user).html("");
			$("#R_USER_"+user).siblings().hide();//隐藏其他兄弟
			talk_get_user_info(user);
		}
	}
	//----------------右侧样式处理结束-----------------
	moveEnd();//光标焦点
}

function changeFasong(){
	if(fasong_key=='ctrl') {
		fasong_key = 'enter';
		$(".fasong").html('Enter发送');
	}else {
		fasong_key = 'ctrl';
		$(".fasong").html('Ctrl+Enter发送');
	}
}

function qingkongsearch() {
	$("#search_result").html('');
	$("#keyword").val('');
}
function openRecord(){
	var left = (screen.width-850)/2;
	var top = (screen.height-610)/2;
	window.open("../ua_toPage?right.num=002005004","msgRecord","left=" +left+",top="+top+",height=610px,width=850px,location=0,menubar=0,resizable=0,scrollbars=0,status=0,toolbar=0")
}
function qiehuanBg(){
	$("body").css("background","none");
}
mfx=function(isWin){
	var t=0,z=3,del=function(){clearInterval(mfx.ID);return mfx};
	del().ID=setInterval(function(){
		var i=t/180*Math.PI,x=Math.sin(i)*z,y=Math.cos(i)*z,s=qq.style;
		isWin?window.moveBy(x,y):(s.top=x+'px',s.left=y+'px');
		if((t+=90)>1080)del();
	},30);
}
//顶部鼠标移入显示滚动条，移出隐藏
$("#top_msg").hover(function () {
	$("#top_msg").css("overflow-y","");
},function () {    
	$("#top_msg").css("overflow-y","hidden");
});
function topshow(content,username,fullname,time){
	//去除换行
	content=content.replace(/(<BR>|<br\/>|<br>|<BR\/>)/g," ");  
	$("#top_msg_content").append("<div class='top_msg_item' ><span>["+time+"] "+"<a href='javascript:' onclick='title_new(\""+fullname+"\",\""+username+"\",\"USER\");return false;'>"+fullname+"</a>：</span>"+content+"</div>");

	$("#top_msg").animate({'scrollTop':($("#top_msg_content").height()-$("#top_msg").height())+'px'},500);//让滚动滚到最底端
	if($("#top_msg_content .top_msg_item").length>50) {
		$("#top_msg_content .top_msg_item:lt(30)").remove();
	}
	//右下角显示公告
	//var pop=new Pop(fullname+"：","#",content);
}

function popupDiv(div_id,id,name) {
    var div_obj = $("#"+div_id);
    var windowWidth = document.documentElement.clientWidth;    
    var windowHeight = document.documentElement.clientHeight;    
    var popupHeight = div_obj.height();    
    var popupWidth = div_obj.width(); 
    //添加并显示遮罩层
    $("<div id='mask'></div>").addClass("mask")
                              .width(windowWidth * 0.99)
                              .height(windowHeight * 0.99)
                              .click(function() {hideDiv(div_id); })
                              .appendTo("body")
                              .fadeIn(200);
    div_obj.css({"position": "absolute"})
           .animate({left: windowWidth/2-popupWidth/2, 
                     top: windowHeight/2-popupHeight/2, opacity: "show" }, "slow");
    
    //更新成员
    div_obj.find("h4").html(name);
    div_obj.find("#groupId").val(id);
}

function hideDiv(div_id) {
    $("#mask").remove();
    $("#" + div_id).animate({left: 0, top: 0, opacity: "hide" }, "slow");
}