function navTabAjax(json){
	navTabAjaxDone(json);
	navTab.reload();
}
//刷新指定id区域
function loadDiv(rel,url) {
	if(rel){
		var $rel=$("#"+rel);
		$rel.loadUrl(url,{},function(){
			$rel.find("[layoutH]").layoutH();
		});
	}
}
//提交并关闭+刷新制定id区域
function dialogCloseLoadDiv(obj,rel,url) {
	validateCallback(obj, dialogAjaxDone);
	loadDiv(rel,url);
    return false;
}
//下载专用
function uploadFile_download(filename) {
	uploadFile_DownloadForm.action = "up_toUserUploadFile?uploadFile.path="+filename;
	uploadFile_DownloadForm.target = "uploadFile_Mess";
	uploadFile_DownloadForm.submit();
	uploadFile_DownloadForm.reset();
}
//调用Aps录音数据
function viewRecord(id) {
	var url="http://172.40.1.66/PerformExamWeb/CallRecord/PlayBx.jsp?callId="+id;
	window.open(url,'_blank','width=600,height=320,scrollbars=yes, status=no,resizable=no,top=80,left=170');
}
function viewRecord2(id) {
	var url="http://172.40.1.66/PerformExamWeb/CallRecord/PlayBx.jsp?recordId="+id;
	window.open(url,'_blank','width=600,height=320,scrollbars=yes, status=no,resizable=no,top=80,left=170');
}